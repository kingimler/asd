function drawSkinEyesOverlay(c, R, sk, fl) {
  if(sk&&sk.startsWith('kiz_'))return;
  c.save();
  const ex = R * 0.22;
  const ey = R * 0.22;
  const er = R * 0.1;
  c.fillStyle = '#fff';
  c.beginPath(); c.arc(ex, -ey, er, 0, Math.PI * 2); c.fill();
  c.beginPath(); c.arc(ex, ey, er, 0, Math.PI * 2); c.fill();
  c.fillStyle = '#000';
  c.beginPath(); c.arc(ex + er * 0.12, -ey + er * 0.05, er * 0.6, 0, Math.PI * 2); c.fill();
  c.beginPath(); c.arc(ex + er * 0.12, ey + er * 0.05, er * 0.6, 0, Math.PI * 2); c.fill();
  c.restore();
}

// ============================================================
// SETUP
// ============================================================

const canvas = document.getElementById('gameCanvas');
// alpha:false avoids a transparent clear (cheaper). desynchronized:true causes tearing/flicker on Windows Chrome.
let ctx = canvas.getContext('2d', { alpha: false });
function createRenderCanvas(width, height) {
  if (typeof OffscreenCanvas === 'function') {
    try { return new OffscreenCanvas(width, height); } catch (e) {}
  }
  const fallback = document.createElement('canvas');
  fallback.width = width;
  fallback.height = height;
  return fallback;
}
window._perf = window._perf || {
  frameMs:0, renderMs:0, tCamps:0, tTelegraph:0, tGround:0, tBuildings:0, tPlayers:0, tEnemies:0, tParticles:0,
  ocRebuild:0, eMobs:0, ePlayers:0, eParticles:0, eProjectiles:0, eTelegraphs:0, eBuildings:0, quality:0, shadowBlurActive:0
};

// Polyfill for ctx.roundRect (Chrome <99, Firefox <112, Safari <15.4)
if (!CanvasRenderingContext2D.prototype.roundRect) {
  CanvasRenderingContext2D.prototype.roundRect = function(x, y, w, h, r) {
    const rad = Array.isArray(r) ? r[0] : (typeof r === 'number' ? r : 0);
    this.moveTo(x + rad, y);
    this.arcTo(x + w, y,     x + w, y + h, rad);
    this.arcTo(x + w, y + h, x,     y + h, rad);
    this.arcTo(x,     y + h, x,     y,     rad);
    this.arcTo(x,     y,     x + w, y,     rad);
    this.closePath();
    return this;
  };
}

// Timestamp until which resize() should be a no-op.
// Set when build-upgrade panel opens so iOS visualViewport.resize events
// fired by the panel animation cannot wipe the canvas.
let _resizePauseUntil = 0;

let _lastCanvasW = 0, _lastCanvasH = 0;
function resize() {
  if (Date.now() < _resizePauseUntil) return;

  const vv = window.visualViewport;
  let w = Math.round(window.innerWidth  || (vv ? vv.width  : 0) || screen.width  || 800);
  let h = Math.round(window.innerHeight || (vv ? vv.height : 0) || screen.height || 600);
  if (!w || !h || w < 50 || h < 50) return;
  // Ignore 1–7px address-bar jitter: assigning canvas.width wipes the bitmap (full-screen flash).
  if (canvas.width > 0 && Math.abs(_lastCanvasW - w) < 8 && Math.abs(_lastCanvasH - h) < 8) return;

  if (_lastCanvasW !== w || _lastCanvasH !== h || canvas.width !== w || canvas.height !== h) {
    canvas.width  = w;
    canvas.height = h;
    _lastCanvasW = w;
    _lastCanvasH = h;
    canvas.style.width  = w + 'px';
    canvas.style.height = h + 'px';
    canvas.style.top    = '0px';
    canvas.style.left   = '0px';
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'low';
    ctx.fillStyle = '#5aaa38';
    ctx.fillRect(0, 0, w, h);
    window._resGrdDirty = true;
  }
}
window.addEventListener('resize', resize);
if (window.visualViewport) {
  window.visualViewport.addEventListener('resize', resize);
  // NOTE: Do NOT call resize() on visualViewport.scroll — that event fires when
  // the user scrolls the inventory div (overflow-x:auto) and calling resize()
  // mid-game resets the canvas context, making the game/player disappear.
  // Address-bar height changes are already handled by the 'resize' event above.
}
window.addEventListener('orientationchange', () => {
  // Multiple retries — orientation takes time to settle on all devices
  resize();
  setTimeout(resize, 50);
  setTimeout(resize, 150);
  setTimeout(resize, 300);
  setTimeout(resize, 600);
  setTimeout(resize, 1000);
});
// PWA / home-screen: fire resize on page show (covers back-navigation and lock/unlock)
window.addEventListener('pageshow', resize);
document.addEventListener('visibilitychange', () => { if (!document.hidden) resize(); });
resize(); // call immediately so canvas is sized before first paint
// Retry after iframe/browser has finished laying out
setTimeout(resize, 50);
setTimeout(resize, 200);
setTimeout(resize, 600);
setTimeout(resize, 1500);

// URL ve oyun başlangıç ayarları
const urlParams = new URLSearchParams(window.location.search);
const playerName = urlParams.get('name') || 'Savaşçı';
const _clanId = urlParams.get('clanId') || localStorage.getItem('fb_clan_id') || '';
const _BASE = window.location.pathname.replace(/\/play\.html$/, '/') || '/';
const _GAME_MODE = urlParams.get('mode') === 'offline' ? 'offline' : 'online';
const _isMobile = ('ontouchstart' in window || navigator.maxTouchPoints > 0) && window.innerWidth < 900;
const _lowPowerDevice = (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) ||
  (navigator.deviceMemory && navigator.deviceMemory <= 4) || /Android\s+[1-7]|iPhone|iPad/i.test(navigator.userAgent);
let ZOOM = _isMobile ? 0.50 : 0.62;
let camX = 0, camY = 0, _camReady = false;

const WORLD = 7200;
const BIOME_EDGE = 0.65;
const BIOME_BORDER = WORLD * BIOME_EDGE;
const LAND_RADIUS = WORLD * 0.94;
const PLAY_RADIUS = WORLD * 0.90;
const _BIOME_ALIASES = { snow: 'winter', swamp: 'lava', darkforest: 'lava' };
function normalizeBiome(biome) { return _BIOME_ALIASES[biome] || biome || 'forest'; }
function getBiome(x, y) {
  const nx = x / WORLD, ny = y / WORLD;
  if (Math.abs(nx) < BIOME_EDGE && Math.abs(ny) < BIOME_EDGE) return 'forest';
  if (Math.abs(ny) >= Math.abs(nx)) return ny < 0 ? 'winter' : 'lava';
  return nx > 0 ? 'desert' : 'lava';
}
const BIOME_LABELS = { forest: '🌿 Orman', winter: '❄️ Kış Diyarı', desert: '☀️ Çöl', lava: '🔥 Lav Vadisi' };
function _makeMulberry32(seed) {
  return function() {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function randomForestPoint() {
  const radius = BIOME_BORDER * 0.85;
  return { x: (Math.random() * 2 - 1) * radius, y: (Math.random() * 2 - 1) * radius };
}

let _qualityLevel = _lowPowerDevice ? 0 : 1;
let _qualityHoldUntil = 0;
const _FPS_BUF_SIZE = 90;
const _fpsBuf = new Float32Array(_FPS_BUF_SIZE);
let _fpsBufHead = 0, _fpsBufCount = 0;
const _fpsArr = [];
const _fpsSamples = _fpsBuf;
let _lastFrameTs = 0, _fpsCheckTimer = 0, _fpsDisplay = 0, _fpsDisplayTimer = 0;

// Static sprite cache. Images are loaded once and reused by the renderer.
const _SPRITE_CACHE = new Map();
const _MOB_SPRITES = new Map();
const _PLAYER_SPRITES = new Map();
const _RESOURCE_SPRITES = new Map();
const _WEAPON_SPRITES = new Map();
function _loadSprite(name, category, priority = 'normal') {
  if (_SPRITE_CACHE.has(name)) return _SPRITE_CACHE.get(name);
  const image = new Image();
  const entry = { image, ready: false, failed: false, priority };
  image.onload = () => {
    entry.ready = true; entry.failed = false;
    if (typeof window.renderInventoryIcons === 'function') window.renderInventoryIcons(true);
  };
  image.onerror = () => { entry.failed = true; entry.ready = false; };
  // PERF: Use loading="lazy" for non-critical sprites to reduce initial load
  if (priority === 'low') {
    image.loading = 'lazy';
  }
  image.src = _BASE + name;
  _SPRITE_CACHE.set(name, entry);
  if (category === 'mob') _MOB_SPRITES.set(name, entry);
  if (category === 'player') _PLAYER_SPRITES.set(name, entry);
  if (category === 'resource') _RESOURCE_SPRITES.set(name, entry);
  if (category === 'weapon') _WEAPON_SPRITES.set(name, entry);
  return entry;
}
function _preloadStaticSprites() {
  // PERF: Load critical resources first with normal priority
  const criticalResources = [
    'asset/tree-forest.png', 'asset/rock-forest.png',
    'asset/gold.png', 'asset/apple.png'
  ];
  for (const name of criticalResources) _loadSprite(name, 'resource', 'normal');
  
  // PERF: Load biome-specific resources with low priority (lazy)
  const biomeResources = [
    'resourceasset/desertwood.png', 'resourceasset/desertstone.png',
    'resourceasset/winterwood.png', 'resourceasset/winterstone.png',
    'asset/tree-snow.png', 'asset/tree-desert.png', 'asset/tree-darkforest.png',
    'asset/rock-snow.png', 'asset/rock-desert.png', 'asset/rock-darkforest.png', 'asset/rock.png',
    'asset/bush.png', 'asset/mushroom.png', 'asset/crystal.png', 'asset/hive.png'
  ];
  for (const name of biomeResources) _loadSprite(name, 'resource', 'low');
  
  // PERF: Load weapons with normal priority (used frequently)
  for (const kind of ['axe', 'sword']) {
    for (let tier = 0; tier <= 6; tier++) _loadSprite(`weapons/${kind}-tier-${tier}.png`, 'weapon', 'normal');
  }
  // PERF: Load mob sprites with low priority (not always visible)
}
function _mobSprite(shape, radius) {
  const exactKey = `mobs/${shape}-${radius}.png`;
  let exact = _MOB_SPRITES.get(exactKey);
  if (!exact || exact.failed) return null;
  if (exact.ready) return exact.image;
  let nearest = null, distance = Infinity;
  for (const [name, entry] of _MOB_SPRITES) {
    const match = name.match(/^mobs\/(.+)-(\d+)\.png$/);
    if (!match || match[1] !== shape || !entry.ready) continue;
    const candidateDistance = Math.abs(Number(match[2]) - radius);
    if (candidateDistance < distance) { nearest = entry.image; distance = candidateDistance; }
  }
  return nearest;
}
function _playerSprite(skin) {
  if (!skin) skin = 'default';
  const key = `players/${skin}.png`;
  let entry = _PLAYER_SPRITES.get(key);
  if (!entry) {
    entry = _loadSprite(key, 'player', 'normal');
  }
  return entry && entry.ready ? entry.image : null;
}
function _resourceSprite(type, biome) {
  const normBiome = (biome === 'snow' || biome === 'winter') ? 'winter' : (biome === 'desert' ? 'desert' : (biome === 'lava' || biome === 'darkforest' ? 'lava' : 'forest'));
  let name;
  if (type === 'wood') {
    if (normBiome === 'winter') name = 'resourceasset/winterwood.png';
    else if (normBiome === 'desert') name = 'resourceasset/desertwood.png';
    else if (normBiome === 'lava') name = 'asset/tree-darkforest.png';
    else name = 'asset/tree-forest.png';
  } else if (type === 'stone') {
    if (normBiome === 'winter') name = 'resourceasset/winterstone.png';
    else if (normBiome === 'desert') name = 'resourceasset/desertstone.png';
    else if (normBiome === 'lava') name = 'asset/rock-darkforest.png';
    else name = 'asset/rock-forest.png';
  } else if (type === 'apple') {
    name = 'asset/apple.png';
  } else if (type === 'gold') {
    name = 'asset/gold.png';
  } else {
    name = `asset/${type}.png`;
  }
  let entry = _RESOURCE_SPRITES.get(name);
  if (!entry) entry = _loadSprite(name, 'resource');
  if (entry && entry.ready) return entry.image;
  if (type === 'stone') {
    const fallback = _RESOURCE_SPRITES.get('asset/rock-forest.png') || _RESOURCE_SPRITES.get('asset/rock.png');
    if (fallback && fallback.ready) return fallback.image;
  }
  if (type === 'wood') {
    const fallback = _RESOURCE_SPRITES.get('asset/tree-forest.png');
    if (fallback && fallback.ready) return fallback.image;
  }
  return null;
}
function _weaponSprite(kind, tier) {
  if (tier > 6) return null;
  const key = `weapons/${kind}-tier-${tier}.png`;
  const entry = _WEAPON_SPRITES.get(key);
  return entry && entry.ready ? entry.image : null;
}
function _drawCenteredSprite(context, image, width, height = width) {
  context.drawImage(image, -width / 2, -height / 2, width, height);
}
function _drawWeaponSprite(context, image, kind) {
  const pivotX = kind === 'axe' ? 32 : 32;
  const pivotY = 130;
  context.drawImage(image, -pivotX, -pivotY);
}
_preloadStaticSprites();

// ── NEW PREMIUM BUILDING ASSET SYSTEM (Preloaded & Optimized) ──
const _BUILD_SPRITES = new Map();
const _BUILD_SPRITE_FILES = {
  spike: 'buildassets/spikes_premium.png',
  windmill_base: 'buildassets/windmill_base.png',
  windmill_blades: 'buildassets/windmill_blades.png',
  boostpad: 'buildassets/boostpad_premium.png',
  beartrap: 'buildassets/beartrap_premium.png',
  turret: 'buildassets/turrets_premium.png',
  door: 'buildassets/doors_premium.png',
  healpad: 'buildassets/healpad_premium.png'
};

function _preloadBuildSprites() {
  for (const [k, src] of Object.entries(_BUILD_SPRITE_FILES)) {
    const img = new Image();
    img.src = src;
    _BUILD_SPRITES.set(k, { image: img, ready: false });
    img.onload = () => {
      const entry = _BUILD_SPRITES.get(k);
      if (entry) entry.ready = true;
      if (typeof renderInventoryIcons === 'function') renderInventoryIcons(true);
    };
  }
}
_preloadBuildSprites();

function _getBuildSprite(k) {
  const e = _BUILD_SPRITES.get(k);
  return (e && (e.ready || (e.image && e.image.complete && e.image.naturalWidth > 0))) ? e.image : (e ? e.image : null);
}

// ── Global Multiplayer & Combat State (Declared early to prevent TDZ) ────────
var _nowMs              = 0;     // Date.now() cached per frame — avoid N calls per frame
var _shadowOk           = true;  // quality >= 1 — gate medium-cost shadow effects
var _glowOk             = true;  // quality >= 2 — gate expensive bloom/glow effects
var _trapCaughtBy       = null, _trapCaughtX = undefined, _trapCaughtY = undefined;
var _trapPendingId      = null, _trapPendingUntil = 0;
var _myTrapVictims      = new Map();
var _spikeEnemyCooldowns= new Map();
var _pvpPredictTime     = new Map();
var _eLidCounter        = 0;
var _buildDmgTimer      = 0;
var _userZoomMultiplier = 1.0;
var _attackPending      = false;
var _attackQueued       = false;

// Clean, authentic .io-style weapon swing slash curve (kavis cizgisi - zero jitter, monotonic sweep)
function _drawWeaponSlashArc(context, prog, weaponType) {
  if (!prog || prog <= 0.04 || prog >= 0.90) return;
  const alpha = Math.sin(prog * Math.PI) * 0.55;
  if (alpha <= 0.01) return;
  context.save();
  const isSword = weaponType === 2;
  const radius = isSword ? 94 : 80;
  // Monotonic forward sweep with swing progression — perfectly stable, zero backward vibration
  const sweep = prog * (isSword ? 1.45 : 1.25);
  const startAng = -0.42 + sweep * 0.28;
  const endAng = -0.42 + sweep;
  
  // Outer blade slash sweep (clean, crisp, semi-transparent white/silver, NO blue lines)
  context.lineCap = 'round';
  context.lineWidth = isSword ? 3.5 : 4.5;
  context.strokeStyle = isSword ? `rgba(245, 248, 255, ${alpha})` : `rgba(255, 248, 215, ${alpha * 0.92})`;
  context.beginPath();
  context.arc(8, 0, radius, startAng, endAng);
  context.stroke();

  // Subtle softer inner glow/trail
  if (_qualityLevel >= 1) {
    context.lineWidth = isSword ? 6.5 : 8;
    context.strokeStyle = isSword ? `rgba(255, 255, 255, ${alpha * 0.22})` : `rgba(255, 235, 180, ${alpha * 0.2})`;
    context.beginPath();
    context.arc(8, 0, radius - 2, startAng + 0.06, endAng);
    context.stroke();
  }
  context.restore();
}

// ── SPATIAL PARTITIONING (GRID SYSTEM) ─────────────────────────────────────
// PERF: Divides map into 250x250 cells to reduce CPU/GPU load by only processing visible objects
const GRID_SIZE = 250;
const _foodGrid = {};
let _resourceGrid = {};

function _getGridKey(x, y) {
  const col = Math.floor(x / GRID_SIZE);
  const row = Math.floor(y / GRID_SIZE);
  return `${col}_${row}`;
}

function _addFoodToGrid(food) {
  const key = _getGridKey(food.x, food.y);
  if (!_foodGrid[key]) _foodGrid[key] = [];
  _foodGrid[key].push(food);
  food._gridKey = key;
}

function _removeFoodFromGrid(food) {
  if (food._gridKey && _foodGrid[food._gridKey]) {
    const idx = _foodGrid[food._gridKey].indexOf(food);
    if (idx !== -1) {
      _foodGrid[food._gridKey].splice(idx, 1);
      if (_foodGrid[food._gridKey].length === 0) delete _foodGrid[food._gridKey];
    }
  }
}

function _addResourceToGrid(res) {
  const key = _getGridKey(res.x, res.y);
  if (!_resourceGrid[key]) _resourceGrid[key] = [];
  _resourceGrid[key].push(res);
  res._gridKey = key;
}

function _removeResourceFromGrid(res) {
  if (res._gridKey && _resourceGrid[res._gridKey]) {
    const idx = _resourceGrid[res._gridKey].indexOf(res);
    if (idx !== -1) {
      _resourceGrid[res._gridKey].splice(idx, 1);
      if (_resourceGrid[res._gridKey].length === 0) delete _resourceGrid[res._gridKey];
    }
  }
}

// Mouse Wheel Zoom Listener (Controlled zoom, clamped to never expose off-map void)
window.addEventListener('wheel', (e) => {
  if (document.activeElement && (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA')) return;
  const delta = e.deltaY < 0 ? 0.04 : -0.04;
  _userZoomMultiplier = Math.max(0.88, Math.min(1.22, _userZoomMultiplier + delta));
}, { passive: true });

function _trackQuestProgress(key, amount = 1) {
  const normalizedKey = key === 'builds' ? 'buildings' : key === 'chests' ? 'airdrops' : key;
  if (!normalizedKey || !Number.isFinite(Number(amount))) return;
  try {
    const progress = JSON.parse(localStorage.getItem('fb_quest_prog') || '{}');
    const delta = Math.max(0, Number(amount));
    progress[normalizedKey] = Math.max(0, Number(progress[normalizedKey] || 0) + delta);
    localStorage.setItem('fb_quest_prog', JSON.stringify(progress));
    _questPending[normalizedKey] = (_questPending[normalizedKey] || 0) + delta;
    _scheduleQuestSync();
  } catch (error) {}
}
const _questPending = {};
const _questPersisted = {};
let _questSyncTimer = null;
function _accountStatePayload() {
  const settings = {};
  ['fb_auto_eat', 'fb_build_snap', 'fb_shake', 'fb_mobile_controls', 'fb_sfx_muted', 'fb_shadows', 'fb_fps', 'fb_minimap', 'fb_grid_show'].forEach(key => {
    const value = localStorage.getItem(key);
    if (value !== null) settings[key] = value === 'true' ? true : value === 'false' ? false : value;
  });
  return { questProgress: { ..._questPending }, settings };
}
function _scheduleQuestSync() {
  if (!localStorage.getItem('fb_auth_token') || _questSyncTimer) return;
  _questSyncTimer = setTimeout(() => { _questSyncTimer = null; _syncGameAccountState(); }, 900);
}
function _syncGameAccountState(keepalive = false) {
  const token = localStorage.getItem('fb_auth_token') || '';
  const pending = { ..._questPending };
  if (!token || (!Object.keys(pending).length && !keepalive)) return Promise.resolve(null);
  Object.entries(pending).forEach(([key, value]) => {
    _questPending[key] = Math.max(0, (_questPending[key] || 0) - value);
    _questPersisted[key] = (_questPersisted[key] || 0) + value;
  });
  return fetch('/api/profile/state', {
    method: 'POST',
    keepalive,
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
    body: JSON.stringify({ ..._accountStatePayload(), questProgress: pending })
  }).then(response => response.ok ? response.json() : null).then(data => {
    if (!data?.user) {
      Object.entries(pending).forEach(([key, value]) => {
        _questPending[key] = (_questPending[key] || 0) + value;
        _questPersisted[key] = Math.max(0, (_questPersisted[key] || 0) - value);
      });
      return data;
    }
    localStorage.setItem('fb_auth_user', JSON.stringify(data.user));
    return data;
  }).catch(() => null);
}
function _saveGameSetting(key, value) {
  localStorage.setItem(key, value ? 'true' : 'false');
  const token = localStorage.getItem('fb_auth_token') || '';
  if (!token) return;
  fetch('/api/profile/state', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
    body: JSON.stringify({ settings: { [key]: !!value } })
  }).catch(() => {});
}
window.addEventListener('pagehide', () => { _syncGameAccountState(true); });
window._updateQuestProgress = _trackQuestProgress;
window._showAchPopup = function(){};

// ── Minimap offscreen BG cache (biome zones drawn once, never re-drawn) ────
const _mmBgCanvas = document.createElement('canvas');
_mmBgCanvas.width = 128; _mmBgCanvas.height = 128;
let _mmBgReady = false;
let _mmFrameCnt = 0; // throttle dynamic minimap dots

// ── Minimap dot layer: separate OC so dots persist between throttle frames ──
// Fixes the flash where dots disappeared 2/3 frames due to clearRect+no-redraw
const _mmDotCanvas = document.createElement('canvas');
_mmDotCanvas.width = 128; _mmDotCanvas.height = 128;
const _mmDotCtx    = _mmDotCanvas.getContext('2d');
const _mmBaseCanvas = document.createElement('canvas');
_mmBaseCanvas.width = 128; _mmBaseCanvas.height = 128;
const _mmBaseCtx = _mmBaseCanvas.getContext('2d');
let _mmBaseReady = false;

// ── Static world layer OC: grid + biome borders + zone labels + walls ────────
// Rebuilt only when camera moves beyond overdraw padding or zoom/quality changes.
// All other frames: one drawImage blit instead of 100+ canvas draw calls.
// _gridPad: extra pixels on each side of the OC — avoids edge gaps on camera pan.
const _gridPad = 320;
let _gridOC = null, _gridOCCtx = null;
let _gridCacheCamX = -999999, _gridCacheCamY = -999999;
let _gridCacheZoom = -1, _gridCacheQuality = -1, _gridCacheTint = '';
let _gridPattern = null, _gridPatternZoom = -1;

// Background offscreen canvas — drawn ONCE at init, blitted every frame.
// Eliminates ~14 createRadialGradient / createLinearGradient calls per frame.
const _bgCanvas = document.createElement('canvas');
const _bgCtx    = _bgCanvas.getContext('2d');
let   _bgReady  = false;
let   _bgBuildScheduled = false;
let _respawnGrace = 0; // frames to skip heavy rendering after respawn/join

function _buildBgCacheUnsafe() {
  const W = WORLD;
  const B = BIOME_BORDER;
  const L = LAND_RADIUS;
  const S = _isMobile ? 1536 : 2048; // Baked map texture; 3072x3072 blit every frame tanks GPU bandwidth
  _bgCanvas.width = S;
  _bgCanvas.height = S;
  const sc = S / (W * 2);
  const c = _bgCtx;
  c.save();
  c.scale(sc, sc);
  c.translate(W, W);

  // === OCEAN — deep blue with depth gradient ===
  const oceanGrd = c.createRadialGradient(0, 0, 0, 0, 0, W * 1.4);
  oceanGrd.addColorStop(0,   '#2e6fa8');
  oceanGrd.addColorStop(0.6, '#1e5488');
  oceanGrd.addColorStop(1,   '#102a50');
  c.fillStyle = oceanGrd;
  c.fillRect(-W, -W, W * 2, W * 2);
  // Ocean shimmer lines
  c.save();
  c.globalAlpha = 0.06;
  c.strokeStyle = '#88ccff';
  c.lineWidth = W * 0.003;
  for (let wi = 0; wi < 14; wi++) {
    const wy = -W + wi * (W * 2 / 14);
    c.beginPath(); c.moveTo(-W, wy); c.bezierCurveTo(-W*0.5, wy+W*0.02, W*0.5, wy-W*0.02, W, wy+W*0.01); c.stroke();
  }
  c.restore();

  // === LAND MASS — Deep rich Taming.io olive forest base ===
  c.fillStyle = '#4d6828';
  c.fillRect(-L, -L, L * 2, L * 2);

  // === FOREST CENTER — Massive lush olive continent ===
  c.fillStyle = '#4d6828';
  c.fillRect(-B, -B, B * 2, B * 2);
  // Natural moss & grass tone variations sampled from reference
  for (const [gpx, gpy, gpc, gr] of [
    [-B*.45, -B*.25, '#5c7832', B*.60],
    [ B*.20,  B*.30, '#435c22', B*.55],
    [-B*.15,  B*.35, '#55722e', B*.50],
    [ B*.38, -B*.18, '#486226', B*.52],
    [-B*.30,  B*.10, '#3e561e', B*.45],
    [ B*.05, -B*.40, '#526e2a', B*.48],
  ]) {
    const g = c.createRadialGradient(gpx, gpy, 0, gpx, gpy, gr);
    g.addColorStop(0, gpc + '99');
    g.addColorStop(1, gpc + '00');
    c.fillStyle = g;
    c.fillRect(-B, -B, B * 2, B * 2);
  }
  // Forest floor darkening at edges
  const fEdge = c.createRadialGradient(0, 0, B * 0.7, 0, 0, B * 1.02);
  fEdge.addColorStop(0, 'rgba(0,0,0,0)');
  fEdge.addColorStop(1, 'rgba(0,20,0,0.25)');
  c.fillStyle = fEdge;
  c.fillRect(-B, -B, B * 2, B * 2);

  // === WEST — lava ===
  c.fillStyle = '#220f15';
  c.fillRect(-L, -L, L - B, L * 2);
  for (const [gpx, gpy, gpc, gr] of [
    [-L*.65,  L*.10, '#3e1820', L*.55],
    [-L*.40, -L*.25, '#2c1218', L*.45],
    [-L*.55,  L*.35, '#1a0b10', L*.50],
    [-L*.30,  L*.50, '#36151c', L*.40],
  ]) {
    const g = c.createRadialGradient(gpx, gpy, 0, gpx, gpy, gr);
    g.addColorStop(0, gpc + 'aa');
    g.addColorStop(1, gpc + '00');
    c.fillStyle = g;
    c.fillRect(-L, -L, L - B, L * 2);
  }
  const wGrd = c.createLinearGradient(-L, 0, -B, 0);
  wGrd.addColorStop(0, 'rgba(12,4,7,0.88)');
  wGrd.addColorStop(0.55, 'rgba(40,12,16,0.45)');
  wGrd.addColorStop(1, 'rgba(65,18,22,0)');
  c.fillStyle = wGrd;
  c.fillRect(-L, -L, L - B, L * 2);
  c.save();
  c.globalAlpha = 0.10;
  c.fillStyle = '#ff6a1a';
  for (const [mx, my, mr] of [[-L*.5, 0, L*.18], [-L*.7, -L*.3, L*.12], [-L*.4, L*.4, L*.15]]) {
    const mg = c.createRadialGradient(mx, my, 0, mx, my, mr);
    mg.addColorStop(0, 'rgba(255,100,25,0.7)'); mg.addColorStop(1, 'rgba(255,100,25,0)');
    c.fillStyle = mg; c.fillRect(-L, -L, L - B, L * 2);
  }
  c.restore();

  // === EAST — desert ===
  c.fillStyle = '#ba9234';
  c.fillRect(B, -L, L - B, L * 2);
  // Sand dune color blobs
  for (const [gpx, gpy, gpc, gr] of [
    [L*.55,  L*.15, '#cba442', L*.55],
    [L*.40, -L*.30, '#aa842c', L*.50],
    [L*.65, -L*.10, '#d2ab48', L*.45],
    [L*.45,  L*.45, '#b28b30', L*.48],
  ]) {
    const g = c.createRadialGradient(gpx, gpy, 0, gpx, gpy, gr);
    g.addColorStop(0, gpc + 'aa');
    g.addColorStop(1, gpc + '00');
    c.fillStyle = g;
    c.fillRect(B, -L, L - B, L * 2);
  }
  const dGrd = c.createLinearGradient(B, 0, L, 0);
  dGrd.addColorStop(0, 'rgba(165,125,25,0)');
  dGrd.addColorStop(1, 'rgba(140,95,15,0.75)');
  c.fillStyle = dGrd;
  c.fillRect(B, -L, L - B, L * 2);
  // Sand ripple lines
  c.save();
  c.globalAlpha = 0.08;
  c.strokeStyle = '#6e4c0c';
  c.lineWidth = L * 0.006;
  for (let ri = 0; ri < 12; ri++) {
    const ry = -L + ri * (L * 2 / 12);
    c.beginPath();
    c.moveTo(B, ry);
    c.bezierCurveTo((B+L)*.38, ry + L*.04, (B+L)*.62, ry - L*.03, L, ry + L*.015);
    c.stroke();
  }
  c.restore();

  // === SOUTH — lava ===
  c.fillStyle = '#2c141a';
  c.fillRect(-L, B, L * 2, L - B);
  for (const [gpx, gpy, gpc, gr] of [
    [-L*.20, L*.55, '#481c24', L*.55],
    [ L*.30, L*.70, '#1e0c12', L*.50],
    [-L*.50, L*.40, '#522028', L*.48],
    [ L*.10, L*.45, '#34141c', L*.45],
  ]) {
    const g = c.createRadialGradient(gpx, gpy, 0, gpx, gpy, gr);
    g.addColorStop(0, gpc + 'bb');
    g.addColorStop(1, gpc + '00');
    c.fillStyle = g;
    c.fillRect(-L, B, L * 2, L - B);
  }
  const sGrd = c.createLinearGradient(0, B, 0, L);
  sGrd.addColorStop(0, 'rgba(55,16,22,0)');
  sGrd.addColorStop(1, 'rgba(20,5,8,0.92)');
  c.fillStyle = sGrd;
  c.fillRect(-L, B, L * 2, L - B);
  c.save();
  c.globalAlpha = 0.14;
  for (const [px, py, pr] of [[-L*.25, L*.6, L*.07], [L*.15, L*.75, L*.06], [-L*.55, L*.8, L*.05]]) {
    c.fillStyle = '#ff7b30';
    c.beginPath(); c.ellipse(px, py, pr, pr * 0.5, 0.3, 0, Math.PI * 2); c.fill();
  }
  c.restore();

  // === NORTH — winter ===
  c.fillStyle = '#4e7088';
  c.fillRect(-L, -L, L * 2, L - B);
  for (const [gpx, gpy, gpc, gr] of [
    [ L*.10, -L*.55, '#60849e', L*.60],
    [-L*.30, -L*.40, '#44647a', L*.50],
    [ L*.40, -L*.70, '#6d92ac', L*.48],
    [-L*.15, -L*.75, '#52758e', L*.52],
  ]) {
    const g = c.createRadialGradient(gpx, gpy, 0, gpx, gpy, gr);
    g.addColorStop(0, gpc + 'cc');
    g.addColorStop(1, gpc + '00');
    c.fillStyle = g;
    c.fillRect(-L, -L, L * 2, L - B);
  }
  const nGrd = c.createLinearGradient(0, -L, 0, -B);
  nGrd.addColorStop(0, 'rgba(80,115,140,0.90)');
  nGrd.addColorStop(1, 'rgba(95,130,155,0)');
  c.fillStyle = nGrd;
  c.fillRect(-L, -L, L * 2, L - B);

  // Snow sparkle dots
  c.save();
  c.globalAlpha = 0.20;
  c.fillStyle = '#ffffff';
  for (let si = 0; si < 60; si++) {
    const sx = -L + ((Math.abs(Math.sin(si * 7.13 + 1.1) * 43758.5453) % 1)) * L * 2;
    const sy = -L + ((Math.abs(Math.sin(si * 3.79 + 2.2) * 43758.5453) % 1)) * (L - B);
    const sr = 2 + (Math.abs(Math.sin(si * 5.44 + 3.3) * 43758.5453) % 1) * 5;
    c.beginPath(); c.arc(sx, sy, sr, 0, Math.PI * 2); c.fill();
  }
  c.restore();

  c.restore();
  _bgReady = true;
}

function _buildBgCache() {
  if (_bgReady) return;
  try {
    _buildBgCacheUnsafe();
  } catch (error) {
    console.error('[background] cache build failed:', error);
    _bgCtx.setTransform(1, 0, 0, 1, 0, 0);
    _bgCanvas.width = 2;
    _bgCanvas.height = 2;
    _bgCtx.fillStyle = '#274b2a';
    _bgCtx.fillRect(0, 0, 2, 2);
    _bgReady = true;
  }
}
// ─────────────────────────────────────────────────────────────────────────────

// ============================================================
// SİLAH TİER SİSTEMİ
// ============================================================
let _axeXP = 0, _swordXP = 0;
const WEAPON_TIERS = [
  { xp:0,     name:'Tahta',   color:'#c8a060', bar:'#a0784a' },
  { xp:150,   name:'Taş',     color:'#9ca3af', bar:'#9ca3af' },
  { xp:500,   name:'Altın',   color:'#FFD700', bar:'#FFD700' },
  { xp:1500,  name:'Elmas',   color:'#7DF9FF', bar:'#00BBFF' },
  { xp:4500,  name:'Ametist', color:'#CC66FF', bar:'#AA44DD' },
  { xp:12000, name:'Reidite', color:'#FF2244', bar:'#CC0022' },
  { xp:30000, name:'Nihai',   color:'#FFD700', bar:'#FF8800' },
];
function _wepTier(xp){ let t=0; for(let i=1;i<WEAPON_TIERS.length;i++){ if(xp>=WEAPON_TIERS[i].xp)t=i; else break; } return t; }
function _wepProg(xp){ const t=_wepTier(xp); if(t>=WEAPON_TIERS.length-1)return 1; return (xp-WEAPON_TIERS[t].xp)/(WEAPON_TIERS[t+1].xp-WEAPON_TIERS[t].xp); }
function addAxeXP(n){
  const ot=_wepTier(_axeXP); _axeXP+=n; const nt=_wepTier(_axeXP);
  if(nt>ot){ const td=WEAPON_TIERS[nt]; floatingTexts.push({x:player.x,y:player.y-90,text:'🪓 BALTA '+td.name.toUpperCase()+'!',alpha:1,life:90,color:td.color}); playSound(880,0.28,'triangle',0.3); }
  updateWeaponUI();
}
function addSwordXP(n){
  const ot=_wepTier(_swordXP); _swordXP+=n; const nt=_wepTier(_swordXP);
  if(nt>ot){ const td=WEAPON_TIERS[nt]; floatingTexts.push({x:player.x,y:player.y-90,text:'⚔️ KILIÇ '+td.name.toUpperCase()+'!',alpha:1,life:90,color:td.color}); playSound(1100,0.28,'triangle',0.3); }
  updateWeaponUI();
}
let _wepUiEls = null;
function updateWeaponUI(){
  if (!_wepUiEls) {
    _wepUiEls = {
      af: document.getElementById('axe-xp-fill'), al: document.getElementById('axe-tier-lbl'),
      sf: document.getElementById('sword-xp-fill'), sl: document.getElementById('sword-tier-lbl'),
      s1: document.getElementById('slot-1'), s2: document.getElementById('slot-2')
    };
  }
  const at=_wepTier(_axeXP), st=_wepTier(_swordXP);
  const { af, al, sf, sl, s1, s2 } = _wepUiEls;
  if(af){ af.style.width=(_wepProg(_axeXP)*100)+'%'; af.style.background=WEAPON_TIERS[at].bar; }
  if(al){ al.textContent=WEAPON_TIERS[at].name; al.style.color=WEAPON_TIERS[at].color; }
  if(sf){ sf.style.width=(_wepProg(_swordXP)*100)+'%'; sf.style.background=WEAPON_TIERS[st].bar; }
  if(sl){ sl.textContent=WEAPON_TIERS[st].name; sl.style.color=WEAPON_TIERS[st].color; }
  if(s1){ s1.style.setProperty('--ax-col',WEAPON_TIERS[at].color); }
  if(s2){ s2.style.setProperty('--sw-col',WEAPON_TIERS[st].color); s2.style.setProperty('--sw-grd',st>=2?WEAPON_TIERS[st].color:'#fbbf24'); }
  if(typeof window.renderInventoryIcons === 'function') window.renderInventoryIcons();
}

// PERF: Gradient cache for static weapon tiers (0-5). Tiers 6-7 (rainbow/galaksi)
// animate each frame so they bypass the cache. One-time allocation per tier.
const _axeHndGrd=[], _axeBladeGrd=[], _swdGripGrd=[], _swdBladeGrd=[];
// Tier-6 rainbow weapon gradient cache — 60 pre-built steps (6° each, lazy-filled on first use)
const _ax6Ph=new Array(60).fill(null), _ax6Rn=new Array(60).fill(null);
const _sw6Ph=new Array(60).fill(null), _sw6Rg=new Array(60).fill(null), _sw6Rb=new Array(60).fill(null);
// Level badge offscreen cache — only redrawn when level changes
let _lvlBadgeOC=null, _lvlBadgeLevel=-1;
// Dash cooldown offscreen cache — only redrawn when cd state or canvas size changes
let _dashCdOC=null, _dashCdState='', _dashCdW=0, _dashCdH=0;
// Sun offscreen cache (drawNightOverlay) — drawn once, blitted every frame
let _sunOC=null;

// Balta çizim fonksiyonu — 7 tier
function drawAxeByTier(c, tier, t){
  const T=WEAPON_TIERS[tier]||WEAPON_TIERS[0];
  if(tier>=2&&_qualityLevel>=2){ c.shadowColor=T.color; c.shadowBlur=10+tier*5; }
  const _staticTier = tier <= 5;
  // Shared handle helper — caches gradient for static tiers
  const handle=(col1,col2,bnd)=>{
    let hg=_staticTier ? _axeHndGrd[tier] : null;
    if(!hg){ hg=c.createLinearGradient(26,-75,38,-75);hg.addColorStop(0,col1);hg.addColorStop(0.5,col2);hg.addColorStop(1,col1); if(_staticTier)_axeHndGrd[tier]=hg; }
    c.fillStyle=hg;c.strokeStyle='#1a0f06';c.lineWidth=4;c.beginPath();c.roundRect(26,-76,12,112,3);c.fill();c.stroke();
    // grip wrap bands
    c.strokeStyle=bnd;c.lineWidth=3;c.lineCap='round';
    for(let i=0;i<5;i++){c.beginPath();c.moveTo(25,-62+i*18);c.lineTo(39,-62+i*18);c.stroke();}
    // pommel
    c.fillStyle=bnd;c.strokeStyle='#1a0f06';c.lineWidth=2;
    c.beginPath();c.ellipse(32,37,9,6,0,0,Math.PI*2);c.fill();c.stroke();
  };
  switch(tier){
    case 0:default:{
      handle('#6b4422','#9b6a38','#4a2a10');
      // crude iron blade — cached gradient
      if(!_axeBladeGrd[0]){const g=c.createLinearGradient(38,-72,88,-46);g.addColorStop(0,'#6b7280');g.addColorStop(0.45,'#d1d5db');g.addColorStop(0.7,'#9ca3af');g.addColorStop(1,'#4b5563');_axeBladeGrd[0]=g;}
      const bg=_axeBladeGrd[0];
      c.fillStyle=bg;c.strokeStyle='#374151';c.lineWidth=4;
      c.beginPath();c.moveTo(38,-68);c.lineTo(72,-80);c.quadraticCurveTo(92,-55,80,-26);c.lineTo(60,-18);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      // beveled edge
      c.strokeStyle='rgba(240,245,255,.75)';c.lineWidth=2;c.beginPath();c.moveTo(68,-74);c.quadraticCurveTo(88,-54,74,-24);c.stroke();
      // nick/chip marks
      c.strokeStyle='rgba(0,0,0,.3)';c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(78,-58);c.lineTo(72,-52);c.stroke();
      c.beginPath();c.moveTo(72,-38);c.lineTo(67,-34);c.stroke();
      break;}
    case 1:{
      handle('#2e1e0e','#5c3a1e','#888');
      // stone blade — cached
      if(!_axeBladeGrd[1]){const g=c.createLinearGradient(38,-72,92,-44);g.addColorStop(0,'#4a5058');g.addColorStop(0.4,'#8a9098');g.addColorStop(0.75,'#6a7078');g.addColorStop(1,'#3a4048');_axeBladeGrd[1]=g;}
      const sg=_axeBladeGrd[1];
      c.fillStyle=sg;c.strokeStyle='#303840';c.lineWidth=4;
      c.beginPath();c.moveTo(38,-68);c.lineTo(75,-82);c.quadraticCurveTo(95,-54,78,-22);c.lineTo(56,-16);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      // stone chips/cracks
      c.strokeStyle='rgba(200,210,220,.45)';c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(70,-76);c.quadraticCurveTo(85,-55,72,-26);c.stroke();
      c.strokeStyle='rgba(0,0,0,.3)';c.lineWidth=1.5;
      c.beginPath();c.moveTo(74,-65);c.lineTo(66,-55);c.stroke();
      c.beginPath();c.moveTo(80,-48);c.lineTo(73,-40);c.stroke();
      c.beginPath();c.moveTo(76,-34);c.lineTo(69,-28);c.stroke();
      // stone texture dots
      c.fillStyle='rgba(0,0,0,.12)';
      for(const[px,py]of[[60,-60],[68,-48],[62,-36],[76,-54],[70,-42]]){c.beginPath();c.arc(px,py,2.5,0,Math.PI*2);c.fill();}
      break;}
    case 2:{
      handle('#4a2800','#7a4818','#FFD700');
      // ornate gold blade — cached
      if(!_axeBladeGrd[2]){const g=c.createLinearGradient(38,-72,96,-42);g.addColorStop(0,'#a07010');g.addColorStop(0.3,'#FFD700');g.addColorStop(0.55,'#FFFACD');g.addColorStop(0.75,'#DAA520');g.addColorStop(1,'#8B6914');_axeBladeGrd[2]=g;}
      const gg=_axeBladeGrd[2];
      c.fillStyle=gg;c.strokeStyle='#8B6914';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(76,-82);c.quadraticCurveTo(98,-54,80,-20);c.lineTo(56,-14);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      // decorative engrave lines
      c.strokeStyle='rgba(255,255,220,.85)';c.lineWidth=2;c.beginPath();c.moveTo(72,-76);c.quadraticCurveTo(92,-53,76,-24);c.stroke();
      c.strokeStyle='rgba(180,130,0,.7)';c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(58,-64);c.lineTo(66,-54);c.lineTo(60,-42);c.stroke();
      // gold gem at center of blade
      c.fillStyle='#ff8800';c.strokeStyle='#cc5500';c.lineWidth=1.5;
      c.beginPath();c.arc(68,-49,5,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='rgba(255,230,180,.7)';c.beginPath();c.arc(67,-50,2,0,Math.PI*2);c.fill();
      break;}
    case 3:{
      // crystal/ice handle — cached (static colors)
      if(!_axeHndGrd[3]){const g=c.createLinearGradient(26,-76,38,-76);g.addColorStop(0,'#4a5878');g.addColorStop(0.5,'#a0c0e0');g.addColorStop(1,'#4a5878');_axeHndGrd[3]=g;}
      const ch=_axeHndGrd[3];
      c.fillStyle=ch;c.strokeStyle='#202840';c.lineWidth=3;c.beginPath();c.roundRect(26,-76,12,112,3);c.fill();c.stroke();
      c.strokeStyle='rgba(150,210,255,.5)';c.lineWidth=2;
      for(let i=0;i<5;i++){c.beginPath();c.moveTo(25,-62+i*18);c.lineTo(39,-62+i*18);c.stroke();}
      c.fillStyle='#7DF9FF';c.strokeStyle='#00BBDD';c.lineWidth=2;c.fillRect(20,-32,24,6);c.strokeRect(20,-32,24,6);
      c.fillStyle='#7DF9FF';c.strokeStyle='#00BBDD';c.lineWidth=2;c.beginPath();c.ellipse(32,37,9,6,0,0,Math.PI*2);c.fill();c.stroke();
      // ice crystal blade — cached
      if(!_axeBladeGrd[3]){const g=c.createLinearGradient(38,-72,98,-42);g.addColorStop(0,'rgba(40,160,255,.55)');g.addColorStop(0.25,'rgba(160,240,255,.96)');g.addColorStop(0.6,'rgba(200,250,255,.75)');g.addColorStop(1,'rgba(80,190,255,.4)');_axeBladeGrd[3]=g;}
      const dg=_axeBladeGrd[3];
      c.fillStyle=dg;c.strokeStyle='#00AACC';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(78,-84);c.lineTo(100,-52);c.lineTo(82,-18);c.lineTo(54,-14);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      // facet lines
      c.strokeStyle='rgba(220,250,255,.9)';c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(74,-78);c.lineTo(96,-52);c.stroke();
      c.beginPath();c.moveTo(50,-62);c.lineTo(70,-50);c.lineTo(56,-34);c.stroke();
      c.beginPath();c.moveTo(78,-40);c.lineTo(64,-28);c.stroke();
      // glowing ice shard tip
      c.fillStyle='rgba(220,250,255,.9)';c.strokeStyle='#7DF9FF';c.lineWidth=1.5;
      c.beginPath();c.moveTo(78,-84);c.lineTo(84,-78);c.lineTo(100,-52);c.stroke();
      break;}
    case 4:{
      handle('#1a0a2e','#32145a','#CC66FF');
      // arcane rune gems on handle
      c.fillStyle='rgba(180,80,255,.75)';
      for(let i=0;i<3;i++){c.beginPath();c.arc(32,-62+i*20,3.5,0,Math.PI*2);c.fill();}
      // void blade — cached
      if(!_axeBladeGrd[4]){const g=c.createLinearGradient(38,-72,98,-42);g.addColorStop(0,'#1a0030');g.addColorStop(0.3,'#7700bb');g.addColorStop(0.58,'#CC66FF');g.addColorStop(0.78,'#EE99FF');g.addColorStop(1,'#440066');_axeBladeGrd[4]=g;}
      const ag=_axeBladeGrd[4];
      c.fillStyle=ag;c.strokeStyle='#5500AA';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(78,-84);c.quadraticCurveTo(102,-54,84,-18);c.lineTo(56,-12);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      // arcane rune lines on blade
      c.strokeStyle='rgba(240,180,255,.82)';c.lineWidth=2;c.lineCap='round';
      c.beginPath();c.moveTo(74,-78);c.quadraticCurveTo(96,-54,78,-24);c.stroke();
      c.strokeStyle='rgba(200,100,255,.6)';c.lineWidth=1.5;
      c.beginPath();c.moveTo(60,-64);c.lineTo(72,-54);c.lineTo(62,-42);c.stroke();
      c.beginPath();c.moveTo(70,-40);c.lineTo(80,-30);c.stroke();
      // diamond gem at blade center
      c.fillStyle='#FF99FF';c.strokeStyle='#CC00FF';c.lineWidth=1.5;
      c.beginPath();c.moveTo(76,-52);c.lineTo(82,-46);c.lineTo(76,-40);c.lineTo(70,-46);c.closePath();c.fill();c.stroke();
      c.fillStyle='rgba(255,255,255,.65)';c.beginPath();c.arc(74,-48,2.5,0,Math.PI*2);c.fill();
      break;}
    case 5:{
      const fl=Math.sin(t*.18)*.5+.5;
      handle('#0e0806','#200e06',`rgba(180,0,0,${.7+fl*.3})`);
      // obsidian blade — cached (static colors; fire vein colors use fl separately)
      if(!_axeBladeGrd[5]){const g=c.createLinearGradient(38,-72,100,-40);g.addColorStop(0,'#0a0000');g.addColorStop(0.28,'#4a0000');g.addColorStop(0.5,'#8B0000');g.addColorStop(0.72,'#CC0000');g.addColorStop(0.88,'#FF2020');g.addColorStop(1,'#060000');_axeBladeGrd[5]=g;}
      const rg=_axeBladeGrd[5];
      c.fillStyle=rg;c.strokeStyle='#200000';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(80,-86);c.quadraticCurveTo(104,-54,86,-16);c.lineTo(56,-10);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      // crack veins glowing with fire
      if(_qualityLevel>=2){c.save();c.shadowColor='#ff4400';c.shadowBlur=8;
      c.strokeStyle=`rgba(255,${Math.round(90+fl*150)},0,${.75+fl*.25})`;c.lineWidth=2;c.lineCap='round';
      c.beginPath();c.moveTo(50,-62);c.lineTo(60,-52);c.lineTo(54,-40);c.lineTo(64,-28);c.stroke();
      c.beginPath();c.moveTo(68,-72);c.lineTo(80,-60);c.lineTo(74,-48);c.stroke();
      c.beginPath();c.moveTo(80,-42);c.lineTo(90,-30);c.stroke();
      c.restore();}
      // blade edge glow
      c.strokeStyle=`rgba(255,80,0,${.35+fl*.35})`;c.lineWidth=3;
      c.beginPath();c.moveTo(76,-82);c.quadraticCurveTo(100,-54,84,-20);c.stroke();
      // lava eye gem
      if(_qualityLevel>=2){c.save();c.shadowColor='#ff6600';c.shadowBlur=12;
      c.fillStyle=`rgba(255,${Math.round(100+fl*120)},0,1)`;c.strokeStyle='#600000';c.lineWidth=1.5;
      c.beginPath();c.arc(74,-50,6,0,Math.PI*2);c.fill();c.stroke();c.restore();}
      break;}
    case 6:{
      // PERF: quantize hue to 6° steps → 60 cached gradient slots (lazy-built on first use).
      // Eliminates 2 createLinearGradient calls per frame per player with T6 axe.
      const nh=(t*2.5)%360;
      const nhI=(nh/6|0)%60, nhQ=nhI*6;
      if(!_ax6Ph[nhI]){const g=c.createLinearGradient(26,-76,38,-76);g.addColorStop(0,`hsl(${nhQ},80%,30%)`);g.addColorStop(0.5,`hsl(${(nhQ+180)%360},80%,55%)`);g.addColorStop(1,`hsl(${nhQ},80%,30%)`);_ax6Ph[nhI]=g;}
      if(!_ax6Rn[nhI]){const g=c.createLinearGradient(38,-72,104,-38);g.addColorStop(0,`hsl(${nhQ},100%,50%)`);g.addColorStop(0.25,`hsl(${(nhQ+90)%360},100%,60%)`);g.addColorStop(0.5,`hsl(${(nhQ+180)%360},100%,65%)`);g.addColorStop(0.75,`hsl(${(nhQ+270)%360},100%,60%)`);g.addColorStop(1,`hsl(${nhQ},100%,50%)`);_ax6Rn[nhI]=g;}
      if(_qualityLevel>=2){c.shadowColor=`hsl(${nhQ},100%,65%)`;c.shadowBlur=28;}
      // prismatic handle (cached gradient)
      c.fillStyle=_ax6Ph[nhI];c.strokeStyle='#202020';c.lineWidth=3;c.beginPath();c.roundRect(26,-76,12,112,3);c.fill();c.stroke();
      for(let i=0;i<4;i++){c.fillStyle=`hsl(${(nhQ+i*90)%360},100%,62%)`;c.strokeStyle='rgba(0,0,0,.4)';c.lineWidth=1;c.beginPath();c.roundRect(25,-65+i*20,14,10,2);c.fill();c.stroke();}
      c.fillStyle=`hsl(${(nhQ+60)%360},100%,72%)`;c.beginPath();c.ellipse(32,38,9,6,0,0,Math.PI*2);c.fill();
      // rainbow spectral blade (cached gradient)
      c.fillStyle=_ax6Rn[nhI];c.strokeStyle=`hsl(${nhQ},100%,30%)`;c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(80,-86);c.quadraticCurveTo(108,-54,88,-14);c.lineTo(56,-8);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      c.strokeStyle='rgba(255,255,255,.95)';c.lineWidth=2.5;c.beginPath();c.moveTo(76,-82);c.quadraticCurveTo(104,-54,86,-18);c.stroke();
      // rainbow orb gem
      if(_qualityLevel>=2){c.shadowColor=`hsl(${(nhQ+60)%360},100%,70%)`;c.shadowBlur=16;}
      c.fillStyle=`hsl(${(nhQ+60)%360},100%,72%)`;c.strokeStyle='rgba(255,255,255,.6)';c.lineWidth=1.5;
      c.beginPath();c.arc(78,-50,7,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='rgba(255,255,255,.7)';c.beginPath();c.arc(75,-53,2.5,0,Math.PI*2);c.fill();
      c.shadowBlur=0;
      break;}
  }
  c.shadowBlur=0;
}

// Kılıç çizim fonksiyonu — 7 tier
function drawSwordByTier(c, tier, t){
  const T=WEAPON_TIERS[tier]||WEAPON_TIERS[0];
  if(tier>=2&&_qualityLevel>=2){ c.shadowColor=T.color; c.shadowBlur=10+tier*5; }
  const _staticTier = tier <= 5;
  // Shared grip helper — caches gradient for static tiers
  const grip=(col1,col2,bnd)=>{
    let hg=_staticTier ? _swdGripGrd[tier] : null;
    if(!hg){ hg=c.createLinearGradient(28,0,36,0);hg.addColorStop(0,col1);hg.addColorStop(0.5,col2);hg.addColorStop(1,col1); if(_staticTier)_swdGripGrd[tier]=hg; }
    c.fillStyle=hg;c.strokeStyle='#111';c.lineWidth=3;c.beginPath();c.roundRect(28,-26,8,52,2);c.fill();c.stroke();
    c.strokeStyle=bnd;c.lineWidth=2.5;c.lineCap='round';
    for(let i=0;i<3;i++){c.beginPath();c.moveTo(27,-20+i*14);c.lineTo(37,-20+i*14);c.stroke();}
    // pommel knob
    c.fillStyle=bnd;c.strokeStyle='#111';c.lineWidth=2;
    c.beginPath();c.ellipse(32,27,7,5,0,0,Math.PI*2);c.fill();c.stroke();
  };
  // Shared blade helper: wide double-edged blade
  const blade=(grd,outl,lw=3)=>{
    c.fillStyle=grd;c.strokeStyle=outl;c.lineWidth=lw;
    // wider, more impressive blade shape
    c.beginPath();c.moveTo(27,-30);c.lineTo(24,-75);c.quadraticCurveTo(32,-124,36,-114);c.lineTo(40,-75);c.lineTo(37,-30);c.closePath();c.fill();c.stroke();
  };
  switch(tier){
    case 0:default:{
      grip('#2a1a0a','#4a2e14','#8B6914');
      // simple wooden crossguard
      c.fillStyle='#6b4820';c.strokeStyle='#3a2010';c.lineWidth=2;
      c.beginPath();c.moveTo(18,-28);c.lineTo(46,-28);c.lineTo(48,-33);c.lineTo(32,-30);c.lineTo(16,-33);c.closePath();c.fill();c.stroke();
      // crude iron blade — cached
      if(!_swdBladeGrd[0]){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#6b7280');g.addColorStop(0.5,'#e5e7eb');g.addColorStop(1,'#6b7280');_swdBladeGrd[0]=g;}
      blade(_swdBladeGrd[0],'#374151');
      // fuller (blood groove)
      c.strokeStyle='rgba(255,255,255,.55)';c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(33,-36);c.lineTo(33,-110);c.stroke();
      // tip bevel
      c.strokeStyle='rgba(255,255,255,.35)';c.lineWidth=1;
      c.beginPath();c.moveTo(30,-100);c.quadraticCurveTo(32,-118,34,-108);c.stroke();
      break;}
    case 1:{
      grip('#2a1f10','#4a3420','#888');
      // iron crossguard with wings
      c.fillStyle='#5a5a5a';c.strokeStyle='#333';c.lineWidth=2;
      c.beginPath();c.moveTo(16,-28);c.lineTo(48,-28);c.lineTo(50,-34);c.lineTo(32,-38);c.lineTo(14,-34);c.closePath();c.fill();c.stroke();
      if(!_swdBladeGrd[1]){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#5a6068');g.addColorStop(0.5,'#b0b8c0');g.addColorStop(1,'#5a6068');_swdBladeGrd[1]=g;}
      blade(_swdBladeGrd[1],'#303840');
      c.strokeStyle='rgba(200,210,220,.65)';c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(33,-36);c.lineTo(33,-112);c.stroke();
      // edge highlights
      c.strokeStyle='rgba(160,180,200,.4)';c.lineWidth=1;
      c.beginPath();c.moveTo(26,-60);c.lineTo(27,-80);c.stroke();
      c.beginPath();c.moveTo(38,-60);c.lineTo(37,-80);c.stroke();
      break;}
    case 2:{
      grip('#4a2800','#7a4810','#FFD700');
      // ornate gold crossguard with swept wings
      if(!_swdBladeGrd[20]){const g=c.createLinearGradient(14,-28,50,-28);g.addColorStop(0,'#8B6914');g.addColorStop(0.5,'#FFD700');g.addColorStop(1,'#8B6914');_swdBladeGrd[20]=g;}
      const gc=_swdBladeGrd[20];
      c.fillStyle=gc;c.strokeStyle='#8B6914';c.lineWidth=2;
      c.beginPath();c.moveTo(14,-26);c.quadraticCurveTo(20,-38,32,-34);c.quadraticCurveTo(44,-38,50,-26);c.quadraticCurveTo(44,-18,32,-22);c.quadraticCurveTo(20,-18,14,-26);c.closePath();c.fill();c.stroke();
      // gem in crossguard
      c.fillStyle='#ff6600';c.strokeStyle='#993300';c.lineWidth=1;c.beginPath();c.arc(32,-26,4,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='rgba(255,220,180,.7)';c.beginPath();c.arc(31,-27,1.5,0,Math.PI*2);c.fill();
      if(!_swdBladeGrd[2]){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#a07010');g.addColorStop(0.35,'#FFD700');g.addColorStop(0.5,'#FFFACD');g.addColorStop(0.65,'#FFD700');g.addColorStop(1,'#a07010');_swdBladeGrd[2]=g;}
      blade(_swdBladeGrd[2],'#8B6914');
      c.strokeStyle='rgba(255,255,220,.9)';c.lineWidth=2;c.lineCap='round';c.beginPath();c.moveTo(33,-36);c.lineTo(33,-112);c.stroke();
      // decorative etch lines
      c.strokeStyle='rgba(180,130,0,.5)';c.lineWidth=1;c.lineCap='round';
      c.beginPath();c.moveTo(28,-50);c.lineTo(30,-70);c.stroke();
      c.beginPath();c.moveTo(36,-50);c.lineTo(34,-70);c.stroke();
      break;}
    case 3:{
      // crystal grip
      if(!_swdBladeGrd[30]){const g=c.createLinearGradient(28,0,36,0);g.addColorStop(0,'#3a4858');g.addColorStop(0.5,'#8ab0d0');g.addColorStop(1,'#3a4858');_swdBladeGrd[30]=g;}
      const ch=_swdBladeGrd[30];
      c.fillStyle=ch;c.strokeStyle='#202840';c.lineWidth=3;c.beginPath();c.roundRect(28,-26,8,52,2);c.fill();c.stroke();
      c.strokeStyle='rgba(150,220,255,.5)';c.lineWidth=2;c.lineCap='round';
      for(let i=0;i<3;i++){c.beginPath();c.moveTo(27,-20+i*14);c.lineTo(37,-20+i*14);c.stroke();}
      c.fillStyle='#7DF9FF';c.strokeStyle='#00AACC';c.lineWidth=2;c.beginPath();c.ellipse(32,27,7,5,0,0,Math.PI*2);c.fill();c.stroke();
      // ice crystal crossguard — star-like
      c.fillStyle='rgba(120,220,255,.9)';c.strokeStyle='#00AACC';c.lineWidth=2;
      c.beginPath();c.moveTo(14,-25);c.lineTo(22,-36);c.lineTo(32,-32);c.lineTo(42,-36);c.lineTo(50,-25);c.lineTo(42,-14);c.lineTo(32,-18);c.lineTo(22,-14);c.closePath();c.fill();c.stroke();
      // center orb
      c.fillStyle='rgba(220,250,255,.95)';c.strokeStyle='#7DF9FF';c.lineWidth=1;c.beginPath();c.arc(32,-25,5,0,Math.PI*2);c.fill();c.stroke();
      // translucent ice blade — cached
      if(!_swdBladeGrd[3]){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'rgba(60,180,255,.6)');g.addColorStop(0.5,'rgba(220,248,255,.96)');g.addColorStop(1,'rgba(60,180,255,.6)');_swdBladeGrd[3]=g;}
      blade(_swdBladeGrd[3],'#00AACC',2.5);
      c.strokeStyle='rgba(220,250,255,.85)';c.lineWidth=2;c.beginPath();c.moveTo(33,-36);c.lineTo(33,-112);c.stroke();
      // facet lines
      c.strokeStyle='rgba(180,240,255,.55)';c.lineWidth=1;c.lineCap='round';
      c.beginPath();c.moveTo(28,-55);c.lineTo(30,-80);c.stroke();
      c.beginPath();c.moveTo(36,-55);c.lineTo(34,-80);c.stroke();
      break;}
    case 4:{
      grip('#1a0030','#34006a','#CC66FF');
      // arcane crossguard with twin crystals
      c.fillStyle='#550088';c.strokeStyle='#330055';c.lineWidth=2;
      c.beginPath();c.moveTo(14,-24);c.lineTo(50,-24);c.lineTo(50,-32);c.lineTo(32,-38);c.lineTo(14,-32);c.closePath();c.fill();c.stroke();
      // crystal spikes on crossguard
      for(const sx of[18,46]){
        c.fillStyle='#CC66FF';c.strokeStyle='#8800CC';c.lineWidth=1.5;
        c.beginPath();c.moveTo(sx,-24);c.lineTo(sx-4,-42);c.lineTo(sx+4,-42);c.closePath();c.fill();c.stroke();
      }
      c.fillStyle='#FF99FF';c.strokeStyle='#CC44FF';c.lineWidth=1;c.beginPath();c.arc(32,-32,5,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='rgba(255,255,255,.65)';c.beginPath();c.arc(30,-34,2,0,Math.PI*2);c.fill();
      if(!_swdBladeGrd[4]){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#1a0030');g.addColorStop(0.3,'#8800bb');g.addColorStop(0.5,'#CC66FF');g.addColorStop(0.7,'#EE99FF');g.addColorStop(1,'#1a0030');_swdBladeGrd[4]=g;}
      blade(_swdBladeGrd[4],'#5500AA');
      c.strokeStyle='rgba(220,170,255,.85)';c.lineWidth=2;c.beginPath();c.moveTo(33,-36);c.lineTo(33,-112);c.stroke();
      // rune marks
      c.strokeStyle='rgba(255,180,255,.5)';c.lineWidth=1;c.lineCap='round';
      c.beginPath();c.moveTo(29,-52);c.lineTo(32,-62);c.lineTo(35,-52);c.stroke();
      c.beginPath();c.moveTo(29,-74);c.lineTo(32,-84);c.lineTo(35,-74);c.stroke();
      break;}
    case 5:{
      const rs=Math.sin(t*.15)*.5+.5;
      grip('#0e0000','#1e0000',`rgba(200,0,0,${.7+rs*.3})`);
      // demonic crossguard — serrated
      c.fillStyle='#1a0000';c.strokeStyle='#000';c.lineWidth=2;
      c.beginPath();c.moveTo(12,-24);c.lineTo(18,-38);c.lineTo(26,-30);c.lineTo(32,-36);c.lineTo(38,-30);c.lineTo(46,-38);c.lineTo(52,-24);c.lineTo(46,-10);c.lineTo(38,-18);c.lineTo(32,-12);c.lineTo(26,-18);c.lineTo(18,-10);c.closePath();c.fill();c.stroke();
      // blood gem center
      if(_qualityLevel>=2){c.save();c.shadowColor='#ff0000';c.shadowBlur=10;}
      c.fillStyle=`rgba(220,0,0,${.8+rs*.2})`;c.strokeStyle='#800000';c.lineWidth=1.5;
      c.beginPath();c.arc(32,-24,5,0,Math.PI*2);c.fill();c.stroke();
      if(_qualityLevel>=2){c.restore();}
      // eye-of-sauron gems on crossguard
      for(const sx of[19,45]){
        c.fillStyle=`rgba(255,${Math.round(50+rs*80)},0,.9)`;c.beginPath();c.arc(sx,-24,3,0,Math.PI*2);c.fill();
      }
      // obsidian blade — cached
      if(!_swdBladeGrd[5]){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#060000');g.addColorStop(0.35,'#440000');g.addColorStop(0.5,'#880000');g.addColorStop(0.65,'#CC0000');g.addColorStop(1,'#060000');_swdBladeGrd[5]=g;}
      blade(_swdBladeGrd[5],'#220000');
      // pulsing lava veins
      if(_qualityLevel>=2){c.save();c.shadowColor='#ff4400';c.shadowBlur=8;}
      c.strokeStyle=`rgba(255,${Math.round(70+rs*120)},0,${.8+rs*.2})`;c.lineWidth=2;c.lineCap='round';
      c.beginPath();c.moveTo(31,-40);c.lineTo(33,-58);c.lineTo(31,-76);c.lineTo(33,-94);c.stroke();
      c.beginPath();c.moveTo(35,-50);c.lineTo(33,-68);c.lineTo(35,-86);c.stroke();
      if(_qualityLevel>=2){c.restore();}
      // glowing edge
      c.strokeStyle=`rgba(255,60,0,${.35+rs*.3})`;c.lineWidth=2.5;
      c.beginPath();c.moveTo(25,-40);c.lineTo(24,-90);c.stroke();
      c.beginPath();c.moveTo(39,-40);c.lineTo(40,-90);c.stroke();
      break;}
    case 6:{
      // PERF: quantize hue to 6° steps → 60 cached gradient slots (lazy-built on first use).
      // Eliminates 3 createLinearGradient calls per frame per player with T6 sword.
      const ns=(t*2)%360;
      const nsI=(ns/6|0)%60, nsQ=nsI*6;
      if(!_sw6Ph[nsI]){const g=c.createLinearGradient(28,0,36,0);g.addColorStop(0,`hsl(${nsQ},80%,28%)`);g.addColorStop(0.5,`hsl(${(nsQ+180)%360},80%,55%)`);g.addColorStop(1,`hsl(${nsQ},80%,28%)`);_sw6Ph[nsI]=g;}
      if(!_sw6Rg[nsI]){const g=c.createLinearGradient(14,-28,50,-28);g.addColorStop(0,`hsl(${nsQ},100%,50%)`);g.addColorStop(0.5,`hsl(${(nsQ+180)%360},100%,70%)`);g.addColorStop(1,`hsl(${nsQ},100%,50%)`);_sw6Rg[nsI]=g;}
      if(!_sw6Rb[nsI]){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,`hsl(${nsQ},100%,45%)`);g.addColorStop(0.25,`hsl(${(nsQ+90)%360},100%,58%)`);g.addColorStop(0.5,`hsl(${(nsQ+180)%360},100%,68%)`);g.addColorStop(0.75,`hsl(${(nsQ+270)%360},100%,58%)`);g.addColorStop(1,`hsl(${nsQ},100%,45%)`);_sw6Rb[nsI]=g;}
      if(_qualityLevel>=2){c.shadowColor=`hsl(${nsQ},100%,65%)`;c.shadowBlur=28;}
      // prismatic grip (cached)
      c.fillStyle=_sw6Ph[nsI];c.strokeStyle='#111';c.lineWidth=3;c.beginPath();c.roundRect(28,-26,8,52,2);c.fill();c.stroke();
      for(let i=0;i<3;i++){c.fillStyle=`hsl(${(nsQ+i*120)%360},100%,62%)`;c.strokeStyle='rgba(0,0,0,.3)';c.lineWidth=1;c.beginPath();c.roundRect(27,-20+i*14,10,7,1);c.fill();c.stroke();}
      c.fillStyle=`hsl(${(nsQ+60)%360},100%,70%)`;c.beginPath();c.ellipse(32,27,7,5,0,0,Math.PI*2);c.fill();
      // prismatic crossguard (cached)
      c.fillStyle=_sw6Rg[nsI];c.strokeStyle=`hsl(${nsQ},100%,30%)`;c.lineWidth=2;
      c.beginPath();c.moveTo(12,-24);c.lineTo(14,-34);c.quadraticCurveTo(32,-42,50,-34);c.lineTo(52,-24);c.quadraticCurveTo(32,-16,12,-24);c.closePath();c.fill();c.stroke();
      if(_qualityLevel>=2){c.shadowColor=`hsl(${(nsQ+60)%360},100%,70%)`;c.shadowBlur=14;}
      c.fillStyle=`hsl(${(nsQ+60)%360},100%,75%)`;c.strokeStyle='rgba(255,255,255,.6)';c.lineWidth=1;
      c.beginPath();c.arc(32,-28,6,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='rgba(255,255,255,.7)';c.beginPath();c.arc(30,-30,2,0,Math.PI*2);c.fill();
      c.shadowBlur=0;
      // rainbow spectral blade (cached)
      blade(_sw6Rb[nsI],`hsl(${nsQ},100%,28%)`);
      c.strokeStyle='rgba(255,255,255,.95)';c.lineWidth=2;c.beginPath();c.moveTo(33,-36);c.lineTo(33,-112);c.stroke();
      // sparkle runes — alpha quantized to avoid per-frame string alloc
      const _spA=(0.4+Math.sin(t*.12)*.35).toFixed(2);
      c.strokeStyle=`rgba(255,255,255,${_spA})`;c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(28,-55);c.lineTo(32,-65);c.lineTo(36,-55);c.stroke();
      c.beginPath();c.moveTo(28,-78);c.lineTo(32,-88);c.lineTo(36,-78);c.stroke();
      if(_qualityLevel>=2){c.shadowColor=`hsl(${(nsQ+120)%360},100%,75%)`;c.shadowBlur=14;}
      c.fillStyle=`hsl(${(nsQ+120)%360},100%,80%)`;c.beginPath();c.arc(32,-115,5,0,Math.PI*2);c.fill();c.shadowBlur=0;
      break;}
  }
  c.shadowBlur=0;
}

// ============================================================
// BALTA & KILIÇ SKİN FONKSİYONLARI — drawAxeSkin / drawSwordSkin
// ============================================================
// PERF: handle/grip gradient cache for static-color skins (called 1×/frame for local player).
const _axeSkinHndGrd = {}, _axeSkinBldGrd = {};
const _swdSkinGrdC   = {};
function drawAxeSkin(c, skinId, t){
  const fl=Math.sin(t*0.18)*0.5+0.5;
  const ql=_qualityLevel;
  // Shared handle helper — cached by (col1,col2) key for static skins
  const handle=(col1,col2,bnd,extra)=>{
    const _hk=col1+'|'+col2;
    let hg=_axeSkinHndGrd[_hk];
    if(!hg){hg=c.createLinearGradient(26,-75,38,-75);hg.addColorStop(0,col1);hg.addColorStop(0.5,col2);hg.addColorStop(1,col1);_axeSkinHndGrd[_hk]=hg;}
    c.fillStyle=hg;c.strokeStyle='#1a0f06';c.lineWidth=4;c.beginPath();c.roundRect(26,-76,12,112,3);c.fill();c.stroke();
    c.strokeStyle=bnd;c.lineWidth=2.5;c.lineCap='round';
    for(let i=0;i<5;i++){c.beginPath();c.moveTo(25,-62+i*18);c.lineTo(39,-62+i*18);c.stroke();}
    c.fillStyle=bnd;c.strokeStyle='#1a0f06';c.lineWidth=2;
    c.beginPath();c.ellipse(32,37,9,6,0,0,Math.PI*2);c.fill();c.stroke();
  };
  switch(skinId){
    case 'ba_demir':{
      handle('#3a3a48','#6a6a78','#888');
      if(!_axeSkinBldGrd['ba_demir']){const g=c.createLinearGradient(38,-72,88,-46);g.addColorStop(0,'#6b7280');g.addColorStop(0.45,'#d1d5db');g.addColorStop(0.7,'#9ca3af');g.addColorStop(1,'#4b5563');_axeSkinBldGrd['ba_demir']=g;}
      const bg=_axeSkinBldGrd['ba_demir'];
      c.fillStyle=bg;c.strokeStyle='#374151';c.lineWidth=4;
      c.beginPath();c.moveTo(38,-68);c.lineTo(72,-80);c.quadraticCurveTo(92,-55,80,-26);c.lineTo(60,-18);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      for(const[px,py]of[[58,-62],[72,-50],[66,-34]]){c.fillStyle='#374151';c.strokeStyle='#888';c.lineWidth=1.5;c.beginPath();c.arc(px,py,4,0,Math.PI*2);c.fill();c.stroke();c.fillStyle='rgba(255,255,255,.3)';c.beginPath();c.arc(px-1,py-1,1.5,0,Math.PI*2);c.fill();}
      c.strokeStyle='rgba(220,225,235,.8)';c.lineWidth=2;c.beginPath();c.moveTo(68,-74);c.quadraticCurveTo(88,-54,74,-24);c.stroke();
      break;}
    case 'ba_kemik':{
      handle('#c8b89a','#e8d8c0','#d4c4a8');
      if(!_axeSkinBldGrd['ba_kemik']){const g=c.createLinearGradient(38,-72,88,-46);g.addColorStop(0,'#c8b89a');g.addColorStop(0.3,'#f0e8d8');g.addColorStop(0.6,'#e0d0b8');g.addColorStop(1,'#b0a088');_axeSkinBldGrd['ba_kemik']=g;}
      const bg=_axeSkinBldGrd['ba_kemik'];
      c.fillStyle=bg;c.strokeStyle='#8a7868';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(68,-82);c.lineTo(76,-76);c.lineTo(72,-68);c.lineTo(80,-60);c.lineTo(74,-52);c.lineTo(86,-44);c.lineTo(78,-28);c.lineTo(60,-18);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      c.strokeStyle='rgba(100,88,70,.35)';c.lineWidth=1.2;c.lineCap='round';
      c.beginPath();c.moveTo(60,-68);c.lineTo(70,-56);c.stroke();c.beginPath();c.moveTo(70,-50);c.lineTo(76,-40);c.stroke();
      c.fillStyle='#e0d0b8';c.strokeStyle='#8a7868';c.lineWidth=2;
      c.beginPath();c.arc(72,-76,5,0,Math.PI*2);c.fill();c.stroke();c.beginPath();c.arc(78,-22,4,0,Math.PI*2);c.fill();c.stroke();
      break;}
    case 'ba_obsidyen':{
      handle('#0a0a0f','#1a1a2f','#5522aa');
      if(ql>=2){c.shadowColor=`rgba(180,0,255,${0.5+fl*0.5})`;c.shadowBlur=18;}
      if(!_axeSkinBldGrd['ba_obsidyen']){const g=c.createLinearGradient(38,-72,94,-44);g.addColorStop(0,'#050508');g.addColorStop(0.3,'#1a1830');g.addColorStop(0.55,'#2a2545');g.addColorStop(0.75,'#0f0e1a');g.addColorStop(1,'#030305');_axeSkinBldGrd['ba_obsidyen']=g;}
      const bg=_axeSkinBldGrd['ba_obsidyen'];
      c.fillStyle=bg;c.strokeStyle='#5522aa';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(74,-84);c.quadraticCurveTo(96,-54,78,-20);c.lineTo(56,-14);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      c.strokeStyle='rgba(180,160,255,.55)';c.lineWidth=1.5;c.beginPath();c.moveTo(70,-78);c.quadraticCurveTo(90,-54,74,-24);c.stroke();
      c.fillStyle=`rgba(180,0,255,${0.7+fl*0.3})`;c.strokeStyle='#5522aa';c.lineWidth=1.5;
      c.beginPath();c.moveTo(72,-52);c.lineTo(78,-46);c.lineTo(72,-40);c.lineTo(66,-46);c.closePath();c.fill();c.stroke();
      break;}
    case 'ba_ember':{
      handle('#1a0a00','#3a1a04','rgba(255,140,0,0.8)');
      if(ql>=2){c.shadowColor=`rgba(255,100,0,${0.6+fl*0.4})`;c.shadowBlur=18;}
      const bg=c.createLinearGradient(38,-72,92,-44);bg.addColorStop(0,'#1a0500');bg.addColorStop(0.25,'#8B2500');bg.addColorStop(0.5,`rgba(255,${100+Math.round(fl*100)},0,1)`);bg.addColorStop(0.75,'#cc4400');bg.addColorStop(1,'#380800');
      c.fillStyle=bg;c.strokeStyle='#8B2200';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(74,-82);c.quadraticCurveTo(96,-54,78,-20);c.lineTo(56,-14);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      if(ql>=2){c.save();c.shadowColor='#ff6600';c.shadowBlur=10;
      c.strokeStyle=`rgba(255,${180+Math.round(fl*75)},0,${0.7+fl*0.3})`;c.lineWidth=2;
      c.beginPath();c.moveTo(50,-64);c.lineTo(60,-52);c.lineTo(54,-42);c.stroke();
      c.beginPath();c.moveTo(68,-74);c.lineTo(78,-62);c.lineTo(74,-48);c.stroke();
      c.restore();}
      break;}
    case 'ba_buz':{
      if(!_axeSkinBldGrd['ba_buz_h']){const g=c.createLinearGradient(26,-76,38,-76);g.addColorStop(0,'#2a4878');g.addColorStop(0.5,'#7ab0e0');g.addColorStop(1,'#2a4878');_axeSkinBldGrd['ba_buz_h']=g;}
      const ch=_axeSkinBldGrd['ba_buz_h'];
      c.fillStyle=ch;c.strokeStyle='#1a3060';c.lineWidth=3;c.beginPath();c.roundRect(26,-76,12,112,3);c.fill();c.stroke();
      c.strokeStyle='rgba(130,190,255,.55)';c.lineWidth=2;for(let i=0;i<5;i++){c.beginPath();c.moveTo(25,-62+i*18);c.lineTo(39,-62+i*18);c.stroke();}
      c.fillStyle='#7DF9FF';c.strokeStyle='#00AACC';c.lineWidth=2;c.beginPath();c.ellipse(32,37,9,6,0,0,Math.PI*2);c.fill();c.stroke();
      if(ql>=2){c.shadowColor='#00ccff';c.shadowBlur=15;}
      if(!_axeSkinBldGrd['ba_buz']){const g=c.createLinearGradient(38,-72,100,-42);g.addColorStop(0,'rgba(30,140,255,.45)');g.addColorStop(0.25,'rgba(140,225,255,.95)');g.addColorStop(0.55,'rgba(200,248,255,.82)');g.addColorStop(0.8,'rgba(70,180,255,.55)');g.addColorStop(1,'rgba(30,100,200,.3)');_axeSkinBldGrd['ba_buz']=g;}
      const bg=_axeSkinBldGrd['ba_buz'];
      c.fillStyle=bg;c.strokeStyle='#00AACC';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(68,-84);c.lineTo(84,-76);c.lineTo(100,-54);c.lineTo(92,-32);c.lineTo(78,-20);c.lineTo(54,-14);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      c.strokeStyle='rgba(210,248,255,.9)';c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(66,-80);c.lineTo(80,-70);c.stroke();c.beginPath();c.moveTo(80,-70);c.lineTo(96,-52);c.stroke();
      c.beginPath();c.moveTo(48,-62);c.lineTo(64,-52);c.lineTo(56,-36);c.stroke();
      break;}
    case 'ba_asma':{
      handle('#4a2e10','#7a5a28','#2a7a10');
      c.strokeStyle='#1a5a08';c.lineWidth=2.5;c.lineCap='round';
      for(let i=0;i<4;i++){c.beginPath();c.moveTo(26,-70+i*22);c.quadraticCurveTo(38,-60+i*22,26,-50+i*22);c.stroke();}
      c.fillStyle='#2a8a14';c.strokeStyle='#1a6008';c.lineWidth=1.2;
      for(const[px,py]of[[24,-68],[38,-52],[24,-36],[38,-18]]){c.save();c.translate(px,py);c.rotate(-0.3);c.beginPath();c.ellipse(0,-5,3,6,0,0,Math.PI*2);c.fill();c.stroke();c.restore();}
      if(!_axeSkinBldGrd['ba_asma']){const g=c.createLinearGradient(38,-72,90,-44);g.addColorStop(0,'#3a6020');g.addColorStop(0.35,'#5a9030');g.addColorStop(0.6,'#7ab840');g.addColorStop(0.85,'#4a7820');g.addColorStop(1,'#283a14');_axeSkinBldGrd['ba_asma']=g;}
      const bg=_axeSkinBldGrd['ba_asma'];
      c.fillStyle=bg;c.strokeStyle='#2a5010';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(70,-82);c.quadraticCurveTo(94,-60,76,-22);c.lineTo(56,-14);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      c.strokeStyle='rgba(50,140,20,.55)';c.lineWidth=1.5;c.beginPath();c.moveTo(54,-60);c.quadraticCurveTo(64,-48,58,-38);c.quadraticCurveTo(66,-28,62,-20);c.stroke();
      break;}
    case 'ba_kan':{
      handle('#1a0000','#3a0808','#880000');
      if(ql>=2){c.shadowColor='rgba(200,0,0,0.5)';c.shadowBlur=10;}
      if(!_axeSkinBldGrd['ba_kan']){const g=c.createLinearGradient(38,-72,90,-44);g.addColorStop(0,'#220000');g.addColorStop(0.3,'#5a0000');g.addColorStop(0.55,'#8B0000');g.addColorStop(0.8,'#6a0000');g.addColorStop(1,'#1a0000');_axeSkinBldGrd['ba_kan']=g;}
      const bg=_axeSkinBldGrd['ba_kan'];
      c.fillStyle=bg;c.strokeStyle='#440000';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(72,-82);c.quadraticCurveTo(94,-54,76,-20);c.lineTo(56,-14);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      c.fillStyle='#cc0000';c.strokeStyle='#880000';c.lineWidth=1;
      for(const[px,py,dr]of[[62,-22,8],[72,-24,6],[80,-30,5],[68,-14,7]]){c.beginPath();c.arc(px,py,3,0,Math.PI*2);c.fill();c.stroke();c.fillStyle='#aa0000';c.beginPath();c.ellipse(px,py+dr/2,2,dr/2,0,0,Math.PI*2);c.fill();c.fillStyle='#cc0000';}
      c.strokeStyle='rgba(200,50,50,.75)';c.lineWidth=2;c.beginPath();c.moveTo(68,-78);c.quadraticCurveTo(90,-54,74,-24);c.stroke();
      break;}
    case 'ba_simsek':{
      handle('#0a0a1a','#1a1a3a','#4466ff');
      if(ql>=2){c.shadowColor=`rgba(80,140,255,${0.5+fl*0.5})`;c.shadowBlur=18;}
      const bg=c.createLinearGradient(38,-72,94,-44);bg.addColorStop(0,'#0a0a20');bg.addColorStop(0.3,'#2244aa');bg.addColorStop(0.55,`rgba(100,180,255,${0.8+fl*0.2})`);bg.addColorStop(0.8,'#1a3a88');bg.addColorStop(1,'#080818');
      c.fillStyle=bg;c.strokeStyle='#2255cc';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(72,-84);c.lineTo(64,-72);c.lineTo(82,-62);c.lineTo(70,-52);c.lineTo(90,-40);c.lineTo(76,-24);c.lineTo(56,-16);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      if(ql>=2){c.save();c.shadowColor='#88bbff';c.shadowBlur=8;
      c.strokeStyle=`rgba(160,210,255,${0.7+fl*0.3})`;c.lineWidth=2;c.lineCap='round';
      c.beginPath();c.moveTo(60,-78);c.lineTo(68,-70);c.lineTo(62,-62);c.lineTo(70,-54);c.lineTo(64,-46);c.lineTo(72,-38);c.stroke();
      c.restore();}
      break;}
    case 'ba_golge':{
      handle('#08000f','#180028','rgba(150,0,255,0.8)');
      if(ql>=2){c.shadowColor=`rgba(180,0,255,${0.4+fl*0.6})`;c.shadowBlur=22;}
      if(!_axeSkinBldGrd['ba_golge']){const g=c.createLinearGradient(38,-72,94,-44);g.addColorStop(0,'rgba(5,0,15,0.98)');g.addColorStop(0.35,'rgba(60,0,120,0.9)');g.addColorStop(0.55,'rgba(120,0,200,0.85)');g.addColorStop(0.78,'rgba(50,0,100,0.9)');g.addColorStop(1,'rgba(3,0,10,0.97)');_axeSkinBldGrd['ba_golge']=g;}
      const bg=_axeSkinBldGrd['ba_golge'];
      c.fillStyle=bg;c.strokeStyle='rgba(120,0,200,0.8)';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(76,-86);c.quadraticCurveTo(100,-54,82,-18);c.lineTo(56,-12);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      if(ql>=2){c.save();c.shadowColor='#aa00ff';c.shadowBlur=14;
      c.strokeStyle=`rgba(200,80,255,${0.5+fl*0.4})`;c.lineWidth=2;c.lineCap='round';
      for(let i=0;i<3;i++){c.beginPath();c.moveTo(52+i*12,-62-i*4);c.quadraticCurveTo(64+i*8,-50-i*4,56+i*10,-40-i*4);c.stroke();}
      c.fillStyle=`rgba(220,100,255,${0.7+fl*0.3})`;c.strokeStyle='#6600aa';c.lineWidth=1.5;
      c.beginPath();c.moveTo(74,-52);c.lineTo(80,-46);c.lineTo(74,-40);c.lineTo(68,-46);c.closePath();c.fill();c.stroke();
      c.restore();}
      break;}
    case 'ba_altin':{
      handle('#4a2800','#9a6010','#FFD700');
      for(let i=0;i<3;i++){c.fillStyle='#FFD700';c.strokeStyle='#8B6914';c.lineWidth=1.5;c.fillRect(24,-68+i*20,16,5);c.strokeRect(24,-68+i*20,16,5);c.fillStyle='#ff6600';c.beginPath();c.arc(32,-66+i*20,2.5,0,Math.PI*2);c.fill();}
      if(ql>=2){c.shadowColor='#FFD700';c.shadowBlur=14;}
      if(!_axeSkinBldGrd['ba_altin']){const g=c.createLinearGradient(38,-72,100,-42);g.addColorStop(0,'#8B6914');g.addColorStop(0.25,'#FFD700');g.addColorStop(0.45,'#FFF8C0');g.addColorStop(0.65,'#FFD700');g.addColorStop(0.85,'#B8860B');g.addColorStop(1,'#6B5010');_axeSkinBldGrd['ba_altin']=g;}
      const bg=_axeSkinBldGrd['ba_altin'];
      c.fillStyle=bg;c.strokeStyle='#8B6914';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(78,-84);c.quadraticCurveTo(102,-54,86,-18);c.quadraticCurveTo(76,-10,56,-14);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      c.strokeStyle='rgba(255,255,200,.9)';c.lineWidth=2;c.beginPath();c.moveTo(74,-80);c.quadraticCurveTo(96,-54,80,-24);c.stroke();
      c.fillStyle='#FF4444';c.strokeStyle='#8B0000';c.lineWidth=1.5;c.beginPath();c.arc(76,-50,7,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='rgba(255,200,200,.7)';c.beginPath();c.arc(73,-53,2.5,0,Math.PI*2);c.fill();
      break;}
    case 'ba_berserker':{
      handle('#2a1a0a','#5a3a18','#6a4020');
      if(!_axeSkinBldGrd['ba_berserker']){const g=c.createLinearGradient(38,-88,102,-40);g.addColorStop(0,'#4a4a52');g.addColorStop(0.35,'#a0a0b0');g.addColorStop(0.55,'#d8d8e0');g.addColorStop(0.75,'#808090');g.addColorStop(1,'#383840');_axeSkinBldGrd['ba_berserker']=g;}
      const bg=_axeSkinBldGrd['ba_berserker'];
      c.fillStyle=bg;c.strokeStyle='#2a2a32';c.lineWidth=5;
      c.beginPath();c.moveTo(36,-72);c.lineTo(76,-92);c.quadraticCurveTo(110,-56,90,-14);c.lineTo(62,-8);c.lineTo(36,-28);c.closePath();c.fill();c.stroke();
      c.strokeStyle='rgba(0,0,0,.4)';c.lineWidth=2;c.lineCap='round';
      c.beginPath();c.moveTo(80,-74);c.lineTo(72,-64);c.stroke();c.beginPath();c.moveTo(88,-56);c.lineTo(80,-50);c.lineTo(84,-42);c.stroke();
      c.strokeStyle='rgba(230,235,245,.85)';c.lineWidth=2.5;c.beginPath();c.moveTo(72,-88);c.quadraticCurveTo(106,-56,88,-18);c.stroke();
      c.fillStyle='rgba(120,0,0,.3)';c.beginPath();c.ellipse(70,-36,10,6,0.5,0,Math.PI*2);c.fill();
      break;}
    case 'ba_ciftkafa':{
      handle('#3a2010','#6a4020','#c8a040');
      if(!_axeSkinBldGrd['ba_ciftkafa1']){const g=c.createLinearGradient(38,-72,92,-44);g.addColorStop(0,'#6b7280');g.addColorStop(0.45,'#d1d5db');g.addColorStop(1,'#4b5563');_axeSkinBldGrd['ba_ciftkafa1']=g;}
      const bg1=_axeSkinBldGrd['ba_ciftkafa1'];
      c.fillStyle=bg1;c.strokeStyle='#374151';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(72,-82);c.quadraticCurveTo(94,-52,78,-20);c.lineTo(56,-16);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      if(!_axeSkinBldGrd['ba_ciftkafa2']){const g=c.createLinearGradient(26,-72,-18,-44);g.addColorStop(0,'#6b7280');g.addColorStop(0.45,'#c8cbd0');g.addColorStop(1,'#4b5563');_axeSkinBldGrd['ba_ciftkafa2']=g;}
      const bg2=_axeSkinBldGrd['ba_ciftkafa2'];
      c.fillStyle=bg2;c.strokeStyle='#374151';c.lineWidth=3;
      c.beginPath();c.moveTo(26,-68);c.lineTo(-8,-82);c.quadraticCurveTo(-30,-52,-14,-20);c.lineTo(8,-16);c.lineTo(26,-30);c.closePath();c.fill();c.stroke();
      c.fillStyle='#c8a040';c.strokeStyle='#8B6914';c.lineWidth=2;
      c.beginPath();c.arc(32,-48,7,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='#ff6600';c.beginPath();c.arc(32,-48,4,0,Math.PI*2);c.fill();
      break;}
    case 'ba_lolipop':{
      if(!_axeSkinBldGrd['ba_lolipop_h']){const g=c.createLinearGradient(26,-76,38,-76);g.addColorStop(0,'#ff69b4');g.addColorStop(0.5,'#fff0f5');g.addColorStop(1,'#ff69b4');_axeSkinBldGrd['ba_lolipop_h']=g;}
      const hg=_axeSkinBldGrd['ba_lolipop_h'];
      c.fillStyle=hg;c.strokeStyle='#dd1177';c.lineWidth=3.5;c.beginPath();c.roundRect(26,-76,12,112,3);c.fill();c.stroke();
      for(let i=0;i<6;i++){c.strokeStyle=i%2===0?'rgba(255,20,130,0.45)':'rgba(255,255,255,0.3)';c.lineWidth=1.5;c.beginPath();c.moveTo(25,-65+i*16);c.lineTo(39,-65+i*16);c.stroke();}
      c.fillStyle='#ff1493';c.strokeStyle='#aa0055';c.lineWidth=2;c.beginPath();c.ellipse(32,37,9,6,0,0,Math.PI*2);c.fill();c.stroke();
      const lx=66,ly=-52,lr=30;
      if(ql>=2){c.shadowColor='rgba(255,20,150,0.7)';c.shadowBlur=18;}
      c.fillStyle='#ff1493';c.strokeStyle='#cc0055';c.lineWidth=3;c.beginPath();c.arc(lx,ly,lr,0,Math.PI*2);c.fill();c.stroke();
      c.shadowBlur=0;
      c.save();c.beginPath();c.arc(lx,ly,lr-1,0,Math.PI*2);c.clip();
      for(let i=0;i<8;i++){c.fillStyle=i%2===0?'rgba(255,255,255,0.82)':'rgba(255,0,100,0.08)';c.beginPath();c.moveTo(lx,ly);c.arc(lx,ly,lr+2,i*Math.PI/4,(i+1)*Math.PI/4);c.closePath();c.fill();}
      c.restore();
      c.fillStyle='rgba(255,255,255,0.45)';c.beginPath();c.ellipse(lx-9,ly-9,11,7,-0.5,0,Math.PI*2);c.fill();
      break;}
    case 'ba_pizza':{
      handle('#5c3d1e','#8b6343','#d4aa70');
      c.fillStyle='#c07030';c.strokeStyle='#7a4a10';c.lineWidth=4;
      c.beginPath();c.moveTo(38,-22);c.lineTo(78,-90);c.lineTo(98,-56);c.lineTo(66,-10);c.closePath();c.fill();c.stroke();
      c.fillStyle='rgba(200,150,80,0.5)';
      for(const[px,py]of[[72,-88],[80,-74],[88,-62]]){c.beginPath();c.arc(px,py,2.5,0,Math.PI*2);c.fill();}
      c.fillStyle='#cc2200';c.beginPath();c.moveTo(42,-26);c.lineTo(78,-84);c.lineTo(94,-54);c.lineTo(64,-14);c.closePath();c.fill();
      c.fillStyle='#f5cc3c';c.beginPath();c.moveTo(46,-30);c.lineTo(76,-80);c.lineTo(90,-52);c.lineTo(62,-18);c.closePath();c.fill();
      for(const[px,py]of[[62,-66],[72,-54],[62,-46],[72,-38]]){c.fillStyle='rgba(245,200,50,0.6)';c.beginPath();c.ellipse(px,py,5,4,0.3,0,Math.PI*2);c.fill();}
      for(const[px,py]of[[60,-70],[70,-58],[62,-50],[71,-40],[64,-62]]){c.fillStyle='#bb2200';c.strokeStyle='#881100';c.lineWidth=1;c.beginPath();c.arc(px,py,5.5,0,Math.PI*2);c.fill();c.stroke();c.fillStyle='rgba(255,100,80,0.4)';c.beginPath();c.arc(px-1,py-1,2,0,Math.PI*2);c.fill();}
      c.fillStyle='#2a8a20';c.strokeStyle='#1a5a10';c.lineWidth=1.5;c.save();c.translate(66,-46);c.rotate(-0.4);c.beginPath();c.ellipse(0,0,5,9,0,0,Math.PI*2);c.fill();c.stroke();c.restore();
      break;}
    case 'ba_mantar':{
      handle('#5c3a18','#8b5a2a','#4a7a20');
      c.strokeStyle='#3a6810';c.lineWidth=2;c.lineCap='round';
      for(let i=0;i<4;i++){c.beginPath();c.moveTo(26,-70+i*22);c.quadraticCurveTo(38,-60+i*22,26,-50+i*22);c.stroke();}
      c.fillStyle='#4a9020';c.strokeStyle='#2a6010';c.lineWidth=1;
      for(const[px,py]of[[24,-68],[38,-52],[24,-36],[38,-18]]){c.save();c.translate(px,py);c.beginPath();c.ellipse(0,-5,3,6,0,0,Math.PI*2);c.fill();c.stroke();c.restore();}
      if(ql>=2){c.shadowColor='rgba(220,50,50,0.4)';c.shadowBlur=12;}
      c.fillStyle='#dd2222';c.strokeStyle='#881111';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-20);c.lineTo(44,-52);c.quadraticCurveTo(56,-94,74,-84);c.quadraticCurveTo(96,-68,90,-42);c.lineTo(72,-14);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      c.strokeStyle='rgba(255,230,210,0.5)';c.lineWidth=1.2;c.lineCap='round';
      for(let i=0;i<4;i++){c.beginPath();c.moveTo(42+i*8,-22);c.lineTo(44+i*8,-14);c.stroke();}
      c.fillStyle='rgba(255,255,255,0.92)';c.strokeStyle='rgba(200,200,200,0.3)';c.lineWidth=0.5;
      for(const[px,py,r]of[[60,-76,7],[76,-62,5],[56,-54,4],[72,-46,6],[62,-38,4],[80,-50,3]]){c.beginPath();c.arc(px,py,r,0,Math.PI*2);c.fill();c.stroke();}
      break;}
    case 'ba_gokkusagi':{
      if(!_axeSkinBldGrd['ba_gokkusagi_h']){const g=c.createLinearGradient(26,-76,38,36);g.addColorStop(0,'#ff0000');g.addColorStop(0.2,'#ff8800');g.addColorStop(0.4,'#ffff00');g.addColorStop(0.6,'#00cc00');g.addColorStop(0.8,'#0088ff');g.addColorStop(1,'#8800ff');_axeSkinBldGrd['ba_gokkusagi_h']=g;}
      const hgr=_axeSkinBldGrd['ba_gokkusagi_h'];
      c.fillStyle=hgr;c.strokeStyle='rgba(255,255,255,0.5)';c.lineWidth=3;c.beginPath();c.roundRect(26,-76,12,112,3);c.fill();c.stroke();
      c.fillStyle='#ff00ff';c.strokeStyle='#8800cc';c.lineWidth=2;c.beginPath();c.ellipse(32,37,9,6,0,0,Math.PI*2);c.fill();c.stroke();
      if(!_axeSkinBldGrd['ba_gokkusagi']){const g=c.createLinearGradient(38,-80,96,-14);g.addColorStop(0,'#ff0000');g.addColorStop(0.17,'#ff8800');g.addColorStop(0.33,'#ffff00');g.addColorStop(0.5,'#00cc00');g.addColorStop(0.67,'#0088ff');g.addColorStop(0.83,'#8800ff');g.addColorStop(1,'#ff00ff');_axeSkinBldGrd['ba_gokkusagi']=g;}
      const rg=_axeSkinBldGrd['ba_gokkusagi'];
      if(ql>=2){c.shadowColor='rgba(200,100,255,0.4)';c.shadowBlur=12;}
      c.fillStyle=rg;c.strokeStyle='rgba(255,255,255,0.6)';c.lineWidth=2;
      c.beginPath();c.moveTo(38,-68);c.lineTo(72,-82);c.quadraticCurveTo(96,-54,78,-20);c.lineTo(56,-14);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      const scr=['#ffaaaa','#ffddaa','#ffffaa','#aaffaa','#aaccff','#ddaaff'];
      if(ql>=1){for(let i=0;i<6;i++){const sf=Math.sin(t*0.12+i*1.05)*0.5+0.5;c.fillStyle=scr[i];c.globalAlpha=0.3+sf*0.7;c.beginPath();c.arc(50+i*8,-64+i*8,3,0,Math.PI*2);c.fill();}c.globalAlpha=1;}
      c.strokeStyle='rgba(255,255,255,0.7)';c.lineWidth=2;c.beginPath();c.moveTo(70,-78);c.quadraticCurveTo(92,-52,76,-22);c.stroke();
      break;}
    case 'ba_neon':{
      handle('#080008','#180018','#ff00ff');
      const nfl2=Math.sin(t*0.22)*0.5+0.5;
      if(ql>=2){c.shadowColor=`rgba(255,0,255,${0.6+nfl2*0.4})`;c.shadowBlur=22;}
      const ng=c.createLinearGradient(36,-84,96,-14);ng.addColorStop(0,'#0d0005');ng.addColorStop(0.3,'#440055');ng.addColorStop(0.55,`rgba(255,0,255,${0.85+nfl2*0.15})`);ng.addColorStop(0.8,'#220033');ng.addColorStop(1,'#0d0005');
      c.fillStyle=ng;c.strokeStyle='#ff00cc';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(74,-82);c.quadraticCurveTo(96,-54,78,-20);c.lineTo(56,-14);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      if(ql>=2){c.save();c.shadowColor=`rgba(255,150,255,${0.8+nfl2*0.2})`;c.shadowBlur=14;c.strokeStyle=`rgba(255,180,255,${0.7+nfl2*0.3})`;c.lineWidth=2;c.lineCap='round';c.beginPath();c.moveTo(56,-78);c.lineTo(72,-62);c.lineTo(62,-50);c.lineTo(76,-36);c.lineTo(66,-24);c.stroke();c.strokeStyle='rgba(255,0,255,0.95)';c.lineWidth=2;c.beginPath();c.moveTo(70,-78);c.quadraticCurveTo(90,-52,74,-22);c.stroke();c.restore();}
      break;}
    case 'ba_kristal':{
      handle('#1a0840','#2a1268','#cc88ff');
      if(ql>=2){c.shadowColor='rgba(150,50,255,0.5)';c.shadowBlur=14;}
      if(!_axeSkinBldGrd['ba_kristal']){const g=c.createLinearGradient(36,-90,98,-14);g.addColorStop(0,'rgba(120,40,255,0.35)');g.addColorStop(0.25,'rgba(190,130,255,0.88)');g.addColorStop(0.5,'rgba(235,210,255,0.95)');g.addColorStop(0.75,'rgba(190,130,255,0.88)');g.addColorStop(1,'rgba(80,20,180,0.35)');_axeSkinBldGrd['ba_kristal']=g;}
      const kg=_axeSkinBldGrd['ba_kristal'];
      c.fillStyle=kg;c.strokeStyle='#8833cc';c.lineWidth=2;
      c.beginPath();c.moveTo(38,-24);c.lineTo(46,-48);c.lineTo(55,-44);c.lineTo(62,-70);c.lineTo(70,-66);c.lineTo(76,-90);c.lineTo(82,-82);c.lineTo(92,-58);c.lineTo(84,-52);c.lineTo(86,-34);c.lineTo(76,-18);c.lineTo(56,-12);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      c.strokeStyle='rgba(220,190,255,0.7)';c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(62,-70);c.lineTo(78,-46);c.lineTo(60,-22);c.stroke();
      c.beginPath();c.moveTo(70,-66);c.lineTo(82,-48);c.stroke();
      if(ql>=2){const sf=Math.sin(t*0.2+1)*0.5+0.5;c.fillStyle=`rgba(255,220,255,${0.5+sf*0.5})`;c.shadowColor='#cc00ff';c.shadowBlur=8;c.beginPath();c.arc(72,-50,4.5,0,Math.PI*2);c.fill();c.shadowBlur=0;}
      break;}
    case 'ba_galaksi':{
      handle('#04020c','#0e0530','#5566ff');
      const gfla=Math.sin(t*0.1)*0.5+0.5;
      if(ql>=2){c.shadowColor=`rgba(80,100,255,${0.4+gfla*0.3})`;c.shadowBlur=16;}
      if(!_axeSkinBldGrd['ba_galaksi']){const g=c.createLinearGradient(36,-84,96,-14);g.addColorStop(0,'#020008');g.addColorStop(0.3,'#0e0438');g.addColorStop(0.55,'#1a0860');g.addColorStop(0.75,'#080228');g.addColorStop(1,'#020008');_axeSkinBldGrd['ba_galaksi']=g;}
      const gg=_axeSkinBldGrd['ba_galaksi'];
      c.fillStyle=gg;c.strokeStyle='#3322aa';c.lineWidth=3;
      c.beginPath();c.moveTo(38,-68);c.lineTo(72,-84);c.quadraticCurveTo(96,-54,78,-20);c.lineTo(56,-14);c.lineTo(38,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      if(ql>=1){
        const spa=[[52,-76,1.2],[66,-64,1.5],[74,-50,1.2],[58,-44,1],[70,-34,1.4],[80,-44,1],[56,-56,1.3],[68,-72,1.1]];
        for(const[px,py,sr]of spa){const sf=Math.sin(t*0.15+px*0.08+py*0.08)*0.5+0.5;c.fillStyle=`rgba(180,210,255,${0.4+sf*0.6})`;c.beginPath();c.arc(px,py,sr+sf*0.8,0,Math.PI*2);c.fill();}
        c.strokeStyle=`rgba(120,80,255,${0.35+gfla*0.3})`;c.lineWidth=2;c.lineCap='round';c.beginPath();c.moveTo(56,-72);c.bezierCurveTo(72,-62,62,-50,78,-40);c.stroke();
        c.strokeStyle=`rgba(200,120,255,${0.25+gfla*0.2})`;c.lineWidth=1.5;c.beginPath();c.moveTo(60,-80);c.bezierCurveTo(74,-68,64,-56,80,-46);c.stroke();
      }
      break;}
    case 'ba_ay':{
      handle('#1a1000','#3a2808','#f5e060');
      const ayfl=Math.sin(t*0.08)*0.5+0.5;
      if(ql>=2){c.shadowColor=`rgba(255,220,60,${0.4+ayfl*0.3})`;c.shadowBlur=18;}
      c.strokeStyle='#ffe050';c.lineWidth=26;c.lineCap='round';c.beginPath();c.arc(62,-52,30,Math.PI*0.6,Math.PI*1.78,false);c.stroke();
      c.strokeStyle='#fff8c0';c.lineWidth=12;c.beginPath();c.arc(62,-52,30,Math.PI*0.65,Math.PI*1.72,false);c.stroke();
      c.strokeStyle='#c8a010';c.lineWidth=2;c.beginPath();c.arc(62,-52,44,Math.PI*0.58,Math.PI*1.8,false);c.stroke();
      c.beginPath();c.arc(62,-52,17,Math.PI*0.58,Math.PI*1.8,false);c.stroke();
      c.shadowBlur=0;
      c.fillStyle='rgba(200,160,30,0.35)';
      for(const[px,py,cr]of[[50,-76,3],[44,-58,2.5],[52,-46,3.5],[45,-38,2]]){c.beginPath();c.arc(px,py,cr,0,Math.PI*2);c.fill();}
      if(ql>=1){c.fillStyle='rgba(255,255,220,0.9)';c.strokeStyle='rgba(220,200,0,0.6)';c.lineWidth=1;c.save();c.translate(48,-72);c.beginPath();for(let i=0;i<5;i++){const a=i*Math.PI*2/5-Math.PI/2,ai=(i*2+1)*Math.PI*2/10-Math.PI/2;c.lineTo(Math.cos(a)*6,Math.sin(a)*6);c.lineTo(Math.cos(ai)*3,Math.sin(ai)*3);}c.closePath();c.fill();c.stroke();c.restore();}
      break;}
    default:{ drawAxeByTier(c,0,t); }
  }
  c.shadowBlur=0;
}

function drawSwordSkin(c, skinId, t){
  const fl=Math.sin(t*0.15)*0.5+0.5;
  const ql=_qualityLevel;
  // PERF: grip helper caches gradient by (col1,col2); guard helper caches by (col1,col2)
  const grip=(col1,col2,bnd)=>{
    const _gk=col1+'|'+col2;
    let hg=_swdSkinGrdC[_gk];
    if(!hg){hg=c.createLinearGradient(28,0,36,0);hg.addColorStop(0,col1);hg.addColorStop(0.5,col2);hg.addColorStop(1,col1);_swdSkinGrdC[_gk]=hg;}
    c.fillStyle=hg;c.strokeStyle='#111';c.lineWidth=3;c.beginPath();c.roundRect(28,-26,8,52,2);c.fill();c.stroke();
    c.strokeStyle=bnd;c.lineWidth=2.5;c.lineCap='round';
    for(let i=0;i<3;i++){c.beginPath();c.moveTo(27,-20+i*14);c.lineTo(37,-20+i*14);c.stroke();}
    c.fillStyle=bnd;c.strokeStyle='#111';c.lineWidth=2;c.beginPath();c.ellipse(32,27,7,5,0,0,Math.PI*2);c.fill();c.stroke();
  };
  const blade=(bg,sc)=>{c.fillStyle=bg;c.strokeStyle=sc;c.lineWidth=3;c.beginPath();c.moveTo(27,-30);c.lineTo(24,-75);c.quadraticCurveTo(32,-124,36,-114);c.lineTo(40,-75);c.lineTo(37,-30);c.closePath();c.fill();c.stroke();};
  const guard=(col1,col2)=>{const _ggk='g|'+col1+'|'+col2;let gc=_swdSkinGrdC[_ggk];if(!gc){gc=c.createLinearGradient(14,-28,50,-28);gc.addColorStop(0,col1);gc.addColorStop(0.5,col2);gc.addColorStop(1,col1);_swdSkinGrdC[_ggk]=gc;}c.fillStyle=gc;c.strokeStyle='rgba(0,0,0,.5)';c.lineWidth=2;c.beginPath();c.moveTo(14,-28);c.lineTo(50,-28);c.lineTo(50,-22);c.lineTo(14,-22);c.closePath();c.fill();c.stroke();};
  switch(skinId){
    case 'ki_demir':{
      grip('#3a3a48','#6a6a78','#8888a0');
      guard('#5a5a6a','#8a8a98');
      for(const[px,py]of[[20,-25],[32,-25],[44,-25]]){c.fillStyle='#888899';c.strokeStyle='#444455';c.lineWidth=1;c.beginPath();c.arc(px,py,3,0,Math.PI*2);c.fill();c.stroke();}
      if(!_swdSkinGrdC['b|ki_demir']){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#5a6068');g.addColorStop(0.5,'#c0c8d0');g.addColorStop(1,'#5a6068');_swdSkinGrdC['b|ki_demir']=g;}
      const bg=_swdSkinGrdC['b|ki_demir'];
      blade(bg,'#303840');
      c.strokeStyle='rgba(200,210,220,.7)';c.lineWidth=1.5;c.beginPath();c.moveTo(33,-36);c.lineTo(33,-112);c.stroke();
      break;}
    case 'ki_katana':{
      if(!_swdSkinGrdC['h|ki_katana']){const g=c.createLinearGradient(28,0,36,0);g.addColorStop(0,'#1a1008');g.addColorStop(0.5,'#2a1810');g.addColorStop(1,'#1a1008');_swdSkinGrdC['h|ki_katana']=g;}
      const hg=_swdSkinGrdC['h|ki_katana'];
      c.fillStyle=hg;c.strokeStyle='#0a0806';c.lineWidth=3;c.beginPath();c.roundRect(29,-26,7,58,2);c.fill();c.stroke();
      c.strokeStyle='#c8a040';c.lineWidth=1.5;
      for(let i=0;i<7;i++){c.beginPath();c.moveTo(29,-18+i*8);c.lineTo(36,-22+i*8);c.stroke();c.beginPath();c.moveTo(36,-18+i*8);c.lineTo(29,-22+i*8);c.stroke();}
      c.fillStyle='#c8a040';c.beginPath();c.ellipse(32,-10,4,2,0,0,Math.PI*2);c.fill();
      c.fillStyle='#2a2018';c.strokeStyle='#c8a040';c.lineWidth=2;c.beginPath();c.ellipse(32,-26,18,5,0.1,0,Math.PI*2);c.fill();c.stroke();
      c.strokeStyle='#c8a040';c.lineWidth=1;c.beginPath();c.ellipse(32,-26,12,3.5,0.1,0,Math.PI*2);c.stroke();
      if(!_swdSkinGrdC['b|ki_katana']){const g=c.createLinearGradient(28,-30,38,-30);g.addColorStop(0,'#3a3840');g.addColorStop(0.3,'#8a8890');g.addColorStop(0.5,'#e8eaf0');g.addColorStop(0.7,'#a8a8b0');g.addColorStop(1,'#4a4850');_swdSkinGrdC['b|ki_katana']=g;}
      const bg=_swdSkinGrdC['b|ki_katana'];
      c.fillStyle=bg;c.strokeStyle='#303035';c.lineWidth=2;
      c.beginPath();c.moveTo(29,-30);c.lineTo(27,-78);c.quadraticCurveTo(31,-128,34,-118);c.lineTo(38,-78);c.lineTo(36,-30);c.closePath();c.fill();c.stroke();
      c.strokeStyle='rgba(200,210,220,.65)';c.lineWidth=1.5;c.beginPath();c.moveTo(34,-36);c.quadraticCurveTo(36,-60,33,-80);c.quadraticCurveTo(30,-100,32,-114);c.stroke();
      break;}
    case 'ki_genis':{
      grip('#2a1a0a','#4a3020','#8B6914');
      if(!_swdSkinGrdC['gc|ki_genis']){const g=c.createLinearGradient(8,-28,56,-28);g.addColorStop(0,'#4a4a58');g.addColorStop(0.5,'#8a8a98');g.addColorStop(1,'#4a4a58');_swdSkinGrdC['gc|ki_genis']=g;}
      const gc=_swdSkinGrdC['gc|ki_genis'];
      c.fillStyle=gc;c.strokeStyle='#303038';c.lineWidth=2;
      c.beginPath();c.moveTo(8,-24);c.quadraticCurveTo(14,-34,32,-30);c.quadraticCurveTo(50,-34,56,-24);c.quadraticCurveTo(50,-16,32,-20);c.quadraticCurveTo(14,-16,8,-24);c.closePath();c.fill();c.stroke();
      if(!_swdSkinGrdC['b|ki_genis']){const g=c.createLinearGradient(20,-30,46,-30);g.addColorStop(0,'#5a5a68');g.addColorStop(0.3,'#b0b0c0');g.addColorStop(0.5,'#e8e8f0');g.addColorStop(0.7,'#b0b0c0');g.addColorStop(1,'#5a5a68');_swdSkinGrdC['b|ki_genis']=g;}
      const bg=_swdSkinGrdC['b|ki_genis'];
      c.fillStyle=bg;c.strokeStyle='#383840';c.lineWidth=3;
      c.beginPath();c.moveTo(22,-30);c.lineTo(18,-72);c.quadraticCurveTo(32,-118,36,-108);c.lineTo(46,-72);c.lineTo(42,-30);c.closePath();c.fill();c.stroke();
      c.strokeStyle='rgba(180,185,200,.7)';c.lineWidth=1.5;c.beginPath();c.moveTo(29,-36);c.lineTo(29,-105);c.stroke();c.beginPath();c.moveTo(35,-36);c.lineTo(35,-105);c.stroke();
      break;}
    case 'ki_ince':{
      if(!_swdSkinGrdC['h|ki_ince']){const g=c.createLinearGradient(29,0,36,0);g.addColorStop(0,'#3a1a08');g.addColorStop(0.5,'#5a2e14');g.addColorStop(1,'#3a1a08');_swdSkinGrdC['h|ki_ince']=g;}
      const hg=_swdSkinGrdC['h|ki_ince'];
      c.fillStyle=hg;c.strokeStyle='#1a0a04';c.lineWidth=3;c.beginPath();c.roundRect(29,-26,6,54,3);c.fill();c.stroke();
      c.strokeStyle='rgba(200,170,100,.55)';c.lineWidth=1.5;for(let i=0;i<8;i++){c.beginPath();c.moveTo(29,-18+i*6);c.lineTo(35,-18+i*6);c.stroke();}
      c.fillStyle='#4a3820';c.strokeStyle='#c8a040';c.lineWidth=1.5;c.beginPath();c.ellipse(32,-28,20,7,0,0,Math.PI*2);c.fill();c.stroke();
      c.strokeStyle='#c8a040';c.lineWidth=2;c.lineCap='round';
      c.beginPath();c.moveTo(12,-30);c.quadraticCurveTo(22,-22,32,-28);c.stroke();c.beginPath();c.moveTo(52,-30);c.quadraticCurveTo(42,-22,32,-28);c.stroke();
      c.fillStyle='#aa44ff';c.strokeStyle='#6600cc';c.lineWidth=1;c.beginPath();c.arc(32,-28,4,0,Math.PI*2);c.fill();c.stroke();
      if(!_swdSkinGrdC['b|ki_ince']){const g=c.createLinearGradient(30,-30,35,-30);g.addColorStop(0,'#5a6070');g.addColorStop(0.5,'#e0e4ec');g.addColorStop(1,'#5a6070');_swdSkinGrdC['b|ki_ince']=g;}
      const bg=_swdSkinGrdC['b|ki_ince'];
      c.fillStyle=bg;c.strokeStyle='#2a3040';c.lineWidth=2;
      c.beginPath();c.moveTo(30,-30);c.lineTo(29,-78);c.quadraticCurveTo(32,-128,35,-118);c.lineTo(34,-78);c.lineTo(34,-30);c.closePath();c.fill();c.stroke();
      break;}
    case 'ki_lanetli':{
      grip('#100808','#200f0f','rgba(160,0,0,.9)');
      c.fillStyle='#1a0a0a';c.strokeStyle='#880000';c.lineWidth=2;
      c.beginPath();c.moveTo(12,-24);c.lineTo(52,-24);c.lineTo(50,-32);c.lineTo(32,-28);c.lineTo(14,-32);c.closePath();c.fill();c.stroke();
      c.fillStyle='#c0b0a0';c.strokeStyle='#5a0000';c.lineWidth=1;c.beginPath();c.arc(32,-28,5,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='#1a0000';c.beginPath();c.arc(30,-28,1.5,0,Math.PI*2);c.fill();c.beginPath();c.arc(34,-28,1.5,0,Math.PI*2);c.fill();
      if(ql>=2){c.shadowColor='rgba(180,0,0,0.5)';c.shadowBlur=12;}
      if(!_swdSkinGrdC['b|ki_lanetli']){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#0f0000');g.addColorStop(0.3,'#2a0000');g.addColorStop(0.5,'#380000');g.addColorStop(0.7,'#1a0000');g.addColorStop(1,'#080000');_swdSkinGrdC['b|ki_lanetli']=g;}
      const bg=_swdSkinGrdC['b|ki_lanetli'];
      blade(bg,'#5a0000');c.shadowBlur=0;
      c.strokeStyle=`rgba(200,0,0,${0.6+fl*0.4})`;c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(30,-40);c.lineTo(34,-56);c.lineTo(30,-70);c.stroke();c.beginPath();c.moveTo(32,-75);c.lineTo(35,-88);c.lineTo(31,-95);c.stroke();
      break;}
    case 'ki_kutsal':{
      grip('#4a2800','#8a5010','#FFD700');
      if(ql>=2){c.shadowColor='rgba(255,255,180,.6)';c.shadowBlur=18;}
      if(!_swdSkinGrdC['gc|ki_kutsal']){const g=c.createLinearGradient(10,-28,54,-28);g.addColorStop(0,'#8B6914');g.addColorStop(0.5,'#FFD700');g.addColorStop(1,'#8B6914');_swdSkinGrdC['gc|ki_kutsal']=g;}
      const gc=_swdSkinGrdC['gc|ki_kutsal'];
      c.fillStyle=gc;c.strokeStyle='#8B6914';c.lineWidth=2;
      c.beginPath();c.moveTo(10,-24);c.quadraticCurveTo(22,-36,32,-30);c.quadraticCurveTo(42,-36,54,-24);c.quadraticCurveTo(42,-14,32,-18);c.quadraticCurveTo(22,-14,10,-24);c.closePath();c.fill();c.stroke();
      c.fillStyle='#FFD700';c.strokeStyle='#8B6914';c.lineWidth=1.5;
      for(const[px,py]of[[14,-26],[50,-26]]){c.beginPath();c.moveTo(px,py);c.lineTo(px-6*(px<32?-1:1),-38);c.lineTo(px,py-4);c.closePath();c.fill();c.stroke();}
      c.fillStyle='#eef8ff';c.strokeStyle='#aacce8';c.lineWidth=1.5;c.beginPath();c.moveTo(32,-22);c.lineTo(38,-28);c.lineTo(32,-34);c.lineTo(26,-28);c.closePath();c.fill();c.stroke();
      if(!_swdSkinGrdC['b|ki_kutsal']){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#d0d8f0');g.addColorStop(0.5,'#ffffff');g.addColorStop(1,'#d0d8f0');_swdSkinGrdC['b|ki_kutsal']=g;}
      const bg=_swdSkinGrdC['b|ki_kutsal'];
      blade(bg,'rgba(200,220,255,.8)');c.shadowBlur=0;
      c.strokeStyle='rgba(255,215,0,.6)';c.lineWidth=1.5;c.beginPath();c.moveTo(33,-40);c.lineTo(33,-112);c.stroke();
      c.strokeStyle='rgba(255,215,0,.4)';c.lineWidth=1;
      for(const[x1,y1,x2,y2]of[[27,-55,31,-55],[27,-70,31,-70],[33,-55,37,-55],[33,-70,37,-70]]){c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();}
      break;}
    case 'ki_buz':{
      if(!_swdSkinGrdC['h|ki_buz']){const g=c.createLinearGradient(28,0,36,0);g.addColorStop(0,'#2a4878');g.addColorStop(0.5,'#7ab0e0');g.addColorStop(1,'#2a4878');_swdSkinGrdC['h|ki_buz']=g;}
      const hg=_swdSkinGrdC['h|ki_buz'];
      c.fillStyle=hg;c.strokeStyle='#1a3060';c.lineWidth=3;c.beginPath();c.roundRect(28,-26,8,54,2);c.fill();c.stroke();
      c.strokeStyle='rgba(130,195,255,.55)';c.lineWidth=2;for(let i=0;i<4;i++){c.beginPath();c.moveTo(27,-16+i*10);c.lineTo(37,-16+i*10);c.stroke();}
      c.fillStyle='#7DF9FF';c.strokeStyle='#00AACC';c.lineWidth=2;c.beginPath();c.ellipse(32,29,8,5,0,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='rgba(160,225,255,.85)';c.strokeStyle='#00AACC';c.lineWidth=2;
      c.beginPath();c.moveTo(14,-26);c.lineTo(50,-26);c.lineTo(48,-32);c.lineTo(32,-30);c.lineTo(16,-32);c.closePath();c.fill();c.stroke();
      if(ql>=2){c.shadowColor='#00ccff';c.shadowBlur=14;}
      if(!_swdSkinGrdC['b|ki_buz']){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'rgba(60,150,255,.5)');g.addColorStop(0.3,'rgba(160,230,255,.95)');g.addColorStop(0.5,'rgba(210,250,255,.8)');g.addColorStop(0.7,'rgba(160,230,255,.95)');g.addColorStop(1,'rgba(60,150,255,.5)');_swdSkinGrdC['b|ki_buz']=g;}
      const bg=_swdSkinGrdC['b|ki_buz'];
      c.fillStyle=bg;c.strokeStyle='rgba(0,170,204,.8)';c.lineWidth=2;
      c.beginPath();c.moveTo(28,-30);c.lineTo(25,-68);c.lineTo(28,-90);c.lineTo(32,-126);c.lineTo(36,-90);c.lineTo(39,-68);c.lineTo(36,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      c.strokeStyle='rgba(200,245,255,.9)';c.lineWidth=1.5;c.beginPath();c.moveTo(33,-36);c.lineTo(33,-116);c.stroke();
      c.beginPath();c.moveTo(29,-50);c.lineTo(25,-60);c.stroke();c.beginPath();c.moveTo(35,-50);c.lineTo(39,-60);c.stroke();
      break;}
    case 'ki_yilan':{
      grip('#1a1408','#3a2c18','#c8a040');
      c.fillStyle='#2a8040';c.strokeStyle='#1a5020';c.lineWidth=2;
      c.beginPath();c.moveTo(14,-24);c.lineTo(50,-24);c.lineTo(52,-30);c.lineTo(32,-26);c.lineTo(12,-30);c.closePath();c.fill();c.stroke();
      c.fillStyle='#ffaa00';c.beginPath();c.arc(20,-27,2.5,0,Math.PI*2);c.fill();c.beginPath();c.arc(44,-27,2.5,0,Math.PI*2);c.fill();
      c.fillStyle='#0a0800';c.beginPath();c.arc(20,-27,1,0,Math.PI*2);c.fill();c.beginPath();c.arc(44,-27,1,0,Math.PI*2);c.fill();
      if(!_swdSkinGrdC['b|ki_yilan']){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#2a5a2a');g.addColorStop(0.35,'#5ab870');g.addColorStop(0.5,'#88e888');g.addColorStop(0.65,'#5ab870');g.addColorStop(1,'#2a5a2a');_swdSkinGrdC['b|ki_yilan']=g;}
      const bg=_swdSkinGrdC['b|ki_yilan'];
      c.fillStyle=bg;c.strokeStyle='#1a4420';c.lineWidth=2;
      c.beginPath();c.moveTo(30,-30);c.bezierCurveTo(36,-45,26,-60,32,-75);c.bezierCurveTo(38,-90,26,-104,32,-120);c.lineTo(34,-116);c.bezierCurveTo(36,-100,28,-88,34,-73);c.bezierCurveTo(40,-58,30,-44,36,-29);c.closePath();c.fill();c.stroke();
      c.strokeStyle='rgba(100,220,100,.45)';c.lineWidth=1;c.lineCap='round';
      for(let i=0;i<6;i++){const yy=-36-i*12,xoff=Math.sin(i*1.1)*3;c.beginPath();c.arc(32+xoff,yy,4,Math.PI,0);c.stroke();}
      c.strokeStyle='#ff2200';c.lineWidth=1.5;c.beginPath();c.moveTo(32,-116);c.lineTo(30,-124);c.stroke();c.beginPath();c.moveTo(32,-116);c.lineTo(34,-124);c.stroke();
      break;}
    case 'ki_yildirim':{
      grip('#0a0a18','#1a1a38','#4466ff');
      if(ql>=2){c.shadowColor=`rgba(80,140,255,${0.5+fl*0.5})`;c.shadowBlur=16;}
      if(!_swdSkinGrdC['gc|ki_yildirim']){const g=c.createLinearGradient(12,-28,52,-28);g.addColorStop(0,'#1a1a3a');g.addColorStop(0.5,'#4466cc');g.addColorStop(1,'#1a1a3a');_swdSkinGrdC['gc|ki_yildirim']=g;}
      const gc=_swdSkinGrdC['gc|ki_yildirim'];
      c.fillStyle=gc;c.strokeStyle='#2244aa';c.lineWidth=2;
      c.beginPath();c.moveTo(12,-24);c.lineTo(20,-32);c.lineTo(32,-28);c.lineTo(44,-32);c.lineTo(52,-24);c.lineTo(44,-20);c.lineTo(32,-24);c.lineTo(20,-20);c.closePath();c.fill();c.stroke();
      if(!_swdSkinGrdC['b|ki_yildirim']){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#1a1a40');g.addColorStop(0.35,'#4466bb');g.addColorStop(0.5,'rgba(130,180,255,0.95)');g.addColorStop(0.65,'#4466bb');g.addColorStop(1,'#1a1a40');_swdSkinGrdC['b|ki_yildirim']=g;}
      const bg=_swdSkinGrdC['b|ki_yildirim'];
      c.fillStyle=bg;c.strokeStyle='#2244aa';c.lineWidth=2;
      c.beginPath();c.moveTo(29,-30);c.lineTo(26,-52);c.lineTo(35,-52);c.lineTo(28,-74);c.lineTo(37,-74);c.lineTo(30,-96);c.lineTo(34,-92);c.lineTo(36,-114);c.lineTo(38,-110);c.lineTo(36,-88);c.lineTo(42,-88);c.lineTo(35,-66);c.lineTo(44,-66);c.lineTo(37,-44);c.lineTo(43,-44);c.lineTo(36,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      if(ql>=2){c.save();c.shadowColor='#88aaff';c.shadowBlur=8;
      c.strokeStyle=`rgba(180,210,255,${0.6+fl*0.4})`;c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(26,-52);c.lineTo(20,-48);c.stroke();c.beginPath();c.moveTo(44,-66);c.lineTo(50,-62);c.stroke();
      c.restore();}break;}
    case 'ki_cellat':{
      if(!_swdSkinGrdC['h|ki_cellat']){const g=c.createLinearGradient(28,0,36,0);g.addColorStop(0,'#1a1008');g.addColorStop(0.5,'#3a2818');g.addColorStop(1,'#1a1008');_swdSkinGrdC['h|ki_cellat']=g;}
      const hg=_swdSkinGrdC['h|ki_cellat'];
      c.fillStyle=hg;c.strokeStyle='#0a0804';c.lineWidth=4;c.beginPath();c.roundRect(26,-26,12,58,3);c.fill();c.stroke();
      c.fillStyle='#3a3840';c.strokeStyle='#1a1820';c.lineWidth=3;
      c.beginPath();c.moveTo(8,-22);c.lineTo(56,-22);c.lineTo(58,-32);c.lineTo(32,-28);c.lineTo(6,-32);c.closePath();c.fill();c.stroke();
      if(!_swdSkinGrdC['b|ki_cellat']){const g=c.createLinearGradient(16,-30,52,-30);g.addColorStop(0,'#3a3840');g.addColorStop(0.3,'#7a7880');g.addColorStop(0.5,'#c8c8d0');g.addColorStop(0.7,'#7a7880');g.addColorStop(1,'#3a3840');_swdSkinGrdC['b|ki_cellat']=g;}
      const bg=_swdSkinGrdC['b|ki_cellat'];
      c.fillStyle=bg;c.strokeStyle='#1a1820';c.lineWidth=3;
      c.beginPath();c.moveTo(18,-30);c.lineTo(16,-65);c.lineTo(14,-80);c.quadraticCurveTo(32,-110,40,-100);c.lineTo(48,-75);c.lineTo(50,-65);c.lineTo(48,-30);c.closePath();c.fill();c.stroke();
      c.strokeStyle='rgba(0,0,0,.5)';c.lineWidth=2;c.lineCap='round';c.beginPath();c.moveTo(24,-48);c.lineTo(28,-56);c.lineTo(22,-62);c.stroke();
      c.strokeStyle='rgba(220,225,235,.8)';c.lineWidth=2;c.beginPath();c.moveTo(16,-50);c.lineTo(15,-72);c.stroke();c.beginPath();c.moveTo(48,-50);c.lineTo(48,-70);c.stroke();
      break;}
    case 'ki_hayalet':{
      grip('#0a1418','#1a2838','rgba(100,200,255,.7)');
      if(ql>=2){c.shadowColor='rgba(100,200,255,.5)';c.shadowBlur=18;}
      c.fillStyle='rgba(100,180,255,.25)';c.strokeStyle='rgba(150,220,255,.6)';c.lineWidth=1.5;
      c.beginPath();c.moveTo(12,-24);c.lineTo(52,-24);c.lineTo(50,-32);c.lineTo(32,-30);c.lineTo(14,-32);c.closePath();c.fill();c.stroke();
      if(!_swdSkinGrdC['b|ki_hayalet']){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'rgba(60,140,220,.12)');g.addColorStop(0.3,'rgba(120,190,255,.4)');g.addColorStop(0.5,'rgba(200,240,255,.6)');g.addColorStop(0.7,'rgba(120,190,255,.4)');g.addColorStop(1,'rgba(60,140,220,.12)');_swdSkinGrdC['b|ki_hayalet']=g;}
      const bg=_swdSkinGrdC['b|ki_hayalet'];
      c.fillStyle=bg;c.strokeStyle='rgba(120,200,255,.55)';c.lineWidth=2;
      c.beginPath();c.moveTo(27,-30);c.lineTo(24,-75);c.quadraticCurveTo(32,-124,36,-114);c.lineTo(40,-75);c.lineTo(37,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      c.strokeStyle=`rgba(220,245,255,${0.4+fl*0.4})`;c.lineWidth=1;c.beginPath();c.moveTo(33,-36);c.lineTo(33,-114);c.stroke();
      break;}
    case 'ki_lav':{
      grip('#0a0500','#1a0d00','rgba(255,80,0,.9)');
      if(ql>=2){c.shadowColor=`rgba(255,60,0,${0.5+fl*0.5})`;c.shadowBlur=16;}
      c.fillStyle='#0a0500';c.strokeStyle='rgba(255,80,0,.7)';c.lineWidth=2;
      c.beginPath();c.moveTo(12,-24);c.lineTo(52,-24);c.lineTo(50,-32);c.lineTo(32,-28);c.lineTo(14,-32);c.closePath();c.fill();c.stroke();
      c.strokeStyle=`rgba(255,${120+Math.round(fl*100)},0,${0.8+fl*0.2})`;c.lineWidth=1.5;
      c.beginPath();c.moveTo(16,-28);c.lineTo(22,-24);c.lineTo(28,-28);c.stroke();c.beginPath();c.moveTo(36,-28);c.lineTo(42,-24);c.lineTo(48,-28);c.stroke();
      if(!_swdSkinGrdC['b|ki_lav']){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#050200');g.addColorStop(0.3,'#150800');g.addColorStop(0.5,'#250e00');g.addColorStop(0.7,'#150800');g.addColorStop(1,'#050200');_swdSkinGrdC['b|ki_lav']=g;}
      const bg=_swdSkinGrdC['b|ki_lav'];
      blade(bg,'#330a00');c.shadowBlur=0;
      if(ql>=2){c.save();c.shadowColor='#ff4400';c.shadowBlur=8;
      c.strokeStyle=`rgba(255,${80+Math.round(fl*140)},0,${0.7+fl*0.3})`;c.lineWidth=1.8;c.lineCap='round';
      c.beginPath();c.moveTo(31,-36);c.lineTo(28,-50);c.lineTo(31,-62);c.lineTo(28,-78);c.lineTo(31,-90);c.stroke();
      c.strokeStyle=`rgba(255,${60+Math.round(fl*100)},0,${0.5+fl*0.4})`;c.lineWidth=1;
      c.beginPath();c.moveTo(33,-44);c.lineTo(37,-56);c.lineTo(33,-68);c.stroke();
      c.restore();}break;}
    case 'ki_dondurma':{
      if(!_swdSkinGrdC['h|ki_dondurma']){const g=c.createLinearGradient(28,0,36,0);g.addColorStop(0,'#8B5e1a');g.addColorStop(0.5,'#d4a050');g.addColorStop(1,'#8B5e1a');_swdSkinGrdC['h|ki_dondurma']=g;}
      const hgd=_swdSkinGrdC['h|ki_dondurma'];
      c.fillStyle=hgd;c.strokeStyle='#5a3a0a';c.lineWidth=3;c.beginPath();c.roundRect(28,-26,8,54,2);c.fill();c.stroke();
      c.strokeStyle='rgba(80,48,8,0.5)';c.lineWidth=1;
      for(let i=0;i<4;i++){c.beginPath();c.moveTo(28,-18+i*10);c.lineTo(36,-18+i*10);c.stroke();}
      c.beginPath();c.moveTo(32,-26);c.lineTo(32,28);c.stroke();
      c.fillStyle='#c8a040';c.strokeStyle='#8B6800';c.lineWidth=2;c.beginPath();c.ellipse(32,29,7,5,0,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='#3a1408';c.strokeStyle='#2a0c04';c.lineWidth=2;c.beginPath();c.moveTo(14,-24);c.lineTo(50,-24);c.lineTo(50,-30);c.lineTo(32,-28);c.lineTo(14,-30);c.closePath();c.fill();c.stroke();
      if(!_swdSkinGrdC['b|ki_dondurma']){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#c87878');g.addColorStop(0.4,'#f0a8a8');g.addColorStop(0.5,'#ffd8d8');g.addColorStop(0.6,'#f0a8a8');g.addColorStop(1,'#c87878');_swdSkinGrdC['b|ki_dondurma']=g;}
      const icbg=_swdSkinGrdC['b|ki_dondurma'];
      c.fillStyle=icbg;c.strokeStyle='#6a2010';c.lineWidth=2;c.beginPath();c.roundRect(24,-122,16,94,4);c.fill();c.stroke();
      c.fillStyle='#3a1408';
      for(const[dx,dy,dh]of[[-7,-30,18],[3,-30,14],[-7,-56,12],[3,-70,16],[-7,-90,10]]){c.beginPath();c.roundRect(32+dx,dy,7,dh,3);c.fill();}
      c.fillStyle='#3a1408';c.strokeStyle='#2a0c04';c.lineWidth=1.5;c.beginPath();c.roundRect(24,-122,16,8,3);c.fill();c.stroke();
      const spr=[['#ff6688',-100,-7],['#44aaff',-88,4],['#ffcc00',-76,-6],['#44ff88',-64,3],['#ff8844',-52,-7],['#cc44ff',-42,5]];
      for(const[col,py,rx]of spr){c.fillStyle=col;c.save();c.translate(32+rx,py);c.rotate(Math.sin(py)*0.8);c.beginPath();c.roundRect(-5,-1.5,10,3,2);c.fill();c.restore();}
      break;}
    case 'ki_lolipop':{
      if(!_swdSkinGrdC['h|ki_lolipop']){const g=c.createLinearGradient(28,0,36,0);g.addColorStop(0,'#ee3355');g.addColorStop(0.5,'#ff8899');g.addColorStop(1,'#ee3355');_swdSkinGrdC['h|ki_lolipop']=g;}
      const hgl=_swdSkinGrdC['h|ki_lolipop'];
      c.fillStyle=hgl;c.strokeStyle='#bb1133';c.lineWidth=3;c.beginPath();c.roundRect(29,-26,7,60,3);c.fill();c.stroke();
      for(let i=0;i<5;i++){c.strokeStyle='rgba(255,255,255,0.5)';c.lineWidth=1.5;c.beginPath();c.moveTo(29,-10+i*8);c.lineTo(36,-10+i*8);c.stroke();}
      c.fillStyle='#dd2244';c.strokeStyle='#aa0022';c.lineWidth=2;c.beginPath();c.ellipse(32,35,6,5,0,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='#ffccdd';c.strokeStyle='#dd4488';c.lineWidth=2;c.beginPath();c.moveTo(18,-24);c.lineTo(46,-24);c.lineTo(44,-30);c.lineTo(32,-28);c.lineTo(20,-30);c.closePath();c.fill();c.stroke();
      c.strokeStyle='#ee3355';c.lineWidth=5;c.lineCap='round';c.beginPath();c.moveTo(32,-30);c.lineTo(32,-50);c.stroke();
      const lly=-85,llr=34;
      if(ql>=2){c.shadowColor='rgba(255,20,130,0.65)';c.shadowBlur=20;}
      c.fillStyle='#ff1493';c.strokeStyle='#cc0055';c.lineWidth=3;c.beginPath();c.arc(32,lly,llr,0,Math.PI*2);c.fill();c.stroke();
      c.shadowBlur=0;
      c.save();c.beginPath();c.arc(32,lly,llr-1,0,Math.PI*2);c.clip();
      for(let i=0;i<8;i++){c.fillStyle=i%2===0?'rgba(255,255,255,0.82)':'rgba(255,0,100,0.06)';c.beginPath();c.moveTo(32,lly);c.arc(32,lly,llr+2,i*Math.PI/4,(i+1)*Math.PI/4);c.closePath();c.fill();}
      c.fillStyle='rgba(255,255,255,0.25)';c.beginPath();c.arc(32,lly,10,0,Math.PI*2);c.fill();
      c.restore();
      c.fillStyle='rgba(255,255,255,0.4)';c.beginPath();c.ellipse(21,lly-12,11,8,-0.5,0,Math.PI*2);c.fill();
      break;}
    case 'ki_kalem':{
      c.fillStyle='#f4a8b0';c.strokeStyle='#c07880';c.lineWidth=2;c.beginPath();c.roundRect(27,16,10,14,2);c.fill();c.stroke();
      c.fillStyle='#b8b8c0';c.strokeStyle='#888898';c.lineWidth=1.5;c.beginPath();c.roundRect(26,10,12,8,1);c.fill();c.stroke();
      if(!_swdSkinGrdC['h|ki_kalem']){const g=c.createLinearGradient(27,0,37,0);g.addColorStop(0,'#d4a010');g.addColorStop(0.15,'#f5c820');g.addColorStop(0.5,'#ffe050');g.addColorStop(0.85,'#f5c820');g.addColorStop(1,'#d4a010');_swdSkinGrdC['h|ki_kalem']=g;}
      const ygk=_swdSkinGrdC['h|ki_kalem'];
      c.fillStyle=ygk;c.strokeStyle='#a07810';c.lineWidth=2;c.beginPath();c.roundRect(27,-26,10,38,1);c.fill();c.stroke();
      c.strokeStyle='rgba(180,140,0,0.35)';c.lineWidth=1;for(let i=0;i<4;i++){c.beginPath();c.moveTo(27,-18+i*8);c.lineTo(37,-18+i*8);c.stroke();}
      c.fillStyle='#a07810';c.strokeStyle='#806000';c.lineWidth=2;c.beginPath();c.roundRect(26,-30,12,5,1);c.fill();c.stroke();
      c.fillStyle='#3a3040';c.strokeStyle='#222030';c.lineWidth=2;c.beginPath();c.moveTo(14,-26);c.lineTo(50,-26);c.lineTo(48,-22);c.lineTo(32,-24);c.lineTo(16,-22);c.closePath();c.fill();c.stroke();
      c.fillStyle='#c8a060';c.strokeStyle='#8a6030';c.lineWidth=2;
      c.beginPath();c.moveTo(27,-30);c.lineTo(25,-60);c.lineTo(32,-90);c.lineTo(39,-60);c.lineTo(37,-30);c.closePath();c.fill();c.stroke();
      c.strokeStyle='rgba(200,170,100,0.4)';c.lineWidth=1;c.beginPath();c.moveTo(29,-32);c.lineTo(27,-58);c.stroke();
      c.fillStyle='#303030';c.strokeStyle='#111';c.lineWidth=1.5;
      c.beginPath();c.moveTo(28,-80);c.lineTo(32,-126);c.lineTo(36,-80);c.closePath();c.fill();c.stroke();
      c.strokeStyle='rgba(255,255,255,0.3)';c.lineWidth=1;c.beginPath();c.moveTo(30,-82);c.lineTo(30,-62);c.stroke();
      break;}
    case 'ki_bambu':{
      if(!_swdSkinGrdC['h|ki_bambu']){const g=c.createLinearGradient(28,0,36,0);g.addColorStop(0,'#2a7a18');g.addColorStop(0.5,'#5aaa30');g.addColorStop(1,'#2a7a18');_swdSkinGrdC['h|ki_bambu']=g;}
      const hgb=_swdSkinGrdC['h|ki_bambu'];
      c.fillStyle=hgb;c.strokeStyle='#1a4a0c';c.lineWidth=2;c.beginPath();c.roundRect(27,-26,10,56,2);c.fill();c.stroke();
      for(let i=0;i<3;i++){c.fillStyle='#1a5a10';c.strokeStyle='#0e3808';c.lineWidth=2;c.beginPath();c.roundRect(26,-10+i*12,12,4,2);c.fill();c.stroke();}
      c.fillStyle='#1a5a10';c.strokeStyle='#0e3808';c.lineWidth=2;c.beginPath();c.ellipse(32,32,7,5,0,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='#1a4a0c';c.strokeStyle='#0a2806';c.lineWidth=2;c.beginPath();c.moveTo(14,-24);c.lineTo(50,-24);c.lineTo(48,-30);c.lineTo(32,-28);c.lineTo(16,-30);c.closePath();c.fill();c.stroke();
      if(ql>=2){c.shadowColor='rgba(60,180,20,0.3)';c.shadowBlur=8;}
      if(!_swdSkinGrdC['b|ki_bambu']){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#2a7a18');g.addColorStop(0.15,'#4aaa2a');g.addColorStop(0.5,'#7acc44');g.addColorStop(0.85,'#4aaa2a');g.addColorStop(1,'#2a7a18');_swdSkinGrdC['b|ki_bambu']=g;}
      const bbg=_swdSkinGrdC['b|ki_bambu'];
      c.fillStyle=bbg;c.strokeStyle='#1a4a0c';c.lineWidth=2;
      c.beginPath();c.moveTo(27,-30);c.lineTo(24,-75);c.quadraticCurveTo(32,-124,36,-114);c.lineTo(40,-75);c.lineTo(37,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      for(const py of[-45,-65,-85,-105]){c.fillStyle='#1a4a0c';c.strokeStyle='#0a2806';c.lineWidth=1.5;c.beginPath();c.roundRect(25,py-1,14,3,2);c.fill();c.stroke();}
      c.strokeStyle='rgba(150,255,80,0.4)';c.lineWidth=1.5;c.beginPath();c.moveTo(29,-36);c.lineTo(28,-108);c.stroke();
      break;}
    case 'ki_gokkusagi':{
      if(!_swdSkinGrdC['h|ki_gokkusagi']){const g=c.createLinearGradient(28,-26,36,30);g.addColorStop(0,'#ff0000');g.addColorStop(0.2,'#ff8800');g.addColorStop(0.4,'#ffff00');g.addColorStop(0.6,'#00cc00');g.addColorStop(0.8,'#0088ff');g.addColorStop(1,'#8800ff');_swdSkinGrdC['h|ki_gokkusagi']=g;}
      const hgrk=_swdSkinGrdC['h|ki_gokkusagi'];
      c.fillStyle=hgrk;c.strokeStyle='rgba(255,255,255,0.4)';c.lineWidth=3;c.beginPath();c.roundRect(28,-26,8,56,2);c.fill();c.stroke();
      for(let i=0;i<3;i++){c.strokeStyle='rgba(255,255,255,0.35)';c.lineWidth=1.5;c.beginPath();c.moveTo(27,-16+i*14);c.lineTo(37,-16+i*14);c.stroke();}
      c.fillStyle='#ff00ff';c.strokeStyle='#8800cc';c.lineWidth=2;c.beginPath();c.ellipse(32,31,7,5,0,0,Math.PI*2);c.fill();c.stroke();
      if(!_swdSkinGrdC['gc|ki_gokkusagi']){const g=c.createLinearGradient(14,-28,50,-28);g.addColorStop(0,'#ff0000');g.addColorStop(0.5,'#00ffff');g.addColorStop(1,'#ff00ff');_swdSkinGrdC['gc|ki_gokkusagi']=g;}
      const rg2k=_swdSkinGrdC['gc|ki_gokkusagi'];
      c.fillStyle=rg2k;c.strokeStyle='rgba(0,0,0,0.4)';c.lineWidth=2;c.beginPath();c.moveTo(14,-22);c.lineTo(50,-22);c.lineTo(50,-28);c.lineTo(14,-28);c.closePath();c.fill();c.stroke();
      if(!_swdSkinGrdC['b|ki_gokkusagi']){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#ff0000');g.addColorStop(0.2,'#ff8800');g.addColorStop(0.4,'#ffff00');g.addColorStop(0.6,'#00cc00');g.addColorStop(0.8,'#0088ff');g.addColorStop(1,'#8800ff');_swdSkinGrdC['b|ki_gokkusagi']=g;}
      const rbg=_swdSkinGrdC['b|ki_gokkusagi'];
      if(ql>=2){c.shadowColor='rgba(200,100,255,0.4)';c.shadowBlur=12;}
      c.fillStyle=rbg;c.strokeStyle='rgba(255,255,255,0.5)';c.lineWidth=2;
      c.beginPath();c.moveTo(27,-30);c.lineTo(24,-75);c.quadraticCurveTo(32,-124,36,-114);c.lineTo(40,-75);c.lineTo(37,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      const sc2k=['#ff8888','#ffcc88','#ffff88','#88ff88','#88aaff','#cc88ff'];
      if(ql>=1){for(let i=0;i<6;i++){const sf=Math.sin(t*0.12+i*1.05)*0.5+0.5;c.fillStyle=sc2k[i];c.globalAlpha=0.3+sf*0.7;c.beginPath();c.arc(26+i*1.5,-38-i*10,2.5,0,Math.PI*2);c.fill();}c.globalAlpha=1;}
      c.strokeStyle='rgba(255,255,255,0.7)';c.lineWidth=1.5;c.beginPath();c.moveTo(34,-36);c.lineTo(34,-112);c.stroke();
      break;}
    case 'ki_neon':{
      grip('#050005','#120012','rgba(255,0,220,0.9)');
      const nfl3=Math.sin(t*0.22)*0.5+0.5;
      if(ql>=2){c.shadowColor=`rgba(255,0,220,${0.6+nfl3*0.4})`;c.shadowBlur=22;}
      c.fillStyle='#0d0005';c.strokeStyle='rgba(255,0,220,0.7)';c.lineWidth=2;c.beginPath();c.moveTo(12,-22);c.lineTo(52,-22);c.lineTo(50,-30);c.lineTo(32,-28);c.lineTo(14,-30);c.closePath();c.fill();c.stroke();
      const ng2=c.createLinearGradient(24,-30,40,-30);ng2.addColorStop(0,'rgba(40,0,40,0.95)');ng2.addColorStop(0.3,'rgba(180,0,180,0.9)');ng2.addColorStop(0.5,`rgba(255,0,220,${0.85+nfl3*0.15})`);ng2.addColorStop(0.7,'rgba(180,0,180,0.9)');ng2.addColorStop(1,'rgba(40,0,40,0.95)');
      c.fillStyle=ng2;c.strokeStyle='#ff00cc';c.lineWidth=2;
      c.beginPath();c.moveTo(27,-30);c.lineTo(24,-75);c.quadraticCurveTo(32,-124,36,-114);c.lineTo(40,-75);c.lineTo(37,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      if(ql>=2){c.save();c.shadowColor=`rgba(255,180,255,${0.8+nfl3*0.2})`;c.shadowBlur=14;c.strokeStyle=`rgba(255,180,255,${0.6+nfl3*0.4})`;c.lineWidth=1.5;c.lineCap='round';c.beginPath();c.moveTo(30,-40);c.lineTo(34,-60);c.lineTo(30,-80);c.lineTo(33,-100);c.stroke();c.strokeStyle='rgba(255,0,220,0.9)';c.lineWidth=2;c.beginPath();c.moveTo(34,-36);c.lineTo(34,-112);c.stroke();c.restore();}
      break;}
    case 'ki_candy':{
      if(!_swdSkinGrdC['h|ki_candy']){const g=c.createLinearGradient(28,0,36,0);g.addColorStop(0,'#cc0000');g.addColorStop(0.5,'#ffffff');g.addColorStop(1,'#cc0000');_swdSkinGrdC['h|ki_candy']=g;}
      const hgc=_swdSkinGrdC['h|ki_candy'];
      c.fillStyle=hgc;c.strokeStyle='#880000';c.lineWidth=3;c.beginPath();c.roundRect(28,-26,8,56,2);c.fill();c.stroke();
      c.save();c.beginPath();c.roundRect(28,-26,8,56,2);c.clip();c.strokeStyle='#cc0000';c.lineWidth=3;for(let i=0;i<10;i++){c.beginPath();c.moveTo(22,-32+i*10);c.lineTo(42,-22+i*10);c.stroke();}c.restore();
      c.strokeStyle='#880000';c.lineWidth=2;c.beginPath();c.roundRect(28,-26,8,56,2);c.stroke();
      c.fillStyle='#cc0000';c.strokeStyle='#880000';c.lineWidth=2;c.beginPath();c.ellipse(32,31,7,5,0,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='#ffffff';c.strokeStyle='#cc0000';c.lineWidth=2;c.beginPath();c.moveTo(12,-22);c.lineTo(52,-22);c.lineTo(52,-28);c.lineTo(12,-28);c.closePath();c.fill();c.stroke();
      for(let i=0;i<4;i++){c.fillStyle='#cc0000';c.beginPath();c.arc(18+i*10,-25,2,0,Math.PI*2);c.fill();}
      if(!_swdSkinGrdC['b|ki_candy']){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#cc0000');g.addColorStop(0.5,'#ffffff');g.addColorStop(1,'#cc0000');_swdSkinGrdC['b|ki_candy']=g;}
      const cbg=_swdSkinGrdC['b|ki_candy'];
      c.fillStyle=cbg;c.strokeStyle='#880000';c.lineWidth=2;
      c.beginPath();c.moveTo(27,-30);c.lineTo(24,-75);c.quadraticCurveTo(32,-124,36,-114);c.lineTo(40,-75);c.lineTo(37,-30);c.closePath();c.fill();c.stroke();
      c.save();c.beginPath();c.moveTo(27,-30);c.lineTo(24,-75);c.quadraticCurveTo(32,-124,36,-114);c.lineTo(40,-75);c.lineTo(37,-30);c.closePath();c.clip();c.strokeStyle='rgba(204,0,0,0.65)';c.lineWidth=3;for(let i=0;i<14;i++){c.beginPath();c.moveTo(18,-28+i*8);c.lineTo(46,-20+i*8);c.stroke();}c.restore();
      c.strokeStyle='#880000';c.lineWidth=2;c.beginPath();c.moveTo(27,-30);c.lineTo(24,-75);c.quadraticCurveTo(32,-124,36,-114);c.lineTo(40,-75);c.lineTo(37,-30);c.closePath();c.stroke();
      c.strokeStyle='rgba(255,255,255,0.5)';c.lineWidth=1.5;c.beginPath();c.moveTo(33,-36);c.lineTo(33,-112);c.stroke();
      break;}
    case 'ki_galaksi':{
      grip('#040010','#0a0028','rgba(80,60,255,0.8)');
      const gfls=Math.sin(t*0.1)*0.5+0.5;
      if(ql>=2){c.shadowColor=`rgba(80,60,255,${0.5+gfls*0.4})`;c.shadowBlur=20;}
      c.fillStyle='#040010';c.strokeStyle='rgba(100,80,255,0.7)';c.lineWidth=2;c.beginPath();c.moveTo(12,-22);c.lineTo(52,-22);c.lineTo(50,-30);c.lineTo(32,-28);c.lineTo(14,-30);c.closePath();c.fill();c.stroke();
      if(!_swdSkinGrdC['b|ki_galaksi']){const g=c.createLinearGradient(24,-30,40,-30);g.addColorStop(0,'#020008');g.addColorStop(0.3,'#0e0440');g.addColorStop(0.5,'#1a0868');g.addColorStop(0.7,'#0e0440');g.addColorStop(1,'#020008');_swdSkinGrdC['b|ki_galaksi']=g;}
      const sgg=_swdSkinGrdC['b|ki_galaksi'];
      c.fillStyle=sgg;c.strokeStyle='#4433aa';c.lineWidth=2;
      c.beginPath();c.moveTo(27,-30);c.lineTo(24,-75);c.quadraticCurveTo(32,-124,36,-114);c.lineTo(40,-75);c.lineTo(37,-30);c.closePath();c.fill();c.stroke();
      c.shadowBlur=0;
      if(ql>=1){
        const sp2=[[-2,-40,1.2],[3,-55,1.5],[-1,-70,1.2],[4,-85,1.4],[-2,-100,1.1],[2,-112,1.3]];
        for(const[dx,py,sr]of sp2){const sf=Math.sin(t*0.18+py*0.08)*0.5+0.5;c.fillStyle=`rgba(200,180,255,${0.4+sf*0.6})`;c.beginPath();c.arc(32+dx,py,sr+sf*0.6,0,Math.PI*2);c.fill();}
        c.strokeStyle=`rgba(140,80,255,${0.4+gfls*0.3})`;c.lineWidth=2;c.lineCap='round';c.beginPath();c.moveTo(30,-40);c.quadraticCurveTo(34,-60,30,-80);c.quadraticCurveTo(34,-100,32,-116);c.stroke();
        c.strokeStyle=`rgba(100,80,255,${0.5+gfls*0.3})`;c.lineWidth=2;c.beginPath();c.moveTo(34,-36);c.lineTo(34,-112);c.stroke();
      }
      break;}
    default:{ drawSwordByTier(c,0,t); }
  }
  c.shadowBlur=0;
}

// ============================================================
// HAREKET İZİ — drawPlayerMovementTrail
// ============================================================
function drawPlayerMovementTrail(trailId, trail){
  if(!trail||trail.length<2||!trailId||trailId==='iz_none')return;
  const len=trail.length, ql=_qualityLevel;
  ctx.save();
  // Footprint stamp helper — draws a heel+toe oval rotated to movement direction,
  // offset left (side=0) or right (side=1) of the movement axis.
  const _fp=(i,side,alpha,sz)=>{
    if(alpha<0.02||sz<0.4)return;
    const t=trail[i], pt=trail[Math.max(0,i-1)];
    const ang=Math.atan2(t.y-pt.y,t.x-pt.x);
    const perp=ang+1.5708;
    const sOff=side?5:-5;
    ctx.globalAlpha=alpha;
    ctx.save();
    ctx.translate(t.x+Math.cos(perp)*sOff,t.y+Math.sin(perp)*sOff);
    ctx.rotate(ang);
    ctx.beginPath();ctx.ellipse(0,sz*0.3,sz*0.52,sz*0.82,0,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.ellipse(0,-sz*0.52,sz*0.68,sz*0.46,0,0,Math.PI*2);ctx.fill();
    ctx.restore();
  };
  switch(trailId){
    case 'iz_ates':{
      for(let i=1;i<len;i+=2){
        const f=i/len, a=f*0.72, sz=2.5+f*5, side=(i>>1)&1;
        ctx.fillStyle=f<0.4?'#cc2200':f<0.7?'#ff7800':'#ffdd00';
        _fp(i,side,a,sz);
        if(ql>=1&&f>0.5){ctx.globalAlpha=a*0.32;ctx.fillStyle='rgba(255,140,0,0.5)';ctx.beginPath();ctx.arc(trail[i].x,trail[i].y,sz*2.4,0,Math.PI*2);ctx.fill();}
      }
    }break;
    case 'iz_buz':{
      for(let i=1;i<len;i+=2){
        const f=i/len, a=f*0.65, sz=2.5+f*4.5, side=(i>>1)&1;
        ctx.fillStyle=`rgba(${120+f*120|0},222,255,0.92)`;
        _fp(i,side,a,sz);
        if(ql>=1&&f>0.55){const sx=trail[i].x,sy=trail[i].y;ctx.globalAlpha=a*0.75;ctx.fillStyle='rgba(220,250,255,0.88)';ctx.beginPath();ctx.moveTo(sx,sy-5);ctx.lineTo(sx+2,sy);ctx.lineTo(sx,sy+5);ctx.lineTo(sx-2,sy);ctx.closePath();ctx.fill();}
      }
    }break;
    case 'iz_yildirim':{
      for(let i=1;i<len;i+=2){
        const f=i/len, a=f*0.78, sz=2.5+f*4, side=(i>>1)&1;
        ctx.fillStyle=i%4===1?'rgba(140,190,255,0.92)':'rgba(255,255,80,0.95)';
        _fp(i,side,a,sz);
        if(ql>=1&&f>0.5){ctx.globalAlpha=a*0.55;ctx.strokeStyle='rgba(200,230,255,0.8)';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(trail[i].x,trail[i].y);ctx.lineTo(trail[i].x+(trail[i].r1-.5)*14,trail[i].y+(trail[i].r2-.5)*14);ctx.stroke();}
      }
    }break;
    case 'iz_golge':{
      for(let i=1;i<len;i+=2){
        const f=i/len, a=f*0.60, sz=3+f*5.5, side=(i>>1)&1;
        ctx.fillStyle=`rgba(${50+f*80|0},0,${140+f*80|0},0.88)`;
        _fp(i,side,a,sz);
        if(ql>=1&&f>0.5){ctx.globalAlpha=a*0.38;ctx.fillStyle='rgba(120,0,200,0.45)';ctx.beginPath();ctx.arc(trail[i].x,trail[i].y,sz*2,0,Math.PI*2);ctx.fill();}
      }
    }break;
    case 'iz_gokkusagi':{
      for(let i=1;i<len;i+=2){
        const f=i/len, hue=(globalTime*4+i*22)%360, side=(i>>1)&1;
        ctx.fillStyle=`hsl(${hue},100%,62%)`;
        _fp(i,side,f*0.78,2.5+f*4.5);
      }
    }break;
    case 'iz_duman':{
      for(let i=1;i<len;i+=2){
        const f=i/len, sz=5+f*9, g=120+f*70|0;
        ctx.globalAlpha=f*0.38;ctx.fillStyle=`rgba(${g},${g},${g},0.55)`;
        ctx.beginPath();ctx.arc(trail[i].x+(trail[i].r1-.5)*5,trail[i].y+(trail[i].r2-.5)*5,sz,0,Math.PI*2);ctx.fill();
      }
    }break;
    case 'iz_altin':{
      for(let i=1;i<len;i+=2){
        const f=i/len, a=f*0.68, sz=2.5+f*4, side=(i>>1)&1;
        ctx.fillStyle=`rgba(255,${185+f*60|0},0,0.95)`;
        _fp(i,side,a,sz);
        if(ql>=1&&f>0.55){ctx.globalAlpha=f*0.82;ctx.fillStyle='rgba(255,220,0,0.9)';const t=trail[i],s=trail[i].r3*2.5+1;ctx.beginPath();ctx.moveTo(t.x,t.y-s*2);ctx.lineTo(t.x+s,t.y);ctx.lineTo(t.x,t.y+s*2);ctx.lineTo(t.x-s,t.y);ctx.closePath();ctx.fill();}
      }
    }break;
    case 'iz_doga':{
      if(ql===0){
        for(let i=1;i<len;i+=2){const f=i/len;ctx.globalAlpha=f*0.75;ctx.fillStyle=`hsl(${95+f*45|0},70%,38%)`;ctx.beginPath();ctx.arc(trail[i].x,trail[i].y,5,0,Math.PI*2);ctx.fill();}
      }else{
        for(let i=1;i<len;i+=2){
          const f=i/len, rot=trail[i].r3*Math.PI*2, lz=trail[i].r1*3+4;
          ctx.globalAlpha=f*0.78;ctx.fillStyle=`hsl(${95+f*45|0},70%,38%)`;
          ctx.save();
          ctx.translate(trail[i].x+(trail[i].r1-.5)*10,trail[i].y+(trail[i].r2-.5)*10);
          ctx.rotate(rot);
          ctx.beginPath();ctx.ellipse(0,0,lz,lz*1.9,0,0,Math.PI*2);ctx.fill();
          ctx.restore();
        }
      }
    }break;
    case 'iz_neon':{
      if(ql>=1){ctx.shadowColor='#00ffcc';ctx.shadowBlur=10;}
      for(let i=1;i<len;i+=2){
        const f=i/len, side=(i>>1)&1;
        ctx.fillStyle=i%4===1?'rgba(0,255,210,0.95)':'rgba(0,190,255,0.95)';
        _fp(i,side,f*0.82,2.5+f*4);
      }
      ctx.shadowBlur=0;
    }break;
    case 'iz_kan':{
      for(let i=1;i<len;i+=2){
        const f=i/len, a=f*0.72, sz=2.5+f*4.5, side=(i>>1)&1;
        ctx.fillStyle=`rgba(${150+f*90|0},0,0,0.9)`;
        _fp(i,side,a,sz);
        if(ql>=1&&f>0.5&&trail[i].r1<0.4){ctx.globalAlpha=f*0.6;ctx.fillStyle=`rgba(180,0,0,${f*0.6})`;ctx.beginPath();ctx.arc(trail[i].x+(trail[i].r2-.5)*8,trail[i].y+(trail[i].r3-.5)*8,trail[i].r1*3+1.5,0,Math.PI*2);ctx.fill();}
      }
    }break;
    case 'iz_yildiz':{
      for(let i=1;i<len;i+=2){
        const f=i/len, t=trail[i], s=trail[i].r3*2+1.5;
        ctx.globalAlpha=f*0.88;ctx.fillStyle=`rgba(255,255,${170+f*85|0},0.95)`;
        ctx.beginPath();ctx.moveTo(t.x,t.y-s*2.5);ctx.lineTo(t.x+s*.7,t.y-s*.7);ctx.lineTo(t.x+s*2.5,t.y);ctx.lineTo(t.x+s*.7,t.y+s*.7);ctx.lineTo(t.x,t.y+s*2.5);ctx.lineTo(t.x-s*.7,t.y+s*.7);ctx.lineTo(t.x-s*2.5,t.y);ctx.lineTo(t.x-s*.7,t.y-s*.7);ctx.closePath();ctx.fill();
      }
    }break;
    case 'iz_bosluk':{
      for(let i=1;i<len;i+=2){
        const f=i/len, sz=3.5+f*6, side=(i>>1)&1;
        ctx.fillStyle=`rgba(${20+f*18|0},0,${40+f*30|0},0.88)`;
        _fp(i,side,f*0.65,sz);
        if(ql>=1&&f>0.5){ctx.globalAlpha=f*0.55;ctx.fillStyle=`rgba(${130+trail[i].r1*80|0},0,255,0.55)`;ctx.beginPath();ctx.arc(trail[i].x+(trail[i].r2-.5)*16,trail[i].y+(trail[i].r3-.5)*16,trail[i].r1*2.5+1,0,Math.PI*2);ctx.fill();}
      }
    }break;
    case 'iz_sakura':{
      for(let i=1;i<len;i+=2){
        const f=i/len, rot=trail[i].r3*Math.PI*2, ps=trail[i].r1*2+3;
        const g=152+trail[i].r2*70|0, b=175+trail[i].r3*60|0;
        ctx.fillStyle=`rgba(255,${g},${b},0.9)`;
        ctx.globalAlpha=f*0.82;
        ctx.save();
        ctx.translate(trail[i].x+(trail[i].r1-.5)*14,trail[i].y+(trail[i].r2-.5)*14-i*0.35);
        ctx.rotate(rot);
        ctx.beginPath();ctx.ellipse(-ps*.5,0,ps,ps*.55,-0.3,0,Math.PI*2);ctx.fill();
        ctx.beginPath();ctx.ellipse(ps*.5,0,ps,ps*.55,0.3,0,Math.PI*2);ctx.fill();
        ctx.restore();
      }
    }break;
    case 'iz_aurora':{
      for(let i=1;i<len;i+=2){
        const f=i/len, hue=(globalTime*2+i*16)%360, sz=3+f*5, side=(i>>1)&1;
        ctx.fillStyle=`hsl(${hue},90%,65%)`;
        _fp(i,side,f*0.62,sz);
        if(ql>=1){ctx.globalAlpha=f*0.28;ctx.fillStyle=`hsla(${(hue+120)%360},80%,75%,0.6)`;ctx.beginPath();ctx.arc(trail[i].x,trail[i].y,sz*1.4,0,Math.PI*2);ctx.fill();}
      }
    }break;
    case 'iz_zehir':{
      for(let i=1;i<len;i+=2){
        const f=i/len, sz=2.5+f*4.5, side=(i>>1)&1;
        ctx.fillStyle=`rgba(${50+f*70|0},${180+f*65|0},0,0.9)`;
        _fp(i,side,f*0.68,sz);
        if(ql>=1&&f>0.5&&trail[i].r1<0.5){ctx.globalAlpha=f*0.55;ctx.fillStyle=`rgba(100,255,0,${f*0.55})`;ctx.beginPath();ctx.arc(trail[i].x+(trail[i].r2-.5)*10,trail[i].y+(trail[i].r3-.5)*10,trail[i].r1*4+2,0,Math.PI*2);ctx.fill();}
      }
    }break;
  }
  ctx.globalAlpha=1;ctx.shadowBlur=0;ctx.restore();
}

// Pre-allocated trail objects — reused instead of creating {x,y,r1,r2,r3} every frame
const _TRAIL_OBJ_POOL = Array.from({length: 16}, () => ({x:0, y:0, r1:0, r2:0, r3:0}));
let _playerMoveTrail = [];
let floatingTexts = [];
// Zero-GC Floating Text Pool
const _FT_POOL_SZ = 48;
const _ftFreePool = Array.from({length: _FT_POOL_SZ}, () => ({ x:0, y:0, text:'', alpha:1, life:0, color:'#fff', big:false }));
function pushFloatingText(x, y, text, color, isBig, life) {
  if (typeof camX === 'number' && typeof canvas === 'object' && canvas.width > 0) {
    const _z = typeof ZOOM === 'number' ? ZOOM : 0.5;
    const _hw = (canvas.width * 0.5) / _z + 120, _hh = (canvas.height * 0.5) / _z + 100;
    const _cx = camX + canvas.width * 0.5, _cy = camY + canvas.height * 0.5;
    if (Math.abs(x - _cx) > _hw || Math.abs(y - _cy) > _hh) return; // Viewport cull
  }
  const _cap = typeof _qualityLevel !== 'undefined' && _qualityLevel === 0 ? 8 : typeof _qualityLevel !== 'undefined' && _qualityLevel === 1 ? 14 : 22;
  if (floatingTexts.length >= _cap) {
    const _old = floatingTexts.shift();
    if (_ftFreePool.length < _FT_POOL_SZ) _ftFreePool.push(_old);
  }
  const ft = _ftFreePool.length > 0 ? _ftFreePool.pop() : { x:0, y:0, text:'', alpha:1, life:0, color:'#fff', big:false };
  ft.x = x; ft.y = y; ft.text = text; ft.color = color || '#fff'; ft.big = !!isBig;
  ft.life = life || (isBig ? 55 : 35); ft.alpha = 1;
  _ftNativePush(ft);
}
const _ftNativePush = Array.prototype.push.bind(floatingTexts);
floatingTexts.push = function(ft) {
  const _cap = typeof _qualityLevel !== 'undefined' && _qualityLevel === 0 ? 8 : typeof _qualityLevel !== 'undefined' && _qualityLevel === 1 ? 14 : 22;
  if (this.length >= _cap) {
    const _old = this.shift();
    if (_ftFreePool.length < _FT_POOL_SZ) _ftFreePool.push(_old);
  }
  if (ft && typeof ft === 'object') {
    const _pooled = _ftFreePool.pop();
    if (_pooled) {
      _pooled.x = ft.x || 0; _pooled.y = ft.y || 0; _pooled.text = ft.text || '';
      _pooled.alpha = ft.alpha == null ? 1 : ft.alpha; _pooled.life = ft.life || 35;
      _pooled.color = ft.color || '#fff'; _pooled.big = !!ft.big;
      return _ftNativePush(_pooled);
    }
  }
  return _ftNativePush(ft);
};
// Pre-interned stroke style strings for 6 alpha quantization steps — avoids rgba() allocation per floating text per frame
const _FT_STROKE_LUT = ['rgba(0,0,0,0)','rgba(0,0,0,0.2)','rgba(0,0,0,0.4)','rgba(0,0,0,0.6)','rgba(0,0,0,0.8)','rgba(0,0,0,1)'];
let buildings = [];
// O(1) bina arama — buildings.find() O(N) tarama yerine Map.get() kullan
// buildings dizisiyle DAIMA senkronize tutulur (push→set, splice→delete)
const _buildingsMap = new Map(); // _netId → bina nesnesi

// Çarpışma konfigürasyonu — hiçbir kaynağın içinden geçilmez
const _RES_COL_FRAC = { wood: 0.65, stone: 0.82, gold: 0.80, apple: 0.65, bush: 0.60, mushroom: 0.55, crystal: 0.60, hive: 0.58 };
const _BLD_RADII    = {3:34, 4:44, 5:65, 6:78, 7:32, 8:24, 9:52, 10:30};
const _P_COL_R      = 370; // oyuncu + en büyük kaynak yarıçapı + güvenlik payı
// checkHits içinde kullanılan sabit — her çağrıda yeniden oluşturulmamalı
const _RES_HIT_FRAC = { wood: 0.85, stone: 0.85, gold: 0.85, apple: 0.85, bush: 0.75, mushroom: 0.70, crystal: 0.75, hive: 0.75 };
// Sıfır-GC katı cisim havuzu: obje oluşturmak yerine alanları güncelleriz
const _SOLID_POOL = Array.from({length: 128}, () => ({x:0, y:0, rad:0}));
let _solidCount = 0;
// Pre-allocated visible-building category arrays — length=0 reused every frame (no GC)
const _vbGround = [], _vbSolid = [], _vbTall = [], _vbAll = [];
// Current world-space render bounds, refreshed once per frame before draw layers.
// Small world objects outside these bounds never reach the canvas renderer.
let _renderCullL = -Infinity, _renderCullR = Infinity;
let _renderCullT = -Infinity, _renderCullB = Infinity;
// ── Spatial Grid — O(1) building neighbor lookup for enemy collision ──
// Avoids O(N×M) full scan: with 10 000 buildings, each enemy only touches ~9 cells.
// PERF: Map<integer, array> replaces object{string: array} — no string key allocation per lookup.
var _sgBuckets = new Map(); // integer key → building array (reused, not reallocated)
var _resBuckets = new Map(); // integer key → resource array
var _sgTmp = [];             // reused building query result — zero-allocation per-frame
var _resTmp = [];            // reused resource query result — zero-allocation per-frame
var _SG_CELL = 180;          // world-units per grid cell (covers max bld radius + mob radius)
// ── Spatial grid throttle: only rebuild every N frames, not every frame ──────
let _sgRebuildTimer = 0;
// ── Ground details offscreen layer cache ──────────────────────────────────────
// Renders _GD items once to an offscreen canvas; blit each frame → ~200x faster
let _gdLayer = null, _gdLayerCtx = null;
let _gdCachedCamX = -99999, _gdCachedCamY = -99999, _gdCachedZoom = -1, _gdCachedQuality = -1;
// PERF: packed integer spatial key — avoids string allocation (_cx * 1000 + _cy, max cell ±40)
function _sgKey(cx, cy) { return (cx + 500) * 1000 + (cy + 500); }
function _sgRebuild() {
  // Clear all existing buckets (reuse arrays, no GC)
  _sgBuckets.forEach(function(arr) { arr.length = 0; });
  _resBuckets.forEach(function(arr) { arr.length = 0; });
  for (var _bi2 = 0; _bi2 < buildings.length; _bi2++) {
    var _bb = buildings[_bi2];
    if (!_bb || _bb.hp <= 0) continue;
    var _cx = (_bb.x / _SG_CELL) | 0, _cy = (_bb.y / _SG_CELL) | 0;
    var _k = _sgKey(_cx, _cy);
    var _bucket = _sgBuckets.get(_k);
    if (!_bucket) { _bucket = []; _sgBuckets.set(_k, _bucket); }
    _bucket.push(_bb);
  }
  for (var _ri2 = 0; _ri2 < resources.length; _ri2++) {
    var _rr = resources[_ri2];
    if (!_rr || _rr._destroyed) continue;
    var _rcx = (_rr.x / _SG_CELL) | 0, _rcy = (_rr.y / _SG_CELL) | 0;
    var _rk = _sgKey(_rcx, _rcy);
    var _rbucket = _resBuckets.get(_rk);
    if (!_rbucket) { _rbucket = []; _resBuckets.set(_rk, _rbucket); }
    _rbucket.push(_rr);
  }
}
function _sgQuery(ex, ey, r) {
  var _cx0 = ((ex - r) / _SG_CELL) | 0, _cx1 = ((ex + r) / _SG_CELL) | 0;
  var _cy0 = ((ey - r) / _SG_CELL) | 0, _cy1 = ((ey + r) / _SG_CELL) | 0;
  _sgTmp.length = 0;
  for (var _gx = _cx0; _gx <= _cx1; _gx++) {
    for (var _gy = _cy0; _gy <= _cy1; _gy++) {
      var _arr = _sgBuckets.get(_sgKey(_gx, _gy));
      if (_arr) for (var _ai = 0; _ai < _arr.length; _ai++) _sgTmp.push(_arr[_ai]);
    }
  }
  return _sgTmp;
}
function _resQuery(ex, ey, r) {
  var _cx0 = ((ex - r) / _SG_CELL) | 0, _cx1 = ((ex + r) / _SG_CELL) | 0;
  var _cy0 = ((ey - r) / _SG_CELL) | 0, _cy1 = ((ey + r) / _SG_CELL) | 0;
  _resTmp.length = 0;
  for (var _gx = _cx0; _gx <= _cx1; _gx++) {
    for (var _gy = _cy0; _gy <= _cy1; _gy++) {
      var _arr = _resBuckets.get(_sgKey(_gx, _gy));
      if (_arr) for (var _ai = 0; _ai < _arr.length; _ai++) _resTmp.push(_arr[_ai]);
    }
  }
  return _resTmp;
}
// Cached turret tier lookup arrays — one array per constant, not recreated in hot loop
const _TURRET_RANGES    = [340,380,420,470,530,600];
const _TURRET_COOLDOWNS = [70,60,50,40,30,20];

// Zone label cached data — avoids allocating a new array literal every frame
const _ZONE_LABEL_STRS = ['❄️ KIŞ','☀️ ÇÖL','🔥 LAV','🌿 ORMAN'];
const _ZONE_LABEL_MULS = [[0,-1],[1,0],[0,1],[-1,0]];
// PERF: Pre-built 256-step building HP bar color table — avoids rgb(${...}) string alloc per frame
// Replaces 3-branch template literal that ran for every visible damaged building every frame.
const _bHpColors = (function() {
  const t = new Array(256);
  for (let _i = 0; _i < 256; _i++) {
    const r = _i / 255;
    if (r > 0.6)      t[_i] = `rgb(${Math.round(255*(1-(r-0.6)/0.4))},210,40)`;
    else if (r > 0.3) t[_i] = `rgb(255,${Math.round(210*(r-0.3)/0.3)},40)`;
    else              t[_i] = `rgb(255,${Math.round(70*r/0.3)},40)`;
  }
  return t;
})();
// Cached regen interval — recomputed only when regenBonus changes
let _cachedRegenBonus = -1, _cachedRegenInterval = 3000;

// ── PERF: Shared OffscreenCanvas caches ─────────────────────────────────────
// _BODY_OC_CACHE: shared per (skinId+flashState). All players with same skin share one OC.
// Each re-renders every 6 frames to capture slow animations (tail, eye pulse etc).
const _BODY_OC_CACHE = new Map(); // key: `${skin}_${fl}` → { oc, age }
// _WING_OC_CACHE: one OC per wing type, re-renders every 3 frames for flap animation.
const _WING_OC_CACHE = new Map(); // key: wingId → { oc, age }
// _WING_COLORS: module-level constant — was created as a new object every drawPlayerWings call.

// PERF: Pre-computed unit circle for 12-sided dodecagon — eliminates 24 Math.sin/cos per call.
// Each drawRankBadge12 calls _drawDodecagon 8-12 times; with 10 players that's 80-120 trig calls/frame.
const _DODEC_COS = new Float32Array(12), _DODEC_SIN = new Float32Array(12);
(function(){const a0=-Math.PI/2; for(let i=0;i<12;i++){const a=a0+i*Math.PI/6; _DODEC_COS[i]=Math.cos(a); _DODEC_SIN[i]=Math.sin(a);}})();

// PERF: Name tag OffscreenCanvas cache — replaces 8-12 dodecagon paths + 4 fillText calls per player per frame
// with 1 drawImage call. Cache key encodes (name, rankId, hpBucket, isOwn, timeBucket).
const _NT_OC_CACHE = new Map();
// PERF: Eye overlay OC cache — eyes don't animate, cache forever per skin.
// Saves 6 arc draws × N remote players per frame (N=player count).
const _EYE_OC_CACHE = new Map();
// PERF: _pendingNameTags pool — reuse objects across frames to avoid per-frame GC pressure.
// Pool size 32 covers up to 32 visible players/objects simultaneously.
const _NT_OBJ_POOL = Array.from({length: 32}, () => ({wx:0,wy:0,name:'',rankId:0,hpRatio:1,isOwn:false}));
let _ntPoolIdx = 0;
// Shared measure context — avoids document.createElement per cache build
const _NT_MEAS_CTX = (function(){
  return createRenderCanvas(1, 1).getContext('2d');
})();
// Cache TTL in frames per rank tier: 0=never (static), 30=slow pulse, 16=rotation animation
const _NT_TTL = [0,0,0,30,30,30,30,30,30,30,16,16];

const _WING_COLORS = {
  w_angel: ['rgba(255,255,255,.92)','rgba(200,235,255,.15)','rgba(180,210,255,.5)'],
  w_devil: ['rgba(200,20,20,.92)',  'rgba(80,0,0,.1)',      'rgba(130,0,0,.6)'],
  w_dragon:['rgba(40,160,20,.92)', 'rgba(20,70,10,.1)',    'rgba(20,110,10,.6)'],
  w_fairy: ['rgba(210,90,255,.7)', 'rgba(90,200,255,.08)', 'rgba(180,120,255,.5)'],
  w_bat:   ['rgba(22,12,40,.95)',  'rgba(50,30,70,.1)',    'rgba(30,18,55,.7)'],
};
let _ghostBuildPos = null;
let enemies = [];
// Boss attack telegraph overlays — drawn on ground before mobs
let bossTelegraphs = [];
// PERF: Pre-allocated map reused every mob_states call (was new Map() every 50ms = 20Hz GC pressure)
const _enemyLocalMap = new Map();
// PERF: Mob ID index array — populated from mob_ids, used for binary mob_states_b decoding
let _mobIdArr = [];
let loots = [];          // gold/item drops on ground
let chests = [];         // treasure chests
let airdropsList = [];   // server-synced loot airdrops & boss chests
let _sessionQuestStats = { wolves: 0, bears: 0, scorpions: 0, spiders: 0, kills: 0, kingKills: 0, airdrops: 0, buildings: 0, wood: 0, stone: 0, gold: 0 };
function _incQuestStat(k, n = 1) {
  if (k && _sessionQuestStats) {
    _sessionQuestStats[k] = (_sessionQuestStats[k] || 0) + n;
    _trackQuestProgress(k, n);
  }
}
const CHEST_COLLECT_RADIUS = 46;
const MAX_CHESTS = 3;
let _nextChestSpawn = 2400 + Math.random() * 1200; // first chest ~40-60s
let projectiles = [];    // turret projectiles
let arrows = [];         // player bow arrows
let enemyProjectiles = []; // enemy ranged attacks
let armorDrops = [];     // armor pickup drops
let ambientParticles = []; // biome ambient (leaves, snow, ash, spores)
// PERF: pre-allocated ambient particle pool — eliminates per-spawn GC pressure
const _AP_POOL_SZ = 36;
const _apFreePool = [];
(function _initAPPool(){ for(let _i=0;_i<_AP_POOL_SZ;_i++) _apFreePool.push({x:0,y:0,vx:0,vy:0,life:0,maxLife:320,color:'#fff',shape:'ash',r:3,angle:0,spin:0}); }());
let playerBiome = 'forest'; // current biome of the player
let globalTime = 0;
let lastRegenTime = 0;
let _playerLevel = 1;
let _playerLevelKills = 0;
const _LEVEL_KILLS = [0,5,12,22,36,55,80,112,150,200]; // kills needed per level
function _checkPlayerLevel(){
  const needed=_LEVEL_KILLS[Math.min(_playerLevel,_LEVEL_KILLS.length-1)]||999;
  if(_playerLevelKills>=needed&&_playerLevel<10){
    _playerLevel++;
    const bonus=_playerLevel*5;
    player.maxHp+=bonus; player.hp=Math.min(player.hp+bonus,player.maxHp); updateHpBar();
    floatingTexts.push({x:player.x,y:player.y-110,text:`⬆️ SEVİYE ${_playerLevel}! +${bonus} MAX HP`,alpha:1,life:110,color:'#ffdd00',big:true});
    playSound(660,0.22,'triangle',0.35); playSound(880,0.18,'triangle',0.25);
    _spawnLevelUpRing();
  }
}
let _lvlRings = []; // level-up ring pulses
function _spawnLevelUpRing(){
  _lvlRings.push({r:0,maxR:240,alpha:1,color:'#ffdd00'});
  _lvlRings.push({r:0,maxR:180,alpha:1,color:'#ffffff'});
}
let _bowCooldown = 0;
const BOW_COOLDOWN = 35;
let _critMulti = 2.2;
// ── HIT COMBO SYSTEM ────────────────────────────────────────
let _comboCount = 0, _comboTimerHandle = null, _comboDmgBonus = 1, _comboLastHitTime = 0;
function _hitCombo() {
  clearTimeout(_comboTimerHandle);
  _comboCount++;
  _comboLastHitTime = performance.now();
  _comboDmgBonus = 1 + Math.min(5, _comboCount - 1) * 0.10; // up to 1.50× at 6+ hits
  if (_comboCount === 3) floatingTexts.push({x:player.x,y:player.y-62,text:'🔥 KOMBO ×3!',alpha:1,life:32,color:'#ffaa00',big:true});
  else if (_comboCount === 5) floatingTexts.push({x:player.x,y:player.y-62,text:'🔥🔥 KOMBO ×5!',alpha:1,life:36,color:'#ff6600',big:true});
  else if (_comboCount === 8 || (_comboCount > 8 && (_comboCount - 8) % 5 === 0)) floatingTexts.push({x:player.x,y:player.y-62,text:`💀 KOMBO ×${_comboCount}!!`,alpha:1,life:40,color:'#ff2200',big:true});
  _comboTimerHandle = setTimeout(() => { _comboCount = 0; _comboDmgBonus = 1; }, 2600);
}
let _comboFontSz = 0, _comboHudCx = 0;
function _drawComboHud() {
  if (_comboCount < 3) return;
  // Fade out over the last 0.8 s of the 2.6 s window so the HUD doesn't hang visibly
  const _timeFade = Math.max(0, 1 - Math.max(0, performance.now() - _comboLastHitTime - 1800) / 800);
  if (_timeFade <= 0.01) return;
  ctx.save(); ctx.setTransform(1,0,0,1,0,0);
  // PERF: cache canvas half-width — avoids division every frame
  const _cx = _comboHudCx || (_comboHudCx = canvas.width >> 1), _cy = 90;
  const _ca = Math.min(1, (_comboCount - 2) * 0.25);
  const _col = _comboCount >= 8 ? '#ff2200' : _comboCount >= 5 ? '#ff6600' : '#ffaa00';
  if (_glowOk) { ctx.shadowColor = _col; ctx.shadowBlur = 18; }
  // PERF: cache font string — only rebuild when font size changes (string concat not template literal)
  const _cfs = 22 + Math.min(_comboCount, 8);
  if (_cfs !== _comboFontSz) { _comboFontSz = _cfs; ctx.font = 'bold ' + _cfs + 'px Arial'; } else { ctx.font = 'bold ' + _cfs + 'px Arial'; }
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.globalAlpha = 0.92 * _ca * _timeFade;
  ctx.fillStyle = _col;
  ctx.fillText('🔥 ×' + _comboCount + ' KOMBO', _cx, _cy);
  ctx.shadowBlur = 0; ctx.globalAlpha = 1; ctx.restore();
}
let _autoEatEnabled = localStorage.getItem('fb_auto_eat') === 'true';
let _shakeEnabled = localStorage.getItem('fb_shake') !== 'false';
let _lastAutoEat = 0;

// ============================================================
// SPAWN PROTECTION (3-second invincibility on respawn)
// ============================================================
let _spawnProtected = false;
let _spawnProtTimer = 0; // countdown in frames
let _spawnProtPulse = 0;

// ============================================================
// GROUND FOOD PICKUPS (moomoo.io style — walk over to collect)
// ============================================================
const GROUND_FOOD_TYPES = [
  { emoji:'🍄', color:'#ff7043', healPct:0.12, name:'Mantar', radius:14, speed:0 },
  { emoji:'🫐', color:'#7c4dff', healPct:0.08, name:'Yaban Mersini', radius:12, speed:0 },
  { emoji:'🍀', color:'#00e676', healPct:0.06, name:'Yonca', radius:10, speed:0.5 },
  { emoji:'🌰', color:'#ff8f00', healPct:0.10, name:'Kestane', radius:13, speed:0.3 },
];
let groundFood = [];
const GROUND_FOOD_MAX = 80;
const GROUND_FOOD_COLLECT_RADIUS = 38;

// PERF: OffscreenCanvas cache for ground food sprites
// Pre-renders each food type once, then blits with drawImage
const _GROUND_FOOD_OC_CACHE = new Map();

function _getGroundFoodSprite(typeIdx) {
  const cacheKey = typeIdx;
  if (_GROUND_FOOD_OC_CACHE.has(cacheKey)) {
    return _GROUND_FOOD_OC_CACHE.get(cacheKey);
  }
  const type = GROUND_FOOD_TYPES[typeIdx];
  const size = Math.ceil(type.radius * 2.8);
  const oc = createRenderCanvas(size, size);
  const occ = oc.getContext('2d');
  occ.textAlign = 'center';
  occ.textBaseline = 'middle';
  occ.font = `${type.radius * 1.4}px Arial`;
  occ.fillStyle = '#fff';
  occ.fillText(type.emoji, size / 2, size / 2);
  _GROUND_FOOD_OC_CACHE.set(cacheKey, oc);
  return oc;
}

function spawnGroundFood() {
  if (groundFood.length >= GROUND_FOOD_MAX) return;
  const t = GROUND_FOOD_TYPES[Math.floor(Math.random() * GROUND_FOOD_TYPES.length)];
  const angle = Math.random() * Math.PI * 2;
  const dist = 200 + Math.random() * (WORLD * 0.85);
  const x = Math.cos(angle) * dist;
  const y = Math.sin(angle) * dist;
  const id = globalTime + Math.random();
  const food = { x, y, type: t, bob: Math.random() * Math.PI * 2, id, life: 1800 + Math.random() * 1800 };
  groundFood.push(food);
  _addFoodToGrid(food);
}

// Pre-spawn initial ground food
(function() {
  for (let i = 0; i < 50; i++) spawnGroundFood();
})();

function updateGroundFood() {
  // Spawn more periodically
  if (globalTime % 45 === 0) spawnGroundFood();
  for (let i = groundFood.length - 1; i >= 0; i--) {
    const f = groundFood[i];
    f.bob += 0.07;
    f.life--;
    if (f.life <= 0) { _removeFoodFromGrid(f); groundFood[i]=groundFood[groundFood.length-1]; groundFood.pop(); continue; }
    const dist = Math.hypot(player.x - f.x, player.y - f.y);
    if (dist < GROUND_FOOD_COLLECT_RADIUS) {
      const healAmt = Math.round(player.maxHp * f.type.healPct);
      player.hp = Math.min(player.maxHp, player.hp + healAmt);
      if (f.type.speed > 0) {
        if (!player._speedBoostEnd || player._speedBoostEnd < Date.now()) {
          player.speedBonus = (player.speedBonus || 1) * (1 + f.type.speed * 0.2);
          const dur = 4000 + f.type.speed * 1000;
          player._speedBoostEnd = Date.now() + dur;
          setTimeout(() => { player.speedBonus = (player.speedBonus || 1) / (1 + f.type.speed * 0.2); player._speedBoostEnd = 0; }, dur);
        }
      }
      floatingTexts.push({ x: f.x, y: f.y - 30, text: '+' + healAmt + ' 💚 ' + f.type.name, alpha: 1, life: 55, color: '#44ff88' });
      for (let pi = 0; pi < 6; pi++) {
        const pa = Math.random() * Math.PI * 2;
        _spawnParticle(f.x+Math.cos(pa)*12,f.y+Math.sin(pa)*12,Math.cos(pa)*2.5,Math.sin(pa)*2.5-1.5,4+Math.random()*3,22,f.type.color);
      }
      playSound(660, 0.1, 'sine', 0.18);
      updateHpBar();
      _removeFoodFromGrid(f);
      groundFood[i]=groundFood[groundFood.length-1]; groundFood.pop();
    }
  }
}

function drawGroundFood() {
  if (groundFood.length === 0) return;
  ctx.save();
  
  // PERF: Use spatial partitioning - only iterate visible grid cells
  const startCol = Math.floor(_renderCullL / GRID_SIZE);
  const endCol = Math.floor(_renderCullR / GRID_SIZE);
  const startRow = Math.floor(_renderCullT / GRID_SIZE);
  const endRow = Math.floor(_renderCullB / GRID_SIZE);
  
  // PERF: Batch drawing operations by type to reduce state changes
  const _batchDraw = [];
  
  for (let col = startCol; col <= endCol; col++) {
    for (let row = startRow; row <= endRow; row++) {
      const key = `${col}_${row}`;
      const cellFoods = _foodGrid[key];
      if (!cellFoods || cellFoods.length === 0) continue;
      
      for (let _gi = 0; _gi < cellFoods.length; _gi++) {
        const f = cellFoods[_gi];
        // Skip double-check culling - grid is accurate enough
        const _fa = f.life < 120 ? f.life / 120 : 1;
        const bobY = Math.sin(f.bob) * 3;
        _batchDraw.push({ f, _fa, bobY });
      }
    }
  }
  
  // PERF: Draw shadows first in batch
  if (_qualityLevel > 0) {
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.beginPath();
    for (let i = 0; i < _batchDraw.length; i++) {
      const { f } = _batchDraw[i];
      ctx.moveTo(f.x + f.type.radius, f.y + 2);
      ctx.arc(f.x, f.y + 2, f.type.radius, 0, Math.PI * 2);
    }
    ctx.fill();
  }
  
  // PERF: Draw food bodies in batch
  for (let i = 0; i < _batchDraw.length; i++) {
    const { f, _fa, bobY } = _batchDraw[i];
    ctx.globalAlpha = _fa;
    // Colored body + glow at quality 2
    if (_qualityLevel >= 2) { ctx.shadowColor = f.type.color; ctx.shadowBlur = 10; }
    ctx.fillStyle = f.type.color;
    ctx.beginPath(); ctx.arc(f.x, f.y + bobY, f.type.radius, 0, Math.PI * 2); ctx.fill();
    if (_qualityLevel >= 2) ctx.shadowBlur = 0;
    // PERF: Use cached OffscreenCanvas sprite instead of fillText
    const typeIdx = GROUND_FOOD_TYPES.indexOf(f.type);
    if (typeIdx >= 0) {
      const sprite = _getGroundFoodSprite(typeIdx);
      const size = Math.ceil(f.type.radius * 2.8);
      ctx.globalAlpha = _fa * 0.9;
      ctx.drawImage(sprite, f.x - size / 2, f.y + bobY - size / 2, size, size);
    }
  }
  
  ctx.restore();
}

// ============================================================
// SPAWN PROTECTION SHIELD DRAW (world-space, over player)
// ============================================================
function drawSpawnShield() {
  if (!_spawnProtected) return;
  const alpha = (Math.sin(_spawnProtPulse) * 0.25 + 0.5);
  const r = player.radius + 10 + Math.sin(_spawnProtPulse * 1.3) * 5;
  ctx.save();
  ctx.globalAlpha = alpha * 0.75;
  ctx.strokeStyle = '#44ddff';
  ctx.lineWidth = 3;
  if(_qualityLevel>=2){ctx.shadowColor = '#44ddff'; ctx.shadowBlur = 18;}
  ctx.beginPath(); ctx.arc(player.x, player.y, r, 0, Math.PI * 2); ctx.stroke();
  ctx.globalAlpha = alpha * 0.18;
  ctx.fillStyle = '#44ddff';
  ctx.beginPath(); ctx.arc(player.x, player.y, r, 0, Math.PI * 2); ctx.fill();
  ctx.shadowBlur = 0;
  // Timer text in screen space
  const secsLeft = Math.ceil(_spawnProtTimer / 60);
  ctx.globalAlpha = 0.9;
  ctx.font = 'bold 11px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillStyle = '#44ddff'; ctx.fillText('🛡️ ' + secsLeft, player.x, player.y - r - 12);
  ctx.restore();
}

// ============================================================
// TAB SCOREBOARD JS
// ============================================================
let _tabOpen = false;
function openTabScoreboard() {
  _tabOpen = true;
  const el = document.getElementById('tab-scoreboard');
  if (!el) return;
  el.style.display = 'flex';
  // Build rows: self + other players sorted by kills desc
  const all = [{ name: player.name || 'Sen', gold: player.gold || 0, kills: player.kills, xp: player.xp, score: player.score||0, isSelf: true, rankId: _myRankId || 0 }];
  _otherPlayers.forEach(p => { all.push({ name: p.name || '?', gold: p.gold || 0, kills: p.kills || 0, xp: p.xp || 0, score: p.score||0, isSelf: false, rankId: p.rankId || 0 }); });
  all.sort((a, b) => (b.gold - a.gold) || (b.kills - a.kills));
  const rows = document.getElementById('tab-sb-rows');
  if (!rows) return;
  rows.innerHTML = all.slice(0, 12).map((p, i) => {
    const bg = p.isSelf ? 'rgba(100,200,50,0.18)' : i === 0 ? 'rgba(255,200,0,0.12)' : 'rgba(255,255,255,0.05)';
    const border = p.isSelf ? '1px solid rgba(100,200,50,0.4)' : i === 0 ? '1px solid rgba(255,200,0,0.3)' : '1px solid rgba(255,255,255,0.07)';
    const sc = p.gold || 0;
    const scStr = sc >= 1000 ? (sc/1000).toFixed(1)+'K' : String(sc);
    return `<div style="display:flex;align-items:center;gap:8px;background:${bg};border:${border};border-radius:8px;padding:5px 10px;font-size:12px;">
      <span style="flex:1;font-weight:${p.isSelf ? 800 : 600};color:${p.isSelf ? '#8ddc52' : '#fff'}">${p.name}${p.isSelf ? ' (Sen)' : ''}</span>
      <span style="color:#ffd700;font-weight:800"><img src="asset/gold.png" alt="Altın" style="width:14px;height:14px;vertical-align:-2px"> ${scStr}</span>
    </div>`;
  }).join('');
}
function toggleTabScoreboard() {
  if (_tabOpen) closeTabScoreboard();
  else openTabScoreboard();
}
function closeTabScoreboard() {
  _tabOpen = false;
  const el = document.getElementById('tab-scoreboard');
  if (el) el.style.display = 'none';
}

// ============================================================
// QUICK CHAT WHEEL (Z key)
// ============================================================
const QUICK_CHATS = [
  { emoji:'👋', text:'Merhaba!' },
  { emoji:'😂', text:'Haha!' },
  { emoji:'💀', text:'GG!' },
  { emoji:'🤝', text:'İyi oyun!' },
  { emoji:'😡', text:'Haksız!' },
  { emoji:'🆘', text:'Yardım!' },
  { emoji:'🙏', text:'Pardon!' },
  { emoji:'🔥', text:'Ezim!' },
];
let _qcwOpen = false;
let _qcwSelected = -1;
let _qcwMouseX = 0, _qcwMouseY = 0;

function openQuickChat(mx, my) {
  _qcwOpen = true;
  _qcwMouseX = mx; _qcwMouseY = my;
  const wheel = document.getElementById('quick-chat-wheel');
  const items = document.getElementById('qcw-items');
  const svg = document.getElementById('qcw-svg');
  if (!wheel || !items) return;
  wheel.style.display = 'block';
  wheel.classList.add('qcw-open');
  wheel.style.pointerEvents = 'auto';
  wheel.style.left = Math.max(4, Math.min(window.innerWidth - 204, mx - 100)) + 'px';
  wheel.style.top = Math.max(4, Math.min(window.innerHeight - 204, my - 100)) + 'px';
  items.innerHTML = '';
  QUICK_CHATS.forEach((c, i) => {
    const angle = (i / QUICK_CHATS.length) * Math.PI * 2 - Math.PI / 2;
    const r = 72;
    const cx = 100 + Math.cos(angle) * r;
    const cy = 100 + Math.sin(angle) * r;
    const div = document.createElement('div');
    div.style.cssText = `position:absolute;left:${cx - 18}px;top:${cy - 18}px;width:36px;height:36px;border-radius:50%;background:rgba(10,40,10,0.92);border:2px solid rgba(100,200,50,0.5);display:flex;align-items:center;justify-content:center;font-size:18px;cursor:pointer;transition:transform .1s;pointer-events:auto;`;
    div.title = c.text;
    div.textContent = c.emoji;
    div.onmouseover = () => { div.style.transform = 'scale(1.2)'; div.style.borderColor = '#8ddc52'; _qcwSelected = i; };
    div.onmouseleave = () => { div.style.transform = ''; div.style.borderColor = 'rgba(100,200,50,0.5)'; _qcwSelected = -1; };
    div.onclick = () => { sendQuickChat(i); closeQuickChat(); };
    items.appendChild(div);
  });
}

function toggleQuickChat() {
  if (_qcwOpen) closeQuickChat();
  else openQuickChat(window.innerWidth / 2, window.innerHeight / 2);
}

function closeQuickChat() {
  _qcwOpen = false;
  const wheel = document.getElementById('quick-chat-wheel');
  if (wheel) {
    wheel.classList.remove('qcw-open');
    wheel.style.display = 'none';
    wheel.style.pointerEvents = 'none';
    wheel.style.left = '-1000px';
    wheel.style.top = '-1000px';
  }
}

function sendQuickChat(idx) {
  const c = QUICK_CHATS[idx];
  if (!c) return;
  if (_connected && _socket) _socket.emit('quick_chat', { idx });
  // Show as floating text above player
  floatingTexts.push({ x: player.x, y: player.y - 120, text: c.emoji + ' ' + c.text, alpha: 1, life: 120, color: '#ffffff', big: true });
  // Also show in chat feed
  addKillFeed('💬 ' + (player.name || 'Sen') + ': ' + c.text, '#aaffaa');
  playSound(440, 0.06, 'sine', 0.15);
}

// ============================================================
// ENEMY TYPES  (biome-tagged, 15 types)
// ============================================================
const ENEMY_TYPES = [
  // --- FOREST ---
  { name:'Goblin',            biome:'forest',     shape:'goblin',       radius:34, hp:52,  maxHp:52,  color:'#3d8a1e', outline:'#1a4a08', dmg:10, speed:0.72, xp:18,  gold:3,  eyes:'#ffee00', aggroRange:180 },
  { name:'Yaban Domuzu',      biome:'forest',     shape:'boar',         radius:46, hp:98,  maxHp:98,  color:'#7a4f2a', outline:'#3a2010', dmg:18, speed:0.55, xp:30,  gold:6,  eyes:'#ff8800', aggroRange:140 },
  { name:'Ağaç Devi',         biome:'forest',     shape:'treant',       radius:64, hp:270, maxHp:270, color:'#3a5e1c', outline:'#162a08', dmg:32, speed:0.26, xp:82,  gold:18, eyes:'#88ff44', aggroRange:220 },
  { name:'Yarasa',            biome:'forest',     shape:'bat',          radius:28, hp:38,  maxHp:38,  color:'#281535', outline:'#0a0814', dmg:8,  speed:1.15, xp:14,  gold:3,  eyes:'#ff2200', aggroRange:320 },
  { name:'Sincap',            biome:'forest',     shape:'squirrel',     radius:22, hp:28,  maxHp:28,  color:'#a05018', outline:'#502808', dmg:5,  speed:1.45, xp:9,   gold:2,  eyes:'#ff9900', aggroRange:180 },
  { name:'Zehirli Mantar',    biome:'forest',     shape:'mushroom',     radius:36, hp:75,  maxHp:75,  color:'#cc2222', outline:'#660808', dmg:13, speed:0.28, xp:25,  gold:5,  eyes:'#ffff00', aggroRange:95  },
  // --- SNOW ---
  { name:'Kardan Adam',       biome:'snow',       shape:'snowman',      radius:38, hp:62,  maxHp:62,  color:'#ddeeff', outline:'#88aacc', dmg:13, speed:0.44, xp:22,  gold:5,  eyes:'#ff6600', aggroRange:160 },
  { name:'Buz Devi',          biome:'snow',       shape:'icetroll',     radius:60, hp:210, maxHp:210, color:'#3a7abb', outline:'#1a3a66', dmg:38, speed:0.34, xp:75,  gold:17, eyes:'#00ffff', aggroRange:200 },
  { name:'Arktik Kurt',       biome:'snow',       shape:'arcticwolf',   radius:36, hp:76,  maxHp:76,  color:'#eef0f8', outline:'#8899bb', dmg:16, speed:0.90, xp:33,  gold:7,  eyes:'#ff44aa', aggroRange:250 },
  { name:'İskelet',           biome:'snow',       shape:'skeleton',     radius:32, hp:58,  maxHp:58,  color:'#e8e0c8', outline:'#888878', dmg:14, speed:0.70, xp:23,  gold:5,  eyes:'#00ff88', aggroRange:200 },
  { name:'Penguen',           biome:'snow',       shape:'penguin',      radius:29, hp:52,  maxHp:52,  color:'#1a2a3a', outline:'#334455', dmg:11, speed:0.55, xp:19,  gold:4,  eyes:'#44aaff', aggroRange:130 },
  { name:'Buz Ruhu',          biome:'snow',       shape:'icewraith',    radius:31, hp:46,  maxHp:46,  color:'#88ccff', outline:'#4488bb', dmg:13, speed:1.08, xp:17,  gold:4,  eyes:'#00ffff', aggroRange:300 },
  // --- DESERT ---
  { name:'Akrep',             biome:'desert',     shape:'scorpion',     radius:40, hp:84,  maxHp:84,  color:'#c0a040', outline:'#604818', dmg:20, speed:0.57, xp:35,  gold:7,  eyes:'#ff2200', aggroRange:170 },
  { name:'Mumya',             biome:'desert',     shape:'mummy',        radius:46, hp:118, maxHp:118, color:'#d4c490', outline:'#8a7840', dmg:22, speed:0.37, xp:43,  gold:9,  eyes:'#44ff88', aggroRange:130 },
  { name:'Kum Devi',          biome:'desert',     shape:'sandgiant',    radius:68, hp:320, maxHp:320, color:'#c47830', outline:'#6a3808', dmg:46, speed:0.26, xp:118, gold:31, eyes:'#ff8800', aggroRange:240 },
  { name:'Kum Yengeci',       biome:'desert',     shape:'sandcrab',     radius:36, hp:70,  maxHp:70,  color:'#d4a060', outline:'#8a5a20', dmg:16, speed:0.63, xp:27,  gold:6,  eyes:'#ff4400', aggroRange:150 },
  { name:'Kobra',             biome:'desert',     shape:'cobra',        radius:27, hp:57,  maxHp:57,  color:'#4a8a22', outline:'#1a4408', dmg:17, speed:0.95, xp:23,  gold:5,  eyes:'#ff3300', aggroRange:200 },
  { name:'Akbaba',            biome:'desert',     shape:'vulture',      radius:38, hp:72,  maxHp:72,  color:'#3a2820', outline:'#181008', dmg:16, speed:0.68, xp:27,  gold:6,  eyes:'#ffaa00', aggroRange:310 },
  // --- SWAMP ---
  { name:'Slime',             biome:'swamp',      shape:'slime',        radius:30, hp:42,  maxHp:42,  color:'#78c828', outline:'#386810', dmg:8,  speed:0.48, xp:14,  gold:3,  eyes:'#ffffff', aggroRange:110 },
  { name:'Dev Kurbağa',       biome:'swamp',      shape:'toad',         radius:52, hp:142, maxHp:142, color:'#2e6a22', outline:'#0e3a08', dmg:25, speed:0.39, xp:52,  gold:11, eyes:'#ffff00', aggroRange:160 },
  { name:'Timsah',            biome:'swamp',      shape:'croc',         radius:68, hp:330, maxHp:330, color:'#2a4a1a', outline:'#0a2006', dmg:48, speed:0.29, xp:128, gold:33, eyes:'#ff8844', aggroRange:190 },
  { name:'Derin Solucan',     biome:'swamp',      shape:'deepworm',     radius:46, hp:135, maxHp:135, color:'#5a2a6a', outline:'#28083a', dmg:29, speed:0.34, xp:50,  gold:11, eyes:'#ff00ff', aggroRange:140 },
  { name:'Sivrisinek',        biome:'swamp',      shape:'mosquito',     radius:18, hp:20,  maxHp:20,  color:'#2a1810', outline:'#0a0806', dmg:6,  speed:1.30, xp:7,   gold:2,  eyes:'#ff4400', aggroRange:230 },
  { name:'Bataklık Şamanı',   biome:'swamp',      shape:'swampshaman',  radius:42, hp:118, maxHp:118, color:'#1a3a10', outline:'#081808', dmg:22, speed:0.40, xp:46,  gold:10, eyes:'#88ff44', aggroRange:175, ranged:true, rangedRange:220, rangedCooldown:110, rangedDmg:14, projColor:'#44ff88' },
  // --- DARK FOREST ---
  { name:'Gölge Kurdu',       biome:'darkforest', shape:'shadowwolf',   radius:38, hp:88,  maxHp:88,  color:'#2a1840', outline:'#10080a', dmg:22, speed:0.84, xp:37,  gold:8,  eyes:'#cc44ff', aggroRange:280 },
  { name:'Örümcek',           biome:'darkforest', shape:'spider',       radius:46, hp:108, maxHp:108, color:'#181028', outline:'#080410', dmg:26, speed:0.60, xp:45,  gold:10, eyes:'#ff3300', aggroRange:200 },
  { name:'Kabus Enti',        biome:'darkforest', shape:'nightmarent',  radius:74, hp:390, maxHp:390, color:'#1a0830', outline:'#080014', dmg:54, speed:0.22, xp:148, gold:39, eyes:'#aa00ff', aggroRange:260 },
  { name:'Ateş Kuşu',         biome:'darkforest', shape:'firebird',     radius:38, hp:94,  maxHp:94,  color:'#cc4400', outline:'#801800', dmg:25, speed:0.97, xp:41,  gold:9,  eyes:'#ffff00', aggroRange:260 },
  { name:'İblis Gözü',        biome:'darkforest', shape:'demoneye',     radius:34, hp:80,  maxHp:80,  color:'#1a0820', outline:'#550088', dmg:20, speed:0.78, xp:33,  gold:7,  eyes:'#ff0066', aggroRange:330, ranged:true, rangedRange:300, rangedCooldown:90, rangedDmg:16, projColor:'#ff0088' },
  { name:'Karanlık Kukla',    biome:'darkforest', shape:'darkpuppet',   radius:28, hp:60,  maxHp:60,  color:'#201020', outline:'#440022', dmg:16, speed:0.88, xp:25,  gold:5,  eyes:'#ff44ff', aggroRange:250 },
  // --- YENİ: FOREST ---
  { name:'Kurt Adam',         biome:'forest',     shape:'werewolf',     radius:52, hp:155, maxHp:155, color:'#4a3020', outline:'#1a0e08', dmg:30, speed:0.78, xp:58,  gold:13, eyes:'#ff4400', aggroRange:240, typeName:'🐺' },
  { name:'Taş Golemi',        biome:'forest',     shape:'golem',        radius:66, hp:290, maxHp:290, color:'#6a6050', outline:'#2a2018', dmg:44, speed:0.24, xp:102, gold:24, eyes:'#ff8800', aggroRange:160, typeName:'🗿' },
  { name:'Vampir',            biome:'forest',     shape:'vampire',      radius:38, hp:92,  maxHp:92,  color:'#e8d8d0', outline:'#601818', dmg:22, speed:0.82, xp:38,  gold:9,  eyes:'#ff0000', aggroRange:290, typeName:'🧛' },
  { name:'Diken Canavarı',    biome:'forest',     shape:'thornbeast',   radius:50, hp:130, maxHp:130, color:'#2a5818', outline:'#0e2808', dmg:26, speed:0.46, xp:50,  gold:11, eyes:'#88ff00', aggroRange:190 },
  { name:'Anka Kuşu',         biome:'forest',     shape:'phoenix',      radius:40, hp:100, maxHp:100, color:'#cc5500', outline:'#881e00', dmg:24, speed:0.95, xp:42,  gold:10, eyes:'#ffff00', aggroRange:270, typeName:'🦅' },
  // --- YENİ: SNOW ---
  { name:'Kristal Golemi',    biome:'snow',       shape:'crystalgolem', radius:60, hp:220, maxHp:220, color:'#88ccff', outline:'#2266aa', dmg:38, speed:0.28, xp:80,  gold:18, eyes:'#00ffff', aggroRange:180, typeName:'💎' },
  // --- YENİ: DESERT ---
  { name:'Minotaur',          biome:'desert',     shape:'minotaur',     radius:60, hp:200, maxHp:200, color:'#8a5020', outline:'#3a1808', dmg:36, speed:0.42, xp:72,  gold:16, eyes:'#ff4400', aggroRange:210, typeName:'🐂' },
  { name:'Taş Kral',          biome:'desert',     shape:'stoneking',    radius:72, hp:360, maxHp:360, color:'#7a7060', outline:'#3a3028', dmg:50, speed:0.22, xp:132, gold:34, eyes:'#ff8800', aggroRange:200, typeName:'👑' },
  // --- YENİ: SWAMP ---
  { name:'Naga',              biome:'swamp',      shape:'naga',         radius:48, hp:128, maxHp:128, color:'#2a6a28', outline:'#0a2808', dmg:28, speed:0.52, xp:48,  gold:11, eyes:'#ffff00', aggroRange:220, typeName:'🐍' },
  // --- YENİ: DARK FOREST ---
  { name:'Lich',              biome:'darkforest', shape:'lich',         radius:44, hp:112, maxHp:112, color:'#181028', outline:'#440066', dmg:28, speed:0.55, xp:48,  gold:11, eyes:'#aa00ff', aggroRange:240, typeName:'💀', ranged:true, rangedRange:260, rangedCooldown:130, rangedDmg:18, projColor:'#8800cc' },
  { name:'Gölge Biçici',      biome:'darkforest', shape:'shadowreaper', radius:38, hp:96,  maxHp:96,  color:'#100820', outline:'#330055', dmg:24, speed:0.76, xp:40,  gold:9,  eyes:'#cc00ff', aggroRange:300, typeName:'☠️', ranged:true, rangedRange:280, rangedCooldown:100, rangedDmg:15, projColor:'#cc00ff' },
  { name:'Harpiya',           biome:'desert',     shape:'harpy',        radius:36, hp:78,  maxHp:78,  color:'#8a6030', outline:'#3a2210', dmg:18, speed:1.05, xp:32,  gold:7,  eyes:'#ff8800', aggroRange:320, typeName:'🦅', ranged:true, rangedRange:310, rangedCooldown:80, rangedDmg:12, projColor:'#ffaa00' },
  // ─── YENİ GELİŞMİŞ MOB'LAR ───────────────────────────────────────────────
  // FOREST
  { name:'Zırhlı Böcek',      biome:'forest',     shape:'armorBeetle',  radius:44, hp:145, maxHp:145, color:'#2a5a1a', outline:'#0a2808', dmg:27, speed:0.44, xp:53,  gold:12, eyes:'#ffdd00', aggroRange:140 },
  { name:'Gece Yarasa Kral',  biome:'forest',     shape:'batking',      radius:52, hp:168, maxHp:168, color:'#2a0a3a', outline:'#080010', dmg:32, speed:0.75, xp:62,  gold:14, eyes:'#ff44cc', aggroRange:280 },
  { name:'Zehir Ağacı',       biome:'forest',     shape:'poisontree',   radius:58, hp:210, maxHp:210, color:'#1e4a0a', outline:'#08200a', dmg:28, speed:0.18, xp:78,  gold:17, eyes:'#44ff22', aggroRange:160, ranged:true, rangedRange:180, rangedCooldown:120, rangedDmg:16, projColor:'#44ff00' },
  // SNOW
  { name:'Buzul Mantikorası', biome:'snow',       shape:'icemanticore', radius:56, hp:195, maxHp:195, color:'#9ab8e8', outline:'#3a5898', dmg:36, speed:0.46, xp:73,  gold:16, eyes:'#00eeff', aggroRange:220, typeName:'🦁' },
  { name:'Donmuş Canavar',    biome:'snow',       shape:'frostbeast',   radius:48, hp:152, maxHp:152, color:'#b8d8f8', outline:'#5888c8', dmg:30, speed:0.52, xp:58,  gold:13, eyes:'#88ffff', aggroRange:190 },
  // DESERT
  { name:'Akrep Kral',        biome:'desert',     shape:'scorpionking', radius:62, hp:285, maxHp:285, color:'#b89018', outline:'#584008', dmg:44, speed:0.36, xp:104, gold:26, eyes:'#ff3300', aggroRange:200, typeName:'🦂' },
  { name:'Kum Wyvern',        biome:'desert',     shape:'sandwyvern',   radius:50, hp:162, maxHp:162, color:'#c89040', outline:'#684810', dmg:32, speed:0.70, xp:62,  gold:14, eyes:'#ffcc00', aggroRange:260 },
  // SWAMP
  { name:'Bataklık Ejderi',   biome:'swamp',      shape:'swampdrake',   radius:54, hp:178, maxHp:178, color:'#1a5a18', outline:'#082808', dmg:36, speed:0.40, xp:67,  gold:15, eyes:'#88ff44', aggroRange:210, typeName:'🐉' },
  { name:'Dev Sülük',         biome:'swamp',      shape:'giantleech',   radius:34, hp:88,  maxHp:88,  color:'#3a1a3a', outline:'#180818', dmg:22, speed:0.62, xp:35,  gold:8,  eyes:'#ff00ff', aggroRange:150 },
  // DARK FOREST
  { name:'Chimera',           biome:'darkforest', shape:'chimera',      radius:60, hp:198, maxHp:198, color:'#1a0a28', outline:'#08000e', dmg:40, speed:0.54, xp:78,  gold:18, eyes:'#ff8800', aggroRange:250, typeName:'🦄' },
  { name:'Taş Krakeni',       biome:'darkforest', shape:'stonekraken',  radius:52, hp:175, maxHp:175, color:'#101828', outline:'#040810', dmg:34, speed:0.30, xp:68,  gold:15, eyes:'#0088ff', aggroRange:185 },
  { name:'Ruh Avcısı',        biome:'darkforest', shape:'souleater',    radius:36, hp:100, maxHp:100, color:'#08051a', outline:'#220055', dmg:26, speed:0.92, xp:42,  gold:10, eyes:'#cc00ff', aggroRange:320, ranged:true, rangedRange:290, rangedCooldown:85, rangedDmg:18, projColor:'#aa00ff' },
  // ─── BİOME'E ÖZEL 4'ER YENİ MOB ─────────────────────────────────────────
  // FOREST (4)
  { name:'Orman Perisi',      biome:'forest',     shape:'forestFairy',  radius:20, hp:32,  maxHp:32,  color:'#aaff44', outline:'#448800', dmg:8,  speed:1.40, xp:13,  gold:4,  eyes:'#ffee00', aggroRange:200, ranged:true, rangedRange:195, rangedCooldown:70, rangedDmg:9,  projColor:'#88ff00' },
  { name:'Kaya Ayısı',        biome:'forest',     shape:'rockBear',     radius:58, hp:235, maxHp:235, color:'#7a6a50', outline:'#3a2a18', dmg:38, speed:0.30, xp:87,  gold:20, eyes:'#ff8800', aggroRange:160 },
  { name:'Asma Yılanı',       biome:'forest',     shape:'vineSnake',    radius:40, hp:102, maxHp:102, color:'#2a6a10', outline:'#0a2804', dmg:22, speed:0.72, xp:40,  gold:9,  eyes:'#ffff00', aggroRange:200 },
  { name:'Yosun Ejderi',      biome:'forest',     shape:'mossDrake',    radius:48, hp:150, maxHp:150, color:'#2a5a1a', outline:'#0a2808', dmg:28, speed:0.50, xp:58,  gold:13, eyes:'#44ff22', aggroRange:220, typeName:'🐉' },
  // SNOW (4)
  { name:'Yeti',              biome:'snow',       shape:'yeti',         radius:64, hp:265, maxHp:265, color:'#ddeeff', outline:'#8899bb', dmg:44, speed:0.30, xp:98,  gold:22, eyes:'#00ffee', aggroRange:200, typeName:'❄️' },
  { name:'Kar Baykuşu',       biome:'snow',       shape:'snowOwl',      radius:32, hp:62,  maxHp:62,  color:'#eef4ff', outline:'#8899cc', dmg:14, speed:1.05, xp:24,  gold:5,  eyes:'#44aaff', aggroRange:280, ranged:true, rangedRange:270, rangedCooldown:75, rangedDmg:11, projColor:'#aaddff' },
  { name:'Buz Şamanı',        biome:'snow',       shape:'frostShaman',  radius:38, hp:98,  maxHp:98,  color:'#5588cc', outline:'#1a3366', dmg:18, speed:0.48, xp:38,  gold:9,  eyes:'#00ffff', aggroRange:230, ranged:true, rangedRange:240, rangedCooldown:95, rangedDmg:16, projColor:'#88ccff' },
  { name:'Buz Örümceği',      biome:'snow',       shape:'iceSpider',    radius:36, hp:78,  maxHp:78,  color:'#aaddff', outline:'#4488bb', dmg:18, speed:0.75, xp:30,  gold:7,  eyes:'#ffffff', aggroRange:180 },
  // DESERT (4)
  { name:'Sfenks Yavrusu',    biome:'desert',     shape:'sphinxCub',    radius:44, hp:122, maxHp:122, color:'#d4a840', outline:'#7a5818', dmg:24, speed:0.52, xp:46,  gold:10, eyes:'#ff8800', aggroRange:200 },
  { name:'Kum Cini',          biome:'desert',     shape:'sandDjinn',    radius:36, hp:86,  maxHp:86,  color:'#e8a840', outline:'#8a5808', dmg:20, speed:0.92, xp:34,  gold:8,  eyes:'#ff4400', aggroRange:260, ranged:true, rangedRange:248, rangedCooldown:80, rangedDmg:14, projColor:'#ff8800' },
  { name:'Kemik Kertenkele',  biome:'desert',     shape:'boneLizard',   radius:34, hp:70,  maxHp:70,  color:'#d4c890', outline:'#8a8450', dmg:18, speed:0.84, xp:28,  gold:6,  eyes:'#ff2200', aggroRange:190 },
  { name:'Çöl Çakalı',        biome:'desert',     shape:'desertJackal', radius:30, hp:64,  maxHp:64,  color:'#c88840', outline:'#6a4418', dmg:16, speed:1.12, xp:24,  gold:5,  eyes:'#ff8800', aggroRange:250 },
  // SWAMP (4)
  { name:'Çamur Canavarı',    biome:'swamp',      shape:'mudLurker',    radius:54, hp:185, maxHp:185, color:'#3a4a1a', outline:'#141c08', dmg:32, speed:0.34, xp:68,  gold:15, eyes:'#aaff44', aggroRange:150 },
  { name:'Bataklık Hayaleti', biome:'swamp',      shape:'swampGhost',   radius:34, hp:56,  maxHp:56,  color:'#5a7a3a', outline:'#283a14', dmg:16, speed:0.90, xp:22,  gold:5,  eyes:'#aaffaa', aggroRange:310, ranged:true, rangedRange:288, rangedCooldown:90, rangedDmg:12, projColor:'#88ff88' },
  { name:'Zehir Ejderi',      biome:'swamp',      shape:'poisonDrake',  radius:46, hp:140, maxHp:140, color:'#2a6a28', outline:'#0a2a0a', dmg:28, speed:0.55, xp:52,  gold:12, eyes:'#aaff00', aggroRange:210, typeName:'🐉' },
  { name:'Bataklık Cadısı',   biome:'swamp',      shape:'bogWitch',     radius:40, hp:110, maxHp:110, color:'#3a5a28', outline:'#162214', dmg:24, speed:0.55, xp:44,  gold:10, eyes:'#88ff44', aggroRange:240, ranged:true, rangedRange:228, rangedCooldown:105, rangedDmg:18, projColor:'#44ff00' },
  // DARKFOREST (4)
  { name:'Void Hortlak',      biome:'darkforest', shape:'voidWraith',   radius:36, hp:92,  maxHp:92,  color:'#0a051a', outline:'#2a0055', dmg:22, speed:0.96, xp:38,  gold:9,  eyes:'#8800ff', aggroRange:310, ranged:true, rangedRange:278, rangedCooldown:85, rangedDmg:16, projColor:'#6600cc' },
  { name:'Karanlık Golem',    biome:'darkforest', shape:'darkGolem',    radius:62, hp:272, maxHp:272, color:'#181028', outline:'#06000e', dmg:44, speed:0.24, xp:100, gold:24, eyes:'#aa00ff', aggroRange:160, typeName:'⛧' },
  { name:'Gece Wyverni',      biome:'darkforest', shape:'nightWyvern',  radius:50, hp:160, maxHp:160, color:'#100820', outline:'#040010', dmg:34, speed:0.65, xp:62,  gold:14, eyes:'#ff0088', aggroRange:260, typeName:'🐉' },
  { name:'Bozuk Peri',        biome:'darkforest', shape:'corruptedFairy',radius:20, hp:34, maxHp:34,  color:'#381058', outline:'#1a0028', dmg:12, speed:1.42, xp:14,  gold:4,  eyes:'#ff00ff', aggroRange:280, ranged:true, rangedRange:258, rangedCooldown:65, rangedDmg:10, projColor:'#ff00cc' },
];

const ACTIVE_ENEMY_TYPES = [
  { name:'Kurt', biome:'forest', shape:'wolf', radius:38, hp:90, maxHp:90, color:'#6b4932', outline:'#28170d', dmg:20, speed:0.84, xp:35, gold:6, eyes:'#ffcc66', typeName:'🐺 Kurt' },
  { name:'Akrep', biome:'forest', shape:'scorpion', radius:42, hp:130, maxHp:130, color:'#4a2818', outline:'#1a0d06', dmg:28, speed:0.65, xp:45, gold:10, eyes:'#ff4400', typeName:'🦂 Akrep' },
  { name:'Ayı', biome:'forest', shape:'bear', radius:50, hp:260, maxHp:260, color:'#4a2f1b', outline:'#1a1008', dmg:38, speed:0.55, xp:75, gold:20, eyes:'#ffaa00', typeName:'🐻 Ayı' },
  { name:'Örümcek', biome:'forest', shape:'spider', radius:40, hp:110, maxHp:110, color:'#2a1a38', outline:'#0f0814', dmg:24, speed:0.75, xp:40, gold:8, eyes:'#ff1100', typeName:'🕷️ Örümcek' },
];
const ACTIVE_MOB_SHAPES = new Set(['wolf', 'kurt', 'scorpion', 'akrep', 'bear', 'ayi', 'spider', 'orumcek', 'örümcek']);
function isActiveMobShape(shape) {
  return ACTIVE_MOB_SHAPES.has(shape);
}

// ============================================================
// AGE / XP PROGRESSION — non-linear, gets harder each age
// ============================================================
// Cumulative XP needed to REACH each age (index = age-1)
const AGE_XP_TABLE = [0, 400, 1050, 2100, 3600, 5600, 8500, 12500, 18000, 25500, 36000];
// XP per age gap: 400, 650, 1050, 1500, 2000, 2900, 4000, 5500, 7500, 10500…

function getAge(xp) {
  let age = 1;
  for (let i = 1; i < AGE_XP_TABLE.length; i++) {
    if (xp >= AGE_XP_TABLE[i]) age = i + 1; else break;
  }
  return age;
}
function getAgeFill(xp) {
  const age  = getAge(xp);
  const idx  = age - 1;
  const xpS  = AGE_XP_TABLE[idx] || 0;
  const xpE  = AGE_XP_TABLE[idx + 1];
  if (!xpE) return 100;
  return Math.min(100, ((xp - xpS) / (xpE - xpS)) * 100);
}

// ============================================================
// Fake AI players removed — leaderboard shows only real connected players

// ── Multiplayer state — declared early so leaderboard & minimap can read them
// before _setupOnlineSystem() runs (avoids TDZ ReferenceError).
let _socket = null;
let _mySocketId = null;
let _connected = false;

// Bounty system
let _bountyId = null; // socket ID of the current bounty target
// ── Rank system (12 ranks with dynamic achievable progression) ──
const _FB_RANK_EMOJIS = ['🌱','🪨','🪵','🏹','⚔️','🛡️','🔥','💎','🌪️','🌙','👑','✨'];
const _FB_RANK_XP     = [0, 500, 1500, 3500, 7000, 12000, 20000, 35000, 60000, 100000, 180000, 300000];
function _fbRankByXP(xp){ let r=0; for(let i=0;i<_FB_RANK_XP.length;i++){if(xp>=_FB_RANK_XP[i])r=i;else break;} return r; }

// ══════════════════════════════════════════════════════════════
//  12-SIDED (DODECAGON) RANK BADGE SYSTEM — Ultra Detaylı
// ══════════════════════════════════════════════════════════════
// [outerColor, innerColor, borderColor, glowColor, textColor, rankName]
// Each rank has a fully unique visual identity
const _RANK_META = [
  ['#6dbf3c','#1a4a08','#3d8a10','rgba(80,180,40,0.65)','#d4ffaa','Tohum'],        // 0  muted green
  ['#aab0b8','#282e34','#60707a','rgba(140,160,180,0.55)','#eef4f8','Taş'],         // 1  stone grey
  ['#c87840','#3a1800','#8a4818','rgba(200,130,60,0.62)','#ffe4b8','Köylü'],        // 2  warm wood
  ['#6898c8','#102030','#306888','rgba(80,140,200,0.72)','#c8e8ff','Acemi'],        // 3  steel blue
  ['#2890ff','#040e60','#0840c0','rgba(40,140,255,0.90)','#b0d8ff','Savaşçı'],      // 4  royal blue
  ['#28e060','#043818','#10a040','rgba(30,210,80,0.90)','#98ffcc','Muhafız'],       // 5  emerald
  ['#ff5010','#6a0000','#cc2800','rgba(255,80,20,0.96)','#ffbf98','Ateş Efendisi'], // 6  fire
  ['#00e0f8','#002838','#0088b0','rgba(0,210,240,0.96)','#80f8ff','Kristal'],       // 7  crystal cyan
  ['#c040f8','#180030','#8000d0','rgba(200,40,255,0.97)','#e4a0ff','Fırtına'],      // 8  storm purple
  ['#3848d8','#020418','#182070','rgba(50,70,220,0.97)','#a8b0ff','Gece Hanı'],     // 9  midnight navy
  ['#ffc800','#602800','#e07000','rgba(255,200,0,1.0)','#fff098','Efsane'],         // 10 gold
  ['#ff80d8','#280018','#c00068','rgba(255,80,200,1.0)','#ffecf8','Tanrısal'],      // 11 divine pink
];


function _drawDodecagon(ctx, r) {
  // PERF: use pre-computed unit-circle table — was 12 Math.cos + 12 Math.sin per call
  ctx.beginPath();
  ctx.moveTo(r * _DODEC_COS[0], r * _DODEC_SIN[0]);
  for (let i = 1; i < 12; i++) ctx.lineTo(r * _DODEC_COS[i], r * _DODEC_SIN[i]);
  ctx.closePath();
}

// ── Unique per-rank inner decoration ─────────────────────────
function _drawRankDecor(ctx, rid, r, t) {
  const s = r * 0.55;
  ctx.save(); ctx.lineCap='round'; ctx.lineJoin='round';
  switch(rid) {
    case 0: { // Tohum — fidan yaprak
      ctx.strokeStyle='rgba(160,255,60,0.72)'; ctx.lineWidth=r*0.11;
      ctx.beginPath(); ctx.moveTo(0,s*0.9); ctx.lineTo(0,-s*0.18); ctx.stroke();
      ctx.fillStyle='rgba(110,220,30,0.72)';
      ctx.beginPath(); ctx.moveTo(0,-s*0.05); ctx.quadraticCurveTo(-s*1.0,-s*0.4,-s*0.1,-s*0.88); ctx.quadraticCurveTo(-s*0.05,-s*0.35,0,-s*0.05); ctx.fill();
      ctx.beginPath(); ctx.moveTo(0,-s*0.28); ctx.quadraticCurveTo(s*1.0,-s*0.58,s*0.08,-s*1.02); ctx.quadraticCurveTo(s*0.04,-s*0.46,0,-s*0.28); ctx.fill();
      ctx.strokeStyle='rgba(200,255,100,0.5)'; ctx.lineWidth=r*0.07;
      ctx.beginPath(); ctx.moveTo(0,-s*0.05); ctx.lineTo(-s*0.42,-s*0.52); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0,-s*0.28); ctx.lineTo(s*0.38,-s*0.7); ctx.stroke();
      break;
    }
    case 1: { // Taş — kırık çatlak deseni
      ctx.strokeStyle='rgba(20,28,35,0.58)'; ctx.lineWidth=r*0.11;
      ctx.beginPath(); ctx.moveTo(-s*0.72,-s*0.82); ctx.lineTo(-s*0.08,-s*0.05); ctx.lineTo(s*0.58,s*0.78); ctx.stroke();
      ctx.lineWidth=r*0.08;
      ctx.beginPath(); ctx.moveTo(-s*0.08,-s*0.05); ctx.lineTo(s*0.68,-s*0.52); ctx.stroke();
      ctx.lineWidth=r*0.06;
      ctx.beginPath(); ctx.moveTo(s*0.58,s*0.78); ctx.lineTo(s*0.82,s*0.18); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-s*0.72,-s*0.82); ctx.lineTo(-s*0.9,-s*0.3); ctx.stroke();
      ctx.strokeStyle='rgba(255,255,255,0.16)'; ctx.lineWidth=r*0.05;
      ctx.beginPath(); ctx.moveTo(-s*0.66,-s*0.74); ctx.lineTo(-s*0.04,s*0.02); ctx.lineTo(s*0.52,s*0.7); ctx.stroke();
      // Stone chips
      ctx.fillStyle='rgba(200,215,225,0.35)';
      ctx.beginPath(); ctx.ellipse(-s*0.42,-s*0.42,s*0.18,s*0.1,-0.5,0,Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(s*0.3,s*0.35,s*0.14,s*0.08,0.4,0,Math.PI*2); ctx.fill();
      break;
    }
    case 2: { // Köylü — ahşap halka deseni
      ctx.strokeStyle='rgba(55,18,0,0.48)'; ctx.lineWidth=r*0.095;
      for(let i=-2;i<=2;i++){const yw=i*s*0.37,xO=Math.abs(i)*s*0.08;ctx.beginPath();ctx.ellipse(0,yw,s*(0.78-xO),s*0.1,0,0,Math.PI);ctx.stroke();}
      ctx.strokeStyle='rgba(150,70,15,0.32)'; ctx.lineWidth=r*0.055;
      for(let x=-s*0.46;x<=s*0.5;x+=s*0.24){ctx.beginPath();ctx.moveTo(x,-s*0.85);ctx.quadraticCurveTo(x+s*0.08,0,x-s*0.04,s*0.85);ctx.stroke();}
      // Knot
      ctx.strokeStyle='rgba(40,10,0,0.4)'; ctx.lineWidth=r*0.07;
      ctx.beginPath(); ctx.ellipse(s*0.18,-s*0.12,s*0.22,s*0.16,0.5,0,Math.PI*2); ctx.stroke();
      ctx.strokeStyle='rgba(80,25,0,0.25)'; ctx.lineWidth=r*0.05;
      ctx.beginPath(); ctx.ellipse(s*0.18,-s*0.12,s*0.12,s*0.08,0.5,0,Math.PI*2); ctx.stroke();
      break;
    }
    case 3: { // Acemi — tek kılıç
      const sw=r*0.11;
      ctx.fillStyle='rgba(140,195,228,0.82)';
      ctx.beginPath();ctx.moveTo(0,-s*0.94);ctx.lineTo(sw,s*0.06);ctx.lineTo(-sw,s*0.06);ctx.closePath();ctx.fill();
      ctx.fillStyle='rgba(255,255,255,0.44)';
      ctx.beginPath();ctx.moveTo(-sw*0.25,-s*0.90);ctx.lineTo(-sw*0.55,-s*0.22);ctx.lineTo(0,-s*0.04);ctx.closePath();ctx.fill();
      // Crossguard
      ctx.fillStyle='rgba(70,115,155,0.9)';
      ctx.beginPath();ctx.roundRect(-s*0.46,s*0.02,s*0.92,s*0.16,r*0.06);ctx.fill();
      ctx.fillStyle='rgba(255,255,255,0.25)';
      ctx.beginPath();ctx.roundRect(-s*0.44,s*0.03,s*0.88,s*0.06,r*0.04);ctx.fill();
      // Handle
      ctx.fillStyle='rgba(90,48,12,0.88)';
      ctx.beginPath();ctx.roundRect(-sw*0.82,s*0.18,sw*1.64,s*0.6,r*0.05);ctx.fill();
      ctx.strokeStyle='rgba(180,140,60,0.5)';ctx.lineWidth=r*0.055;
      ctx.beginPath();ctx.moveTo(-sw*0.82,s*0.32);ctx.lineTo(sw*0.82,s*0.32);ctx.stroke();
      ctx.beginPath();ctx.moveTo(-sw*0.82,s*0.48);ctx.lineTo(sw*0.82,s*0.48);ctx.stroke();
      // Pommel
      ctx.fillStyle='rgba(120,170,200,0.9)';
      ctx.beginPath();ctx.arc(0,s*0.88,sw*1.35,0,Math.PI*2);ctx.fill();
      ctx.fillStyle='rgba(255,255,255,0.4)';
      ctx.beginPath();ctx.arc(-sw*0.35,s*0.82,sw*0.5,0,Math.PI*2);ctx.fill();
      break;
    }
    case 4: { // Savaşçı — çapraz kılıçlar
      const sw=r*0.095;
      for(const ang of[-Math.PI/4,Math.PI/4]){
        ctx.save(); ctx.rotate(ang);
        ctx.fillStyle='rgba(70,145,255,0.85)';
        ctx.beginPath();ctx.moveTo(0,-s*0.94);ctx.lineTo(sw,-s*0.0);ctx.lineTo(-sw,-s*0.0);ctx.closePath();ctx.fill();
        ctx.fillStyle='rgba(180,220,255,0.52)';
        ctx.beginPath();ctx.moveTo(-sw*0.2,-s*0.90);ctx.lineTo(-sw*0.55,-s*0.28);ctx.lineTo(0,-s*0.44);ctx.closePath();ctx.fill();
        ctx.fillStyle='rgba(25,75,200,0.95)';
        ctx.beginPath();ctx.roundRect(-s*0.4,-s*0.08,s*0.8,s*0.15,r*0.05);ctx.fill();
        ctx.fillStyle='rgba(255,255,255,0.22)';
        ctx.beginPath();ctx.roundRect(-s*0.38,-s*0.07,s*0.76,s*0.06,r*0.03);ctx.fill();
        ctx.fillStyle='rgba(15,50,150,0.88)';
        ctx.beginPath();ctx.roundRect(-sw*0.78,s*0.07,sw*1.56,s*0.48,r*0.04);ctx.fill();
        ctx.restore();
      }
      // Center rivet
      ctx.fillStyle='rgba(200,230,255,0.9)';
      ctx.beginPath();ctx.arc(0,0,r*0.1,0,Math.PI*2);ctx.fill();
      break;
    }
    case 5: { // Muhafız — kalkan
      ctx.fillStyle='rgba(18,155,58,0.75)';
      ctx.beginPath();ctx.moveTo(0,-s*0.94);ctx.lineTo(s*0.74,-s*0.38);ctx.lineTo(s*0.74,s*0.32);ctx.lineTo(0,s*0.94);ctx.lineTo(-s*0.74,s*0.32);ctx.lineTo(-s*0.74,-s*0.38);ctx.closePath();ctx.fill();
      ctx.strokeStyle='rgba(140,255,120,0.58)';ctx.lineWidth=r*0.1;ctx.stroke();
      // Inner shield boss
      ctx.fillStyle='rgba(10,120,40,0.55)';
      ctx.beginPath();ctx.moveTo(0,-s*0.5);ctx.lineTo(s*0.42,-s*0.18);ctx.lineTo(s*0.42,s*0.22);ctx.lineTo(0,s*0.5);ctx.lineTo(-s*0.42,s*0.22);ctx.lineTo(-s*0.42,-s*0.18);ctx.closePath();ctx.fill();
      ctx.strokeStyle='rgba(180,255,160,0.55)';ctx.lineWidth=r*0.085;
      ctx.beginPath();ctx.moveTo(0,-s*0.58);ctx.lineTo(0,s*0.58);ctx.moveTo(-s*0.52,0);ctx.lineTo(s*0.52,0);ctx.stroke();
      // Top-left shine
      ctx.fillStyle='rgba(255,255,255,0.34)';
      ctx.beginPath();ctx.moveTo(-s*0.6,-s*0.3);ctx.lineTo(0,-s*0.9);ctx.lineTo(s*0.22,-s*0.42);ctx.lineTo(-s*0.16,-s*0.08);ctx.closePath();ctx.fill();
      // Center stud
      ctx.fillStyle='rgba(200,255,170,0.8)';
      ctx.beginPath();ctx.arc(0,0,r*0.1,0,Math.PI*2);ctx.fill();
      break;
    }
    case 6: { // Ateş Efendisi — üç katmanlı alev
      // Outer flame
      ctx.fillStyle='rgba(255,95,5,0.80)';
      ctx.beginPath();ctx.moveTo(0,s*0.9);ctx.bezierCurveTo(-s*0.58,s*0.4,-s*0.68,-s*0.08,-s*0.14,-s*0.54);ctx.bezierCurveTo(-s*0.24,-s*0.1,s*0.06,s*0.08,0,-s*0.94);ctx.bezierCurveTo(s*0.44,-s*0.34,s*0.54,s*0.2,s*0.16,s*0.58);ctx.bezierCurveTo(s*0.5,s*0.44,s*0.6,s*0.74,0,s*0.9);ctx.closePath();ctx.fill();
      // Mid flame
      ctx.fillStyle='rgba(255,185,15,0.82)';
      ctx.beginPath();ctx.moveTo(0,s*0.56);ctx.bezierCurveTo(-s*0.32,s*0.14,-s*0.36,-s*0.18,0,-s*0.68);ctx.bezierCurveTo(s*0.32,-s*0.12,s*0.36,s*0.18,0,s*0.56);ctx.closePath();ctx.fill();
      // Inner core
      ctx.fillStyle='rgba(255,252,180,0.88)';
      ctx.beginPath();ctx.moveTo(0,s*0.28);ctx.bezierCurveTo(-s*0.16,s*0.05,-s*0.18,-s*0.1,0,-s*0.38);ctx.bezierCurveTo(s*0.16,-s*0.05,s*0.18,s*0.1,0,s*0.28);ctx.closePath();ctx.fill();
      // Hot white tip
      ctx.fillStyle='rgba(255,255,240,0.9)';
      ctx.beginPath();ctx.arc(0,-s*0.18,r*0.1,0,Math.PI*2);ctx.fill();
      break;
    }
    case 7: { // Kristal — elmas facet + ışıltı
      // Crystal facet lines (6-pointed star)
      ctx.strokeStyle='rgba(100,235,255,0.62)'; ctx.lineWidth=r*0.075;
      for(let i=0;i<6;i++){const a=(i*Math.PI)/6;ctx.beginPath();ctx.moveTo(Math.cos(a)*s*0.9,Math.sin(a)*s*0.9);ctx.lineTo(-Math.cos(a)*s*0.9,-Math.sin(a)*s*0.9);ctx.stroke();}
      // Hexagonal facet outline
      ctx.strokeStyle='rgba(180,250,255,0.45)'; ctx.lineWidth=r*0.065;
      ctx.beginPath();
      for(let i=0;i<6;i++){const a=(i*Math.PI/3)-Math.PI/6;i===0?ctx.moveTo(Math.cos(a)*s*0.65,Math.sin(a)*s*0.65):ctx.lineTo(Math.cos(a)*s*0.65,Math.sin(a)*s*0.65);}
      ctx.closePath();ctx.stroke();
      // Center gem radial gradient
      const cg7=ctx.createRadialGradient(0,0,0,0,0,s*0.35);
      cg7.addColorStop(0,'rgba(255,255,255,0.95)');cg7.addColorStop(0.4,'rgba(140,248,255,0.75)');cg7.addColorStop(1,'rgba(0,200,240,0)');
      ctx.fillStyle=cg7;ctx.beginPath();ctx.arc(0,0,s*0.35,0,Math.PI*2);ctx.fill();
      // Corner sparkles
      ctx.fillStyle='rgba(255,255,255,0.85)';
      for(const[sx,sy,sr]of[[s*0.75,-s*0.75,r*0.08],[-s*0.75,-s*0.75,r*0.06],[s*0.75,s*0.75,r*0.065],[-s*0.75,s*0.75,r*0.07]]){
        ctx.save();ctx.translate(sx,sy);
        // 4-point star
        ctx.beginPath();ctx.moveTo(0,-sr*2);ctx.lineTo(sr*0.6,-sr*0.6);ctx.lineTo(sr*2,0);ctx.lineTo(sr*0.6,sr*0.6);ctx.lineTo(0,sr*2);ctx.lineTo(-sr*0.6,sr*0.6);ctx.lineTo(-sr*2,0);ctx.lineTo(-sr*0.6,-sr*0.6);ctx.closePath();ctx.fill();
        ctx.restore();
      }
      break;
    }
    case 8: { // Fırtına — şimşek + elektrik
      // Main lightning bolt
      ctx.fillStyle='rgba(210,155,255,0.88)';
      ctx.beginPath();ctx.moveTo(s*0.18,-s*0.94);ctx.lineTo(-s*0.38,-s*0.04);ctx.lineTo(s*0.06,-s*0.04);ctx.lineTo(-s*0.24,s*0.94);ctx.lineTo(s*0.44,s*0.0);ctx.lineTo(s*0.02,s*0.0);ctx.lineTo(s*0.54,-s*0.94);ctx.closePath();ctx.fill();
      ctx.strokeStyle='rgba(255,255,255,0.52)';ctx.lineWidth=r*0.065;ctx.stroke();
      // Bright core
      ctx.fillStyle='rgba(255,255,255,0.65)';
      ctx.beginPath();ctx.moveTo(s*0.26,-s*0.84);ctx.lineTo(-s*0.2,-s*0.08);ctx.lineTo(s*0.12,-s*0.08);ctx.lineTo(-s*0.1,s*0.65);ctx.lineTo(s*0.32,s*0.02);ctx.lineTo(s*0.08,s*0.02);ctx.lineTo(s*0.46,-s*0.84);ctx.closePath();ctx.fill();
      // Side electric arcs
      ctx.strokeStyle='rgba(220,160,255,0.68)';ctx.lineWidth=r*0.065;
      ctx.beginPath();ctx.moveTo(-s*0.72,-s*0.52);ctx.quadraticCurveTo(-s*0.5,-s*0.18,-s*0.38,-s*0.04);ctx.stroke();
      ctx.beginPath();ctx.moveTo(s*0.7,s*0.5);ctx.quadraticCurveTo(s*0.55,s*0.22,s*0.44,s*0.0);ctx.stroke();
      // Spark dots
      ctx.fillStyle='rgba(255,240,255,0.9)';
      for(const[sx,sy]of[[-s*0.78,-s*0.7],[s*0.78,s*0.68],[-s*0.6,s*0.0],[s*0.6,-s*0.62]]){
        ctx.beginPath();ctx.arc(sx,sy,r*0.07,0,Math.PI*2);ctx.fill();
      }
      break;
    }
    case 9: { // Gece Hanı — hilal + yıldız gökyüzü
      // Sky circle bg
      ctx.fillStyle='rgba(6,10,48,0.58)';
      ctx.beginPath();ctx.arc(0,0,s*0.88,0,Math.PI*2);ctx.fill();
      // Moon body (full circle)
      const mg9=ctx.createRadialGradient(-s*0.14,-s*0.05,0,-s*0.14,-s*0.05,s*0.65);
      mg9.addColorStop(0,'rgba(210,220,255,0.95)');mg9.addColorStop(0.6,'rgba(165,180,248,0.88)');mg9.addColorStop(1,'rgba(100,120,210,0.5)');
      ctx.fillStyle=mg9;ctx.beginPath();ctx.arc(-s*0.14,-s*0.04,s*0.62,0,Math.PI*2);ctx.fill();
      // Dark overlay for crescent illusion (matches badge dark bg)
      ctx.fillStyle='rgba(5,8,38,0.97)';
      ctx.beginPath();ctx.arc(s*0.22,-s*0.08,s*0.52,0,Math.PI*2);ctx.fill();
      // Moon edge glow
      ctx.strokeStyle='rgba(160,180,255,0.42)';ctx.lineWidth=r*0.08;
      ctx.beginPath();ctx.arc(-s*0.14,-s*0.04,s*0.62,0,Math.PI*2);ctx.stroke();
      // Stars (5-pointed, small)
      ctx.fillStyle='rgba(225,232,255,0.95)';
      for(const[sx,sy,sr9]of[[s*0.6,-s*0.65,r*0.075],[s*0.76,-s*0.08,r*0.055],[s*0.5,s*0.64,r*0.065],[-s*0.62,-s*0.55,r*0.055],[s*0.3,s*0.88,r*0.048]]){
        ctx.save();ctx.translate(sx,sy);
        ctx.beginPath();
        for(let k=0;k<5;k++){const a=(k*4*Math.PI/5)-Math.PI/2,a2=a+Math.PI/5;k===0?ctx.moveTo(sr9*1.7*Math.cos(a),sr9*1.7*Math.sin(a)):ctx.lineTo(sr9*1.7*Math.cos(a),sr9*1.7*Math.sin(a));ctx.lineTo(sr9*0.65*Math.cos(a2),sr9*0.65*Math.sin(a2));}
        ctx.closePath();ctx.fill();ctx.restore();
      }
      break;
    }
    case 10: { // Efsane — altın taç + mücevher
      const cw=s*0.88,ch=s*0.7;
      // Crown base
      ctx.fillStyle='rgba(255,192,8,0.90)';
      ctx.beginPath();ctx.roundRect(-cw*0.5,ch*0.08,cw,ch*0.5,r*0.1);ctx.fill();
      // Crown prongs (3)
      ctx.beginPath();
      ctx.moveTo(-cw*0.5,ch*0.12);ctx.lineTo(-cw*0.42,-ch*0.64);ctx.lineTo(-cw*0.24,ch*0.08);
      ctx.lineTo(-cw*0.08,-ch*0.9);ctx.lineTo(cw*0.08,-ch*0.9);
      ctx.lineTo(cw*0.24,ch*0.08);ctx.lineTo(cw*0.42,-ch*0.64);ctx.lineTo(cw*0.5,ch*0.12);
      ctx.closePath();ctx.fill();
      ctx.strokeStyle='rgba(255,238,70,0.62)';ctx.lineWidth=r*0.085;ctx.stroke();
      // Gems (3 colors)
      for(const[gx,col,hcol]of[[-cw*0.3,'#ff4444','#ff9999'],[0,'#4488ff','#aaccff'],[cw*0.3,'#44ee88','#aaffcc']]){
        ctx.fillStyle=col;ctx.beginPath();ctx.arc(gx,ch*0.32,r*0.115,0,Math.PI*2);ctx.fill();
        ctx.fillStyle=hcol;ctx.beginPath();ctx.arc(gx-r*0.04,ch*0.28,r*0.048,0,Math.PI*2);ctx.fill();
      }
      // Crown shine highlight
      ctx.fillStyle='rgba(255,255,255,0.28)';
      ctx.beginPath();ctx.moveTo(-cw*0.44,-ch*0.52);ctx.lineTo(-cw*0.08,-ch*0.86);ctx.lineTo(cw*0.08,-ch*0.86);ctx.lineTo(cw*0.26,-ch*0.08);ctx.lineTo(-cw*0.28,-ch*0.08);ctx.closePath();ctx.fill();
      // Top center jewel
      ctx.fillStyle='rgba(255,255,180,0.95)';
      ctx.beginPath();ctx.arc(0,-ch*0.88,r*0.1,0,Math.PI*2);ctx.fill();
      break;
    }
    case 11: { // Tanrısal — ilahi ışıma + halka + orb
      const rays=18;
      // Outer aura
      const ag11=ctx.createRadialGradient(0,0,s*0.18,0,0,s*0.95);
      ag11.addColorStop(0,'rgba(255,255,255,0)');ag11.addColorStop(0.6,'rgba(255,180,240,0.18)');ag11.addColorStop(1,'rgba(255,80,200,0.38)');
      ctx.fillStyle=ag11;ctx.beginPath();ctx.arc(0,0,s*0.95,0,Math.PI*2);ctx.fill();
      // Halo ring (rainbow animate)
      ctx.lineWidth=r*0.11;
      const hue11=t?(t*0.5)%360:0;
      ctx.strokeStyle=`hsla(${hue11},100%,85%,0.7)`;
      ctx.beginPath();ctx.arc(0,0,s*0.88,0,Math.PI*2);ctx.stroke();
      // Inner halo
      ctx.lineWidth=r*0.065;
      ctx.strokeStyle=`hsla(${(hue11+60)%360},100%,88%,0.45)`;
      ctx.beginPath();ctx.arc(0,0,s*0.6,0,Math.PI*2);ctx.stroke();
      // Radiant rays (alternating long/short, rainbow)
      for(let i=0;i<rays;i++){
        const a=(i*Math.PI*2/rays)+(t?t*0.001:0);
        const isLong=i%2===0;
        const len=isLong?s*0.75:s*0.5;
        const rh=(hue11+i*20)%360;
        ctx.strokeStyle=`hsla(${rh},100%,82%,${isLong?0.72:0.4})`;
        ctx.lineWidth=r*(isLong?0.1:0.065);
        ctx.beginPath();ctx.moveTo(Math.cos(a)*s*0.22,Math.sin(a)*s*0.22);ctx.lineTo(Math.cos(a)*len,Math.sin(a)*len);ctx.stroke();
      }
      // Divine orb center
      const og11=ctx.createRadialGradient(0,0,0,0,0,s*0.3);
      og11.addColorStop(0,'rgba(255,255,255,1)');og11.addColorStop(0.35,'rgba(255,195,245,0.9)');og11.addColorStop(0.7,'rgba(255,80,200,0.5)');og11.addColorStop(1,'rgba(200,0,160,0)');
      ctx.fillStyle=og11;ctx.beginPath();ctx.arc(0,0,s*0.32,0,Math.PI*2);ctx.fill();
      break;
    }
  }
  ctx.restore();
}

// ── GRADIENT CACHE for rank badges ──────────────────────────────────────────
// Rank badges are drawn per player per frame. Creating 3 RadialGradients each
// time is hugely expensive. Cache by (rid | sizeKey): only 24 possible entries.
// Gradients are defined in translated ctx space, so they're position-independent.
const _rankGC = {}; // key: rid+'|'+sizeKey → {fill,shine,shad}
function _getRankGrad(ctx, rid, r){
  const sk = r <= 8 ? 0 : 1;
  const key = rid + '|' + sk;
  if (_rankGC[key]) return _rankGC[key];
  const m = _RANK_META[rid], [c1,c2] = m;
  let fill;
  if(rid===0){fill=ctx.createRadialGradient(-r*.28,-r*.32,0,r*.1,r*.1,r*1.05);fill.addColorStop(0,'#a0e050');fill.addColorStop(0.4,c1);fill.addColorStop(0.82,c2);fill.addColorStop(1,'#030a00');}
  else if(rid===1){fill=ctx.createRadialGradient(0,-r*.18,0,0,r*.12,r*0.98);fill.addColorStop(0,'#d5dde5');fill.addColorStop(0.5,'#8898a8');fill.addColorStop(1,'#222830');}
  else if(rid===2){fill=ctx.createRadialGradient(-r*.22,-r*.28,0,r*.08,r*.08,r*1.02);fill.addColorStop(0,'#e8a060');fill.addColorStop(0.45,c1);fill.addColorStop(0.82,c2);fill.addColorStop(1,'#1a0800');}
  else if(rid===3){fill=ctx.createRadialGradient(-r*.25,-r*.30,0,0,0,r*1.05);fill.addColorStop(0,'#b0d8f8');fill.addColorStop(0.4,c1);fill.addColorStop(0.82,c2);fill.addColorStop(1,'#020810');}
  else if(rid===6){fill=ctx.createRadialGradient(0,r*.22,0,0,0,r*1.05);fill.addColorStop(0,'#ffee50');fill.addColorStop(0.25,'#ff8820');fill.addColorStop(0.65,c2);fill.addColorStop(1,'#1a0000');}
  else if(rid===7){fill=ctx.createRadialGradient(-r*.28,-r*.28,0,0,0,r*1.05);fill.addColorStop(0,'#ffffff');fill.addColorStop(0.22,'#88f0ff');fill.addColorStop(0.7,c2);fill.addColorStop(1,'#000a12');}
  else if(rid===8){fill=ctx.createRadialGradient(0,0,0,0,0,r);fill.addColorStop(0,'#5020a0');fill.addColorStop(0.45,c2);fill.addColorStop(1,'#080010');}
  else if(rid===9){fill=ctx.createRadialGradient(0,0,0,0,0,r);fill.addColorStop(0,'#2038b0');fill.addColorStop(0.5,'#080c58');fill.addColorStop(1,'#010210');}
  else if(rid===10){fill=ctx.createRadialGradient(-r*.2,-r*.22,0,0,0,r*1.06);fill.addColorStop(0,'#fff8a0');fill.addColorStop(0.3,'#ffc800');fill.addColorStop(0.75,c2);fill.addColorStop(1,'#120800');}
  else if(rid===11){fill=ctx.createRadialGradient(0,0,0,0,0,r);fill.addColorStop(0,'#ffffff');fill.addColorStop(0.18,'#ffddff');fill.addColorStop(0.5,c1);fill.addColorStop(1,c2);}
  else{fill=ctx.createRadialGradient(-r*.30,-r*.34,0,0,0,r*1.06);fill.addColorStop(0,c1);fill.addColorStop(0.46,c1);fill.addColorStop(0.82,c2);fill.addColorStop(1,'#000');}
  const shine=ctx.createRadialGradient(-r*.30,-r*.38,0,-r*.12,-r*.18,r*.76);
  const shA=rid<=2?0.52:rid<=6?0.38:0.22;
  shine.addColorStop(0,`rgba(255,255,255,${shA})`);shine.addColorStop(0.44,'rgba(255,255,255,0.06)');shine.addColorStop(1,'rgba(255,255,255,0)');
  const shad=ctx.createRadialGradient(r*.28,r*.32,0,r*.12,r*.18,r*.82);
  shad.addColorStop(0,'rgba(0,0,0,0.58)');shad.addColorStop(1,'rgba(0,0,0,0)');
  _rankGC[key]={fill,shine,shad};
  return _rankGC[key];
}

function drawRankBadge12(ctx, cx, cy, rankId, size, t) {
  const rid = Math.max(0, Math.min(11, (rankId|0)));
  const m = _RANK_META[rid];
  const [c1, c2, cb, cg] = m;
  const r = size;
  ctx.save();
  ctx.translate(cx, cy);

  // Glow (rank 3+), pulsing for high tiers — only at quality level 2 (shadowBlur is expensive)
  if (rid >= 3 && _qualityLevel >= 2) {
    const pulse = t ? (Math.sin(t * 0.003) * 0.25 + 0.85) : 1;
    ctx.shadowColor = cg;
    ctx.shadowBlur = (5 + rid * 2.6) * pulse;
  }

  // Outer dark shell (unique shade per rank group)
  ctx.fillStyle = rid <= 2 ? '#0a0a0a' : rid <= 5 ? '#060810' : rid <= 8 ? '#08040e' : '#040408';
  _drawDodecagon(ctx, r + 1.5);
  ctx.fill();
  ctx.shadowBlur = 0;

  // Main fill — CACHED gradient (zero allocation after first draw per rid+size)
  const _gc = _getRankGrad(ctx, rid, r);
  ctx.fillStyle = _gc.fill;
  _drawDodecagon(ctx,r);ctx.fill();

  // Border — thinner and cleaner for better readability
  ctx.strokeStyle=cb;
  ctx.lineWidth=rid<=2?0.8:rid<=6?1.0:rid<=9?1.15:1.3;
  _drawDodecagon(ctx,r);ctx.stroke();

  // Inner trim ring
  const trimA=[0.18,0.12,0.18,0.22,0.28,0.30,0.32,0.35,0.28,0.22,0.35,0.42][rid];
  ctx.strokeStyle=`rgba(255,255,255,${trimA})`;ctx.lineWidth=0.6;
  _drawDodecagon(ctx,r*0.68);ctx.stroke();

  // Top-left shine overlay — CACHED
  ctx.fillStyle=_gc.shine;_drawDodecagon(ctx,r-1);ctx.fill();

  // Bottom-right depth shadow — CACHED
  ctx.fillStyle=_gc.shad;_drawDodecagon(ctx,r-1);ctx.fill();

  // Extra rings per rank group
  if(rid>=7&&rid<=9){
    const rc7=rid===7?'rgba(180,248,255,0.2)':rid===8?'rgba(220,100,255,0.2)':'rgba(100,120,255,0.18)';
    ctx.strokeStyle=rc7;ctx.lineWidth=0.85;_drawDodecagon(ctx,r*0.84);ctx.stroke();
  }
  if(rid>=10&&t){
    ctx.save();ctx.rotate(t*(rid===11?0.0025:0.0014));
    ctx.strokeStyle=rid===11?'rgba(255,170,240,0.68)':'rgba(255,228,50,0.65)';
    ctx.lineWidth=1.5;_drawDodecagon(ctx,r*0.84);ctx.stroke();ctx.restore();
    if(rid===11){
      ctx.save();ctx.rotate(-t*0.002);
      ctx.strokeStyle='rgba(255,130,220,0.38)';ctx.lineWidth=1.0;_drawDodecagon(ctx,r*0.93);ctx.stroke();ctx.restore();
      ctx.save();ctx.rotate(t*0.0008);
      ctx.strokeStyle='rgba(200,255,240,0.25)';ctx.lineWidth=0.8;_drawDodecagon(ctx,r*0.76);ctx.stroke();ctx.restore();
    }
  }
  if(rid===8&&t&&Math.sin(t*0.012)>0.5){
    ctx.strokeStyle='rgba(200,80,255,0.38)';ctx.lineWidth=1.1;_drawDodecagon(ctx,r*0.92);ctx.stroke();
  }

  // Draw unique decoration (clipped to badge interior)
  ctx.save();
  _drawDodecagon(ctx, r - 1.8);
  ctx.clip();
  _drawRankDecor(ctx, rid, r, t);
  ctx.restore();

  ctx.restore();
}

function _renderRankBadgeCanvas(canvas, rankId, size = 48) {
  if (!canvas) return;
  canvas.width = size * 2;
  canvas.height = size * 2;
  const context = canvas.getContext('2d');
  context.clearRect(0, 0, canvas.width, canvas.height);
  drawRankBadge12(context, size, size, rankId, size * .82, globalTime || 0);
}

function _renderDeathRankVisuals(currentId, nextId) {
  const label = document.getElementById('death-rank-label');
  if (!label) return;
  label.innerHTML = '<canvas id="death-current-rank" aria-label="Mevcut rank"></canvas><span class="death-rank-arrow">→</span><canvas id="death-next-rank" aria-label="Sonraki rank"></canvas>';
  _renderRankBadgeCanvas(document.getElementById('death-current-rank'), currentId);
  _renderRankBadgeCanvas(document.getElementById('death-next-rank'), nextId);
}

// ── Name tag: [badge] PlayerName / RankName ──────────────────
function drawNameTag12(ctx, wx, wy, name, rankId, hpRatio, isOwn, t) {
  const rid = Math.max(0, Math.min(11, (rankId|0)));
  const BR  = isOwn ? 8 : 7;
  const FS  = isOwn ? 9 : 8;
  const GAP = 5;

  ctx.save();
  ctx.font = `900 ${FS}px Arial`;
  ctx.textBaseline = 'middle';
  const tw = ctx.measureText(name).width;
  const totalW = tw + GAP + BR * 2 + 2;
  const lx = wx - totalW / 2;

  // ── Name text ──
  const nameX = lx;
  const nameCol = isOwn ? '#ffffff' : (hpRatio < 0.30 ? '#ff7777' : '#ffffff');
  ctx.strokeStyle = 'rgba(0,0,0,0.80)';
  ctx.lineWidth = 1.25;
  ctx.textAlign = 'left';
  ctx.strokeText(name, nameX, wy);
  ctx.fillStyle = nameCol;
  ctx.fillText(name, nameX, wy);

  // ── Badge on the right side of the name with a tiny gap ──
  drawRankBadge12(ctx, nameX + tw + GAP + BR, wy, rid, BR, t);

  ctx.restore();
}

// PERF: Cached name tag renderer — wraps drawNameTag12 with OffscreenCanvas caching.
// Eliminates 8-12 dodecagon path rebuilds + 4 fillText calls per player per frame.
// For 10 visible players: 120 path ops → 10 drawImage calls per frame.
// Cache key: name + rankId + hpBucket (0=low, 1=ok) + isOwn + timeBucket (rank animation).
function _drawNameTagCached(ctx, sx, sy, name, rankId, hpRatio, isOwn, t) {
  const rid = Math.max(0, Math.min(11, rankId | 0));
  const hpBucket = hpRatio < 0.30 ? 0 : 1;
  const ttl = _NT_TTL[rid];
  const timeBucket = ttl > 0 ? ((t / ttl) | 0) : 0;
  const key = name + '_' + rid + '_' + hpBucket + '_' + (isOwn ? 1 : 0) + '_' + timeBucket;

  let entry = _NT_OC_CACHE.get(key);
  if (!entry) {
    // Measure text to size the OC exactly (no padding waste)
    const BR = isOwn ? 8 : 7, FS = isOwn ? 9 : 8, GAP = 5;
    _NT_MEAS_CTX.font = '900 ' + FS + 'px Arial';
    const tw = _NT_MEAS_CTX.measureText(name).width;
    const totalW = tw + GAP + BR * 2 + 2;
    const pad = 6;
    const ocW = Math.ceil(totalW + pad * 2);
    const anchorX = pad + totalW / 2;
    const anchorY = pad + BR + 2;
    const ocH = Math.ceil(anchorY + BR * 1.5 + pad);
    const oc = createRenderCanvas(ocW, ocH);
    const occ = oc.getContext('2d');
    drawNameTag12(occ, anchorX, anchorY, name, rankId, hpRatio, isOwn, t);
    entry = { oc, anchorX, anchorY };
    _NT_OC_CACHE.set(key, entry);
    // LRU eviction: keep cache bounded at 120 entries — evict oldest
    if (_NT_OC_CACHE.size > 120) { _NT_OC_CACHE.delete(_NT_OC_CACHE.keys().next().value); }
  }
  ctx.drawImage(entry.oc, sx - entry.anchorX, sy - entry.anchorY);
}

// Load own rank from stored auth user
const _storedAuthUser = JSON.parse(localStorage.getItem('fb_auth_user')||'null');
let _myRankId = _storedAuthUser ? (_storedAuthUser.rankId ?? 0) : 0;
const _otherPlayers = new Map(); // id → serverPlayerState
// Deferred name tag queue — filled during world rendering, flushed in screen-space after ctx.restore()
// This guarantees names are always rendered on top of every game object and are pixel-crisp.
let _pendingNameTags = [];
let _ping = 0;
let _pingTimer = 0;
let _stateTimer = 0;
let _lastEmitX = 0, _lastEmitY = 0, _lastEmitAngle = 0, _lastEmitHp = 100, _lastEmitScore = 0, _lastEmitGold = 0, _lastEmitKills = 0, _lastEmitXp = 0, _lastEmitAttacking = false;
let _lastEmitVx = 0, _lastEmitVy = 0; // ② velocity change detection for delta emit
let _posErrorX = 0, _posErrorY = 0; // Smooth CSP error blending
let _lastMpSendTime = 0; // Fixed network tick rate
let _chatInput = null;
let _isDying = false; // guard against double-die (pvp_hit + pvp_killed race)

// ============================================================
// PLAYER
// ============================================================
const ATTACK_DUR = {
  1: 23,   // Axe: quick strike, heavier return
  2: 19,   // Sword: quick strike, controlled return
  3: 15, 4: 15, 5: 15, 6: 15, 7: 15, 8: 15, 9: 15, // Buildings
};
// Per-swing hit tracking: each swing gets a unique ID, each enemy/resource can be hit once per swing
let _swingId = 0; // increments each new swing
// Kill cam state
let _killCamTimer = 0;
let _killCamX = 0, _killCamY = 0;
let _lastDamager = null; // tracks which enemy last damaged the player

// Load equipped accessories and skin color from shop system
const _shopAcc = JSON.parse(localStorage.getItem('fb_acc_equipped') || '{}');
const _urlWepSkin = urlParams.get('wepSkin') || localStorage.getItem('fb_weapon_skin') || _shopAcc.baltalar || _shopAcc.kiliclar;
if (_urlWepSkin) {
  if (_urlWepSkin.startsWith('ba_')) _shopAcc.baltalar = _urlWepSkin;
  else if (_urlWepSkin.startsWith('ki_')) _shopAcc.kiliclar = _urlWepSkin;
}
const _SKIN_COL = {c_beige:'#d4a574',c_dark:'#5a4030',c_pink:'#e87fac',c_blue:'#4d8aff',c_purple:'#9b59b6',c_red:'#e84444',c_green:'#2ecc71',c_gold:'#f5c842'};
const playerColor = (_shopAcc.renkler && _SKIN_COL[_shopAcc.renkler]) || decodeURIComponent(urlParams.get('color') || '#cda886');
const playerAcc = _shopAcc; // {kanatlar, sapkalar, yuz, aksesuarlar, renkler}
const _playerSkin = urlParams.get('skin') || localStorage.getItem('fb_skin') || (_shopAcc && _shopAcc.deriler) || 'default';
const SKIN_ARM_COLORS = {
  default:'#c4966a',panda:'#e8e8e8',fox:'#e06020',wolf:'#667788',
  rabbit:'#ccccdd',croc:'#3a7a28',frog:'#55cc44',polarbear:'#ddeeff',
  penguin:'#333344',shark:'#6688aa',lion:'#e8b040',dragon:'#2a6020',
  skull:'#d8d4cc',ninja:'#1a1a22',robot:'#aabbcc',phoenix:'#cc4400',
  yeti:'#aaccee',octopus:'#aa44ee',
  kiz_sakura:'#f5c8d8',kiz_deniz:'#50c8b8',kiz_ates:'#c83000',kiz_buz:'#b8e8ff',
  kiz_orman:'#78bc40',kiz_vampir:'#3a0050',kiz_neon:'#100820',
  kiz_samurai:'#4a0808',kiz_karanlik:'#150830',kiz_peri:'#ffb8cc'
};
const SKIN_HAND_ACCENTS = {
  default:'#9b6a46',panda:'#777777',fox:'#ffd0a8',wolf:'#a8c0d4',rabbit:'#f08ca8',croc:'#7fbd58',frog:'#b5ef72',polarbear:'#c9e8f4',
  penguin:'#8ad7ed',shark:'#a8d8ef',lion:'#ffe08a',dragon:'#69c980',skull:'#ffffff',ninja:'#5d6680',robot:'#d9f2ff',phoenix:'#ffb36b',
  yeti:'#e8f8ff',octopus:'#f0a0ff',kiz_sakura:'#fff0f7',kiz_deniz:'#a8fff0',kiz_ates:'#ff8d64',kiz_buz:'#e4ffff',
  kiz_orman:'#c4f28a',kiz_vampir:'#b879d9',kiz_neon:'#8affee',kiz_samurai:'#e89090',kiz_karanlik:'#ba8cff',kiz_peri:'#fff0fa'
};
const _spawn = randomForestPoint();
const player = {
  name: playerName,
  clanId: _clanId,
  x: _spawn.x, y: _spawn.y, radius: 35, color: playerColor,
  angle: 0, vx: 0, vy: 0, momX: 0, momY: 0,
  weapon: 1,
  wood: 50, stone: 30, gold: 0, apples: 5,
  hp: 250, maxHp: 250, xp: 0,
  _fruitUseUntil: 0,
  isAttacking: false, attackTimer: 0,
  attackDuration: ATTACK_DUR[1],
  lastHitEnemyTime: 0,
  // Perk multipliers
  speedBonus: 1, dmgBonus: 1, harvestBonus: 1,
  armorBonus: 0, regenBonus: 1, atkSpdBonus: 1,
  hitFlash: 0,
  kills: 0, totalDmg: 0, score: 0
};
let _wasAttacking = false; // edge-detect for immediate first-frame hit

// ============================================================
// RESOURCES
// ============================================================
// Per-biome resource definitions
const RES_DEFS_BY_BIOME = {
  forest: [
    { type:'wood',  w:30, radius:176, hp:550,  yW:10, yS:0, yG:0, yA:0.35 },
    { type:'wood',  w:16, radius:219, hp:750,  yW:18, yS:0, yG:0, yA:0.25 },
    { type:'stone', w:20, radius:120, hp:650,  yW:0,  yS:10, yG:0, yA:0 },
    { type:'stone', w:10, radius:150, hp:950,  yW:0,  yS:18, yG:0, yA:0 },
    { type:'gold',  w:5,  radius:115, hp:500,  yW:0,  yS:3,  yG:3, yA:0 },
    { type:'gold',  w:3,  radius:140, hp:700,  yW:0,  yS:4,  yG:5, yA:0 },
    { type:'apple',    w:10, radius:133, hp:380,  yW:6,  yS:0,  yG:0, yA:1.5 },
    { type:'bush',     w:14, radius:83,  hp:240,  yW:4,  yS:0,  yG:0, yA:0.8 },
    { type:'mushroom', w:8,  radius:65,  hp:180,  yW:0,  yS:0,  yG:0, yA:0, yHp:45 },
    { type:'crystal',  w:4,  radius:85,  hp:300,  yW:0,  yS:0,  yG:0, yA:0, yXp:55 },
    { type:'hive',     w:3,  radius:75,  hp:260,  yW:0,  yS:0,  yG:1, yA:0, ySpd:180 },
  ],
  winter: [
    { type:'wood',  w:26, radius:167, hp:500,  yW:9,  yS:0, yG:0, yA:0.20 },
    { type:'wood',  w:13, radius:207, hp:680,  yW:14, yS:0, yG:0, yA:0.14 },
    { type:'stone', w:24, radius:123, hp:750,  yW:0,  yS:12, yG:0, yA:0 },
    { type:'stone', w:12, radius:153, hp:1050, yW:0,  yS:20, yG:0, yA:0 },
    { type:'gold',  w:6,  radius:118, hp:540,  yW:0,  yS:3,  yG:3, yA:0 },
    { type:'gold',  w:3,  radius:143, hp:740,  yW:0,  yS:4,  yG:5, yA:0 },
    { type:'crystal', w:5, radius:85, hp:300,  yW:0,  yS:0,  yG:0, yA:0, yXp:55 },
    { type:'bush',  w:8,  radius:78,  hp:220,  yW:2,  yS:0,  yG:0, yA:0.5 },
  ],
  desert: [
    { type:'wood',  w:16, radius:161, hp:460,  yW:7,  yS:0, yG:0, yA:0.14 },
    { type:'wood',  w:9,  radius:199, hp:640,  yW:12, yS:0, yG:0, yA:0.09 },
    { type:'stone', w:28, radius:125, hp:700,  yW:0,  yS:12, yG:0, yA:0 },
    { type:'stone', w:14, radius:155, hp:1000, yW:0,  yS:20, yG:0, yA:0 },
    { type:'gold',  w:8,  radius:123, hp:520,  yW:0,  yS:3,  yG:3, yA:0 },
    { type:'gold',  w:4,  radius:145, hp:720,  yW:0,  yS:4,  yG:5, yA:0 },
    { type:'bush',  w:10, radius:75,  hp:200,  yW:2,  yS:0,  yG:0, yA:0.35 },
  ],
  lava: [
    { type:'wood',  w:28, radius:184, hp:600,  yW:12, yS:0, yG:0, yA:0.18 },
    { type:'wood',  w:14, radius:224, hp:840,  yW:20, yS:0, yG:0, yA:0.12 },
    { type:'stone', w:20, radius:123, hp:800,  yW:0,  yS:14, yG:0, yA:0 },
    { type:'stone', w:10, radius:153, hp:1120, yW:0,  yS:22, yG:0, yA:0 },
    { type:'gold',  w:6,  radius:118, hp:540,  yW:0,  yS:4,  yG:3, yA:0 },
    { type:'gold',  w:3,  radius:143, hp:780,  yW:0,  yS:5,  yG:6, yA:0 },
    { type:'bush',  w:12, radius:85,  hp:250,  yW:4,  yS:0,  yG:0, yA:0.7 },
  ],
};
RES_DEFS_BY_BIOME.snow = RES_DEFS_BY_BIOME.winter;
RES_DEFS_BY_BIOME.swamp = RES_DEFS_BY_BIOME.lava;
RES_DEFS_BY_BIOME.darkforest = RES_DEFS_BY_BIOME.lava;

function pickResDef(biome, rng) {
  const _r = rng || (() => Math.random());
  const normBiome = (biome === 'snow' || biome === 'winter') ? 'winter' : (biome === 'desert' ? 'desert' : (biome === 'lava' || biome === 'darkforest' ? 'lava' : 'forest'));
  const defs = RES_DEFS_BY_BIOME[normBiome] || RES_DEFS_BY_BIOME[biome] || RES_DEFS_BY_BIOME.forest;
  const total = defs.reduce((s,d)=>s+d.w, 0);
  let r = _r() * total;
  for (const d of defs) { r -= d.w; if (r <= 0) return d; }
  return defs[0];
}
function makeResource(x, y, rng) {
  const biome = getBiome(x, y);
  const d = pickResDef(biome, rng);
  const HP_MUL = 1;
  const hp = Math.round(d.hp * HP_MUL);
  return { x, y, radius: d.radius, biome,
    type: d.type, hp, maxHp: hp, shake: 0,
    yW: d.yW, yS: d.yS, yG: d.yG, yA: d.yA,
    yHp: d.yHp||0, yXp: d.yXp||0, ySpd: d.ySpd||0 };
}
const resources = [];
const RES_COUNT = 420;
// Use the same fixed seed as the server so world is always identical
const _FIXED_WORLD_SEED = 0x4F524553; // matches server WORLD_SEED exactly
_rebuildResourcesFromSeed(_FIXED_WORLD_SEED, {});
// Rebuild resources from server seed (online mode) — same RNG sequence as server
function _rebuildResourcesFromSeed(seed, resHpOverrides) {
  const rng = _makeMulberry32(seed);
  const r = PLAY_RADIUS * 0.98;
  resources.length = 0;
  _resourceGrid = {}; // Clear resource grid on reset
  for (let i = 0; i < RES_COUNT; i++) {
    const x = (rng() * 2 - 1) * r;
    const y = (rng() * 2 - 1) * r;
    const res = makeResource(x, y, rng);
    res._netIdx = i;
    res.hp = res.maxHp;
    resources.push(res);
    _addResourceToGrid(res);
  }
}

// Respawn queue: { x, y, timer } — only used in solo mode; server manages respawns online
const respawnQueue = [];
function tickRespawns() {
  if (_connected) return; // server sends res_respawn events instead
  for (let i = respawnQueue.length - 1; i >= 0; i--) {
    respawnQueue[i].timer--;
    if (respawnQueue[i].timer <= 0) {
      const _newRes = makeResource(respawnQueue[i].x, respawnQueue[i].y);
      _newRes._netIdx = -1;
      resources.push(_newRes);
      _addResourceToGrid(_newRes);
      respawnQueue.splice(i, 1);
    }
  }
}
setInterval(tickRespawns, 1000);

// ============================================================
// ENEMIES
// ============================================================
function spawnEnemy() {
  if (_connected) return; // server manages all mobs when online
  if (enemies.length < 26) {
    const ang = Math.random() * Math.PI * 2;
    const dist = 700 + Math.random() * 700;
    const _spawnBound = PLAY_RADIUS - 260;
    const sx = Math.max(-_spawnBound, Math.min(_spawnBound, player.x + Math.cos(ang) * dist));
    const sy = Math.max(-_spawnBound, Math.min(_spawnBound, player.y + Math.sin(ang) * dist));
    const biome = getBiome(sx, sy);
    if (biome !== 'forest') return;
    const src  = ACTIVE_ENEMY_TYPES;
    const curAge  = getAge(player.xp);
    // Unlock one tier every 2 ages so higher biome enemies appear gradually
    const maxTier = Math.min(Math.floor((curAge - 1) / 2), src.length - 1);
    const t = src[Math.floor(Math.random() * (maxTier + 1))];
    // Scale enemy stats with age: HP +22%/age, DMG +18%/age, speed +5%/age (max 1.7×)
    const scaleMult  = 1 + (curAge - 1) * 0.22;
    const dmgMult    = 1 + (curAge - 1) * 0.18;
    const speedMult  = Math.min(1 + (curAge - 1) * 0.05, 1.70);
    const scaledHp   = Math.round(t.hp   * scaleMult);
    const scaledDmg  = Math.round(t.dmg  * dmgMult);
    const scaledSpd  = t.speed * speedMult;
    // At age 5+ grant a small XP/gold bonus so higher-age play still rewards
    const xpBonus    = 1 + (curAge - 1) * 0.08;
    enemies.push({
      x: sx, y: sy,
      _netId: Math.random().toString(36).slice(2, 9), // stable ID for multiplayer routing
      radius: t.radius, hp: scaledHp, maxHp: scaledHp,
      color: t.color, outline: t.outline,
      dmg: scaledDmg, speed: scaledSpd,
      xpReward: Math.round(t.xp * xpBonus), goldReward: Math.round(t.gold * xpBonus),
      typeName: t.name, eyes: t.eyes, shape: t.shape,
      vx: 0, vy: 0, lastHit: 0, lastBuildHit: 0, lastSpikeHit: 0, lastResHit: 0, hitFlash: 0,
      provoked: false, lastHitSwingId: -1,
      _homeBiome: biome, _homeX: sx, _homeY: sy, _wanderTimer: 0
    });
  }
}
setInterval(spawnEnemy, 2200);

// ============================================================
// INVENTORY SLOTS
// ============================================================
const invSlots = document.querySelectorAll('.inv-slot');
invSlots.forEach((slot, index) => {
  const selectSlot = (e) => {
    e.preventDefault();
    // stopPropagation prevents this touch from leaking to joystick zones that
    // might overlap the inventory area on narrow phones.
    e.stopPropagation();
    const slotNum = index + 1;
    player.weapon = slotNum;
    player.attackDuration = ATTACK_DUR[slotNum] || 28;
    player.isAttacking = false;
    player.attackTimer = 0;
    invSlots.forEach(s => s.classList.remove('active'));
    slot.classList.add('active');
  };
  slot.addEventListener('touchstart', selectSlot, { passive: false });
  slot.addEventListener('mousedown', selectSlot);
});

// ============================================================
// APPLE / FOOD EATING
// ============================================================
function eatApple() {
  if (!player || player.dead) return;
  const now = Date.now();
  if (player._fruitUseUntil && now < player._fruitUseUntil) {
    floatingTexts.push({ x: player.x, y: player.y - 45, text: 'Meyve Dinleniyor…', alpha: 1, life: 22, color: '#ffbb55' });
    return;
  }
  if (player.apples > 0 && player.hp < player.maxHp) {
    player.apples--;
    const healAmt = 25;
    player.hp = Math.min(player.maxHp, player.hp + healAmt);
    player._fruitUseUntil = now + 650;
    if (_connected && _socket) _socket.emit('eat_apple');
    updateHpBar();
    updateUI();
    playSound(440, 0.12, 'sine', 0.3);
    floatingTexts.push({ x: player.x, y: player.y - 45, text: `+${healAmt} HP`, alpha: 1, life: 35, color: '#44ff66' });
  } else if (player.apples <= 0) {
    floatingTexts.push({ x: player.x, y: player.y - 45, text: 'Meyve / Elma Yok!', alpha: 1, life: 30, color: '#ff6666' });
  } else if (player.hp >= player.maxHp) {
    floatingTexts.push({ x: player.x, y: player.y - 45, text: 'Canın Zaten Dolu!', alpha: 1, life: 25, color: '#ffea55' });
  }
}
const appleBtn = document.getElementById('apple-btn');
if (appleBtn) {
  appleBtn.addEventListener('touchstart', e => { e.preventDefault(); eatApple(); });
  appleBtn.addEventListener('mousedown', eatApple);
}

// ============================================================
// BUILDING PLACEMENT
// ============================================================
// ── BUILD SNAP SETTING (localStorage: fb_build_snap, default off + temporary lock) ──
const _snapLockMs = 30000;
let _buildSnapEnabled = false;
let _buildSnapLocked = false;

function _syncSnapLockState() {
  try {
    const lockUntil = Number(localStorage.getItem('fb_build_snap_lock_until') || 0);
    const now = Date.now();
    _buildSnapLocked = lockUntil > now;
    if (_buildSnapLocked) {
      const remaining = Math.max(0, lockUntil - now);
      const note = document.getElementById('snap-lock-note');
      if (note) {
        note.classList.add('visible');
        note.textContent = `🔒 Kenetlenme ${Math.ceil(remaining / 1000)} saniye boyunca kilitli`;
      }
    } else {
      localStorage.removeItem('fb_build_snap_lock_until');
      const note = document.getElementById('snap-lock-note');
      if (note) note.classList.remove('visible');
    }
  } catch {
    _buildSnapLocked = false;
  }
}

function _lockSnapSettingsForSession() {
  const lockUntil = Date.now() + _snapLockMs;
  try { localStorage.setItem('fb_build_snap_lock_until', String(lockUntil)); } catch {}
  _buildSnapLocked = true;
  _syncSnapLockState();
}

function _initSnapSettingsUI() {
  try {
    const v = localStorage.getItem('fb_build_snap');
    _buildSnapEnabled = v === 'true';
  } catch {
    _buildSnapEnabled = false;
  }
  const el = document.getElementById('snap-toggle-input');
  if (el) {
    el.checked = _buildSnapEnabled;
    el.disabled = _buildSnapLocked;
  }
  _syncSnapLockState();
  const note = document.getElementById('snap-lock-note');
  if (note && _buildSnapLocked) note.classList.add('visible');
  if (el) el.disabled = _buildSnapLocked;
}
_initSnapSettingsUI();

function _onSnapToggle(checked) {
  if (_buildSnapLocked) {
    const el = document.getElementById('snap-toggle-input');
    if (el) el.checked = false;
    if (typeof showToast === 'function') showToast('🔒 Kenetlenme şu an kilitli. 30 saniye sonra açılacak.', 1800, '#ffbb33');
    return;
  }
  _buildSnapEnabled = checked;
  localStorage.setItem('fb_build_snap', checked ? 'true' : 'false');
  if (checked) {
    _lockSnapSettingsForSession();
  }
  const el = document.getElementById('snap-toggle-input');
  if (el) el.disabled = _buildSnapLocked;
  floatingTexts.push({
    x: player.x,
    y: player.y - 50,
    text: checked ? '🔗 Kenetlenme: AÇIK' : '🔓 Kenetlenme: KAPALI',
    alpha: 1,
    life: 38,
    color: checked ? '#8ddc52' : '#ffaa44'
  });
  playSound(checked ? 440 : 330, 0.1, 'sine', 0.2);
}

function _onGridToggle(checked) {
  const mm = document.getElementById('mm-col-labels');
  const mmr = document.getElementById('mm-row-labels');
  if (mm) mm.style.display = checked ? 'flex' : 'none';
  if (mmr) mmr.style.display = checked ? 'flex' : 'none';
  _saveGameSetting('fb_grid_show', checked);
}

let _sfxMuted = localStorage.getItem('fb_sfx_muted') === 'true';
function _onSfxToggle(checked) {
  _sfxMuted = !checked;
  _saveGameSetting('fb_sfx_muted', _sfxMuted);
}

function _onAutoEatToggle(checked) {
  _autoEatEnabled = checked;
  _saveGameSetting('fb_auto_eat', checked);
}
function _onShakeToggle(checked) {
  _shakeEnabled = checked;
  _saveGameSetting('fb_shake', checked);
  if (!checked) shakeMag = 0;
}
function _onMinimapToggle(checked) {
  const minimap = document.getElementById('minimap');
  if (minimap) minimap.style.display = checked ? '' : 'none';
  _saveGameSetting('fb_minimap', checked);
}
function _onFpsToggle(checked) {
  const fpsElement = document.getElementById('fps-display');
  if (fpsElement) fpsElement.style.display = checked ? '' : 'none';
  _saveGameSetting('fb_fps', checked);
}

function _initGameSettingsUI() {
  const minimapVisible = localStorage.getItem('fb_minimap') !== 'false';
  const fpsVisible = localStorage.getItem('fb_fps') !== 'false';
  const values = {
    'auto-eat-toggle': _autoEatEnabled,
    'shake-toggle': _shakeEnabled,
    'minimap-toggle': minimapVisible,
    'fps-toggle': fpsVisible,
  };
  Object.entries(values).forEach(([id, checked]) => {
    const input = document.getElementById(id);
    if (input) input.checked = checked;
  });
  _onMinimapToggle(minimapVisible);
  _onFpsToggle(fpsVisible);
}

// ============================================================
// KEYBINDINGS SYSTEM
// ============================================================
const DEFAULT_KEYBINDS = {
  trap: 'f',
  spike: 'e',
  eat: 'q',
  boost: 'v',
  windmill: 'n',
  turret: 'c',
  wall: 'x',
  dash: ' ',
  bow: 'r',
  chatWheel: 'z',
};

let _customKeybinds = { ...DEFAULT_KEYBINDS };
try {
  const _savedKb = localStorage.getItem('fb_keybinds');
  if (_savedKb) _customKeybinds = Object.assign({}, DEFAULT_KEYBINDS, JSON.parse(_savedKb));
} catch(e) {}

_initGameSettingsUI();

let _listeningKeybindAction = null;

function _formatKey(k) {
  if (!k) return '?';
  if (k === ' ') return 'SPACE';
  if (k === 'arrowup') return '↑';
  if (k === 'arrowdown') return '↓';
  if (k === 'arrowleft') return '←';
  if (k === 'arrowright') return '→';
  return k.toUpperCase();
}

function _updateKeybindsButtonsUI() {
  for (const [action, key] of Object.entries(_customKeybinds)) {
    const btn = document.getElementById('kb-btn-' + action);
    if (btn) {
      btn.textContent = _formatKey(key);
      btn.classList.remove('listening');
    }
  }
}

function _startListeningKeybind(action, btnEl) {
  if (_listeningKeybindAction === action) {
    _listeningKeybindAction = null;
    _updateKeybindsButtonsUI();
    return;
  }
  _updateKeybindsButtonsUI();
  _listeningKeybindAction = action;
  if (btnEl) {
    btnEl.textContent = '...';
    btnEl.classList.add('listening');
  }
}

function _setKeybind(action, newKey) {
  if (!action || !newKey) return;
  const cleanKey = newKey.toLowerCase();
  _customKeybinds[action] = cleanKey;
  localStorage.setItem('fb_keybinds', JSON.stringify(_customKeybinds));
  _listeningKeybindAction = null;
  _updateKeybindsButtonsUI();
  if (typeof showToast === 'function') {
    showToast(`✅ Tuş [${_formatKey(cleanKey)}] olarak ayarlandı!`, 1800, '#22cc66');
  }
}

function _resetDefaultKeybinds() {
  _customKeybinds = { ...DEFAULT_KEYBINDS };
  localStorage.setItem('fb_keybinds', JSON.stringify(_customKeybinds));
  _listeningKeybindAction = null;
  _updateKeybindsButtonsUI();
  if (typeof showToast === 'function') {
    showToast('🔄 Tuş kısayolları varsayılana sıfırlandı!', 1800, '#ffd700');
  }
}

function _matchKey(k, targetKey) {
  if (!targetKey) return false;
  return k.toLowerCase() === targetKey.toLowerCase();
}

function _toggleSnapSettings(e) {
  if (e) {
    if (typeof e.stopPropagation === 'function') e.stopPropagation();
    if (typeof e.preventDefault === 'function') e.preventDefault();
  }
  const panel = document.getElementById('snap-settings-panel');
  if (!panel) return;
  const isOpening = !panel.classList.contains('open');
  panel.classList.toggle('open');
  if (isOpening) {
    _syncSnapLockState();
    const snapInput = document.getElementById('snap-toggle-input');
    if (snapInput) {
      snapInput.checked = (typeof _buildSnapEnabled !== 'undefined' ? _buildSnapEnabled : (localStorage.getItem('fb_build_snap') === 'true'));
      snapInput.disabled = _buildSnapLocked;
    }
    const lockNote = document.getElementById('snap-lock-note');
    if (lockNote) {
      lockNote.classList.toggle('visible', _buildSnapLocked);
      if (_buildSnapLocked) {
        const remaining = Math.max(0, Number(localStorage.getItem('fb_build_snap_lock_until') || 0) - Date.now());
        lockNote.textContent = `🔒 Kenetlenme ${Math.ceil(remaining / 1000)} saniye boyunca kilitli`;
      }
    }
    const gridInput = document.getElementById('grid-toggle-input');
    if (gridInput) gridInput.checked = localStorage.getItem('fb_grid_show') !== 'false';
    const sfxInput = document.getElementById('sfx-toggle-input');
    if (sfxInput) sfxInput.checked = localStorage.getItem('fb_sfx_muted') !== 'true';
    _updateKeybindsButtonsUI();
  }
}

const _settingsButton = document.getElementById('settings-btn');
if (_settingsButton) _settingsButton.addEventListener('click', _toggleSnapSettings);

// Close settings panel when clicking outside of it
document.addEventListener('click', function(e) {
  const panel = document.getElementById('snap-settings-panel');
  const btn = document.getElementById('settings-btn');
  if (!panel || !panel.classList.contains('open')) return;
  if (!panel.contains(e.target) && e.target !== btn && !(btn && btn.contains(e.target))) {
    panel.classList.remove('open');
  }
});

// Close quest panel when clicking outside
document.addEventListener('click', function(e) {
  var qPanel = document.getElementById('quest-panel');
  var qBtn   = document.getElementById('quest-btn');
  if (!qPanel || !qPanel.classList.contains('open')) return;
  if (!qPanel.contains(e.target) && e.target !== qBtn && !(qBtn && qBtn.contains(e.target))) {
    qPanel.classList.remove('open');
  }
});

// ── BUILDING LIMITS PER TYPE (Moomoo / IO style balance) ──
const BUILD_LIMITS = {
  3: 25,  // Kazık (Spikes)
  4: 7,   // Değirmen (Windmill)
  5: 12,  // Hız Pedi (Boost Pad)
  6: 8,   // Tuzak (Trap)
  7: 4,   // Taret (Turret)
  8: 35,  // Duvar (Wall)
  9: 12,  // Kale (Castle)
  10: 4   // Kamp Ateşi (Campfire)
};

function getPlayerBuildingCount(type) {
  let count = 0;
  const targetType = Number(type);
  for (let i = 0; i < buildings.length; i++) {
    const b = buildings[i];
    if (Number(b.type) === targetType && b.hp > 0) {
      if (_mySocketId) {
        if (b._ownerId === _mySocketId) count++;
      } else {
        if (!b._remote && (!b._ownerId || b._ownerId === _mySocketId)) count++;
      }
    }
  }
  return count;
}

// ── BUILDING SNAP / OVERLAP RADII (visual extents used for placement) ──
const _SNAP_RADII = { 3:42, 4:54, 5:40, 6:55, 7:48, 8:40, 9:56, 10:32 };

// Wall (type 8) is drawn as 115x115 → half-width=42, half-height=40.
// Use these for AABB snap so walls touch flush without overlap.
const _WALL_HW = 42; // wall half-width  (X axis snap gap = HW*2 = 84)
const _WALL_HH = 40; // wall half-height (Y axis snap gap = HH*2 = 80)

// Returns true if a wall placed at (cx,cy) overlaps an existing wall at (bx,by)
function _wallOverlapsWall(cx, cy, bx, by, margin) {
  return Math.abs(cx - bx) < _WALL_HW * 2 - margin && Math.abs(cy - by) < _WALL_HH * 2 - margin;
}

function _computeGhostPos() {
  const bx0 = player.x + Math.cos(player.angle) * 80;
  const by0 = player.y + Math.sin(player.angle) * 80;
  const newR = _SNAP_RADII[player.weapon] || 30;
  const newIsWall = player.weapon === 8;

  let bx = bx0, by = by0, snapped = false, snapTarget = null;
  // Snap to nearest CARDINAL edge. Walls use AABB gap; other buildings use circle gap.
  // Snapping is skipped when the player has disabled it in settings.
  const SNAP_PULL = 90;
  let bestDist = SNAP_PULL;
  for (const b of _buildSnapEnabled ? buildings : []) {
    if (b.hp <= 0) continue;
    const existIsWall = b.type === 8;
    const existR = _SNAP_RADII[b.type] || 30;

    // Axis-aligned snap gaps differ by direction for rectangles
    const gapX = (newIsWall && existIsWall) ? _WALL_HW * 2 : newR + existR;
    const gapY = (newIsWall && existIsWall) ? _WALL_HH * 2 : newR + existR;

    const candidates = [
      { x: b.x + gapX, y: b.y },   // right
      { x: b.x - gapX, y: b.y },   // left
      { x: b.x,        y: b.y + gapY }, // down
      { x: b.x,        y: b.y - gapY }, // up
    ];
    for (const c of candidates) {
      const dist = Math.hypot(bx0 - c.x, by0 - c.y);
      if (dist < bestDist) {
        // Skip positions that would overlap any existing building
        let overlaps = false;
        for (const ob of buildings) {
          if (ob.hp <= 0) continue;
          if (newIsWall && ob.type === 8) {
            if (_wallOverlapsWall(c.x, c.y, ob.x, ob.y, 2)) { overlaps = true; break; }
          } else {
            const obR = _SNAP_RADII[ob.type] || 30;
            if (Math.hypot(c.x - ob.x, c.y - ob.y) < newR + obR - 2) { overlaps = true; break; }
          }
        }
        if (overlaps) continue;
        bestDist = dist;
        bx = c.x;
        by = c.y;
        snapped = true;
        snapTarget = b;
      }
    }
  }

  // Check if blocked (overlaps an existing building)
  let blocked = false;
  for (const b of buildings) {
    if (b.hp <= 0) continue;
    if (newIsWall && b.type === 8) {
      if (_wallOverlapsWall(bx, by, b.x, b.y, 2)) { blocked = true; break; }
    } else {
      const existR = _SNAP_RADII[b.type] || 30;
            const _hDist = Math.hypot(bx - b.x, by - b.y);
      if (_hDist < 0.01 || _hDist < newR + existR - 2) { blocked = true; break; }
    }
  }
  // Also blocked by resources — can't place buildings on trees/stones/gold
  if (!blocked) {
    for (const r of resources) {
      if (r._destroyed) continue;
      const rBlockR = (r.radius || 80) * 0.52;
      if (Math.hypot(bx - r.x, by - r.y) < newR + rBlockR) { blocked = true; break; }
    }
  }

  _ghostBuildPos = { x: bx, y: by, snapped, blocked, snapTarget };
  return _ghostBuildPos;
}

function drawBuildingConnections(visArr) {
  const _cVis = visArr || buildings;
  if (_cVis.length < 2) return;
  const CONN_GAP = 28; // max pixel gap to draw a visual bridge
  for (let i = 0; i < _cVis.length; i++) {
    const b1 = _cVis[i];
    const r1 = _SNAP_RADII[b1.type] || 30;
    for (let j = i + 1; j < _cVis.length; j++) {
      const b2 = _cVis[j];
      if (b2.hp <= 0) continue;
      const r2 = _SNAP_RADII[b2.type] || 30;
      const dx = b2.x - b1.x, dy = b2.y - b1.y;
      // Fast squared-distance reject before expensive sqrt
      const maxD = r1 + r2 + CONN_GAP;
      if (dx*dx + dy*dy > maxD*maxD) continue;
      const d = Math.sqrt(dx * dx + dy * dy);
      const gap = d - (r1 + r2);
      if (gap < 0 || gap > CONN_GAP) continue;
      const ang = Math.atan2(dy, dx);
      ctx.save();
      ctx.translate((b1.x + b2.x) / 2, (b1.y + b2.y) / 2);
      ctx.rotate(ang);
      const connH = gap + 8; // fill gap + slight overlap into both buildings
      if (b1.type === 8 && b2.type === 8) {
        // Wall ↔ Wall: stone/brick bridge
        const connW = 14;
        const g1 = ctx.createLinearGradient(0, -connW, 0, connW);
        g1.addColorStop(0,'#9e9e9e'); g1.addColorStop(0.5,'#bdbdbd'); g1.addColorStop(1,'#757575');
        ctx.fillStyle = g1; ctx.strokeStyle = '#424242'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.roundRect(-connH/2, -connW, connH, connW*2, 2); ctx.fill(); ctx.stroke();
        // brick row in middle
        ctx.fillStyle = '#8b4513'; ctx.strokeStyle = '#1a0900'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.roundRect(-connH/2+1, -connW*0.45, connH-2, connW*0.9, 1); ctx.fill(); ctx.stroke();
      } else if (b1.type === 9 || b2.type === 9) {
        // Castle: heavy stone block
        const connW = 18;
        const g2 = ctx.createLinearGradient(0,-connW,0,connW);
        g2.addColorStop(0,'#8d8d8d'); g2.addColorStop(0.5,'#bdbdbd'); g2.addColorStop(1,'#6d6d6d');
        ctx.fillStyle = g2; ctx.strokeStyle = '#333'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.roundRect(-connH/2,-connW,connH,connW*2,2); ctx.fill(); ctx.stroke();
      } else if (b1.type === 3 || b2.type === 3) {
        // Spike: dark metal bar
        const connW = 9;
        const g3 = ctx.createLinearGradient(0,-connW,0,connW);
        g3.addColorStop(0,'#7a7a7a'); g3.addColorStop(0.5,'#c0c0c0'); g3.addColorStop(1,'#4a4a4a');
        ctx.fillStyle = g3; ctx.strokeStyle = '#222'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.roundRect(-connH/2,-connW,connH,connW*2,3); ctx.fill(); ctx.stroke();
      } else {
        // Generic: wood plank
        const connW = 8;
        const g4 = ctx.createLinearGradient(0,-connW,0,connW);
        g4.addColorStop(0,'#a1887f'); g4.addColorStop(0.5,'#c5a07f'); g4.addColorStop(1,'#6d4c41');
        ctx.fillStyle = g4; ctx.strokeStyle = '#3e2723'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.roundRect(-connH/2,-connW,connH,connW*2,2); ctx.fill(); ctx.stroke();
      }
      ctx.restore();
    }
  }
}

function tryPlaceBuilding() {
  if (player.weapon < 3) return;

  // ── BUILDING LIMIT CHECK ──
  const _curCount = getPlayerBuildingCount(player.weapon);
  const _maxLimit = BUILD_LIMITS[player.weapon] || 25;
  if (_curCount >= _maxLimit) {
    floatingTexts.push({ x: player.x, y: player.y - 50, text: `⚠️ BİNA LİMİTİ DOLU! (${_curCount}/${_maxLimit})`, alpha: 1, life: 45, color: '#ff4444', big: true });
    playSound(160, 0.12, 'sawtooth', 0.2);
    shake(3);
    return;
  }

  const costs = { 3:[20,5,150], 4:[40,20,100], 5:[10,20,50], 6:[30,10,80], 7:[60,40,200], 8:[30,0,300], 9:[80,60,400], 10:[25,0,300] };
  const radii = { 3:34, 4:44, 5:22, 6:32, 7:32, 8:20, 9:52, 10:28 };
  const [cW, cS, mHp] = costs[player.weapon] || [0,0,0];

  // Use snapped position computed during last ghost preview frame
  const bx = _ghostBuildPos ? _ghostBuildPos.x : player.x + Math.cos(player.angle) * 80;
  const by = _ghostBuildPos ? _ghostBuildPos.y : player.y + Math.sin(player.angle) * 80;

  // Block if overlapping an existing building — redirect to upgrade panel if own building
  const newR = _SNAP_RADII[player.weapon] || 30;
  const _placeIsWall = player.weapon === 8;
  function _bldOverlap(gx, gy, b) {
    if (_placeIsWall && b.type === 8) return _wallOverlapsWall(gx, gy, b.x, b.y, 4);
    const er = _SNAP_RADII[b.type] || 30;
    return Math.hypot(gx - b.x, gy - b.y) < newR + er - 4;
  }
  function _findOwnBldAtGhost(gx, gy) {
    for (const b of buildings) {
      if (!_isOwnBuilding(b)) continue;
      if (_bldOverlap(gx, gy, b)) return b;
    }
    return null;
  }
  if (_ghostBuildPos && _ghostBuildPos.blocked) {
    hideBuildUpgradePanel();
    floatingTexts.push({ x: player.x, y: player.y - 50, text: '⛔ ALAN DOLU!', alpha: 1, life: 35, color: '#ff4444' });
    return;
  }
  // Safety overlap check even without cached ghost (e.g. first frame)
  for (const b of buildings) {
    if (b.hp <= 0) continue;
    if (_bldOverlap(bx, by, b)) {
      hideBuildUpgradePanel();
      floatingTexts.push({ x: player.x, y: player.y - 50, text: '⛔ ALAN DOLU!', alpha: 1, life: 35, color: '#ff4444' });
      return;
    }
  }

  if (player.wood >= cW && player.stone >= cS) {
    player.wood -= cW; player.stone -= cS;
    updateUI();
    const bId = `${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
    _lastPlacedClientId = bId; // save so build_limit_reached can remove ghost
    _lastBuildPlaceTime = Date.now();
    const newB = { x: bx, y: by, type: player.weapon, angle: player.angle, life: 0, hp: mHp, maxHp: mHp, shake: 0, hitTimer: 0, _netId: bId, _ownerId: _mySocketId, _spawnAnim: 0, _hpBarVisibleUntil: 0, tier: 0 };
    for(let pi=0;pi<8;pi++){const pa=Math.random()*Math.PI*2;_spawnParticle(bx+Math.cos(pa)*18,by+Math.sin(pa)*18,Math.cos(pa)*4.5,Math.sin(pa)*4.5-2,3+Math.random()*3,18+Math.random()*10,['#ffe066','#ffcc33','#ffaa00'][Math.floor(Math.random()*3)]);}
    buildings.push(newB);
    if (newB._netId) _buildingsMap.set(newB._netId, newB);
    _sgRebuildTimer = 8; // force spatial grid rebuild next frame on new building
    _trackMission('m3', 1);
    window._updateQuestProgress('builds', 1);
    _incQuestStat('buildings', 1);
    _queueBuildMetaUpdate(1);
    _mpBuildPlaced(newB, radii[player.weapon] || 34);
    updateUI();
  } else {
    floatingTexts.push({ x: player.x, y: player.y - 50, text: 'YETERSİZ KAYNAK!', alpha: 1, life: 35, color: '#ffaa00' });
  }
}

// ════════════════════════════════════════════════════════════
// BUILDING TIER SYSTEM — Constants, glow overlay & upgrade UI
// ════════════════════════════════════════════════════════════
const TIER_NAMES   = ['⛏️ Taş','🥇 Altın','💎 Elmas','💜 Ametist','☢️ Reidite','👑 Nihai'];
const TIER_COLORS  = ['#b0b0b0','#f5c842','#60d4ff','#c07de8','#60ff88','#ffffff'];
const TIER_GLOWS   = ['#888888','#ffd700','#00bcd4','#9c27b0','#00e676','#ffffff'];
const UPGRADE_SCORE = [400, 1000, 2500, 6000, 15000]; // puan maliyeti (her tier için)
const TIER_HP_MULS  = [1.0, 1.6, 2.5, 4.0, 6.5, 10.0];
const TIER_DMG_MULS = [1.0, 1.5, 2.2, 3.5, 5.0, 8.0];
const BTYPE_NAMES   = {3:'Kazık',4:'Değirmen',5:'Hız Pedi',6:'Tuzak',7:'Taret',8:'Duvar',9:'Kale',10:'Kamp Ateşi'};
const BTYPE_BASE_HP = {3:250,4:180,5:100,6:220,7:350,8:500,9:750,10:400};

function _getTier(b) { return Math.min(5, Math.max(0, b.tier || 0)); }

// ── Upgrade panel state ───────────────────────────────────────
let _bup_building = null;
let _lastBuildPlaceTime = 0;
let _lastPlacedClientId = null; // track pending placement to clean up ghost on server rejection
let _lastUpgPanelToggle = 0;

const _BUP_THEMES = {
  3:  { icon:'⚔️',  color:'#e55050', dark:'#380808', mid:'#6a1010', name:'Kazık Tuzağı' },
  4:  { icon:'⭐',  color:'#f5c842', dark:'#3a2800', mid:'#6a4800', name:'XP Değirmeni' },
  5:  { icon:'💨',  color:'#42a8f5', dark:'#00203a', mid:'#00366a', name:'Hız Pedi' },
  6:  { icon:'🕸️', color:'#c07de8', dark:'#1c0838', mid:'#38166a', name:'Ayak Tuzağı' },
  7:  { icon:'🔫',  color:'#ff8833', dark:'#281000', mid:'#4a2000', name:'Koruma Tareti' },
  8:  { icon:'🧱',  color:'#aaaaaa', dark:'#181818', mid:'#2c2c2c', name:'Savunma Duvarı' },
  9:  { icon:'🏰',  color:'#6688ff', dark:'#060b28', mid:'#101e78', name:'Kale Kulesi' },
  10: { icon:'🔥',  color:'#ff6622', dark:'#280800', mid:'#581800', name:'Kamp Ateşi' },
};

function showBuildUpgradePanel(b) {
  // Upgrade flow is intentionally disabled in this build.
  _bup_building = null;
  const pnl = document.getElementById('build-upg-panel');
  if (pnl) pnl.classList.remove('bup-open');
  return;
}
function hideBuildUpgradePanel() {
  // Build upgrade panel is intentionally disabled; never leave stale state behind.
  _bup_building = null;
  const pnl = document.getElementById('build-upg-panel');
  if (pnl) pnl.classList.remove('bup-open');
}
function _clearTrapLock() {
  _trapCaughtBy = null;
  _trapCaughtX = undefined;
  _trapCaughtY = undefined;
  if (player) {
    player.vx = 0;
    player.vy = 0;
    player.momX = 0;
    player.momY = 0;
  }
}
function _refreshBuildUpgradePanel() {
  if (!_bup_building) return;
  const b     = _bup_building;
  const tier  = _getTier(b);
  const type  = b.type;
  const theme = _BUP_THEMES[type] || { icon:'🏗️', color:'#4db832', dark:'#1a3a0a', mid:'#2d5a18', name:'Yapı' };
  const pnl   = document.getElementById('build-upg-panel');

  // Apply theme via CSS variables
  pnl.style.setProperty('--bup-color', theme.color);
  pnl.style.setProperty('--bup-dark',  theme.dark);
  pnl.style.setProperty('--bup-mid',   theme.mid);

  // Header
  document.getElementById('bup-type-icon').textContent = theme.icon;
  document.getElementById('bup-title').textContent = `🔨 ${theme.name}`;
  document.getElementById('bup-subtitle').textContent =
    tier < 5
      ? `${TIER_NAMES[tier]} — ${5 - tier} yükseltme kaldı`
      : `${TIER_NAMES[tier]} — Maksimum seviye!`;

  // Tier bar
  const tierLabels = ['Taş','Altın','Elmas','Ametist','Reidite','Nihai'];
  document.getElementById('bup-tierbar').innerHTML = tierLabels.map((lbl, t) => {
    const cls = t < tier ? 'td-done' : t === tier ? 'td-cur' : 'td-lock';
    const bg  = t <= tier ? TIER_COLORS[t]+'28' : 'rgba(255,255,255,0.04)';
    const brd = t === tier
      ? `2px solid ${TIER_COLORS[t]}`
      : t < tier ? `1px solid ${TIER_COLORS[t]}55` : '1px solid rgba(255,255,255,0.07)';
    const col = t <= tier ? TIER_COLORS[t] : 'rgba(255,255,255,0.18)';
    return `<div class="bup-td ${cls}" style="background:${bg};border:${brd};color:${col}">${lbl}</div>`;
  }).join('');

  // HP bar
  const hpR  = b.maxHp > 0 ? b.hp / b.maxHp : 1;
  const hpCol = hpR > 0.6 ? '#4db832' : hpR > 0.3 ? '#f5c842' : '#e55050';
  document.getElementById('bup-hpbar-fill').style.cssText = `width:${(hpR*100).toFixed(1)}%;background:${hpCol};`;
  document.getElementById('bup-hptxt').textContent = `${b.hp} / ${b.maxHp}`;

  // Stats
  const baseHp   = BTYPE_BASE_HP[type] || 100;
  const curHp    = Math.round(baseHp * TIER_HP_MULS[tier]);
  const nxtHp    = tier < 5 ? Math.round(baseHp * TIER_HP_MULS[tier + 1]) : null;
  const sameType = buildings.filter(x => x.type === type && (x._ownerId === _mySocketId || (!x._ownerId && !x._remote)) && x.hp > 0);
  const maxLim   = BUILD_LIMITS[type] || 25;

  const row = (label, cur, nxt) =>
    `<div class="bup-sr"><span class="bup-sl">${label}</span><span>` +
    `<b class="bup-sv">${cur}</b>` +
    (nxt != null ? `<span class="bup-sa">→</span><b class="bup-sn">${nxt}</b>` : '') +
    `</span></div>`;

  let html = row('❤️ Maksimum Can', curHp, nxtHp);
  if (type === 4) {
    const sc  = [25, 50, 100, 200, 400, 800];
    const gld = [1, 2, 3, 5, 8, 12];
    html += row('⭐ Skor / tik',  sc[tier],  tier < 5 ? sc[tier + 1]  : null);
    html += row('💰 Altın / tik', gld[tier], tier < 5 ? gld[tier + 1] : null);
  }
  if (type === 3 || type === 6 || type === 7) {
    const bd   = { 3: 15, 6: 55, 7: 22 }[type];
    const dmgC = Math.round(bd * TIER_DMG_MULS[tier]);
    const dmgN = tier < 5 ? Math.round(bd * TIER_DMG_MULS[tier + 1]) : null;
    html += row('⚔️ Hasar', dmgC, dmgN);
  }
  if (type === 7) {
    const rng = [340, 380, 420, 470, 530, 600];
    html += row('📡 Menzil', rng[tier], tier < 5 ? rng[tier + 1] : null);
  }
  if (type === 5) {
    const sp = [9, 13, 18, 26, 38, 56];
    html += row('💨 İvme', sp[tier], tier < 5 ? sp[tier + 1] : null);
  }
  html += row('🔢 Sahip olunan', `${sameType.length} / ${maxLim} adet`, null);
  document.getElementById('bup-stats').innerHTML = html;

  // Repair button
  const repBtn    = document.getElementById('bup-btn-repair');
  const canRepair = b.hp < b.maxHp;
  const repCost   = canRepair ? Math.max(1, Math.ceil((b.maxHp - b.hp) / b.maxHp * 15)) : 0;
  repBtn.disabled = !canRepair || player.wood < repCost;
  repBtn.textContent = canRepair ? `🔧 Onar (🪵${repCost})` : '🔧 Onar';

  // Upgrade buttons
  const oneBtn = document.getElementById('bup-btn-one');
  const allBtn = document.getElementById('bup-btn-all');
  if (tier >= 5) {
    document.getElementById('bup-cost').innerHTML =
      '<span style="color:#8ddc52;font-size:13px">✅ Maksimum seviye!</span>';
    oneBtn.disabled = true;
    allBtn.disabled = true;
    allBtn.textContent = '⬆️ Tümünü';
  } else {
    const sc = UPGRADE_SCORE[tier];
    const ok = player.score >= sc;
    const nextCol = TIER_COLORS[tier + 1] || '#fff';
    document.getElementById('bup-cost').innerHTML =
      `<span style="color:${nextCol};font-weight:900">${TIER_NAMES[tier + 1]}</span> için: ` +
      `⭐ <b style="color:${ok ? '#f5c842' : '#ff5555'}">${sc}</b> Puan` +
      `  <span style="font-size:14px">${ok ? '✅' : '❌'}</span>`;
    oneBtn.disabled = !ok;
    allBtn.disabled = false;
    oneBtn.textContent = '⬆️ Geliştir';
    allBtn.textContent = `⬆️ Tümünü (${sameType.length})`;
  }
}

function _canUpgrade(b) {
  const t = _getTier(b);
  return t < 5 && player.score >= UPGRADE_SCORE[t];
}
function _applyUpgrade(b, spawnVfx = true) {
  const tier = _getTier(b);
  if (tier >= 5) return false;
  if (player.score < UPGRADE_SCORE[tier]) return false;
  player.score -= UPGRADE_SCORE[tier];
  b.tier = tier + 1;
  // Pre-invalidate only this building type's new-tier cache so it rebuilds on next draw
  const _bTypeKeys = {3:'sp_',5:'bp_',6:'tr_',7:'tu_',8:'wa3_',9:'ca_',10:'cf_'};
  const _bPfx = _bTypeKeys[b.type];
  if (_bPfx) { _bldSC.delete(_bPfx + b.tier); }
  if (b.type === 4) { _wmOC.delete(b.tier); } // windmill uses _wmOC, not _bldSC
  _bldSC.delete('tr_eye_'+b.tier);  // trap eye cache per tier
  _bldSC.delete('ca_cyd_'+b.tier);  // castle courtyard cache per tier
  const hpRatio = b.hp / b.maxHp;
  const baseHp  = BTYPE_BASE_HP[b.type] || 100;
  b.maxHp = Math.round(baseHp * TIER_HP_MULS[b.tier]);
  b.hp    = Math.max(1, Math.round(b.maxHp * hpRatio));
  updateUI();
  if (spawnVfx && _qualityLevel >= 1) {
    const pcol = TIER_COLORS[b.tier];
    for(let i=0;i<8;i++){const a=Math.random()*Math.PI*2;_spawnParticle(b.x+Math.cos(a)*20,b.y+Math.sin(a)*20,Math.cos(a)*4,Math.sin(a)*4-1.5,3+Math.random()*3,20+Math.random()*12,pcol);}
  }
  if (_connected && _socket) _socket.emit('build_tier_update', { id: b._netId, tier: b.tier, maxHp: b.maxHp, hp: b.hp });
  return true;
}
function _doRepair() {
  if (!_bup_building) return;
  const b = _bup_building;
  if (b.hp >= b.maxHp) return;
  const repCost = Math.max(1, Math.ceil((b.maxHp - b.hp) / b.maxHp * 15));
  if (player.wood < repCost) {
    const pnl = document.getElementById('build-upg-panel');
    pnl.style.animation='none'; pnl.classList.remove('bup-shake'); requestAnimationFrame(()=>{pnl.style.animation=''; pnl.classList.add('bup-shake');});
    floatingTexts.push({ x: player.x, y: player.y - 55, text: '❌ Yetersiz odun!', alpha: 1, life: 45, color: '#ff8833' });
    return;
  }
  player.wood -= repCost;
  b.hp = b.maxHp;
  updateUI();
  floatingTexts.push({ x: b.x, y: b.y - 55, text: '🔧 Onarıldı!', alpha: 1, life: 50, color: '#44cc44' });
  _refreshBuildUpgradePanel();
}
function _doUpgradeOne() {
  if (!_bup_building) return;
  if (!_applyUpgrade(_bup_building, true)) {
    const pnl = document.getElementById('build-upg-panel');
    pnl.style.animation='none'; pnl.classList.remove('bup-shake'); requestAnimationFrame(()=>{pnl.style.animation=''; pnl.classList.add('bup-shake');});
    floatingTexts.push({ x: player.x, y: player.y - 55, text: '❌ Yetersiz puan!', alpha: 1, life: 45, color: '#ff4444' });
  }
  _refreshBuildUpgradePanel();
}
function _doUpgradeAll() {
  if (!_bup_building) return;
  const type = _bup_building.type;
  let done = 0;
  for (let _bi = 0; _bi < buildings.length; _bi++) {
    const b2 = buildings[_bi];
    if (b2.type === type && (b2._ownerId === _mySocketId || (!b2._ownerId && !b2._remote)) && b2.hp > 0) {
      if (_canUpgrade(b2)) {
        if (_applyUpgrade(b2, false)) done++;
      }
    }
  }
  if (done === 0) {
    const pnl = document.getElementById('build-upg-panel');
    pnl.style.animation='none'; pnl.classList.remove('bup-shake'); requestAnimationFrame(()=>{pnl.style.animation=''; pnl.classList.add('bup-shake');});
    floatingTexts.push({ x: player.x, y: player.y - 55, text: '❌ Yetersiz puan!', alpha: 1, life: 45, color: '#ff4444' });
  } else {
    floatingTexts.push({ x: player.x, y: player.y - 65, text: `✅ ${done} yapı geliştirildi!`, alpha: 1, life: 65, color: '#8ddc52', big: true });
    if (_qualityLevel >= 1) {
      const pcol = TIER_COLORS[_getTier(_bup_building)];
      for(let i=0;i<12;i++){const a=Math.random()*Math.PI*2;_spawnParticle(player.x+Math.cos(a)*24,player.y+Math.sin(a)*24,Math.cos(a)*5,Math.sin(a)*5-2,3+Math.random()*3,24+Math.random()*12,pcol);}
    }
  }
  _refreshBuildUpgradePanel();
}

let _pendingBuildMetaAdds = 0;
let _scheduledBuildMetaWrite = false;
function _safeStorageGet(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw == null ? fallback : raw;
  } catch {
    return fallback;
  }
}
function _queueBuildMetaUpdate(delta) {
  _pendingBuildMetaAdds += Number(delta) || 0;
  if (_scheduledBuildMetaWrite) return;
  _scheduledBuildMetaWrite = true;
  requestAnimationFrame(() => {
    _scheduledBuildMetaWrite = false;
    if (_pendingBuildMetaAdds <= 0) return;
    try {
      const prev = Number.parseInt(_safeStorageGet('fb_total_builds_meta', '0'), 10) || 0;
      localStorage.setItem('fb_total_builds_meta', String(prev + _pendingBuildMetaAdds));
    } catch {
      // Ignore storage failures and keep gameplay running.
    }
    _pendingBuildMetaAdds = 0;
  });
}

// Canvas click → ESC kapatma (açma/kapama mousedown'da yapılıyor)
(function() {
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') hideBuildUpgradePanel();
  });
})();

// ============================================================
// JOYSTICKS  (touch only — hidden on desktop via CSS)
// ============================================================
let _joystickActive = false;
let _joystickMoveX = 0, _joystickMoveY = 0;
let activeAttackInput = false;
let _entryConsentAccepted = false;
function _controlsAllowed() {
  const consent = document.getElementById('entry-consent');
  return _entryConsentAccepted || !consent || consent.classList.contains('hidden');
}

function setupJoy(zoneId, stickId, isMove) {
  const zone = document.getElementById(zoneId);
  const stick = document.getElementById(stickId);
  const base = zone ? zone.querySelector('.joy-base') : null;
  if (!zone || !stick) return;
  if (zone.dataset.joyReady === '1') return;
  zone.dataset.joyReady = '1';
  const hasPointerEvents = 'PointerEvent' in window;
  let active = false, cx, cy, currentId = null, lastDist = 0;
  const maxDist = 36;

  const begin = e => {
    e.preventDefault();
    if (typeof e.stopPropagation === 'function') e.stopPropagation();
    if (!_controlsAllowed()) return;
    if (active || (e.pointerType === 'mouse' && e.button !== 0)) return;
    currentId = e.pointerId; active = true; lastDist = 0;
    if (typeof zone.setPointerCapture === 'function') {
      try { zone.setPointerCapture(e.pointerId); } catch (_) {}
    }
    if (isMove) _joystickActive = true;
    // Floating joystick: appear exactly where user taps
    const r = zone.getBoundingClientRect();
    cx = e.clientX; cy = e.clientY;
    const relX = cx - r.left, relY = cy - r.top;
    if (base) {
      base.style.position = 'absolute';
      base.style.left = relX + 'px'; base.style.top = relY + 'px';
      base.style.width = '104px'; base.style.height = '104px';
      base.style.transform = 'translate(-50%,-50%)';
    }
    stick.style.left = relX + 'px'; stick.style.top = relY + 'px';
    stick.style.transform = 'translate(-50%,-50%)';
    // Add class AFTER sizing so the base never flashes at full zone size
    zone.classList.add('joy-active');
    handle(e);
  };
  zone.addEventListener('pointerdown', begin, { passive: false });

  function handle(t) {
    if (!_controlsAllowed()) return;
    const dx = t.clientX - cx, dy = t.clientY - cy;
    const dist = Math.min(Math.hypot(dx, dy), maxDist);
    const ang = Math.atan2(dy, dx);
    const ox = Math.cos(ang) * dist, oy = Math.sin(ang) * dist;
    stick.style.transform = `translate(calc(-50% + ${ox}px), calc(-50% + ${oy}px))`;
    lastDist = dist;
    if (isMove) {
      // Keep touch movement aligned with the slower keyboard speed baseline.
      const moveScale = 5.2;
      _joystickMoveX = (ox / maxDist) * moveScale;
      _joystickMoveY = (oy / maxDist) * moveScale;
      player.vx = _joystickMoveX;
      player.vy = _joystickMoveY;
    } else {
      player.angle = ang;
      const doAtk = dist > 8;
      // A joystick press is a single attack, even while pointermove updates its aim.
      _attackPending = doAtk && player.weapon >= 3;
      if (doAtk && !activeAttackInput) _attackQueued = true;
      activeAttackInput = doAtk;
    }
  }

  zone.addEventListener('pointermove', e => {
    e.preventDefault();
    if (!active || e.pointerId !== currentId) return;
    handle(e);
  }, { passive: false });

  const end = e => {
    if (!active || e.pointerId !== currentId) return;
    active = false; currentId = null;
    try { zone.releasePointerCapture(e.pointerId); } catch (_) {}
    zone.classList.remove('joy-active');
    // Reset stick and base back to zone center
    stick.style.left = '50%'; stick.style.top = '50%';
    stick.style.transform = 'translate(-50%,-50%)';
    if (base) {
      base.style.left = '50%'; base.style.top = '50%';
      base.style.width = '104px'; base.style.height = '104px';
      base.style.transform = 'translate(-50%,-50%)';
    }
    if (isMove) {
      player.vx = 0; player.vy = 0;
      _joystickMoveX = 0; _joystickMoveY = 0;
      _joystickActive = false;
    }
    else {
      const doFruitUse = lastDist < 10 && !player.isAttacking && player.hp < player.maxHp && player.apples > 0 && (!player._fruitUseUntil || Date.now() >= player._fruitUseUntil);
      if (doFruitUse) {
        eatApple();
      }
      if (player.weapon >= 3 && _attackPending) tryPlaceBuilding();
      _attackPending = false;
      activeAttackInput = false;
    }
  };
  zone.addEventListener('pointerup', end);
  zone.addEventListener('pointercancel', end);
  zone.addEventListener('lostpointercapture', e => { if (active) end(e); });
  if (!hasPointerEvents) {
    const touchPoint = e => e.changedTouches && e.changedTouches[0];
    zone.addEventListener('touchstart', e => {
      const point = touchPoint(e);
      if (!point || active) return;
      e.preventDefault();
      begin({
        preventDefault: () => {}, pointerId: point.identifier, pointerType: 'touch',
        button: 0, clientX: point.clientX, clientY: point.clientY
      });
    }, { passive: false });
    zone.addEventListener('touchmove', e => {
      const point = touchPoint(e);
      if (!point || !active) return;
      e.preventDefault();
      handle(point);
    }, { passive: false });
    zone.addEventListener('touchend', e => {
      const point = touchPoint(e);
      if (!point || !active) return;
      e.preventDefault();
      end({ pointerId: point.identifier });
    }, { passive: false });
    zone.addEventListener('touchcancel', e => {
      const point = touchPoint(e);
      if (point && active) end({ pointerId: point.identifier });
    }, { passive: false });
  }
}
// The game script appears before the joystick markup, so initialize after DOM parsing.
function initJoysticks(){
  setupJoy('joy-left', 'stick-left', true);
  setupJoy('joy-right', 'stick-right', false);
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initJoysticks, { once:true });
else initJoysticks();
if ('ontouchstart' in window || navigator.maxTouchPoints > 0) document.documentElement.classList.add('touch-device');

// ============================================================
// COMBAT — Fully decoupled hit detection
// ============================================================
// ── Toast notifications ─────────────────────────────────────────────────────
let _toastTimer = null;
function showToast(msg, duration, color) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = msg;
  el.style.setProperty('color', color || '#ffffff', 'important');
  el.style.setProperty('display', 'block', 'important');
  el.style.setProperty('opacity', '1', 'important');
  el.style.setProperty('visibility', 'visible', 'important');
  el.style.setProperty('pointer-events', 'auto', 'important');
  if (_toastTimer) clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => {
    el.style.removeProperty('display');
    el.style.removeProperty('opacity');
    el.style.removeProperty('visibility');
  }, duration || 2500);
}

// KILL FEED
// ============================================================
const killFeedEl = document.getElementById('kill-feed');
let _kfPending = [];
let _kfRafPending = false;
function pushKillFeed(msg) {
  _kfPending.push(msg);
  if (!_kfRafPending) {
    _kfRafPending = true;
    requestAnimationFrame(function() {
      _kfRafPending = false;
      // Batch all queued messages in one DOM pass — no layout thrash per-kill
      while (_kfPending.length) {
        const m = _kfPending.shift();
        const div = document.createElement('div');
        div.className = 'kf-item';
        div.textContent = m;
        killFeedEl.prepend(div);
        setTimeout(() => div.remove(), 3200);
      }
      while (killFeedEl.children.length > 4) killFeedEl.lastChild.remove();
    });
  }
}

// ============================================================
// LEADERBOARD
// ============================================================
const lbRowsEl = document.getElementById('lb-rows');
let _lbLastHtml = '';
function formatScore(score) {
  const value = Math.max(0, Number(score) || 0);
  if (value >= 1000000) return (value / 1000000).toFixed(1).replace('.0', '') + 'M';
  if (value >= 1000) return (value / 1000).toFixed(1).replace('.0', '') + 'K';
  return String(Math.floor(value));
}
function updateLeaderboard() {
  const playerGold = player.gold || 0;
  const all = [{ name: player.name || 'Sen', gold: playerGold, kills: player.kills, isMe: true }];
  if (typeof _otherPlayers !== 'undefined') {
    _otherPlayers.forEach((p) => {
      if (!p || !p.name) return;
      all.push({ name: p.name, gold: (typeof p.gold === 'number' ? p.gold : (p.score || 0)), kills: p.kills || 0, isMe: false });
    });
  }
  all.sort((a, b) => b.gold - a.gold);
  const top10 = all.slice(0, 10);
  const newHtml = top10.map(e => {
    const pts = formatScore(e.gold);
    return `<div class="lb-row${e.isMe ? ' me' : ''}">
      <span class="lb-name">${e.name}</span>
      <span class="lb-score"><img class="lb-gold-icon" src="asset/gold.png" alt="Altın">${pts}</span>
    </div>`;
  }).join('') || '<div style="color:#aaa;text-align:center;padding:8px;font-size:11px">Bağlanılıyor...</div>';
  // PERF: skip DOM rebuild when nothing changed — avoids style recalc + layout every 2s
  if (newHtml !== _lbLastHtml) { _lbLastHtml = newHtml; lbRowsEl.innerHTML = newHtml; }
}
setInterval(() => updateLeaderboard(), 2000);
updateLeaderboard();

// ============================================================
// MINIMAP
// ============================================================
const mmCanvas = document.getElementById('minimapCanvas');
const mmCtx = mmCanvas.getContext('2d');
const MM_SIZE = 128;
const MM_SCALE = MM_SIZE / (WORLD * 2);
// PERF: module-level constant — avoids re-creating this object literal every 6 frames in drawMinimap
const _MM_RES_COLOR = { wood:'rgba(80,185,40,0.85)', stone:'rgba(150,155,168,0.85)', gold:'rgba(240,195,0,0.95)', apple:'rgba(215,55,55,0.88)', bush:'rgba(90,170,45,0.75)', mushroom:'rgba(220,80,50,0.8)', crystal:'rgba(80,190,255,0.8)', hive:'rgba(220,160,0,0.8)' };

function _buildMmBgCache() {
  const S = MM_SIZE;
  const bc = _mmBgCanvas.getContext('2d');
  const mmEdge = 0.5 - BIOME_EDGE / 2;
  const mmIn = mmEdge * S;
  const mmOut = (1 - mmEdge) * S;
  bc.fillStyle = '#3a7eb8'; bc.fillRect(0, 0, S, S);
  bc.fillStyle = '#6cb545'; bc.fillRect(1, 1, S - 2, S - 2);
  bc.fillStyle = '#74b84a'; bc.fillRect(mmIn, mmIn, mmOut - mmIn, mmOut - mmIn);
  bc.fillStyle = '#5a190b'; bc.fillRect(1, mmIn, mmIn - 1, mmOut - mmIn);
  bc.fillStyle = '#dcc060'; bc.fillRect(mmOut, mmIn, S - mmOut, mmOut - mmIn);
  bc.fillStyle = '#5a190b'; bc.fillRect(mmIn, mmOut, mmOut - mmIn, S - mmOut);
  bc.fillStyle = '#e2f0fa'; bc.fillRect(mmIn, 1, mmOut - mmIn, mmIn - 1);
  bc.save();
  bc.strokeStyle = 'rgba(24,30,38,0.72)'; bc.lineWidth = 1.6;
  bc.beginPath();
  bc.moveTo(0, mmIn); bc.lineTo(S, mmIn);
  bc.moveTo(0, mmOut); bc.lineTo(S, mmOut);
  bc.moveTo(mmIn, 0); bc.lineTo(mmIn, S);
  bc.moveTo(mmOut, 0); bc.lineTo(mmOut, S);
  bc.stroke(); bc.restore();
  _mmBgReady = true;
}

function drawMinimap() {
  const S = MM_SIZE;
  if (!_mmBgReady) _buildMmBgCache();
  // PERF: inline coordinate transform — avoids {x,y} object allocation per dot
  // MM_SCALE is constant so we compute _mmOff once outside the hot path.
  const _mmOff = WORLD; // reused below

  // ── Refresh dot layer every 6 frames onto _mmDotCanvas ──────────────────
  // CRITICAL FIX: dots are drawn to a SEPARATE offscreen canvas so they
  // persist between frames. Old code ran clearRect every frame then skipped
  // dot redraw 2/3 frames → dots vanished → visible flash every ~0.05 sec.
  _mmFrameCnt++;
  if (!_mmBaseReady || _mmFrameCnt % 6 === 0) {
    _mmDotCtx.clearRect(0, 0, S, S);
    // Resources — fillRect instead of arc (3× faster for small dots at minimap scale)
    // _MM_RES_COLOR is module-level constant; dotSz replaces arc radius with rect half-size
    for (let _ri = 0; _ri < resources.length; _ri++) {
      const r = resources[_ri];
      if (r._destroyed) continue;
      const mx = (r.x + _mmOff) * MM_SCALE, my = (r.y + _mmOff) * MM_SCALE;
      if (mx < 0 || mx > S || my < 0 || my > S) continue;
      _mmDotCtx.fillStyle = _MM_RES_COLOR[r.type] || 'rgba(80,165,40,0.75)';
      const dotSz = r.type === 'gold' ? 2.4 : r.type === 'stone' ? 2.0 : 1.6;
      _mmDotCtx.fillRect(mx - dotSz, my - dotSz, dotSz * 2, dotSz * 2);
    }
    // Enemies — fillRect (same speed boost; arcs are expensive even at 2px radius)
    _mmDotCtx.fillStyle = '#ff3333';
    for (let _ei = 0; _ei < enemies.length; _ei++) {
      const e = enemies[_ei];
      const mx = (e.x + _mmOff) * MM_SCALE, my = (e.y + _mmOff) * MM_SCALE;
      if (mx < 0 || mx > S || my < 0 || my > S) continue;
      _mmDotCtx.fillRect(mx - 2, my - 2, 4, 4);
    }
    // Buildings — inline coords
    _mmDotCtx.fillStyle = '#ffd700';
    for (let _bi = 0; _bi < buildings.length; _bi++) {
      const b = buildings[_bi];
      const mx = (b.x + _mmOff) * MM_SCALE, my = (b.y + _mmOff) * MM_SCALE;
      if (mx < 0 || mx > S || my < 0 || my > S) continue;
      _mmDotCtx.fillRect(mx - 1.8, my - 1.8, 3.6, 3.6);
    }
    // Other players — inline coords
    _mmDotCtx.fillStyle = '#5599ff'; _mmDotCtx.strokeStyle = '#ffffff'; _mmDotCtx.lineWidth = 0.8;
    _otherPlayers.forEach(function(p) {
      const mx = (p.x + _mmOff) * MM_SCALE, my = (p.y + _mmOff) * MM_SCALE;
      if (mx < 0 || mx > S || my < 0 || my > S) return;
      _mmDotCtx.beginPath(); _mmDotCtx.arc(mx, my, 3, 0, Math.PI*2); _mmDotCtx.fill(); _mmDotCtx.stroke();
    });
    // Ground food — inline coords
    _mmDotCtx.fillStyle = '#44ff88';
    for (let _fi = 0; _fi < groundFood.length; _fi++) {
      const f = groundFood[_fi];
      const mx = (f.x + _mmOff) * MM_SCALE, my = (f.y + _mmOff) * MM_SCALE;
      if (mx < 0 || mx > S || my < 0 || my > S) continue;
      _mmDotCtx.beginPath(); _mmDotCtx.arc(mx, my, 2, 0, Math.PI*2); _mmDotCtx.fill();
    }
    _mmBaseCtx.clearRect(0, 0, S, S);
    _mmBaseCtx.drawImage(_mmBgCanvas, 0, 0);
    _mmBaseCtx.drawImage(_mmDotCanvas, 0, 0);
    _mmBaseReady = true;
  }

  // ── Composite every frame: cached base + player ──────────────────────────
  mmCtx.clearRect(0, 0, S, S);
  mmCtx.drawImage(_mmBaseCanvas, 0, 0);

  // Player triangle — always drawn fresh so rotation stays smooth (inline coords)
  const _pmx = (player.x + _mmOff) * MM_SCALE, _pmy = (player.y + _mmOff) * MM_SCALE;
  mmCtx.save();
  mmCtx.translate(_pmx, _pmy);
  mmCtx.rotate(player.angle + Math.PI / 2);
  mmCtx.fillStyle = '#ffffff'; mmCtx.strokeStyle = '#222222'; mmCtx.lineWidth = 0.8;
  mmCtx.beginPath(); mmCtx.moveTo(0,-5.5); mmCtx.lineTo(3.8,3.8); mmCtx.lineTo(-3.8,3.8); mmCtx.closePath();
  mmCtx.fill(); mmCtx.stroke();
  mmCtx.restore();

  // Border
  mmCtx.strokeStyle = 'rgba(255,255,255,0.18)'; mmCtx.lineWidth = 1.5;
  mmCtx.strokeRect(0.75, 0.75, S - 1.5, S - 1.5);
}

// ============================================================
// LOOT DROPS
// ============================================================
function spawnLoot(x, y, amount) {
  if (loots.length >= 40) return; // cap: prevents mass-kill burst from creating hundreds of loot objects
  loots.push({ x: x + (Math.random()-0.5)*40, y: y + (Math.random()-0.5)*40,
    amount, radius: 10, life: 480 });
}
function updateLoots() {
  for (let i = loots.length - 1; i >= 0; i--) {
    const l = loots[i];
    l.life--;
    // Auto-collect when player is close
    const dx = player.x - l.x, dy = player.y - l.y;
    const collectR = player.radius + l.radius + 10;
    if (Math.abs(dx) > collectR || Math.abs(dy) > collectR) continue;
    const dist = Math.hypot(dx, dy);
    if (dist < player.radius + l.radius + 10) {
      player.gold += l.amount; player.score = (player.score||0) + l.amount * 2; updateUI();
      floatingTexts.push({ x:l.x, y:l.y-20, text:`+${l.amount}💰 +${l.amount*2}⭐`, alpha:1, life:32, color:'#ffd700' });
      loots[i]=loots[loots.length-1]; loots.pop();
    } else if (l.life <= 0) {
      loots[i]=loots[loots.length-1]; loots.pop();
    }
  }
}
function drawLoots() {
  if (loots.length === 0) return;
  // PERF: single save/restore for all loots — was N save/restore pairs per frame
  const _pulse = 0.8 + Math.sin(globalTime * 0.12) * 0.2;
  ctx.save();
  ctx.strokeStyle = '#b8860b'; ctx.lineWidth = 2.5;
  ctx.font = 'bold 10px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  for (let _li = 0; _li < loots.length; _li++) {
    const l = loots[_li];
    if (l.x < _renderCullL - 28 || l.x > _renderCullR + 28 ||
        l.y < _renderCullT - 28 || l.y > _renderCullB + 28) continue;
    ctx.globalAlpha = Math.min(1, l.life / 60);
    ctx.fillStyle = '#ffd700';
    ctx.beginPath(); ctx.arc(l.x, l.y, l.radius * _pulse, 0, Math.PI*2);
    ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#fff';
    ctx.fillText('💰', l.x, l.y + 4);
  }
  ctx.restore();
}

// MISSION TRACKING — batched localStorage writes (no sync I/O per event)
const _missionBatch = Object.create(null);
let   _missionFlushPending = false;
function _trackMission(key, amount) {
  _missionBatch[key] = (_missionBatch[key] || 0) + (amount || 1);
  if (!_missionFlushPending) {
    _missionFlushPending = true;
    setTimeout(function(){
      _missionFlushPending = false;
      try {
        const _mp = JSON.parse(localStorage.getItem('fb_missions') || '{}');
        for (const _k in _missionBatch) { _mp[_k] = (_mp[_k] || 0) + _missionBatch[_k]; delete _missionBatch[_k]; }
        localStorage.setItem('fb_missions', JSON.stringify(_mp));
      } catch(e){}
    }, 5000); // flush every 5 seconds — zero sync I/O during gameplay
  }
}

// ============================================================
// TREASURE CHESTS — Spawn every ~40s, max 3, give 50-200 gold
// ============================================================
function spawnChest() {
  if (chests.length >= MAX_CHESTS) return;
  const margin = 500;
  const x = (Math.random() * 2 - 1) * (WORLD - margin);
  const y = (Math.random() * 2 - 1) * (WORLD - margin);
  chests.push({ x, y, pulse: Math.random() * Math.PI * 2, life: 2400 });
}

function updateChests() {
  _nextChestSpawn--;
  if (_nextChestSpawn <= 0) {
    spawnChest();
    _nextChestSpawn = 2000 + Math.random() * 1600;
  }
  for (let i = chests.length - 1; i >= 0; i--) {
    const c = chests[i];
    c.pulse += 0.05;
    c.life--;
    const dx = player.x - c.x, dy = player.y - c.y;
    const collectR = player.radius + CHEST_COLLECT_RADIUS;
    if (Math.abs(dx) > collectR || Math.abs(dy) > collectR) continue;
    const dist = Math.hypot(dx, dy);
    if (dist < player.radius + CHEST_COLLECT_RADIUS) {
      const gold = 60 + Math.floor(Math.random() * 141); // 60-200 gold
      const mult = (_activeMapEvent && _activeMapEvent.effect === 'gold2x') ? 2 : 1;
      const finalGold = gold * mult;
      player.gold += finalGold; player.score = (player.score||0) + finalGold * 4;
      updateUI();
      floatingTexts.push({ x:c.x, y:c.y-36, text:`💎 HAZINE! +${finalGold}💰`, alpha:1, life:90, color:'#ffd700', big:true });
      spawnGoldBurst(c.x, c.y);
      playSound(880, 0.28, 'triangle', 0.4);
      setTimeout(()=>playSound(1100, 0.2, 'triangle', 0.25), 80);
      shake(4);
      _trackMission('m5', finalGold);
      window._updateQuestProgress('chests', 1); window._updateQuestProgress('gold', finalGold);
      chests[i]=chests[chests.length-1]; chests.pop();
    } else if (c.life <= 0) {
      chests[i]=chests[chests.length-1]; chests.pop();
    }
  }
}

function spawnBuildingDebris(x, y, type) {
  const isStone = type === 2 || type === 6 || type === 7;
  const colors = isStone ? ['#999999', '#bbbbbb', '#777777', '#dddddd'] : ['#8b5a2b', '#cd853f', '#d2691e', '#deb887', '#f4a460'];
  const count = _qualityLevel === 0 ? 3 : 6;
  for (let i = 0; i < count; i++) {
    const ang = Math.random() * Math.PI * 2;
    const spd = 2.5 + Math.random() * 5.5;
    const col = colors[Math.floor(Math.random() * colors.length)];
    _spawnParticle(x + (Math.random() - 0.5) * 16, y + (Math.random() - 0.5) * 16, Math.cos(ang) * spd, Math.sin(ang) * spd - 1.2, 2 + Math.random() * 3, 16 + Math.random() * 12, col);
  }
}

function drawChests() {
  // ── 1. Local Map Chests ──────────────────────────────
  for (let _ci = 0; _ci < chests.length; _ci++) {
    const c = chests[_ci];
    if (c.x < _renderCullL - 64 || c.x > _renderCullR + 64 || c.y < _renderCullT - 64 || c.y > _renderCullB + 64) continue;
    const pulse = 0.85 + Math.sin(c.pulse * 2) * 0.15;
    const glowA = 0.45 + Math.sin(c.pulse * 2) * 0.45;
    ctx.save();
    ctx.translate(c.x, c.y);
    if (_qualityLevel >= 1) {
      const gr = ctx.createRadialGradient(0, 0, 0, 0, 0, 44 * pulse);
      gr.addColorStop(0, `rgba(255,215,0,${glowA * 0.32})`);
      gr.addColorStop(1, 'rgba(255,215,0,0)');
      ctx.fillStyle = gr;
      ctx.beginPath(); ctx.arc(0, 0, 44 * pulse, 0, Math.PI * 2); ctx.fill();
    }
    const sz = 20 * pulse;
    ctx.fillStyle = '#7B3F00'; ctx.strokeStyle = '#4a2000'; ctx.lineWidth = 2;
    ctx.fillRect(-sz, -sz * 0.55, sz * 2, sz * 1.2);
    ctx.strokeRect(-sz, -sz * 0.55, sz * 2, sz * 1.2);
    ctx.fillStyle = '#9B5413';
    ctx.fillRect(-sz, -sz * 0.55, sz * 2, sz * 0.5);
    ctx.strokeRect(-sz, -sz * 0.55, sz * 2, sz * 0.5);
    ctx.fillStyle = '#ffd700'; ctx.strokeStyle = '#b8860b'; ctx.lineWidth = 1.5;
    ctx.fillRect(-sz, -sz * 0.05, sz * 2, sz * 0.14);
    ctx.beginPath(); ctx.arc(0, sz * 0.02, sz * 0.2, 0, Math.PI * 2);
    ctx.fill(); ctx.stroke();
    ctx.restore();
  }

  // ── 2. Server Airdrop & Treasure Chest Events ───────────
  if (typeof airdropsList !== 'undefined' && airdropsList.length > 0) {
    for (let _ai = 0; _ai < airdropsList.length; _ai++) {
      const ad = airdropsList[_ai];
      if (!ad || typeof ad.x !== 'number') continue;
      if (ad.dropY === undefined) ad.dropY = 0;
      if (ad.dropY < 0) { ad.dropY = Math.min(0, ad.dropY + 12); }
      const curY = ad.y + ad.dropY;
      if (ad.x < _renderCullL - 100 || ad.x > _renderCullR + 100 || curY < _renderCullT - 100 || curY > _renderCullB + 100) continue;
      
      ad.pulse = (ad.pulse || 0) + 0.05;
      const isDiamond = ad.tier === 2;
      const mainCol = isDiamond ? '#00e5ff' : '#ffd700';
      const darkCol = isDiamond ? '#007799' : '#b8860b';
      const bodyCol = isDiamond ? '#1a3344' : '#5c3317';
      
      let sX = 0, sY = 0;
      if (ad.shake > 0) { sX = (Math.random() - 0.5) * ad.shake; sY = (Math.random() - 0.5) * ad.shake; ad.shake--; }
      
      // Sky light beam shining down
      ctx.save();
      ctx.translate(ad.x + sX, curY + sY);
      
      if (_qualityLevel >= 1 && ad.dropY >= 0) {
        const bg = ctx.createLinearGradient(0, -350, 0, 0);
        bg.addColorStop(0, 'rgba(255, 255, 255, 0)');
        bg.addColorStop(0.7, isDiamond ? 'rgba(0, 229, 255, 0.18)' : 'rgba(255, 215, 0, 0.18)');
        bg.addColorStop(1, isDiamond ? 'rgba(0, 229, 255, 0.35)' : 'rgba(255, 215, 0, 0.35)');
        ctx.fillStyle = bg;
        ctx.beginPath();
        ctx.moveTo(-16, -350); ctx.lineTo(16, -350); ctx.lineTo(44, 15); ctx.lineTo(-44, 15);
        ctx.closePath(); ctx.fill();
      }

      // Parachute while falling from sky
      if (ad.dropY < -10) {
        ctx.save();
        ctx.translate(0, -36);
        ctx.fillStyle = isDiamond ? '#00bcd4' : '#e67e22';
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(0, -18, 38, Math.PI, 0);
        ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(-32, -18); ctx.lineTo(0, 30);
        ctx.moveTo(32, -18); ctx.lineTo(0, 30);
        ctx.moveTo(0, -18); ctx.lineTo(0, 30);
        ctx.stroke();
        ctx.restore();
      }

      // Hit wobble
      if (ad.hitFlash > 0) {
        ad.hitFlash--;
        ctx.scale(1.12, 0.9);
      }

      // 3D Chest Base & Lid
      const w = 34, h = 24;
      ctx.fillStyle = bodyCol; ctx.strokeStyle = '#111'; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.roundRect(-w, -h * 0.5, w * 2, h, 6); ctx.fill(); ctx.stroke();

      // Metallic corner reinforcements
      ctx.fillStyle = mainCol; ctx.strokeStyle = darkCol; ctx.lineWidth = 1.5;
      ctx.fillRect(-w + 3, -h * 0.5 + 2, 7, h - 4);
      ctx.strokeRect(-w + 3, -h * 0.5 + 2, 7, h - 4);
      ctx.fillRect(w - 10, -h * 0.5 + 2, 7, h - 4);
      ctx.strokeRect(w - 10, -h * 0.5 + 2, 7, h - 4);

      // Center lock
      ctx.fillStyle = mainCol;
      ctx.beginPath(); ctx.arc(0, 0, 7, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#000';
      ctx.beginPath(); ctx.arc(0, 0, 2.5, 0, Math.PI * 2); ctx.fill();

      // Sparkles around chest
      if (_qualityLevel >= 1) {
        const sp = ad.pulse * 1.5;
        for (let i = 0; i < 4; i++) {
          const ang = sp + i * (Math.PI / 2);
          const r = 28 + Math.sin(sp * 2 + i) * 6;
          ctx.fillStyle = isDiamond ? '#e0f7fa' : '#fff9c4';
          ctx.beginPath();
          ctx.arc(Math.cos(ang) * r, Math.sin(ang) * r - 4, 2.2, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      ctx.restore();

      // Health bar & Label
      drawHpBar(ad.x, curY - 34, ad.hp, ad.maxHp, 58, 0);
      ctx.save();
      ctx.font = 'bold 12px Nunito,Arial,sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
      ctx.strokeStyle = '#000'; ctx.lineWidth = 3;
      const tagText = isDiamond ? '💎 Elmas Sandık' : '📦 Hazine Sandığı';
      ctx.strokeText(tagText, ad.x, curY - 40);
      ctx.fillStyle = isDiamond ? '#80deea' : '#ffd54f';
      ctx.fillText(tagText, ad.x, curY - 40);
      ctx.restore();
    }
  }
}

// ============================================================
// GLOBAL MAP EVENTS — Disabled
const _MAP_EVENTS_LIST = [];
let _activeMapEvent = null;
let _mapEventTimer = 0;
let _nextMapEventIn = 99999999;
const _eventBannerEl = null;

function _startMapEvent(ev) {}
function _endMapEvent() {}
function updateMapEvents() {}

// ============================================================
// COMBAT — per-swing arc hit, her enemy bir swing'de 1 kez hasar alır
// hitRange: oyuncudan hedefe merkez-merkez max mesafe (e.radius ayrıca eklenir)
// ============================================================

// Tek yetkili yay hesabı — hem düşman hem boss hem görsel bu değeri kullanır
function _swingHalfArc() {
  // Axe: 70° half-arc (140° total), Sword: 55° half-arc (110° total) — daha gerçekçi
  const base = player.weapon === 2 ? Math.PI / 3.25 : Math.PI / 2.57;
  return base * (player._wideSwing ? 1.4 : 1);
}
// Tek yetkili vuruş menzili
function _swingHitRange() {
  return player.weapon === 2 ? 140 : 128; // katana 140, balta/bıçak 128
}

// ── Lag compensation: immediate client-side PvP hit prediction ──────────────
// Replicates the server's arc+range check against _otherPlayers so that blood,
function _checkPvpHits() {
  if (!_connected || !_otherPlayers || _otherPlayers.size === 0) return;
  if (player.weapon >= 3) return;
  const hitRange = _swingHitRange();
  const spread   = _swingHalfArc();
  const tier     = player.weapon === 2 ? _wepTier(_swordXP) : _wepTier(_axeXP);
  const baseDmg  = player.weapon === 2 ? 30 : 22;
  const _TM      = [1.0, 1.5, 2.2, 3.5, 5.0, 8.0];
  const dmgEst   = Math.min(120, Math.round(baseDmg * (_TM[tier] || 1) * (player.dmgBonus || 1)));
  const now      = Date.now();
  const _maxPR   = player.radius * 0.5 + hitRange + 28;
  const _maxPR2  = _maxPR * _maxPR;

  _otherPlayers.forEach((op, opId) => {
    // Don't hit teammates
    if ((op.clanId && player.clanId && op.clanId === player.clanId) || (op.team && player.team && op.team === player.team)) return;
    // Once-per-swing gate: same opId + same swingId → skip
    if (_pvpPredictTime.get(opId + '_sw') === _swingId) return;
    // Use interpolated render position for best accuracy
    const opX = op._sx ?? op.x, opY = op._sy ?? op.y;
    const _pdx = opX - player.x, _pdy = opY - player.y;
    if (Math.abs(_pdx) > _maxPR || Math.abs(_pdy) > _maxPR) return;
    if (_pdx * _pdx + _pdy * _pdy > _maxPR2) return;
    let diff = Math.abs(Math.atan2(_pdy, _pdx) - player.angle);
    if (diff > Math.PI) diff = 2 * Math.PI - diff;
    if (diff > spread) return;
    // ── Predicted hit ────────────────────────────────────────────────────────
    _pvpPredictTime.set(opId + '_sw', _swingId); // once-per-swing gate
    _pvpPredictTime.set(opId, now);               // timestamp for pvp_confirm dedup
    // Immediate visual feedback — blood, damage number, hit flash, sound, shake
    spawnBlood(opX, opY, 5);
    floatingTexts.push({ x: opX, y: opY - 35, text: '-' + dmgEst + ' ⚔️', alpha: 1, life: 35, color: '#ff8866' });
    if (typeof op.hitFlash !== 'undefined') op.hitFlash = 8;
    playSound(220 + Math.floor(Math.random() * 100), 0.08, 'square', 0.15);
    shake(4);
  });
}

function checkHits() {
  if (player.weapon >= 3) return;

  const hitRange = _swingHitRange();
  const spread   = _swingHalfArc();
  const baseDmg  = player.weapon === 2 ? 30 : 22;
  const dmg      = Math.round(baseDmg * (player.dmgBonus || 1));

  // ---- Enemies — hit EVERY enemy in arc (per-swing, no global cooldown) ----
  // PERF: cache range once — avoids 3 multiplies/additions per enemy
  const _cHitRange = player.radius * 0.5 + hitRange;
  {
    for (let i = enemies.length - 1; i >= 0; i--) {
      const e = enemies[i];
      // Each enemy can only be hit ONCE per swing; also skip already-dead mobs
      if (e.lastHitSwingId === _swingId) continue;
      if (e.hp <= 0) continue; // dead but not yet removed (pending mob_dead from server)

      // PERF: AABB fast reject — no sqrt needed for most out-of-range enemies
      const _cdx = e.x - player.x, _cdy = e.y - player.y;
      const _cRange = _cHitRange + e.radius;
      if (Math.abs(_cdx) > _cRange || Math.abs(_cdy) > _cRange) continue;
      if (_cdx * _cdx + _cdy * _cdy > _cRange * _cRange) continue;
      let diff = Math.abs(Math.atan2(_cdy, _cdx) - player.angle);
      if (diff > Math.PI) diff = 2 * Math.PI - diff;
      if (diff > spread) continue;  // > değil >= : sınır dahil

      // HIT confirmed
      e.lastHitSwingId = _swingId;
      e.provoked = true; // enemy is now aggressive
      // Critical hit system
      const _isCrit = Math.random() < (player._highCrit ? 0.22 : 0.10);
      const dmgFinal = Math.round((_isCrit ? Math.round(dmg * _critMulti) : dmg) * (_comboDmgBonus || 1));
      if (_connected && _socket && e._netId) {
        // Server-authoritative: send hit to server; server applies damage and broadcasts result
        _socket.emit('mob_hit_req', { mobId: e._netId, dmg: dmgFinal });
        // Optimistic local HP update: clamp at min 1 so client NEVER deletes mob early in multiplayer!
        e.hp = Math.max(1, e.hp - dmgFinal);
      } else {
        e.hp -= dmgFinal;
      }
      if (player.weapon === 2) addSwordXP(6);
      e.vx += Math.cos(player.angle) * (_isCrit ? 18 : 12);
      e.vy += Math.sin(player.angle) * (_isCrit ? 18 : 12);
      player.totalDmg += dmgFinal;
      e.hitFlash = _isCrit ? 14 : 10;
      spawnBlood(e.x, e.y, _isCrit ? 5 : 3);
      playSound(220 + Math.floor(Math.random()*100), 0.08, 'square', 0.15);
      if(_isCrit){ playSound(440,0.1,'triangle',0.15); shake(5); }
      floatingTexts.push({ x: e.x, y: e.y - 35, text: (_isCrit?'💥 KRİT! -':'-') + dmgFinal, alpha: 1, life: _isCrit?55:35, color: _isCrit?'#ffdd00':'#ff6666', big:_isCrit });
      if (_isCrit) { for(let _cp=0;_cp<10;_cp++) _spawnParticle(e.x+(Math.random()-0.5)*20,e.y+(Math.random()-0.5)*20,(Math.random()-0.5)*9,Math.random()*-7-2,3+Math.random()*3,22,'#ffd700'); }
      if (player._lifeSteal && !_isDying) { player.hp = Math.min(player.maxHp, player.hp + 4); updateHpBar(); floatingTexts.push({x:player.x,y:player.y-38,text:'🌿 +4',alpha:1,life:28,color:'#66ee44'}); }
      if (e.hp <= 0 && !_connected) {
        // Offline mode: handle kill locally
        const xpGain = e.xpReward || 25;
        const goldDrop = e.goldReward || 5;
        const scoreGain = Math.round(xpGain * 0.75 + goldDrop * 3);
        player.xp += xpGain; player.kills++;
        player.score = (player.score||0) + scoreGain;
        _playerLevelKills++; _checkPlayerLevel();
        updateUI(); updateXP();
        // PERF: spread 20-particle kill burst over 4 frames — prevents single-frame spike
        if(!window._deferBlood)window._deferBlood=[];
        for(var _dbi=0;_dbi<4;_dbi++)window._deferBlood.push({x:e.x,y:e.y,n:5,d:_dbi*2});
        if(window._deferBlood.length>48)window._deferBlood.length=48;
        spawnGoldBurst(e.x, e.y);
        if (player._explosiveKills) {
          shake(7);
          for(let _ek=0;_ek<16;_ek++) _spawnParticle(e.x+(Math.random()-0.5)*28,e.y+(Math.random()-0.5)*28,(Math.random()-0.5)*13,Math.random()*-9-2,3+Math.random()*4,28+Math.random()*18,Math.random()<0.5?'#ff8800':'#ffcc00');
          // PERF: squared-distance check — eliminates Math.hypot (sqrt) per nearby enemy
          for(let _ne=enemies.length-1;_ne>=0;_ne--){ const _neT=enemies[_ne]; if(_neT===e) continue; const _ndx=_neT.x-e.x,_ndy=_neT.y-e.y; if(_ndx*_ndx+_ndy*_ndy<16900){_neT.hp-=Math.round(dmgFinal*0.45);_neT.hitFlash=10;spawnBlood(_neT.x,_neT.y,3);} }
        }
        e._killCredited = true;
        recordKill();
        _killCamTimer = 55; _killCamX = e.x; _killCamY = e.y;
        playSound(280 + Math.floor(Math.random()*120), 0.14, 'square', 0.22);
        if (player.vampire) { player.hp = Math.min(player.maxHp, player.hp + 12); updateHpBar(); floatingTexts.push({ x: player.x, y: player.y - 40, text: '🧛 +12 HP', alpha: 1, life: 35, color: '#cc55ff' }); }
        if(Math.random()<0.22) spawnArmorDrop(e.x,e.y);
        spawnLoot(e.x, e.y, goldDrop);
        floatingTexts.push({ x: e.x, y: e.y - 55, text: `+${xpGain} XP  +${scoreGain}⭐`, alpha: 1, life: 50, color: '#ffe555' });
        // PERF: swap-and-pop O(1) removal — safe since we iterate backward
        enemies[i] = enemies[enemies.length - 1]; enemies.pop();
      }
    }
  }

  // ---- Boss camps — silah swing'leri bosslara da hasar verir ----
  if (typeof CAMPS !== 'undefined' && typeof bossState !== 'undefined') {
    CAMPS.forEach(function(c) {
      const bs = bossState[c.id];
      if (!bs || !bs.alive) return;
      const _bdx = bs.x - player.x, _bdy = bs.y - player.y;
      const _bMaxR = hitRange + c.bossR + player.radius;
      if (Math.abs(_bdx) > _bMaxR || Math.abs(_bdy) > _bMaxR) return;
      if (_bdx*_bdx + _bdy*_bdy > _bMaxR * _bMaxR) return;
      let _bDiff = Math.abs(Math.atan2(_bdy, _bdx) - player.angle);
      if (_bDiff > Math.PI) _bDiff = 2 * Math.PI - _bDiff;
      if (_bDiff > spread * 1.35) return; // slightly wider arc for big boss
      const _isBossCrit = Math.random() < (player._highCrit ? 0.22 : 0.10);
      const _bossDmg = Math.round(dmg * (_isBossCrit ? _critMulti : 1) * (_comboDmgBonus || 1));
      bs.hp = Math.max(0, bs.hp - _bossDmg);
      bs.dmgFlashFrames = 6;
      spawnBlood(bs.x, bs.y, _isBossCrit ? 8 : 4);
      if (floatingTexts.length < 20) floatingTexts.push({x:bs.x+(Math.random()-0.5)*30,y:bs.y-c.bossR-20,text:(_isBossCrit?'💥 KRİT! -':'-')+_bossDmg,alpha:1,life:_isBossCrit?60:38,color:_isBossCrit?'#ffdd00':'#ffaa44',big:_isBossCrit});
      if (player._lifeSteal && !_isDying) { player.hp = Math.min(player.maxHp, player.hp + 4); updateHpBar(); }
      if (bs.hp <= 0 && typeof _bossDied === 'function') _bossDied(c, bs);
    });
  }

  // ---- Resources — her swing'de sadece 1 kez hasar (Spatial Grid ile O(1) arama) ----
  {
    const _resHitFrac = _RES_HIT_FRAC;
    const _nearbyRes = _resQuery(player.x, player.y, hitRange + 160);
    for (let i = _nearbyRes.length - 1; i >= 0; i--) {
      const res = _nearbyRes[i];
      if (res.lastHitSwingId === _swingId) continue;
      if (res._destroyed) continue;
      const _rdx = res.x - player.x, _rdy = res.y - player.y;
      const _rMaxDist = hitRange + res.radius * (_resHitFrac[res.type] || 0.65);
      if (Math.abs(_rdx) > _rMaxDist || Math.abs(_rdy) > _rMaxDist) continue;
      if (_rdx * _rdx + _rdy * _rdy > _rMaxDist * _rMaxDist) continue;
      let diff = Math.abs(Math.atan2(_rdy, _rdx) - player.angle);
      if (diff > Math.PI) diff = 2 * Math.PI - diff;
      if (diff > spread) continue;

      // HIT this resource — bu swing için kilitle
      res.lastHitSwingId = _swingId;
      res.shake = 5; res.shakeAng = player.angle + Math.PI;
      // In online mode: notify server so all players see the damage
      if (_connected && _socket && res._netIdx !== undefined && res._netIdx >= 0) {
        _socket.emit('res_hit', { idx: res._netIdx, dmg });
      }
      hitAny = true;
      if (player.weapon === 1) addAxeXP(4);
      const harvestMult = (player.weapon === 1 ? 3 : 2) * (player.harvestBonus || 1);
      const harvest = harvestMult;
      const yW = Math.round((res.yW || 0) * harvest), yS = Math.round((res.yS || 0) * harvest);
      const yG = res.yG || 0;
      const yA = res.yA || 0;
      const _ftParts = [];
      if (yW > 0) { player.wood  += yW; _ftParts.push('+'+yW+'🪵'); _trackMission('m2', yW); window._updateQuestProgress('wood', yW); localStorage.setItem('fb_total_wood_meta', parseInt(localStorage.getItem('fb_total_wood_meta')||'0',10)+yW); }
      if (yS > 0) { player.stone += yS; _ftParts.push('+'+yS+'🪨'); window._updateQuestProgress('stone', yS); }
      if (yG > 0) { player.gold  += yG; _ftParts.push('+'+yG+'💰'); }
      if (yA > 0 && Math.random() < yA) { player.apples++; _ftParts.push('+1🍎'); }
      if (_ftParts.length) floatingTexts.push({ x: res.x+(Math.random()-0.5)*30, y: res.y-40, text:_ftParts.join(' '), alpha:1, life:38, color:'#c8f5a0' });
      // NEW: Mushroom — heal
      if ((res.yHp||0) > 0) {
        const healAmt = res.yHp;
        player.hp = Math.min(player.maxHp, player.hp + healAmt);
        floatingTexts.push({ x: res.x, y: res.y-50, text:'+'+healAmt+' 💚 CAN', alpha:1, life:50, color:'#44ff88' });
        for(let pi=0;pi<4;pi++){const pa=Math.random()*Math.PI*2;_spawnParticle(res.x+Math.cos(pa)*18,res.y+Math.sin(pa)*18,Math.cos(pa)*3,Math.sin(pa)*3-2,4+Math.random()*3,22,'#44ff88');}
        playSound(660,0.12,'sine',0.2);
      }
      // NEW: Crystal — XP burst
      if ((res.yXp||0) > 0) {
        player.xp += res.yXp;
        floatingTexts.push({ x: res.x, y: res.y-50, text:'+'+res.yXp+' ✨ XP', alpha:1, life:55, color:'#aaeeff' });
        for(let pi=0;pi<4;pi++){const pa=Math.random()*Math.PI*2;_spawnParticle(res.x+Math.cos(pa)*14,res.y+Math.sin(pa)*14,Math.cos(pa)*4.5,Math.sin(pa)*4.5-3,3+Math.random()*3,28,'#aaeeff');}
        playSound(880,0.12,'triangle',0.22); updateXP();
      }
      // NEW: Hive — speed boost
      if ((res.ySpd||0) > 0) {
        if (!player._speedBoostEnd || player._speedBoostEnd < Date.now()) {
          player.speedBonus = (player.speedBonus||1) * 1.55;
          player._speedBoostEnd = Date.now() + res.ySpd * (1000/60);
          setTimeout(()=>{ player.speedBonus = (player.speedBonus||1) / 1.55; player._speedBoostEnd = 0; }, res.ySpd*(1000/60));
          floatingTexts.push({ x: res.x, y: res.y-50, text:'⚡ HIZ +55%!', alpha:1, life:55, color:'#ffcc00' });
          playSound(440,0.15,'sine',0.25);
        }
      }
      player.xp += harvest;
      updateUI(); updateXP();
    }
  }

  // ---- Buildings — player weapon hits nearby buildings in arc (Spatial Grid O(1)) ----
  {
    const _nearbyBlds = _sgQuery(player.x, player.y, hitRange + 90);
    for (let i = _nearbyBlds.length - 1; i >= 0; i--) {
      const b = _nearbyBlds[i];
      if (b.hp <= 0) continue;
      // Each building only takes 1 hit per swing
      if (b.lastHitSwingId === _swingId) continue;
      if (b.ownerClanId && player.clanId && b.ownerClanId === player.clanId) continue;

      const isTrappedInThis = Boolean(_trapCaughtBy && (b._netId === _trapCaughtBy || b.id === _trapCaughtBy || b._bLid === _trapCaughtBy));
      const _bdx = b.x - player.x, _bdy = b.y - player.y;
      const _bDist2 = _bdx * _bdx + _bdy * _bdy;
      const bRad = {3:34,4:44,5:22,6:45,7:32,8:20,9:52}[b.type] || 36;
      const _bMaxDist = player.radius * 0.5 + hitRange + bRad;
      if (!isTrappedInThis) {
        if (Math.abs(_bdx) > _bMaxDist || Math.abs(_bdy) > _bMaxDist) continue;
        if (_bDist2 > _bMaxDist * _bMaxDist) continue;
        const isDirectTouch = _bDist2 <= (bRad + player.radius) * (bRad + player.radius);
        if (!isDirectTouch) {
          let diff = Math.abs(Math.atan2(_bdy, _bdx) - player.angle);
          if (diff > Math.PI) diff = 2 * Math.PI - diff;
          if (diff > spread) continue;
        }
      }

      // HIT confirmed — deal weapon damage to building
      b.lastHitSwingId = _swingId;
      const bDmg = Math.round(dmg * 0.6); // buildings tougher than enemies
      b.hp = Math.max(0, b.hp - bDmg);
      b.shake = 8; b.hitTimer = 15;
      spawnBuildingDebris(b.x, b.y, b.type);
      shake(3.5);
      playSound(180 + Math.random() * 60, 0.08, 'square', 0.16);
      floatingTexts.push({ x: b.x, y: b.y - 38, text: '-' + bDmg + ' 🪓', alpha: 1, life: 28, color: '#ffcc66' });

      // Tell server about damage to ANY building — server broadcasts to ALL players
      if (b._netId && _connected && _socket) {
        _socket.emit('building_hit', { id: b._netId, dmg: bDmg, swingId: _swingId });
      }

      // If destroyed — notify server/remove
      if (b.hp <= 0) {
        floatingTexts.push({ x: b.x, y: b.y, text: '💥 Yıkıldı!', alpha: 1, life: 45, color: '#ff8800' });
        // For owned buildings: also send build_destroy so server knows to clean up
        if (b._netId && b._ownerId === _mySocketId) _mpBuildDestroyed(b);
        if (b._netId) _buildingsMap.delete(b._netId);
        if (b.type === 10) { const _ci=_campfires.indexOf(b); if(_ci>=0){_campfires[_ci]=_campfires[_campfires.length-1];_campfires.pop();} }
        const _bIdx = buildings.indexOf(b);
        if (_bIdx >= 0) buildings.splice(_bIdx, 1);
      }
    }
  }

  // ── Airdrops / Treasure Chests Hit Check ────────────────────────
  if (typeof airdropsList !== 'undefined' && airdropsList.length > 0) {
    for (let _ai = airdropsList.length - 1; _ai >= 0; _ai--) {
      const ad = airdropsList[_ai];
      if (!ad || typeof ad.x !== 'number') continue;
      const curY = ad.y + (ad.dropY || 0);
      const adx = ad.x - player.x, ady = curY - player.y;
      const adMaxDist = player.radius * 0.5 + hitRange + 40;
      if (Math.abs(adx) > adMaxDist || Math.abs(ady) > adMaxDist) continue;
      if (adx * adx + ady * ady > adMaxDist * adMaxDist) continue;
      let diff = Math.abs(Math.atan2(ady, adx) - player.angle);
      if (diff > Math.PI) diff = 2 * Math.PI - diff;
      if (diff > spread) continue;

      const aDmg = Math.round(dmg * 0.8);
      ad.hp = Math.max(0, ad.hp - aDmg);
      ad.hitFlash = 10;
      ad.shake = 7;
      spawnBuildingDebris(ad.x, curY, 2);
      shake(4.0);
      playSound(240 + Math.random() * 50, 0.09, 'square', 0.22);
      floatingTexts.push({ x: ad.x, y: curY - 38, text: '-' + aDmg + ' ⚔️', alpha: 1, life: 25, color: '#ffd700', big: true });

      if (_connected && _socket) {
        _socket.emit('airdrop_hit', { id: ad.id, dmg: aDmg });
      }
    }
  }
}

// ============================================================
// PERF: Module-level static maps — hoisted from hot loops to prevent
// GC allocation pressure (these were created fresh every frame before).
// ============================================================
const _RES_HP_COLORS = { wood:'#4caf50', stone:'#90a4ae', gold:'#ffd54f', apple:'#ef9a9a', bush:'#81c784', mushroom:'#ce93d8', crystal:'#80deea', hive:'#ffcc80' };
const _BUILD_COSTS_MAP = { 3:[20,5], 4:[40,20], 5:[10,20], 6:[30,10], 7:[60,40], 8:[30,0], 9:[80,60], 10:[25,0] };

// ============================================================
// SCREEN SHAKE
// ============================================================
let shakeX=0, shakeY=0, shakeMag=0;
// Delta-time: 1.0 = 60fps, 2.0 = 30fps — tüm fizik bu değerle ölçeklenir
// Böylece oyuncu/düşman hızı her FPS'de eşit görünür (frame-rate independent physics)
let _dt = 1.0;
// Friction cache — Math.pow(0.84,_dt) aynı frame'de player + her enemy için tekrar hesaplanmamalı.
let _fricFrame = 0.84, _fricFrameDt = 1.0;
function shake(mag){ if (_shakeEnabled) shakeMag=Math.max(shakeMag,mag); }
function updateShake(){ if(shakeMag>0.3){ shakeX=(Math.random()-0.5)*shakeMag*2; shakeY=(Math.random()-0.5)*shakeMag*2; shakeMag*=Math.pow(0.84,_dt); }else{ shakeX=0;shakeY=0;shakeMag=0; } }

// ============================================================
// PARTICLE SYSTEM
// ============================================================
let particles=[];
// ── PRE-ALLOCATED PARTICLE POOL ─────────────────────────────────────────
// Zero garbage-collection: pool objects are recycled instead of created/destroyed.
const _P_POOL_SZ = _isMobile ? 48 : 96;
const _pFreePool  = [];
(function _initPPool(){for(let _i=0;_i<_P_POOL_SZ;_i++) _pFreePool.push({x:0,y:0,vx:0,vy:0,r:0,life:0,maxLife:1,color:'#fff'});})();

function _spawnParticle(x,y,vx,vy,r,life,color){
  // PERF: Reduced particle caps for better performance on all quality levels
  const _cap=_qualityLevel===0?3:_qualityLevel===1?8:24;
  if(particles.length>=_cap) return;
  const p=_pFreePool.length>0?_pFreePool.pop():{x:0,y:0,vx:0,vy:0,r:0,life:0,maxLife:1,color:'#fff'};
  p.x=x;p.y=y;p.vx=vx;p.vy=vy;p.r=r;p.life=life;p.maxLife=life;p.color=color;
  particles.push(p);
}

// PERF: Scale blood particle count by quality level — avoids allocation spikes on kills
function spawnBlood(x,y,n){
  const _bn=_qualityLevel===0?Math.min(n,2):_qualityLevel===1?Math.min(n,Math.ceil(n*0.5)):n;
  for(let i=0;i<_bn;i++) _spawnParticle(x,y,(Math.random()-0.5)*15,Math.random()*-11-2,2+Math.random()*4,20+Math.random()*20,'#cc2020');
}

// ============================================================
// BOW / ARROW SYSTEM
// ============================================================
function fireBowArrow(){
  if(_bowCooldown>0)return;
  _bowCooldown=BOW_COOLDOWN;
  const spd=9.5;
  const tier=_wepTier(_axeXP);
  const dmg=Math.round((14+tier*6)*(player.dmgBonus||1));
  /* trail: pre-allocated 8-slot ring buffer — zero GC vs push({x,y})/shift() */
  arrows.push({x:player.x+Math.cos(player.angle)*player.radius,y:player.y+Math.sin(player.angle)*player.radius,vx:Math.cos(player.angle)*spd,vy:Math.sin(player.angle)*spd,dmg,life:90,color:WEAPON_TIERS[tier].color,tier,
    trail:[{x:0,y:0},{x:0,y:0},{x:0,y:0},{x:0,y:0},{x:0,y:0},{x:0,y:0},{x:0,y:0},{x:0,y:0}],_tH:0,_tLen:0});
  playSound(520,0.07,'sawtooth',0.15);
}
function updateArrows(){
  if(_bowCooldown>0)_bowCooldown--;
  for(let i=arrows.length-1;i>=0;i--){
    const a=arrows[i];
    /* Ring buffer write — reuses pre-allocated slot, no new {} no O(N) shift */
    a.trail[a._tH].x=a.x; a.trail[a._tH].y=a.y;
    a._tH=(a._tH+1)%8; if(a._tLen<8)a._tLen++;
    a.x+=a.vx; a.y+=a.vy;
    a.life--;
    let _aHit=false;
    // Hit enemies — squared distance (no sqrt needed for threshold)
    for(let j=enemies.length-1;j>=0;j--){
      const e=enemies[j];
      const _aDx=a.x-e.x,_aDy=a.y-e.y,_aR=e.radius+6;
      if(_aDx*_aDx+_aDy*_aDy<_aR*_aR){
        const isCrit=Math.random()<0.12;
        const dmg=isCrit?Math.round(a.dmg*_critMulti):a.dmg;
        e.hitFlash=8; e.provoked=true;
        floatingTexts.push({x:e.x,y:e.y-40,text:(isCrit?'💥 KRİT! -':'-')+dmg,alpha:1,life:45,color:isCrit?'#ffdd00':'#ffaa55',big:isCrit});
        spawnBlood(e.x,e.y,4);
        if(_connected && _socket && e._netId){
          // Multiplayer: server-authoritative damage via mob_hit_req
          _socket.emit('mob_hit_req',{mobId:e._netId,dmg});
          e.hp = Math.max(1, e.hp - dmg);
        } else {
          // Offline: apply HP locally
          e.hp-=dmg;
          if(e.hp<=0){
            const xpGain=e.xp; const goldDrop=e.gold+(Math.random()<0.3?1:0);
            player.xp+=xpGain; updateXP(); player.gold+=goldDrop; updateUI();
            player.kills++; _playerLevelKills++; _checkPlayerLevel();
            recordKill();
            floatingTexts.push({x:e.x,y:e.y-55,text:'+'+xpGain+' XP',alpha:1,life:45,color:'#a0e8ff'});
            if(Math.random()<0.25) spawnArmorDrop(e.x,e.y);
            spawnLoot(e.x,e.y,goldDrop);
            spawnBlood(e.x,e.y,16);
            enemies.splice(j,1);
          }
        }
        _aHit=true; break;
      }
    }
    // ── Bug fix: bow arrows now hit other players in multiplayer ─────────────
    // Previously, updateArrows() only checked enemies — PvP hits were impossible
    // with a bow. This adds the same arc check as turret projectiles (line 11748).
    if(!_aHit && _connected && _socket && _otherPlayers.size>0){
      _otherPlayers.forEach((tgt,tgtId)=>{
        if(_aHit) return;
        if(tgt.team && player.team && tgt.team===player.team) return;
        const _opX=tgt._sx??tgt.x, _opY=tgt._sy??tgt.y;
        const _aDx2=a.x-_opX, _aDy2=a.y-_opY;
        if(_aDx2*_aDx2+_aDy2*_aDy2<42*42){
          const _finalDmg=Math.round(a.dmg);
          // Lag compensation: show instant visual feedback
          spawnBlood(_opX,_opY,5);
          floatingTexts.push({x:_opX,y:_opY-40,text:'-'+_finalDmg+' 🏹',alpha:1,life:35,color:'#ffaa55'});
          playSound(280+Math.floor(Math.random()*100),0.08,'square',0.15);
          _pvpPredictTime.set(tgtId,Date.now()); // dedup pvp_confirm visual
          _socket.emit('arrow_hit',{targetId:tgtId,dmg:_finalDmg});
          addAxeXP(3);
          _aHit=true;
        }
      });
    }
    if(_aHit||a.life<=0||a.x<-WORLD||a.x>WORLD||a.y<-WORLD||a.y>WORLD) arrows.splice(i,1);
  }
}
function drawArrows(){
  for(let _ai=0;_ai<arrows.length;_ai++){const a=arrows[_ai];
    if(a.x<_renderCullL-40||a.x>_renderCullR+40||a.y<_renderCullT-40||a.y>_renderCullB+40) continue;
    // Trail
    ctx.save();
    var _atLen=a._tLen;
    for(var _at=0;_at<_atLen;_at++){
      const al=_at/_atLen*0.55;
      ctx.globalAlpha=al; ctx.strokeStyle=a.color; ctx.lineWidth=3*(_at/_atLen);
      if(_at>0){
        var _ai0=(a._tH-_atLen+_at-1+16)%8, _ai1=(a._tH-_atLen+_at+16)%8;
        ctx.beginPath();ctx.moveTo(a.trail[_ai0].x,a.trail[_ai0].y);ctx.lineTo(a.trail[_ai1].x,a.trail[_ai1].y);ctx.stroke();
      }
    }
    ctx.restore();
    // Arrow shaft
    const ang=Math.atan2(a.vy,a.vx);
    ctx.save();
    ctx.translate(a.x,a.y);ctx.rotate(ang);
    ctx.fillStyle='#8a6020';ctx.strokeStyle='#3a2000';ctx.lineWidth=2;
    ctx.beginPath();ctx.rect(-18,-2,24,4);ctx.fill();ctx.stroke();
    // Tip
    ctx.fillStyle=a.color;ctx.beginPath();ctx.moveTo(6,0);ctx.lineTo(-4,-5);ctx.lineTo(-4,5);ctx.closePath();ctx.fill();
    // Feathers
    ctx.fillStyle='rgba(200,200,220,0.8)';
    ctx.beginPath();ctx.moveTo(-16,-2);ctx.lineTo(-24,-7);ctx.lineTo(-18,0);ctx.closePath();ctx.fill();
    ctx.beginPath();ctx.moveTo(-16,2);ctx.lineTo(-24,7);ctx.lineTo(-18,0);ctx.closePath();ctx.fill();
    if(a.tier>=2&&_qualityLevel>=2){ctx.shadowColor=a.color;ctx.shadowBlur=8;}
    ctx.restore();
  }
}

// ============================================================
// ENEMY PROJECTILE SYSTEM
// ============================================================
function updateEnemyProjectiles(){
  const now=Date.now();
  for(let i=enemyProjectiles.length-1;i>=0;i--){
    const p=enemyProjectiles[i];
    // PERF: ring buffer write — zero object allocation, no O(N) shift
    if(p._tH!==undefined){
      p.trail[p._tH].x=p.x; p.trail[p._tH].y=p.y;
      p._tH=(p._tH+1)%6; if(p._tN<6)p._tN++;
    } else {
      // legacy fallback for projectiles spawned before upgrade
      p.trail.push({x:p.x,y:p.y}); if(p.trail.length>6)p.trail.shift();
    }
    p.x+=p.vx; p.y+=p.vy;
    p.life--;
    // Hit player — squared distance check (no sqrt needed for threshold comparison)
    const _epDx=p.x-player.x, _epDy=p.y-player.y;
    const _epHit=player.radius+p.r;
    if(_epDx*_epDx+_epDy*_epDy < _epHit*_epHit){
      if(_spawnProtected){ enemyProjectiles[i]=enemyProjectiles[enemyProjectiles.length-1];enemyProjectiles.pop(); continue; }
      const reducedDmg=Math.round(p.dmg*(1-(player.armorBonus||0)));
      player.hp-=reducedDmg; player.lastHitEnemyTime=now;
      shake(8); triggerDmgFlash(); spawnBlood(player.x,player.y,5);
      floatingTexts.push({x:player.x,y:player.y-50,text:'-'+reducedDmg+' HP',alpha:1,life:35,color:'#ff3333'});
      playSound(110,0.12,'sawtooth',0.22);
      if(player.hp<=0){player.hp=0;die();}
      for(let k=0;k<8;k++) _spawnParticle(p.x,p.y,(Math.random()-0.5)*8,(Math.random()-0.5)*8,3+Math.random()*3,16,p.color);
      // PERF: swap-and-pop O(1) removal (was splice O(n))
      enemyProjectiles[i]=enemyProjectiles[enemyProjectiles.length-1];enemyProjectiles.pop();
      continue;
    }
    // PERF: swap-and-pop O(1) removal
    if(p.life<=0){ enemyProjectiles[i]=enemyProjectiles[enemyProjectiles.length-1];enemyProjectiles.pop(); }
  }
}
function drawEnemyProjectiles(){
  if(!enemyProjectiles.length) return;
  // PERF: single save/restore wrapping all projectiles (was one per projectile — 2×N GPU flushes)
  ctx.save(); ctx.lineCap='round';
  for(let _epi=0;_epi<enemyProjectiles.length;_epi++){const p=enemyProjectiles[_epi];
    if(p.x<_renderCullL-80||p.x>_renderCullR+80||p.y<_renderCullT-80||p.y>_renderCullB+80) continue;
    // Trail — skip entirely at quality 0; use ring buffer indices for correct draw order
    if(_qualityLevel>=1 && p._tN>1){
      const _tn=p._tN, _invN=1/_tn;
      ctx.strokeStyle=p.color;
      for(let t=0;t<_tn-1;t++){
        // PERF: ring buffer index math — correct oldest-to-newest ordering
        const ti0=(p._tH-_tn+t+12)%6, ti1=(p._tH-_tn+t+1+12)%6;
        const _ta=(t+1)*_invN;
        ctx.globalAlpha=_ta*0.5; ctx.lineWidth=p.r*0.8*_ta;
        ctx.beginPath();ctx.moveTo(p.trail[ti0].x,p.trail[ti0].y);ctx.lineTo(p.trail[ti1].x,p.trail[ti1].y);ctx.stroke();
      }
      ctx.globalAlpha=1;
    }
    // Orb — PERF: createRadialGradient only at quality 2 (was quality>=1 — costly every frame)
    if(_qualityLevel>=2){ctx.shadowColor=p.color;ctx.shadowBlur=12;}
    if(_qualityLevel>=2){
      const pg=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.r);
      pg.addColorStop(0,'rgba(255,255,255,0.9)');pg.addColorStop(0.4,p.color);pg.addColorStop(1,'rgba(0,0,0,0)');
      ctx.fillStyle=pg;
    } else { ctx.fillStyle=p.color; }
    ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill();
    if(_qualityLevel>=2) ctx.shadowBlur=0;
  }
  ctx.restore();
}

// ============================================================
// ARMOR DROP SYSTEM
// ============================================================
function spawnArmorDrop(x,y){
  if (armorDrops.length >= 20) return; // cap: prevent heavy kill-burst overflow
  armorDrops.push({x:x+(Math.random()-0.5)*30,y:y+(Math.random()-0.5)*30,life:360,r:10});
}
function updateArmorDrops(){
  for(let i=armorDrops.length-1;i>=0;i--){
    const a=armorDrops[i];
    a.life--;
    const dx = player.x - a.x, dy = player.y - a.y;
    const collectR = player.radius + a.r + 8;
    if(Math.abs(dx) > collectR || Math.abs(dy) > collectR) continue;
    if(Math.hypot(dx,dy)<collectR){
      const gain=0.08; player.armorBonus=Math.min(0.5,(player.armorBonus||0)+gain);
      floatingTexts.push({x:a.x,y:a.y-25,text:`🛡️ ZIRH +${Math.round(gain*100)}%`,alpha:1,life:55,color:'#88ccff'});
      playSound(660,0.1,'triangle',0.18);
      for(let k=0;k<10;k++) _spawnParticle(a.x,a.y,(Math.random()-0.5)*7,Math.random()*-6-1,3+Math.random()*3,20,'#88ccff');
      armorDrops[i]=armorDrops[armorDrops.length-1]; armorDrops.pop();
    } else if(a.life<=0) armorDrops[i]=armorDrops[armorDrops.length-1]; armorDrops.pop();
  }
}
function drawArmorDrops(){
  for(let _adi=0;_adi<armorDrops.length;_adi++){const a=armorDrops[_adi];
    const pulse=0.85+Math.sin(globalTime*0.14)*0.15;
    const fadeAlpha=Math.min(1,a.life/60);
    ctx.save();ctx.globalAlpha=fadeAlpha;
    if(_qualityLevel>=2){ctx.shadowColor='#88ccff';ctx.shadowBlur=14;}
    ctx.fillStyle='#88ccff';ctx.strokeStyle='#004488';ctx.lineWidth=2;
    ctx.beginPath();ctx.arc(a.x,a.y,a.r*pulse,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle='rgba(255,255,255,0.9)';ctx.font='bold 11px Arial';ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillText('🛡',a.x,a.y+1);
    ctx.restore();
  }
}

// ============================================================
// BIOME AMBIENT PARTICLES
// ============================================================
const _BIOME_AMBIENT = {
  forest:     { color:['#44aa22','#88cc44','#228822'], shape:'leaf',  rate:4, spd:0.6 },
  winter:     { color:['#ffffff','#ccddff','#eeeeff'], shape:'snow',  rate:5, spd:0.4 },
  lava:       { color:['#ff8a1a','#ff5a00','#aa2200'], shape:'ash',   rate:3, spd:0.5 },
  desert:     { color:['#ddaa44','#ccaa22','#bbaa55'], shape:'sand',  rate:6, spd:0.9 },
};
function updateAmbientParticles(){
  // Spawn based on player biome — throttle at lower quality levels
  const bDef=_BIOME_AMBIENT[playerBiome];
  const _ambRate=_qualityLevel===0?0:_qualityLevel===1?0.20:1.0;
  if(_ambRate===0){ambientParticles.length=0;return;}
  if(bDef&&Math.random()<_ambRate/bDef.rate){
    const ex=(Math.random()-0.5)*canvas.width/ZOOM;
    const ey=(Math.random()-0.5)*canvas.height/ZOOM;
    const wx=camX+ex, wy=camY+ey;
    const col=bDef.color[Math.floor(Math.random()*bDef.color.length)];
    const baseVx=(playerBiome==='desert'?bDef.spd*(0.5+Math.random()*0.8):((Math.random()-0.5)*bDef.spd));
    // PERF: reuse from pre-allocated pool — zero GC pressure (was new {} every spawn)
    const _apObj=_apFreePool.length?_apFreePool.pop():{x:0,y:0,vx:0,vy:0,life:0,maxLife:320,color:'#fff',shape:'ash',r:3,angle:0,spin:0};
    _apObj.x=wx; _apObj.y=wy; _apObj.vx=baseVx; _apObj.vy=bDef.spd*(0.4+Math.random()*0.6);
    _apObj.life=200+Math.random()*120; _apObj.maxLife=320; _apObj.color=col;
    _apObj.shape=bDef.shape; _apObj.r=2+Math.random()*3;
    _apObj.angle=Math.random()*Math.PI*2; _apObj.spin=(Math.random()-0.5)*0.08;
    ambientParticles.push(_apObj);
  }
  // Cap ambient particles — return extras to pool before truncation
  // PERF: Reduced caps for better performance
  const _aCap = _qualityLevel === 0 ? 0 : _qualityLevel === 1 ? 6 : 20;
  if (ambientParticles.length > _aCap) {
    for(let _ci=_aCap;_ci<ambientParticles.length;_ci++) _apFreePool.push(ambientParticles[_ci]);
    ambientParticles.length = _aCap;
  }
  for(let i=ambientParticles.length-1;i>=0;i--){
    const p=ambientParticles[i];
    p.x+=p.vx; p.y+=p.vy; p.angle+=p.spin; p.life--;
    if(p.life<=0){ _apFreePool.push(ambientParticles[i]); ambientParticles[i]=ambientParticles[ambientParticles.length-1]; ambientParticles.pop(); }
  }
}
function drawAmbientParticles(){
  if(!ambientParticles.length) return;
  // PERF: no per-call object allocation — iterate the array directly 3 times
  // (ash / spore / complex pass) instead of creating ashByColor={}, sporeByColor={},
  // complex=[] and calling Object.entries() every frame. Array sizes are tiny (≤32).

  // Pass 1: ash circles — no save/restore needed
  let _apLastCol = null;
  for(let _api=0;_api<ambientParticles.length;_api++){
    const p=ambientParticles[_api];
    if(p.shape!=='ash'||p.x<_renderCullL||p.x>_renderCullR||p.y<_renderCullT||p.y>_renderCullB) continue;
    if(p.color!==_apLastCol){ ctx.fillStyle=p.color; _apLastCol=p.color; }
    ctx.globalAlpha=Math.min(1,p.life/60)*0.455;
    ctx.beginPath(); ctx.arc(p.x,p.y,p.r*0.6,0,Math.PI*2); ctx.fill();
  }

  // Pass 2: spore circles (glow at quality 2)
  if(_qualityLevel>=2) ctx.shadowBlur=6;
  _apLastCol=null;
  for(let _api=0;_api<ambientParticles.length;_api++){
    const p=ambientParticles[_api];
    if(p.shape!=='spore'||p.x<_renderCullL||p.x>_renderCullR||p.y<_renderCullT||p.y>_renderCullB) continue;
    if(p.color!==_apLastCol){
      ctx.fillStyle=p.color;
      if(_qualityLevel>=2) ctx.shadowColor=p.color;
      _apLastCol=p.color;
    }
    ctx.globalAlpha=Math.min(1,p.life/60)*0.52;
    ctx.beginPath(); ctx.arc(p.x,p.y,p.r*0.55,0,Math.PI*2); ctx.fill();
  }
  if(_qualityLevel>=2) ctx.shadowBlur=0;

  // Pass 3: complex shapes (leaf, snow, other) — still need rotate
  for(let _api=0;_api<ambientParticles.length;_api++){
    const p=ambientParticles[_api];
    if(p.shape==='ash'||p.shape==='spore'||p.x<_renderCullL||p.x>_renderCullR||p.y<_renderCullT||p.y>_renderCullB) continue;
    const al=Math.min(1,p.life/60)*0.65;
    ctx.save(); ctx.globalAlpha=al; ctx.fillStyle=p.color; ctx.strokeStyle='rgba(0,0,0,0.2)'; ctx.lineWidth=0.5;
    ctx.translate(p.x,p.y); ctx.rotate(p.angle);
    if(p.shape==='leaf'){
      ctx.beginPath();ctx.ellipse(0,0,p.r*1.8,p.r*0.9,0,0,Math.PI*2);ctx.fill();ctx.stroke();
      ctx.strokeStyle=p.color+'88';ctx.lineWidth=0.4;ctx.beginPath();ctx.moveTo(-p.r,0);ctx.lineTo(p.r,0);ctx.stroke();
    } else if(p.shape==='snow'){
      ctx.fillStyle='rgba(220,235,255,0.88)';ctx.beginPath();ctx.arc(0,0,p.r*0.85,0,Math.PI*2);ctx.fill();
      ctx.strokeStyle='rgba(200,220,255,0.5)';ctx.lineWidth=0.6;ctx.stroke();
    } else {
      ctx.globalAlpha=al*0.5;ctx.fillStyle=p.color;ctx.beginPath();ctx.ellipse(0,0,p.r*1.2,p.r*0.6,0,0,Math.PI*2);ctx.fill();
    }
    ctx.restore();
  }
  ctx.globalAlpha=1;
}

// ============================================================
// LEVEL-UP RING + LOW-HP VIGNETTE DRAW
// ============================================================
function drawLevelUpRings(){
  _lvlRings.forEach((r,i)=>{
    r.r+=7; r.alpha=Math.max(0,1-r.r/r.maxR);
    ctx.save();
    ctx.globalAlpha=r.alpha*0.75;
    ctx.strokeStyle=r.color; ctx.lineWidth=4;
    if(_qualityLevel>=2){ctx.shadowColor=r.color; ctx.shadowBlur=16;}
    ctx.beginPath(); ctx.arc(player.x,player.y,r.r,0,Math.PI*2); ctx.stroke();
    ctx.restore();
  });
  // swap-delete: O(1) per removal, no GC alloc (filter yerine)
  for(let _lri=_lvlRings.length-1;_lri>=0;_lri--){if(_lvlRings[_lri].alpha<=0){_lvlRings[_lri]=_lvlRings[_lvlRings.length-1];_lvlRings.pop();}}
}
// PERF: cache low-HP vignette gradient — recreate only on resize, not every frame
let _lpVigGrd=null, _lpVigW=-1, _lpVigH=-1;
function drawLowHpVignette(){
  const pct=player.hp/player.maxHp;
  if(pct>0.25)return; // only trigger at <25% HP (was 40% — too aggressive)
  const intensity=(1-pct/0.25)*0.4; // max alpha 0.4 (was 0.7*0.8=0.56)
  const pulse=0.8+Math.sin(_nowMs*0.004)*0.2; // subtle pulse
  if(!_lpVigGrd||_lpVigW!==canvas.width||_lpVigH!==canvas.height){
    _lpVigGrd=ctx.createRadialGradient(canvas.width/2,canvas.height/2,canvas.height*0.3,canvas.width/2,canvas.height/2,canvas.height*0.9);
    _lpVigGrd.addColorStop(0,'rgba(0,0,0,0)');
    _lpVigGrd.addColorStop(1,'rgba(160,0,0,1)');
    _lpVigW=canvas.width; _lpVigH=canvas.height;
  }
  ctx.save(); ctx.setTransform(1,0,0,1,0,0);
  ctx.globalAlpha=intensity*pulse;
  ctx.fillStyle=_lpVigGrd; ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.restore();
}

// ============================================================
// CAMPFIRE UPDATE (HP regen aura)
// ============================================================
// _campfires[] — buildings.forEach(type===10) yerine bu listeyi kullan (O(1) per frame)
// buildings push/splice ile senkronize tutulur
let _campfires = [];
function updateCampfires(){
  for(let _cfi=0;_cfi<_campfires.length;_cfi++){const b=_campfires[_cfi];
    if(b.hp<=0)continue;
    const dx = player.x - b.x, dy = player.y - b.y;
    if (Math.abs(dx) > 180 || Math.abs(dy) > 180) continue;
    const dist=Math.hypot(dx,dy);
    if(dist<180){
      if(!b._healTimer)b._healTimer=0;
      b._healTimer--;
      if(b._healTimer<=0&&player.hp<player.maxHp){
        b._healTimer=90;
        const heal=Math.min(3,player.maxHp-player.hp);
        player.hp+=heal; updateHpBar();
        floatingTexts.push({x:player.x,y:player.y-38,text:'+'+heal+' 🔥',alpha:1,life:30,color:'#ff8844'});
      }
      // Emit fire particles
      if(_qualityLevel>=1&&Math.random()<0.12) _spawnParticle(b.x+(Math.random()-0.5)*12,b.y+(Math.random()-0.5)*8,(Math.random()-0.5)*1.5,-1.2-Math.random()*2,2+Math.random()*3,20+Math.random()*15,Math.random()<0.5?'#ff8800':'#ffcc00');
    }
  }
}
function spawnGoldBurst(x,y){
  const n = _qualityLevel === 0 ? 1 : _qualityLevel === 1 ? 5 : 12;
  for(let i=0;i<n;i++) _spawnParticle(x,y,(Math.random()-0.5)*12,Math.random()*-12-3,3+Math.random()*4,35,'#ffd700');
}
function updateParticles(){
  // Hard cap enforced at spawn; trim excess (safety net)
  const _pCap=_qualityLevel===0?6:_qualityLevel===1?18:50;
  if(particles.length>_pCap){
    // Return excess to pool
    for(let _ei=_pCap;_ei<particles.length;_ei++) if(_pFreePool.length<_P_POOL_SZ) _pFreePool.push(particles[_ei]);
    particles.length=_pCap;
  }
  for(let i=particles.length-1;i>=0;i--){
    const p=particles[i]; p.x+=p.vx; p.y+=p.vy; p.vx*=0.87; p.vy+=0.55; p.life--;
    if(p.life<=0){
      // Return to pool instead of letting it become garbage
      if(_pFreePool.length<_P_POOL_SZ) _pFreePool.push(p);
      particles[i]=particles[particles.length-1]; particles.pop();
    }
  }
}
function drawParticles(){
  if (particles.length === 0) return;
  // No per-frame sort — removing O(N²) insertion sort eliminates frame spikes on blood/kill bursts.
  // fillStyle changes are cheap; sorting 50 particles every 16ms was not.
  var _dLastColor = null, _dLastAlpha10 = -1;
  ctx.beginPath();
  for (var _dpi = 0; _dpi < particles.length; _dpi++) {
    var _dp = particles[_dpi];
    var _dpa = _dp.life / _dp.maxLife;
    var _dpa10 = _dpa * 10 | 0;
    if (_dp.color !== _dLastColor || _dpa10 !== _dLastAlpha10) {
      if (_dLastColor !== null) { ctx.fill(); ctx.beginPath(); }
      ctx.globalAlpha = _dpa;
      ctx.fillStyle = _dp.color;
      _dLastColor = _dp.color; _dLastAlpha10 = _dpa10;
    }
    ctx.moveTo(_dp.x + _dp.r, _dp.y); ctx.arc(_dp.x, _dp.y, _dp.r, 0, Math.PI * 2);
  }
  if (_dLastColor !== null) ctx.fill();
  ctx.globalAlpha = 1;
}

// ============================================================
// SOUND EFFECTS — Rich Web Audio API Synthesis Engine
// ============================================================
let _audio=null;
function _tryInitAudio(){ if(!_audio){ try{_audio=new(window.AudioContext||window.webkitAudioContext)();}catch(e){} } if(_audio&&_audio.state==='suspended') _audio.resume(); }

// Pre-cached noise buffers keyed by quantized duration bucket (100ms steps).
// _mkNoise previously created a new AudioBuffer on every sound call — huge GC pressure.
var _noiseCache={};
function _mkNoise(sec){
  var bucket=(Math.min(sec,1.2)*10|0)/10;
  var cached=_noiseCache[bucket];
  if(cached&&_audio&&cached._sr===_audio.sampleRate) return cached;
  var len=Math.ceil(_audio.sampleRate*Math.max(bucket,0.05));
  var b=_audio.createBuffer(1,len,_audio.sampleRate);
  var d=b.getChannelData(0);
  for(var _ni=0;_ni<len;_ni++) d[_ni]=Math.random()*2-1;
  if(_audio){b._sr=_audio.sampleRate;_noiseCache[bucket]=b;}
  return b;
}

// Per-category sound rate limiter: same sound type+frequency bucket fires at most once per 38ms.
// Prevents audio GC spike when 10+ enemies die in one frame.
var _sndThrottle={};
var _activeAudioVoices = 0;
const MAX_ACTIVE_VOICES = 10;
function playSound(freq,dur,type,vol){
  if(!_audio||_audio.state!=='running'||_sfxMuted) return;
  if(_activeAudioVoices >= MAX_ACTIVE_VOICES) return;
  _activeAudioVoices++;
  setTimeout(function(){ if(_activeAudioVoices > 0) _activeAudioVoices--; }, Math.min(Math.round((dur||0.1)*1000)+30, 800));
  // Use frequency BUCKETS for the throttle key so rapid hits at random pitches
  // (e.g. 220–320 Hz mob hits) all share one slot instead of each bypassing
  // the throttle independently and creating 12+ audio nodes per frame.
  var _sndBucket = freq < 160 ? 'lo' : freq < 400 ? 'mid' : freq < 800 ? 'hi' : 'vhi';
  var _sndKey = type + '|' + _sndBucket;
  var _sndNow=_audio.currentTime;
  // Mobile gets a slightly wider window (65ms) to prevent node pile-up during rapid hits.
  var _sndGap = _isMobile ? 0.065 : 0.038;
  if(_sndThrottle[_sndKey]&&_sndNow-_sndThrottle[_sndKey]<_sndGap) return;
  _sndThrottle[_sndKey]=_sndNow;
  const t=_audio.currentTime, v=Math.min((vol||0.15),0.9);
  try{
    if(type==='sawtooth' && freq<130){
      // ── Boss / Death / Heavy Rumble ──────────────────────
      const o=_audio.createOscillator(),g=_audio.createGain(),lp=_audio.createBiquadFilter();
      o.type='sawtooth'; o.frequency.setValueAtTime(freq,t); o.frequency.exponentialRampToValueAtTime(Math.max(18,freq*0.4),t+dur);
      lp.type='lowpass'; lp.frequency.value=600;
      g.gain.setValueAtTime(v*5.5,t); g.gain.exponentialRampToValueAtTime(0.001,t+dur);
      o.connect(lp); lp.connect(g); g.connect(_audio.destination); o.start(t); o.stop(t+dur+0.05);
      const o2=_audio.createOscillator(),g2=_audio.createGain();
      o2.type='sine'; o2.frequency.setValueAtTime(freq*0.52,t); o2.frequency.exponentialRampToValueAtTime(18,t+dur*0.85);
      g2.gain.setValueAtTime(v*4.5,t); g2.gain.exponentialRampToValueAtTime(0.001,t+dur*0.87);
      o2.connect(g2); g2.connect(_audio.destination); o2.start(t); o2.stop(t+dur*0.9);
      const src=_audio.createBufferSource(); src.buffer=_mkNoise(Math.min(dur,1.0));
      const bp=_audio.createBiquadFilter(); bp.type='bandpass'; bp.frequency.value=320; bp.Q.value=1.2;
      const g3=_audio.createGain(); g3.gain.setValueAtTime(v*3,t); g3.gain.exponentialRampToValueAtTime(0.001,t+Math.min(dur,1.0));
      src.connect(bp); bp.connect(g3); g3.connect(_audio.destination); src.start(t);
    } else if(type==='sawtooth'){
      // ── Swoosh / Arrow / Fast ────────────────────────────
      const src=_audio.createBufferSource(); src.buffer=_mkNoise(dur+0.05);
      const hp=_audio.createBiquadFilter(); hp.type='highpass';
      hp.frequency.setValueAtTime(freq*0.9,t); hp.frequency.exponentialRampToValueAtTime(freq*7,t+dur);
      const g=_audio.createGain(); g.gain.setValueAtTime(v*3,t); g.gain.exponentialRampToValueAtTime(0.001,t+dur);
      src.connect(hp); hp.connect(g); g.connect(_audio.destination); src.start(t);
      const o=_audio.createOscillator(),og=_audio.createGain(),lp=_audio.createBiquadFilter();
      o.type='sawtooth'; lp.type='lowpass'; lp.frequency.value=1800;
      o.frequency.setValueAtTime(freq,t); o.frequency.exponentialRampToValueAtTime(freq*2.2,t+dur);
      og.gain.setValueAtTime(v*1.8,t); og.gain.exponentialRampToValueAtTime(0.001,t+dur);
      o.connect(lp); lp.connect(og); og.connect(_audio.destination); o.start(t); o.stop(t+dur+0.02);
    } else if(type==='square' && freq<160){
      // ── Low Impact / Mob Hit / Punch ─────────────────────
      const src=_audio.createBufferSource(); src.buffer=_mkNoise(dur+0.05);
      const lp=_audio.createBiquadFilter(); lp.type='lowpass';
      lp.frequency.setValueAtTime(2200,t); lp.frequency.exponentialRampToValueAtTime(380,t+dur);
      const g=_audio.createGain(); g.gain.setValueAtTime(v*4.5,t); g.gain.exponentialRampToValueAtTime(0.001,t+dur);
      src.connect(lp); lp.connect(g); g.connect(_audio.destination); src.start(t);
      const o=_audio.createOscillator(),og=_audio.createGain();
      o.type='sine'; o.frequency.setValueAtTime(freq,t); o.frequency.exponentialRampToValueAtTime(freq*0.38,t+dur);
      og.gain.setValueAtTime(v*4,t); og.gain.exponentialRampToValueAtTime(0.001,t+dur);
      o.connect(og); og.connect(_audio.destination); o.start(t); o.stop(t+dur+0.02);
    } else if(type==='square'){
      // ── Mid Hit / Chop / Impact ──────────────────────────
      const src=_audio.createBufferSource(); src.buffer=_mkNoise(dur+0.04);
      const bp=_audio.createBiquadFilter(); bp.type='bandpass'; bp.frequency.value=freq*1.6; bp.Q.value=2.2;
      const g=_audio.createGain(); g.gain.setValueAtTime(v*4,t); g.gain.exponentialRampToValueAtTime(0.001,t+dur);
      src.connect(bp); bp.connect(g); g.connect(_audio.destination); src.start(t);
      const o=_audio.createOscillator(),og=_audio.createGain(),lp=_audio.createBiquadFilter();
      o.type='square'; lp.type='lowpass'; lp.frequency.value=1100;
      o.frequency.setValueAtTime(freq,t); o.frequency.exponentialRampToValueAtTime(freq*0.3,t+dur);
      og.gain.setValueAtTime(v*3,t); og.gain.exponentialRampToValueAtTime(0.001,t+dur);
      o.connect(lp); lp.connect(og); og.connect(_audio.destination); o.start(t); o.stop(t+dur+0.02);
    } else if(type==='triangle'){
      // ── Weapon / Upgrade / Milestone ─────────────────────
      const o=_audio.createOscillator(),g=_audio.createGain();
      o.type='triangle';
      o.frequency.setValueAtTime(freq,t); o.frequency.linearRampToValueAtTime(freq*1.12,t+dur*0.08); o.frequency.exponentialRampToValueAtTime(freq*0.72,t+dur);
      g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(v*3.8,t+0.012); g.gain.exponentialRampToValueAtTime(0.001,t+dur);
      o.connect(g); g.connect(_audio.destination); o.start(t); o.stop(t+dur+0.02);
      const o2=_audio.createOscillator(),g2=_audio.createGain();
      o2.type='sine'; o2.frequency.value=freq*2.08;
      g2.gain.setValueAtTime(v*1.4,t+0.01); g2.gain.exponentialRampToValueAtTime(0.001,t+dur*0.55);
      o2.connect(g2); g2.connect(_audio.destination); o2.start(t+0.01); o2.stop(t+dur*0.6);
    } else {
      // ── Sine — Collect / Chime / Pleasant ────────────────
      const o=_audio.createOscillator(),g=_audio.createGain();
      o.type='sine';
      o.frequency.setValueAtTime(freq,t); o.frequency.linearRampToValueAtTime(freq*1.06,t+dur*0.07); o.frequency.exponentialRampToValueAtTime(freq*0.9,t+dur);
      g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(v*4,t+0.01); g.gain.exponentialRampToValueAtTime(0.001,t+dur);
      o.connect(g); g.connect(_audio.destination); o.start(t); o.stop(t+dur+0.02);
      const o2=_audio.createOscillator(),g2=_audio.createGain();
      o2.type='sine'; o2.frequency.value=freq*1.5;
      g2.gain.setValueAtTime(v*1.6,t+0.008); g2.gain.exponentialRampToValueAtTime(0.001,t+dur*0.52);
      o2.connect(g2); g2.connect(_audio.destination); o2.start(t+0.008); o2.stop(t+dur*0.58);
    }
  }catch(e){}
}

// ============================================================
// KILL STREAK
// ============================================================
let killStreak=0, lastKillMs=0, streakFade=0;

// ── Multi-kill / milestone system ──────────────────────────────────────────
const _MULTI_KILL_LABELS = [
  null, null,
  { label:'DOUBLE KILL!',  color:'#ffdd00', flash:'rgba(255,210,0,0.18)',   sound:880, size:0.068 },
  { label:'TRIPLE KILL!',  color:'#ff8c00', flash:'rgba(255,100,0,0.20)',   sound:990, size:0.072 },
  { label:'QUADRA KILL!',  color:'#ff4400', flash:'rgba(255,40,0,0.24)',    sound:1100,size:0.076 },
  { label:'PENTA KILL!',   color:'#ff00ff', flash:'rgba(220,0,255,0.28)',   sound:1320,size:0.082 },
  { label:'ULTRA KILL!!',  color:'#00ffff', flash:'rgba(0,220,255,0.30)',   sound:1560,size:0.088 },
  { label:'M-M-MONSTER!', color:'#ff0000', flash:'rgba(255,0,0,0.35)',     sound:1760,size:0.095 },
];
const _STREAK_LABELS = [
  { at:3,  label:'🔥 İLK KAN!',      color:'#ff6600' },
  { at:5,  label:'🔥 RAMPAGE!',      color:'#ff4400' },
  { at:7,  label:'⚡ DOMİNATİNG!',   color:'#ff2200' },
  { at:10, label:'💀 UNSTOPPABLE!',  color:'#ff0000' },
  { at:15, label:'👑 TANRISAL!',     color:'#ffd700' },
  { at:20, label:'☠️ EFSANE!',       color:'#ff00ff' },
];

let _multiKillCount=0, _multiKillTimer=0;
let _milestoneLabel='', _milestoneFade=0, _milestoneColor='#fff', _milestoneFlash='', _milestoneSize=0.07;
let _milestoneOC=null, _milestoneOC_label='', _milestoneOC_sz=0;
let _streakMilestones=new Set();
let _dmgFlashTimer=0; // screen-flash counter (set by recordKill)

let _lastKillTimestamp = 0;
function recordKill(){
  const now=Date.now();
  if(now - _lastKillTimestamp < 150) return; // Prevent duplicate trigger in the same tick
  _lastKillTimestamp = now;
  if(now-lastKillMs<5000) killStreak++;
  else { killStreak=1; _streakMilestones.clear(); }
  lastKillMs=now; streakFade=220;
  // Mission tracking: m1 (5 kills), m4 (10 kills)
  _trackMission('m1', 1);
  _trackMission('m4', 1);
  window._updateQuestProgress('kills', 1);

}

// Streak metni OC önbelleği — emoji strokeText her frame yerine bir kez pişirilir
let _streakOC = null, _streakOC_n = -1, _streakOC_w = 0;
function drawStreakOverlay() {
  if (false && streakFade > 0 && killStreak >= 2) {
    streakFade--;
    const a = Math.min(1, streakFade / 60) * 0.95;
    ctx.save();
    const _sFs = Math.max(16, Math.floor(canvas.width * 0.038));
    ctx.font = 'bold ' + _sFs + 'px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.globalAlpha = a;
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 5;
    const _stText = '🔥 ' + killStreak + '× KILLSTREAK';
    const _sy = Math.floor(canvas.height * 0.12);
    ctx.strokeText(_stText, canvas.width / 2, _sy);
    ctx.fillStyle = '#ff6600';
    ctx.fillText(_stText, canvas.width / 2, _sy);
    ctx.restore();
  }
  if (_milestoneFade <= 0) return;
  _milestoneFade--;
  const pct = _milestoneFade / 160;
  const scl = 1 + Math.sin(pct * Math.PI) * 0.28;
  const a = Math.min(1, pct * 4) * Math.min(1, (1 - pct) * 5.5);
  if (a <= 0) return;
  const fs = Math.max(20, Math.floor(canvas.width * _milestoneSize));
  if (_milestoneOC_label !== _milestoneLabel || _milestoneOC_sz !== fs) {
    _milestoneOC_label = _milestoneLabel; _milestoneOC_sz = fs;
    const _mpad = Math.ceil(fs * 1.8);
    _milestoneOC = createRenderCanvas(Math.ceil(canvas.width) + _mpad * 2, Math.ceil(fs * 2) + _mpad * 2);
    const _moc = _milestoneOC.getContext('2d');
    _moc.font = `900 ${fs}px Arial`; _moc.textAlign = 'center'; _moc.textBaseline = 'middle';
    _moc.shadowColor = _milestoneColor; _moc.shadowBlur = 32;
    _moc.strokeStyle = '#000'; _moc.lineWidth = fs * 0.22;
    _moc.strokeText(_milestoneLabel, _milestoneOC.width / 2, _milestoneOC.height / 2);
    _moc.fillStyle = _milestoneColor; _moc.fillText(_milestoneLabel, _milestoneOC.width / 2, _milestoneOC.height / 2);
  }
  ctx.save();
  ctx.globalAlpha = a;
  ctx.translate(canvas.width / 2, canvas.height * 0.38);
  ctx.scale(scl, scl);
  if (_milestoneOC) ctx.drawImage(_milestoneOC, -_milestoneOC.width / 2, -_milestoneOC.height / 2);
  ctx.restore();
}

// ============================================================
// DAY / NIGHT CYCLE
// ============================================================

function drawNightOverlay(){
  // PERF: draw sun to a 78×78 OffscreenCanvas once, blit every frame.
  // Eliminates shadowBlur=22 setup cost on the main canvas each frame.
  if(!_sunOC){
    _sunOC=createRenderCanvas(78,78);
    const _sc=_sunOC.getContext('2d');
    _sc.fillStyle='#ffe066';
    if(_qualityLevel>=2){ _sc.shadowColor='#ffcc00'; _sc.shadowBlur=22; }
    _sc.beginPath(); _sc.arc(39,39,17,0,Math.PI*2); _sc.fill();
  }
  const sx=canvas.width*0.88-39, sy=canvas.height*0.1-39;
  ctx.drawImage(_sunOC, sx, sy);
}

// ============================================================
// RAIN WEATHER
// ============================================================
let _rain=[],_raining=false,_rT=0,_rCd=1500+Math.random()*1200;
function updateRain(){ return; }
// PERF: rain alpha buckets pre-allocated once — zero object allocation during drawRain
const _RAIN_BUCKETS = (function(){
  const b=[];
  for(let i=0;i<11;i++) b.push({al:0,d:[]});
  return b;
})();
function drawRain(){
  if(!_raining) return;
  ctx.save(); ctx.strokeStyle='#99ccff'; ctx.lineWidth=1;
  // Reset bucket arrays (reuse same arrays, no new {})
  for(let _bi=0;_bi<11;_bi++) _RAIN_BUCKETS[_bi].d.length=0;
  for(let _ri=0;_ri<_rain.length;_ri++){
    const r=_rain[_ri];
    const k=r.al*10|0;
    if(_RAIN_BUCKETS[k].d.length===0) _RAIN_BUCKETS[k].al=r.al;
    _RAIN_BUCKETS[k].d.push(r);
  }
  for(let _bi=0;_bi<11;_bi++){
    const g=_RAIN_BUCKETS[_bi];
    if(g.d.length===0) continue;
    ctx.globalAlpha=g.al;
    ctx.beginPath();
    for(let _ri=0;_ri<g.d.length;_ri++){
      const r=g.d[_ri];
      ctx.moveTo(r.x,r.y); ctx.lineTo(r.x-r.spd*0.18,r.y-r.len);
    }
    ctx.stroke();
  }
  ctx.globalAlpha=1; ctx.restore();
}

const _bossBarEl=document.getElementById('boss-bar');
const _bossBarFill=document.getElementById('boss-bar-fill');
const _bossBarHpText=document.getElementById('boss-bar-hp-text');
// Server-spawned boss mob tracking
let _serverBossId = null;
let _serverBossName = '';
let _serverBossMaxHp = 1;
function _updateServerBossBar(hp, maxHp) {
  if (!_bossBarEl) return;
  if (maxHp > 0) _serverBossMaxHp = maxHp;
  const pct = Math.max(0, Math.min(1, hp / _serverBossMaxHp));
  if (_bossBarFill) _bossBarFill.style.width = (pct * 100) + '%';
  if (_bossBarHpText) _bossBarHpText.textContent = _serverBossName + '  ' + Math.ceil(hp) + ' / ' + Math.ceil(_serverBossMaxHp) + ' HP';
  _bossBarEl.style.display = '';
}
function _hideServerBossBar() {
  _serverBossId = null; _serverBossName = ''; _serverBossMaxHp = 1;
  if (_bossBarEl) _bossBarEl.style.display = 'none';
}
// UI UPDATES
// ============================================================
const _hpFill = document.getElementById('hp-bar-fill');
const _hpText = document.getElementById('hp-text');
// Cached DOM references for hot-path UI updates (set on first call)
let _uiAppleEl = null, _uiWoodEl = null, _uiStoneEl = null, _uiGoldEl = null, _uiScoreEl = null;
// Last-written values — skip DOM write when nothing changed
let _uiLast = { apples: -1, wood: -1, stone: -1, gold: -1, score: -1 };
let _lastScoreSync = null, _lastWoodSync = null, _lastStoneSync = null, _lastGoldSync = null, _lastAppleSync = null;
// Cached DOM references for ultra-fast zero-query HUD updates
let _domWood = null, _domStone = null, _domGold = null, _domApple = null, _domKills = null, _domScore = null;
let _domHpBar = null, _domHpText = null, _domXpBar = null, _domXpText = null;
function _initDomCache() {
  _domWood = document.getElementById('wood-count');
  _domStone = document.getElementById('stone-count');
  _domGold = document.getElementById('gold-count');
  _domApple = document.getElementById('apple-count');
  _domKills = document.getElementById('kill-count');
  _domScore = document.getElementById('score-count');
  _domHpBar = document.getElementById('hp-bar-fill');
  _domHpText = document.getElementById('hp-text');
  _domXpBar = document.getElementById('xp-fill') || document.getElementById('xp-bar-fill');
  _domXpText = document.getElementById('age-text') || document.getElementById('xp-text');
}
function updateUI() {
  if (!_uiAppleEl) {
    _uiAppleEl = document.getElementById('apple-count');
    _uiWoodEl  = document.getElementById('wood-count');
    _uiStoneEl = document.getElementById('stone-count');
    _uiGoldEl  = document.getElementById('gold-count');
    _uiScoreEl = document.getElementById('score-count');
  }
  const curA = String(player.apples ?? 0);
  const curW = String(player.wood ?? 0);
  const curS = String(player.stone ?? 0);
  const curG = String(player.gold ?? 0);
  const curSc = player.score ?? 0;

  if (_uiAppleEl && _uiAppleEl.textContent !== curA) _uiAppleEl.textContent = curA;
  if (_uiWoodEl  && _uiWoodEl.textContent  !== curW) _uiWoodEl.textContent  = curW;
  if (_uiStoneEl && _uiStoneEl.textContent !== curS) _uiStoneEl.textContent = curS;
  if (_uiGoldEl  && _uiGoldEl.textContent  !== curG) _uiGoldEl.textContent  = curG;
  
  const foodBadge = document.getElementById('food-count-badge');
  if (foodBadge && foodBadge.textContent !== curA) foodBadge.textContent = curA;
  const mobAppleCount = document.getElementById('mobile-apple-count');
  if (mobAppleCount && mobAppleCount.textContent !== curA) mobAppleCount.textContent = curA;
  if (_uiScoreEl && curSc !== _uiLast.score) {
    _uiScoreEl.textContent = formatScore(curSc);
    _uiLast.score = curSc;
  }
  if (_connected && _socket) {
    _lastScoreSync = curSc;
    _lastWoodSync = player.wood;
    _lastStoneSync = player.stone;
    _lastGoldSync = player.gold;
    _lastAppleSync = player.apples;
  }

  // Update building count limit badges in hotbar (slots 3-9) with dirty check
  if (!_bldBadgeEls) {
    _bldBadgeEls = {};
    _bldLastCounts = {};
    for (let _b = 3; _b <= 9; _b++) {
      _bldBadgeEls[_b] = document.getElementById('bld-cnt-' + _b);
      _bldLastCounts[_b] = -1;
    }
  }
  for (let _bType = 3; _bType <= 9; _bType++) {
    const _badgeEl = _bldBadgeEls[_bType] || document.getElementById('bld-cnt-' + _bType);
    if (_badgeEl) {
      const _lim = BUILD_LIMITS[_bType] || 25;
      const _cnt = getPlayerBuildingCount(_bType);
      const _txt = _cnt + '/' + _lim;
      if (_badgeEl.textContent !== _txt) {
        _badgeEl.textContent = _txt;
        if (_cnt >= _lim) _badgeEl.classList.add('at-limit');
        else _badgeEl.classList.remove('at-limit');
      }
    }
  }
}
let _bldBadgeEls = null, _bldLastCounts = null;
// Cached HP values — updateHpBar is called every frame, skip DOM write when nothing changed
// PERF: Batch DOM updates and throttle to every 3 frames for better performance
let _hpLast = { hp: -1, maxHp: -1, band: -1 };
let _hpUpdateCounter = 0;
function updateHpBar() {
  _hpUpdateCounter++;
  if (_hpUpdateCounter < 3) return; // Throttle to every 3 frames
  _hpUpdateCounter = 0;
  
  const pct = Math.max(0, player.hp / player.maxHp * 100);
  const band = pct > 55 ? 2 : pct > 25 ? 1 : 0;
  const hpCeil = Math.ceil(player.hp);
  if (hpCeil === _hpLast.hp && player.maxHp === _hpLast.maxHp && band === _hpLast.band) return;
  _hpLast.hp = hpCeil; _hpLast.maxHp = player.maxHp; _hpLast.band = band;
  _hpFill.style.width = pct + '%';
  // Colour: green → yellow → red, with low-HP class for pulse animation
  if (band === 2) {
    _hpFill.style.background = 'linear-gradient(to right,#18b812,#45e832,#78ff60)';
    _hpFill.classList.remove('low-hp');
  } else if (band === 1) {
    _hpFill.style.background = 'linear-gradient(to right,#c4970a,#f5c430,#ffe080)';
    _hpFill.classList.remove('low-hp');
  } else {
    _hpFill.style.background = '';
    _hpFill.classList.add('low-hp');
  }
  _hpText.textContent = '❤️ ' + hpCeil + '/' + player.maxHp;
}
let _prevAge = 1;
const PERKS = [
  { icon:'🏃', name:'Hız Artışı',       desc:'+20% hareket hızı',        apply:(p)=>{ p.speedBonus  *= 1.20; } },
  { icon:'⚔️', name:'Hasar Artışı',     desc:'+25% saldırı hasarı',      apply:(p)=>{ p.dmgBonus    *= 1.25; } },
  { icon:'❤️', name:'Can Artışı',       desc:'+35 maksimum can',          apply:(p)=>{ p.maxHp+=35; p.hp=Math.min(p.hp+35,p.maxHp); } },
  { icon:'🌲', name:'Usta Toplayıcı',   desc:'+50% kaynak verimi',        apply:(p)=>{ p.harvestBonus*=1.50; } },
  { icon:'🛡️', name:'Zırh',            desc:'%20 az hasar al',           apply:(p)=>{ p.armorBonus =Math.min(0.65,p.armorBonus+0.20); } },
  { icon:'⚡', name:'Hızlı Saldırı',    desc:'+25% saldırı hızı',        apply:(p)=>{ p.atkSpdBonus*=0.75; } },
  { icon:'💚', name:'Yenileme',         desc:'2× HP yenilenme hızı',      apply:(p)=>{ p.regenBonus *=2;    } },
  { icon:'🍎', name:'Doğa Şifacısı',   desc:'+5 elma',                   apply:(p)=>{ p.apples+=5; updateUI(); } },
  { icon:'💰', name:'Hazine Avcısı',   desc:'+20 altın',                 apply:(p)=>{ p.gold+=20; updateUI(); } },
  { icon:'🧛', name:'Vampir',          desc:'Öldürmede +12 HP kazan',    apply:(p)=>{ p.vampire=true; } },
  { icon:'💥', name:'Berserker',       desc:'+35% hasar, -%10 zırh',     apply:(p)=>{ p.dmgBonus*=1.35; p.armorBonus=Math.max(0,p.armorBonus-0.10); } },
  { icon:'🌀', name:'Girdap',          desc:'Saldırı yayı çok genişler',         apply:(p)=>{ p._wideSwing=true; } },
  { icon:'🌑', name:'Dikenli Zırh',   desc:'Hasarın %20\'sini geri yansıt',     apply:(p)=>{ p._thorns=true; } },
  { icon:'⚡', name:'Çift Şarj',      desc:'Dash 2× daha hızlı şarj olur',      apply:(p)=>{ p._doubleDash=true; } },
  { icon:'💢', name:'Patlayan Öfke',  desc:'Öldürmede çevreye hasar ver',       apply:(p)=>{ p._explosiveKills=true; } },
  { icon:'🧊', name:'Buz Aurası',     desc:'Yakın düşmanları %35 yavaşlatır',   apply:(p)=>{ p._frostAura=true; } },
  { icon:'🌿', name:'Yaşam Çalma',    desc:'Her vuruşta +4 HP kazan',           apply:(p)=>{ p._lifeSteal=true; } },
  { icon:'🎯', name:'Keskin Nişancı', desc:'Kritik vuruş şansı %22\'ye çıkar',  apply:(p)=>{ p._highCrit=true; } },
];
const _dmgFlashEl = document.getElementById('dmg-flash');
let _dmgFlashLastMs = 0;
function triggerDmgFlash() {
  if (!_dmgFlashEl) return;
  const _now = Date.now();
  if (_now - _dmgFlashLastMs < 250) return;
  _dmgFlashLastMs = _now;
  // PERF: Remove forced reflow - use animation restart via class toggle without offsetWidth read
  _dmgFlashEl.classList.remove('active');
  requestAnimationFrame(() => {
    _dmgFlashEl.classList.add('active');
  });
}
// ── Upgrade notification system ──────────────────────────────
let _pendingUpgrades = [], _upgPanelOpen = false;

function _refreshUpgBtn(){
  const btn = document.getElementById('upg-notify-btn');
  const badge = document.getElementById('upg-notify-badge');
  if(!btn) return;
  if(_pendingUpgrades.length > 0){
    btn.classList.add('show');
    badge.textContent = _pendingUpgrades.length;
  } else {
    btn.classList.remove('show');
    document.getElementById('upgrade-overlay').classList.remove('show');
    document.getElementById('upg-backdrop').classList.remove('show');
    _upgPanelOpen = false;
  }
}

let _upgPickFns = []; // current card pick functions for keyboard shortcuts

function _skipUpgrade(){
  // Pick a random perk from the current choices so the player still gets a benefit
  if(_upgPickFns.length > 0) _upgPickFns[Math.floor(Math.random()*_upgPickFns.length)]();
}

function _openUpgradePanel(){
  if(_pendingUpgrades.length === 0) return;
  const {age, shuffled} = _pendingUpgrades[0];
  document.getElementById('upgrade-age-num').textContent = age;
  const choices = document.getElementById('upgrade-choices');
  choices.innerHTML = '';
  _upgPickFns = [];
  shuffled.forEach((perk, idx) => {
    const card = document.createElement('div');
    card.className = 'upg-card';
    card.innerHTML = `<div class="upg-card-key">${idx+1}</div><div class="upg-icon">${perk.icon}</div><div class="upg-name">${perk.name}</div><div class="upg-desc">${perk.desc}</div>`;
    const pick = () => {
      perk.apply(player);
      updateHpBar();
      _pendingUpgrades.shift();
      _upgPickFns = [];
      _refreshUpgBtn();
      if(_pendingUpgrades.length > 0){
        setTimeout(_openUpgradePanel, 280);
      }
    };
    _upgPickFns.push(pick);
    card.addEventListener('click', pick);
    card.addEventListener('touchstart', (e) => { e.preventDefault(); pick(); }, { passive: false });
    choices.appendChild(card);
  });
  document.getElementById('upgrade-overlay').classList.add('show');
  document.getElementById('upg-backdrop').classList.add('show');
  _upgPanelOpen = true;
}

// Keyboard shortcuts for upgrade panel: 1/2/3 = pick card, Escape = skip
document.addEventListener('keydown', function(e){
  if (!_upgPanelOpen) return;
  if (e.key === '1' && _upgPickFns[0]) { e.preventDefault(); _upgPickFns[0](); }
  else if (e.key === '2' && _upgPickFns[1]) { e.preventDefault(); _upgPickFns[1](); }
  else if (e.key === '3' && _upgPickFns[2]) { e.preventDefault(); _upgPickFns[2](); }
  else if (e.key === 'Escape') { e.preventDefault(); _skipUpgrade(); }
});

function showUpgradeOverlay(age) {
  return;
}
// XP DOM güncellemesi — her kaynak darbede DOM yazmak layout tetikler.
// Çözüm: dirty flag → her 8 frame'de bir toplu yaz (_flushXP) for better performance.
let _xpDirty = false;
let _xpFlushCounter = 0;
function updateXP() {
  // Level-up kontrolü anında çalışır (hesaplama, DOM yazısı değil)
  const age = getAge(player.xp);
  if (age > _prevAge) {
    _prevAge = age;
    floatingTexts.push({ x: player.x, y: player.y - 60, text: '⬆️ AGE ' + age + '!', alpha: 1, life: 55, color: '#ffd700' });
    _xpDirty = true; _flushXP(); // level-up'ta DOM'u hemen güncelle
    return;
  }
  _xpDirty = true; // DOM güncelleme ertelendi
}
function _flushXP() {
  if (!_xpDirty) return;
  _xpFlushCounter++;
  if (_xpFlushCounter < 8) return; // Flush every 8 frames instead of immediately
  _xpFlushCounter = 0;
  _xpDirty = false;
  const age  = getAge(player.xp);
  const fill = getAgeFill(player.xp);
  const xpFill = document.getElementById('xp-fill');
  const ageText = document.getElementById('age-text');
  if (xpFill) xpFill.style.width = fill + '%';
  if (ageText) {
    const idx  = age - 1;
    const xpS  = AGE_XP_TABLE[idx] || 0;
    const xpE  = AGE_XP_TABLE[idx + 1];
    const prog = xpE ? `${player.xp - xpS}/${xpE - xpS}` : 'MAX';
    ageText.textContent = `AGE ${age}  (${prog} XP)`;
  }
}

// ============================================================
// DEATH
// ============================================================
let _survivalStartTime = Date.now();

function _fmtTime(secs){
  const s = Math.max(0, Math.floor(Number(secs) || 0));
  const m = Math.floor(s / 60), remS = s % 60;
  return m > 0 ? `${m}d ${remS < 10 ? '0' : ''}${remS}s` : `${remS}s`;
}
// ── Score submission to leaderboard ──────────────────────────────────────────
// Works for both guests (localStorage guestId) and logged-in users (token).
// Fire-and-forget — navigation doesn't wait for the response.
function _submitScore() {
  const score = player.score || (player.xp * 10 + player.kills * 120 + player.gold * 3) || player.gold || 0;
  if (score <= 0 && (!player.kills || player.kills <= 0) && (!player.gold || player.gold <= 0)) return;
  // Ensure persistent guest ID
  let guestId = localStorage.getItem('fb_guest_id');
  if (!guestId) { guestId = Math.random().toString(36).slice(2) + Date.now().toString(36); localStorage.setItem('fb_guest_id', guestId); }
  const token = localStorage.getItem('fb_auth_token') || '';
  const timeSec = Math.max(0, Math.floor(globalTime / 60));
  fetch('/api/leaderboard/submit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(token ? { 'Authorization': 'Bearer ' + token } : {}) },
    body: JSON.stringify({
      name: player.name || 'Oyuncu',
      score,
      gold: player.gold || 0,
      kills: player.kills || 0,
      timeAlive: timeSec,
      guestId
    }),
  }).catch(() => {});
}

// Called by the HUD "← Menü" button — submits score then navigates
function tryFullscreen() {
  const root = document.documentElement;
  if (document.fullscreenElement) {
    document.exitFullscreen?.();
    return;
  }
  root.requestFullscreen?.().catch(() => {});
}

function _goToMenu() {
  _submitScore();
  if (typeof _syncGameAccountState === 'function') _syncGameAccountState(true);
  setTimeout(() => { window.location.href = _BASE; }, 120);
}

function die() {
  if (_isDying) return; // already dying — ignore duplicate call
  _isDying = true;
  player.dead = true;
  player.hp = 0;
  _trapCaughtBy = null; // free from any trap on death
  _playerMoveTrail = []; // clear movement trail on death
  if (typeof bossTelegraphs !== 'undefined') bossTelegraphs.length = 0; // clear stale boss skill telegraphs on death

  // Clear own buildings on death so limits and map are immediately clean
  for (let _bi = buildings.length - 1; _bi >= 0; _bi--) {
    const _bRem = buildings[_bi];
    if (!_bRem._remote || (_mySocketId && _bRem._ownerId === _mySocketId)) {
      if (_bRem._netId) _buildingsMap.delete(_bRem._netId);
      if (_bRem.type === 10) { const _ci = _campfires.indexOf(_bRem); if (_ci >= 0) _campfires.splice(_ci, 1); }
      buildings.splice(_bi, 1);
    }
  }
  if (typeof _socket !== 'undefined' && _socket && _connected) {
    _socket.emit('player_dead', { id: _mySocketId });
  }

  // Invalidate UI caches so bars redraw correctly after respawn
  _hpLast = { hp: -1, maxHp: -1, band: -1 };
  _uiLast = { apples: -1, wood: -1, stone: -1, gold: -1, score: -1 };
  // Submit score to leaderboard for all players (guests + logged in)
  _submitScore();
  // Close chat input if open
  if (_chatInput && document.body.contains(_chatInput)) {
    document.body.removeChild(_chatInput);
    _chatInput = null;
  }
  const score = player.score || (player.xp * 10 + player.kills * 120 + player.gold * 3);
  const prev = parseInt(localStorage.getItem('fb_best_score') || '0');
  if (score > prev) {
    localStorage.setItem('fb_best_score', score);
    localStorage.setItem('fb_best_kills', player.kills);
    localStorage.setItem('fb_best_age', getAge(player.xp));
    localStorage.setItem('fb_best_name', player.name);
  }
  localStorage.setItem('fb_last_kills', player.kills);
  localStorage.setItem('fb_last_age', getAge(player.xp));
  localStorage.setItem('fb_last_gold', player.gold);
  // Update cumulative stats for achievement tracking
  const _prevTotalKills = parseInt(localStorage.getItem('fb_total_kills')||'0', 10);
  const _newTotalKills  = _prevTotalKills + player.kills;
  localStorage.setItem('fb_total_kills', _newTotalKills);
  // Cumulative deaths + games played (for guest profile display)
  const _prevTotalDeaths = parseInt(localStorage.getItem('fb_total_deaths')||'0', 10);
  localStorage.setItem('fb_total_deaths', _prevTotalDeaths + 1);
  const _prevTotalGames = parseInt(localStorage.getItem('fb_total_games')||'0', 10);
  localStorage.setItem('fb_total_games', _prevTotalGames + 1);
  const _prevMaxAge = parseInt(localStorage.getItem('fb_max_age')||'1', 10);
  const _curAge = getAge(player.xp);
  if(_curAge > _prevMaxAge) localStorage.setItem('fb_max_age', _curAge);
  // Mark pending achievements for popup in lobby
  (function(){
    const ACHS=[{id:'kills_5',type:'kills',req:5},{id:'kills_10',type:'kills',req:10},{id:'kills_50',type:'kills',req:50},{id:'kills_100',type:'kills',req:100},{id:'age_4',type:'age',req:4},{id:'age_5',type:'age',req:5},{id:'age_6',type:'age',req:6},{id:'age_7',type:'age',req:7},{id:'age_8',type:'age',req:8}];
    const done=JSON.parse(localStorage.getItem('fb_unlocked_ach')||'[]');
    const newMax=Math.max(parseInt(localStorage.getItem('fb_max_age')||'1',10),_curAge);
    const newKills=_newTotalKills;
    const nowDone=ACHS.filter(a=>(a.type==='kills'?newKills:newMax)>=a.req).map(a=>a.id);
    const fresh=nowDone.filter(id=>!done.includes(id));
    if(fresh.length){
      localStorage.setItem('fb_unlocked_ach',JSON.stringify(nowDone));
      const pend=JSON.parse(localStorage.getItem('fb_pending_ach')||'[]');
      localStorage.setItem('fb_pending_ach',JSON.stringify([...pend,...fresh]));
    }
  })();
  // ── Meta-progression die hook ──────────────────────────────────────
  const _dieKills    = player.kills;
  const _dieTimeSec  = Math.max(0, Math.floor((Date.now() - _survivalStartTime) / 1000));
  const _dieScore    = score;
  if (typeof window._metaOnDie === 'function')
    setTimeout(function(){ window._metaOnDie(_dieKills, _dieTimeSec, _dieScore); }, 200);
  // Add earned gold to shop balance
  const prevShopGold = parseInt(localStorage.getItem('fb_gold')||'1500',10);
  localStorage.setItem('fb_gold', prevShopGold + player.gold);
  // ── Guest & User cumulative stat tracking ─────────
  const _dieAuthTok = localStorage.getItem('fb_auth_token') || '';
  const _dieTimePlayed = Math.floor(globalTime / 60); // seconds alive this session
  const _xpEarned = player.kills * 60 + _dieTimePlayed * 2 + (score > 0 ? Math.floor(Math.sqrt(score) * 8) : 0);
  const _earnedGold = Math.floor((player.gold || 0) / 10);
  
  localStorage.setItem('fb_total_xp',   parseInt(localStorage.getItem('fb_total_xp')||'0',10)   + Math.min(_xpEarned, 10000));
  localStorage.setItem('fb_total_time', parseInt(localStorage.getItem('fb_total_time')||'0',10) + _dieTimePlayed);
  localStorage.setItem('fb_total_gold', parseInt(localStorage.getItem('fb_total_gold')||'0',10) + _earnedGold);
  localStorage.setItem('fb_gold', prevShopGold + _earnedGold);
  localStorage.setItem('fb_total_kills', parseInt(localStorage.getItem('fb_total_kills')||'0',10) + player.kills);
  localStorage.setItem('fb_total_deaths', parseInt(localStorage.getItem('fb_total_deaths')||'0',10) + 1);
  if (score > parseInt(localStorage.getItem('fb_best_score')||'0', 10)) {
    localStorage.setItem('fb_best_score', score);
  }

  fetch('/api/profile/xp', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': _dieAuthTok ? ('Bearer ' + _dieAuthTok) : ''
    },
    body: JSON.stringify({
      xp: Math.min(_xpEarned, 10000),
      kills: player.kills,
      deaths: 1,
      score,
      timePlayed: _dieTimePlayed,
      coins: _earnedGold,
      gold: _earnedGold,
      questProgress: {
        wolves: Math.max(0, (_sessionQuestStats.wolves || 0) - (_questPersisted.wolves || 0)),
        bears: Math.max(0, (_sessionQuestStats.bears || 0) - (_questPersisted.bears || 0)),
        scorpions: Math.max(0, (_sessionQuestStats.scorpions || 0) - (_questPersisted.scorpions || 0)),
        spiders: Math.max(0, (_sessionQuestStats.spiders || 0) - (_questPersisted.spiders || 0)),
        kills: Math.max(0, (player.kills || 0) - (_questPersisted.kills || 0)),
        kingKills: Math.max(0, (_sessionQuestStats.kingKills || 0) - (_questPersisted.kingKills || 0)),
        airdrops: Math.max(0, (_sessionQuestStats.airdrops || 0) - (_questPersisted.airdrops || 0)),
        buildings: Math.max(0, (_sessionQuestStats.buildings || 0) - (_questPersisted.buildings || 0)),
        wood: Math.max(0, (_sessionQuestStats.wood || 0) - (_questPersisted.wood || 0)),
        gold: Math.max(0, (player.gold || 0) - (_questPersisted.gold || 0))
      }
    }),
  }).then(r => {
    if (r.status === 401) {
      localStorage.removeItem('fb_auth_token');
      localStorage.removeItem('fb_auth_user');
      return null;
    }
    return r.json();
  }).then(d => {
    if (!d || d.isGuest) return;
    if (d.newToken) { localStorage.setItem('fb_auth_token', d.newToken); }
    if (d.user) {
      localStorage.setItem('fb_auth_user', JSON.stringify(d.user));
      if (d.user.coins != null) {
        localStorage.setItem('fb_gold', d.user.coins);
      }
    }
    if (d.rankId !== undefined) {
      _myRankId = d.rankId;
      localStorage.setItem('fb_user_rank', d.rankId);
    }
    if (d.rankUp && d.newRankName) {
      const statEl = document.getElementById('death-stats');
      if (statEl) {
        const rankUpBanner = document.createElement('div');
        rankUpBanner.style.cssText = 'background:rgba(255,215,0,0.18);border:2px solid #ffd700;border-radius:10px;padding:8px 14px;margin:8px 0;font-size:15px;font-weight:800;color:#ffd700;text-align:center';
        rankUpBanner.textContent = '🎉 RANK ATLADI! → ' + (d.newRankIcon || '👑') + ' ' + d.newRankName;
        statEl.prepend(rankUpBanner);
      }
    }
    _updateRankBarFromServer(d);
  }).catch(() => {});

  const isNew = score > prev;
  const timeStr = _fmtTime(globalTime);
  const age = getAge(player.xp);
  const newTotalGold = prevShopGold + _earnedGold;

  // Killer info banner
  const killerEl = document.getElementById('death-killer');
  const avatarEl = document.getElementById('death-player-avatar');
  if (avatarEl) {
    avatarEl.src = `players/${_playerSkin || 'default'}.png`;
    avatarEl.onerror = () => { avatarEl.src = 'players/default.png'; };
  }
  if (_lastDamager && killerEl) {
    killerEl.style.display = '';
    killerEl.innerHTML = `☠️ <b>${_lastDamager.typeName || 'Düşman'}</b> tarafından öldürüldün!`;
  } else if (killerEl) {
    killerEl.style.display = 'none';
  }

  // Fill new stat grid boxes
  const _dsKills = document.getElementById('ds-kills');
  const _dsStreak = document.getElementById('ds-streak');
  const _dsAge = document.getElementById('ds-age');
  const _dsTime = document.getElementById('ds-time');
  const _dsDmg = document.getElementById('ds-dmg');
  const _dsGold = document.getElementById('ds-gold');
  if (_dsKills) _dsKills.textContent = player.kills;
  if (_dsStreak) _dsStreak.textContent = killStreak + '×';
  if (_dsAge) _dsAge.textContent = age;
  if (_dsTime) _dsTime.textContent = timeStr;
  if (_dsDmg) _dsDmg.textContent = player.totalDmg || 0;
  if (_dsGold) _dsGold.textContent = '+' + _earnedGold;
  // New record banner
  const _recEl = document.getElementById('death-new-record');
  if (_recEl) _recEl.style.display = isNew ? '' : 'none';
  // Gold earned toast in old #death-stats (hidden by default, only show for big gold)
  if (_earnedGold > 0) {
    const _ds = document.getElementById('death-stats');
    if (_ds) { _ds.style.display = ''; _ds.innerHTML = `<div style="background:rgba(245,200,66,0.15);border:1.5px solid rgba(245,200,66,0.35);border-radius:10px;padding:7px 14px;color:#ffd700;font-size:clamp(11px,3.2vw,14px);font-weight:800;line-height:1.5;word-break:break-word;">💰 +${_earnedGold} Altın profiline eklendi!<br><span style="font-size:0.9em;opacity:0.85;">Toplam: ${newTotalGold.toLocaleString('tr-TR')}</span></div>`; }
  }
  document.getElementById('death-overlay').classList.add('show');
  // Update quest progress for time survived
  {
    const _minsSurvived = Math.floor(globalTime / 60);
    if (_minsSurvived >= 1) window._updateQuestProgress('time', _minsSurvived);
  }

  // Rank progress bar — show immediately with session XP & lifetime progress
  (function(){
    const _sessXP = Math.min(player.kills * 75 + Math.floor(globalTime / 60) * 10 + Math.floor((player.totalDmg||0) / 15) + Math.floor((score || 0) / 10), 5000);
    const _earnedGoldEl = document.getElementById('death-xp-earned');
    if (_earnedGoldEl) _earnedGoldEl.textContent = '+' + _earnedGold.toLocaleString('tr-TR') + ' Altın';
    const _prevTotalXp = parseInt(localStorage.getItem('fb_user_xp') || localStorage.getItem('fb_total_xp') || '0', 10);
    const _newTotalXp = _prevTotalXp + _sessXP;
    localStorage.setItem('fb_user_xp', _newTotalXp);
    localStorage.setItem('fb_total_xp', _newTotalXp);

    const _rid = _fbRankByXP(_newTotalXp);
    _myRankId = _rid;
    localStorage.setItem('fb_user_rank', _rid);

    const _rbEl = document.getElementById('death-rank-bar');
    const _rlEl = document.getElementById('death-rank-label');
    const _rfEl = document.getElementById('death-rank-fill');
    const _rtEl = document.getElementById('death-rank-xp');
    if (!_rbEl || !_rlEl || !_rfEl || !_rtEl) return;

    const _rm = _RANK_META[_rid];
    const _nm = _RANK_META[Math.min(_rid + 1, 11)];
    const _rs = _FB_RANK_XP[_rid];
    const _re = _FB_RANK_XP[Math.min(_rid + 1, 11)];
    const _needed = Math.max(0, _re - _newTotalXp);
    const _pct = _rid >= 11 ? 100 : Math.min(100, Math.max(0, Math.round(((_newTotalXp - _rs) / (_re - _rs)) * 100)));

    _renderDeathRankVisuals(_rid, Math.min(_rid + 1, 11));
    if (_rid >= 11) {
      _rtEl.innerHTML = `<b>+${_sessXP.toLocaleString('tr-TR')} XP</b> kazandın! (${_newTotalXp.toLocaleString('tr-TR')} XP · MAKSİMUM RANK 👑)`;
    } else {
      _rtEl.innerHTML = `<b>+${_sessXP.toLocaleString('tr-TR')} XP</b> kazandın! (${_newTotalXp.toLocaleString('tr-TR')} / ${_re.toLocaleString('tr-TR')} XP · %${_pct})<br><span style="font-size:10px;color:#79D138;font-weight:800;">Sonraki Rank (${_nm[5]}) için: ${_needed.toLocaleString('tr-TR')} XP kaldı</span>`;
    }
    _rbEl.style.display = '';
    _rfEl.style.width = '0%';
    setTimeout(() => { _rfEl.style.width = _pct + '%'; }, 180);
  })();
}

function _updateRankBarFromServer(d) {
  if (!d || d.newXp === undefined) return;
  const totalXP = d.newXp;
  const rid     = _fbRankByXP(totalXP);
  const rm      = _RANK_META[rid];
  const nm      = _RANK_META[Math.min(rid+1,11)];
  const rs      = _FB_RANK_XP[rid];
  const re      = _FB_RANK_XP[Math.min(rid+1,11)] || _FB_RANK_XP[11];
  const pct     = rid >= 11 ? 100 : Math.min(98, ((totalXP - rs) / (re - rs)) * 100);
  const rlEl    = document.getElementById('death-rank-label');
  const rfEl    = document.getElementById('death-rank-fill');
  const rtEl    = document.getElementById('death-rank-xp');
  if (rlEl) _renderDeathRankVisuals(rid, Math.min(rid + 1, 11));
  if (rfEl) { rfEl.style.transition='width 1.8s cubic-bezier(.25,.46,.45,.94)'; rfEl.style.width = pct + '%'; }
  if (rtEl) rtEl.textContent = `${totalXP.toLocaleString('tr-TR')} / ${re.toLocaleString('tr-TR')} XP`;
}

function _shareScore() {
  const kills    = player.kills || 0;
  const name     = player.name || 'Oyuncu';
  const ridSafe  = Math.min(typeof _myRankId!=='undefined'?_myRankId:0, 11);
  const rankName = (_RANK_META[ridSafe]||_RANK_META[0])[5];
  const rankEmoji= _FB_RANK_EMOJIS[ridSafe] || '🌱';
  const timeStr  = _fmtTime ? _fmtTime(globalTime) : '';
  const streak   = killStreak || 0;
  const base     = window.location.origin + (_BASE || '/');
  const text     = `${rankEmoji} ForestBrawl.io'da ${name} olarak ${kills} kill yaptım!\n🔥 ${streak > 1 ? streak+'× kill serisi! ' : ''}⏱️ ${timeStr} · Rank: ${rankName}\n🌲 Sen de oyna: ${base}`;
  const url      = base;
  const btn      = document.getElementById('share-score-btn');
  if (navigator.share) {
    navigator.share({ title: '🌲 ForestBrawl.io', text: text.replace('\n'+url,''), url }).catch(() => {});
  } else if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(() => {
      if (btn) { const old = btn.innerHTML; btn.innerHTML = '✅ Kopyalandı!'; setTimeout(() => { btn.innerHTML = old; }, 2500); }
    }).catch(() => { prompt('Kopyala:', text); });
  } else {
    prompt('Kopyala:', text);
  }
  if (navigator.vibrate) navigator.vibrate([40,20,40]);
}

function respawn() {
  _isDying = false; // allow die() to fire again on next life
  document.getElementById('death-overlay').classList.remove('show');
  _lastDamager = null;
  _killCamTimer = 0;
  player.hp = player.maxHp = 250;
  // ── Clear FPS history so quality recalibrates from scratch after respawn ──
  // Without this, quality=2 is inherited from grace-period (light rendering) and
  // causes a sudden FPS drop when full rendering resumes after grace ends.
  _fpsBufCount = 0; _fpsBufHead = 0;
  _qualityLevel = 2; // Respawn must preserve the selected visual quality
  // ── SPAWN PROTECTION ──
  _spawnProtected = true;
  _spawnProtTimer = 180; // 3 seconds at 60fps
  // Position will be set by server via 'own_respawn' event — do NOT teleport locally
  // to avoid the 3-position race-condition that caused random teleports
  player.vx = 0; player.vy = 0; player.momX = 0; player.momY = 0;
  _trapCaughtBy = null; // release from any trap on respawn
  floatingTexts.length = 0;
  particles.length = 0;
  loots.length = 0;
  chests.length = 0;
  armorDrops.length = 0;
  ambientParticles.length = 0;
  _pendingNameTags.length = 0;
  _fpsArr.length = 0;
  projectiles.length = 0;
  arrows.length = 0;
  enemyProjectiles.length = 0;
  if (window._deferBlood) window._deferBlood.length = 0;
  if (typeof _spikeEnemyCooldowns !== 'undefined') _spikeEnemyCooldowns.clear();
  if (typeof _myTrapVictims !== 'undefined') _myTrapVictims.clear();
  if (typeof _pvpPredictTime !== 'undefined') _pvpPredictTime.clear();
  player.wood = 0; player.stone = 0;
  player.gold = 0; player.kills = 0; player.totalDmg = 0; player.score = 0;
  player.xp = 0; player.apples = 5;
  player.speedBonus = 1; player.dmgBonus = 1; player.harvestBonus = 1;
  player.armorBonus = 0; player.atkSpdBonus = 1; player.regenBonus = 1;
  player.vampire = false; player._wideSwing = false;
  player.weapon = 1; player.isAttacking = false; player.attackTimer = 0;
  _survivalStartTime = Date.now();
  // Only clear OWN buildings — remote buildings from other players must survive respawn.
  // The server will send a buildings_sync event with the current full state.
  for (let _bi = buildings.length - 1; _bi >= 0; _bi--) {
    const _bRem = buildings[_bi];
    if (!_bRem._remote || (_mySocketId && _bRem._ownerId === _mySocketId)) {
      if (_bRem._netId) _buildingsMap.delete(_bRem._netId);
      if (_bRem.type === 10) { const _ci=_campfires.indexOf(_bRem); if(_ci>=0){_campfires[_ci]=_campfires[_campfires.length-1];_campfires.pop();} }
      buildings.splice(_bi, 1);
    }
  }
  _campfires.length = 0; // full clear safety: rebuild from remaining buildings
  for (let _bi=0;_bi<buildings.length;_bi++) { if(buildings[_bi].type===10) _campfires.push(buildings[_bi]); }
  _prevAge = getAge(player.xp); // sync to current XP — prevents false level-up overlay on first kill after respawn
  _pendingUpgrades.length = 0; // clear stale upgrade queue from previous life
  if (typeof bossTelegraphs !== 'undefined') bossTelegraphs.length = 0; // clear stale boss telegraphs on respawn
  // Reset any casting boss skills so they don't re-fire after respawn
  if (typeof bossState !== 'undefined' && typeof CAMPS !== 'undefined') {
    CAMPS.forEach(function(c){ if(bossState[c.id]) bossState[c.id].castingSkill=null; });
  }
  document.getElementById('upgrade-overlay').classList.remove('show');
  document.getElementById('upg-backdrop').classList.remove('show');
  _upgPanelOpen = false;
  _upgPickFns = [];
  killStreak = 0; lastKillMs = 0; streakFade = 0;
  _multiKillCount = 0; _multiKillTimer = 0; _milestoneFade = 0; _streakMilestones.clear();
  _bowCooldown = 0; _lvlRings.length = 0; _playerLevel = 1; _playerLevelKills = 0;
  document.querySelectorAll('.inv-slot').forEach((s,i)=>s.classList.toggle('active',i===0));
  _respawnGrace = 60; // skip expensive background passes for ~1s to guarantee buttery respawn
  _isDying = false; // Reset dying guard on respawn so player can immediately act
  const _rp = randomForestPoint();
  player.x = _rp.x;
  player.y = _rp.y;
  if (canvas.width > 0) {
    camX = player.x - canvas.width / 2;
    camY = player.y - canvas.height / 2;
  }
  floatingTexts.push({ x: player.x, y: player.y - 80, text: '🛡️ 3 Saniyelik Koruma!', alpha: 1, life: 100, color: '#44ddff', big: true });
  // Tell server to respawn — server will echo back 'own_respawn' with the authoritative position.
  if (typeof _socket !== 'undefined' && _socket && _connected) {
    _socket.emit('respawn');
  }
}
window.respawn = respawn;

// Ground details are simplified for maximum 60FPS performance

// ============================================================
// ULTRA RESOURCE DRAWING HELPERS
// ============================================================
// ─── RESOURCE DRAWING — sploop.io / moomoo.io style ─────────────────────────
// PERF: shared gradient cache — avoids createLinearGradient/createRadialGradient per entity per frame.
// Canvas 2D gradient objects are context-relative: coordinates transform with CTM at draw time,
// so the same gradient object is safe to reuse across any translate() position.
const _resGrdCache = new Map();
let _bakingResource = false;
function _resGrd(key, createFn) {
  if (window._resGrdDirty) {
    window._resGrdDirty = false;
    _resGrdCache.clear();
  }
  if (_bakingResource) return createFn();
  let g = _resGrdCache.get(key);
  if (!g) { g = createFn(); _resGrdCache.set(key, g); }
  return g;
}

/* ── TREE ───────────────────────────────────────────────────────────────────
   moomoo.io / sploop.io look: 2 overlapping circles on a short trunk.
   Desert → cactus, Snow → 3-tier pine with snow caps. All others share the
   same clean 2-blob silhouette, biome colour-shifted.
   ─────────────────────────────────────────────────────────────────────────── */
function _drawUltraTree(ctx, x, y, R, biome, t, hp) {
  // PERF: quality=0 fast-path — single circle, no gradient, no save/restore
  if (_qualityLevel === 0) {
    const fc = biome==='darkforest'?'#3d1578':biome==='swamp'?'#2c4c10':biome==='desert'?'#4da830':biome==='snow'?'#2e6658':'#1e6204';
    ctx.fillStyle = fc; ctx.strokeStyle = '#0a2801'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(x, y, R*.50, 0, Math.PI*2); ctx.fill(); ctx.stroke();
    return;
  }
  const sway = Math.sin(t * 0.018 + x * 0.003) * 0.028;
  ctx.save(); ctx.translate(x, y);


  if (biome === 'desert') {
    // ── Cactus ──────────────────────────────────────────────────────────
    ctx.rotate(sway);
    const cv = '#4da830', cs = '#1e5c18', ch = '#7acc48';
    ctx.fillStyle = cv; ctx.strokeStyle = cs; ctx.lineWidth = 2.5;
    // Trunk
    ctx.beginPath(); ctx.roundRect(-R*.14, -R*.58, R*.28, R*.84, R*.08); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.ellipse(0, -R*.58, R*.14, R*.09, 0, 0, Math.PI*2); ctx.fill(); ctx.stroke();
    // Arms
    ctx.beginPath(); ctx.roundRect(-R*.50, -R*.30, R*.36, R*.16, R*.07); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.ellipse(-R*.50, -R*.22, R*.09, R*.13, 0, 0, Math.PI*2); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.roundRect(R*.14, -R*.20, R*.36, R*.16, R*.07); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.ellipse(R*.50, -R*.12, R*.09, R*.13, 0, 0, Math.PI*2); ctx.fill(); ctx.stroke();
    // Highlight streak
    ctx.fillStyle = 'rgba(140,220,90,0.24)';
    ctx.beginPath(); ctx.ellipse(-R*.05, -R*.22, R*.06, R*.36, 0, 0, Math.PI*2); ctx.fill();

  } else if (biome === 'snow') {
    // ── Snow pine — 3 tiers ─────────────────────────────────────────────
    ctx.rotate(sway);
    ctx.fillStyle = '#3d2214'; ctx.strokeStyle = '#1e0e08'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.roundRect(-R*.09, R*.10, R*.18, R*.44, 3); ctx.fill(); ctx.stroke();
    const tiers = [
      [R*.10, R*.50, '#2e6658', '#deeeff'],
      [-R*.12, R*.38, '#378070', '#eef4ff'],
      [-R*.32, R*.26, '#429088', '#ffffff'],
    ];
    for (const [ty, tr, tc, sc] of tiers) {
      ctx.fillStyle = tc; ctx.strokeStyle = '#1a4038'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(0, ty, tr, 0, Math.PI*2); ctx.fill(); ctx.stroke();
      // Snow cap — white half-ellipse on top of each tier
      ctx.fillStyle = sc; ctx.strokeStyle = '#a8cce0'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.ellipse(0, ty - tr * .50, tr * .50, tr * .17, 0, 0, Math.PI); ctx.fill(); ctx.stroke();
    }

  } else {
    // ── Forest / Swamp / DarkForest — 2-blob moomoo style ───────────────
    ctx.rotate(sway);

    // Short trunk — visible under canopy (gradient cached by R bucket)
    const tg = _resGrd('tree_trunk_'+(R|0), ()=>{ const g=ctx.createLinearGradient(-R*.10,0,R*.10,0); g.addColorStop(0,'#4e2808'); g.addColorStop(0.45,'#7a4418'); g.addColorStop(1,'#4e2808'); return g; });
    ctx.fillStyle = tg; ctx.strokeStyle = '#2a1006'; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.roundRect(-R*.09, R*.08, R*.18, R*.48, 4); ctx.fill(); ctx.stroke();

    // Biome-aware canopy colours
    let col1, col2, stroke1, stroke2;
    if (biome === 'darkforest') {
      col1 = '#3d1578'; col2 = '#7030cc'; stroke1 = '#150832'; stroke2 = '#3a1060';
    } else if (biome === 'swamp') {
      col1 = '#2c4c10'; col2 = '#406018'; stroke1 = '#182808'; stroke2 = '#243010';
    } else {
      col1 = '#1e6204'; col2 = '#58c820'; stroke1 = '#0a2801'; stroke2 = '#1a4a02';
    }

    // Bottom blob — larger, slightly right/down
    ctx.fillStyle = col1; ctx.strokeStyle = stroke1; ctx.lineWidth = 5.5;
    ctx.beginPath(); ctx.arc(R*.05, R*.02, R*.53, 0, Math.PI*2); ctx.fill(); ctx.stroke();

    // Top blob — brighter, shifted up-left (sploop.io signature)
    ctx.fillStyle = col2; ctx.strokeStyle = stroke2; ctx.lineWidth = 4.5;
    ctx.beginPath(); ctx.arc(-R*.05, -R*.16, R*.40, 0, Math.PI*2); ctx.fill(); ctx.stroke();

    // Top-left highlight shine (biome-aware)
    ctx.fillStyle = biome === 'darkforest' ? 'rgba(180,100,255,0.28)' : biome === 'swamp' ? 'rgba(120,200,80,0.20)' : 'rgba(190,255,110,0.20)';
    ctx.beginPath(); ctx.ellipse(-R*.18, -R*.38, R*.15, R*.09, -0.4, 0, Math.PI*2); ctx.fill();

    // DarkForest purple glow pulse — only on high quality
    if (biome === 'darkforest' && _qualityLevel >= 2) {
      ctx.save();
      ctx.globalAlpha = 0.28 + Math.sin(t * .07) * .11;
      ctx.shadowColor = '#9922ff'; ctx.shadowBlur = 14;
      ctx.fillStyle = 'rgba(110,20,210,0.20)';
      ctx.beginPath(); ctx.arc(0, -R*.08, R*.46, 0, Math.PI*2); ctx.fill();
      ctx.restore();
    }
  }

  ctx.restore();
}

/* ── STONE ──────────────────────────────────────────────────────────────────
   moomoo.io / sploop.io look: rounded 7-side polygon with a bold dark stroke,
   radial gradient (bright top-left → dark bottom-right), and a white shine.
   Stone and Gold share the EXACT same silhouette — only colours differ.
   ─────────────────────────────────────────────────────────────────────────── */
function _drawUltraRock(ctx, x, y, R, biome, hp) {
  // PERF: quality=0 fast-path — flat circle, no gradient
  if (_qualityLevel === 0) {
    const fc = biome==='snow'?'#8fb4cc':biome==='desert'?'#c09c36':biome==='swamp'?'#6a7c48':biome==='darkforest'?'#6a30aa':'#8090a8';
    ctx.fillStyle = fc; ctx.strokeStyle = '#243040'; ctx.lineWidth = 5;
    ctx.beginPath(); ctx.arc(x, y, R*.84, 0, Math.PI*2); ctx.fill(); ctx.stroke();
    return;
  }
  ctx.save(); ctx.translate(x, y);

  // Biome colour palette
  let mainC, lightC, darkC;
  if      (biome === 'snow')       { mainC = '#8fb4cc'; lightC = '#daf0ff'; darkC = '#2a4e6a'; }
  else if (biome === 'desert')     { mainC = '#c09c36'; lightC = '#e8d47a'; darkC = '#5a3e08'; }
  else if (biome === 'swamp')      { mainC = '#6a7c48'; lightC = '#9eb474'; darkC = '#1a2408'; }
  else if (biome === 'darkforest') { mainC = '#6a30aa'; lightC = '#b060ff'; darkC = '#250848'; }
  else                             { mainC = '#8090a8'; lightC = '#c8dcea'; darkC = '#243040'; }

  // Rounded polygon — 7 sides, slight vertex jitter for natural look
  const sides = 7;
  const jit   = [0.06, -0.08, 0.10, -0.06, 0.08, -0.04, 0.07];
  ctx.beginPath();
  for (let i = 0; i < sides; i++) {
    const a  = i / sides * Math.PI * 2 - Math.PI / 2;
    const rv = R * (0.84 + jit[i]);
    if (i === 0) ctx.moveTo(Math.cos(a)*rv, Math.sin(a)*rv);
    else         ctx.lineTo(Math.cos(a)*rv, Math.sin(a)*rv);
  }
  ctx.closePath();

  // Radial gradient: bright top-left → dark bottom-right (cached by biome+R)
  const g = _resGrd('rock_'+(R|0)+'_'+biome, ()=>{ const gg=ctx.createRadialGradient(-R*.28,-R*.30,R*.04,R*.06,R*.08,R*1.02); gg.addColorStop(0,lightC); gg.addColorStop(0.44,mainC); gg.addColorStop(1,darkC); return gg; });
  ctx.fillStyle = g; ctx.strokeStyle = darkC; ctx.lineWidth = 7; ctx.lineJoin = 'round';
  ctx.fill(); ctx.stroke();

  // Primary shine — top-left white ellipse (moomoo.io signature)
  ctx.fillStyle = 'rgba(255,255,255,0.30)';
  ctx.beginPath(); ctx.ellipse(-R*.22, -R*.26, R*.26, R*.15, -0.45, 0, Math.PI*2); ctx.fill();

  // Small secondary gleam
  ctx.fillStyle = 'rgba(255,255,255,0.14)';
  ctx.beginPath(); ctx.ellipse(-R*.08, -R*.44, R*.10, R*.06, -0.20, 0, Math.PI*2); ctx.fill();

  // Snow cap on top
  if (biome === 'snow') {
    ctx.fillStyle = 'rgba(220,240,255,0.62)';
    ctx.beginPath(); ctx.ellipse(-R*.04, -R*.08, R*.40, R*.18, -0.18, 0, Math.PI*2); ctx.fill();
  }

  ctx.restore();
}

/* ── GOLD ───────────────────────────────────────────────────────────────────
   Identical polygon silhouette as Stone — only gold/amber palette + glow.
   sploop.io style: same rock shape but yellow, with a sparkle cross on top.
   ─────────────────────────────────────────────────────────────────────────── */
function _drawUltraGold(ctx, x, y, R, biome, t) {
  // PERF: quality=0 fast-path
  if (_qualityLevel === 0) {
    ctx.fillStyle = '#f0b800'; ctx.strokeStyle = '#8a5a00'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.arc(x, y, R*.84, 0, Math.PI*2); ctx.fill(); ctx.stroke();
    return;
  }
  ctx.save(); ctx.translate(x, y);
  const bob = _qualityLevel >= 2 ? Math.sin(t * .055) * R * .022 : 0; // bob only at quality=2

  // Outer warm glow halo — quality=2 only (gradient with frame-varying bob, can't cache)
  if (_qualityLevel >= 2) {
    const glow = ctx.createRadialGradient(0, bob, R*.15, 0, bob, R*1.45);
    glow.addColorStop(0, 'rgba(255,208,0,0.28)');
    glow.addColorStop(1, 'rgba(255,190,0,0)');
    ctx.fillStyle = glow;
    ctx.beginPath(); ctx.arc(0, bob, R*1.45, 0, Math.PI*2); ctx.fill();
  }

  // Same 7-side polygon as Stone (moomoo.io: stone & gold are the SAME rock)
  const sides = 7;
  const jit   = [0.06, -0.08, 0.10, -0.06, 0.08, -0.04, 0.07];
  ctx.beginPath();
  for (let i = 0; i < sides; i++) {
    const a  = i / sides * Math.PI * 2 - Math.PI / 2;
    const rv = R * (0.84 + jit[i]);
    if (i === 0) ctx.moveTo(Math.cos(a)*rv, Math.sin(a)*rv + bob);
    else         ctx.lineTo(Math.cos(a)*rv, Math.sin(a)*rv + bob);
  }
  ctx.closePath();

  // Body gradient — cached (bob=0 at quality=1, negligible visual diff)
  const g = _resGrd('gold_body_'+(R|0), ()=>{ const gg=ctx.createRadialGradient(-R*.28,-R*.30,R*.04,R*.06,R*.06,R*1.02); gg.addColorStop(0,'#ffe966'); gg.addColorStop(0.38,'#f0b800'); gg.addColorStop(0.76,'#b07800'); gg.addColorStop(1,'#664200'); return gg; });
  ctx.fillStyle = g; ctx.strokeStyle = '#8a5a00'; ctx.lineWidth = 4.5; ctx.lineJoin = 'round';
  ctx.fill(); ctx.stroke();

  // Primary shine — same position as Stone
  ctx.fillStyle = 'rgba(255,255,190,0.45)';
  ctx.beginPath(); ctx.ellipse(-R*.22, -R*.26 + bob, R*.24, R*.14, -0.45, 0, Math.PI*2); ctx.fill();

  // Small secondary gleam
  ctx.fillStyle = 'rgba(255,255,255,0.22)';
  ctx.beginPath(); ctx.ellipse(-R*.08, -R*.44 + bob, R*.09, R*.055, -0.20, 0, Math.PI*2); ctx.fill();

  // Sparkle cross (sploop.io signature) — rotates slowly, pulses
  ctx.save();
  ctx.translate(R*.26, -R*.26 + bob);
  ctx.rotate(t * .055);
  const sl = R * (.13 + Math.sin(t * .09) * .025);
  ctx.strokeStyle = 'rgba(255,248,140,0.92)'; ctx.lineWidth = 1.8; ctx.lineCap = 'round';
  for (let i = 0; i < 4; i++) {
    const sa = i * Math.PI / 2;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(Math.cos(sa) * sl, Math.sin(sa) * sl);
    ctx.stroke();
  }
  ctx.restore();

  ctx.restore();
}

function _drawUltraAppleTree(ctx,x,y,R,t,hp){
  const prevQuality = typeof _qualityLevel === 'number' ? _qualityLevel : 2;
  // Fruit trees must never visually degrade regardless of device/FPS quality tier.
  if (prevQuality !== 2) {
    _qualityLevel = 2;
  }
  try {
    _drawUltraTree(ctx,x,y,R,'forest',t,hp);
  } finally {
    _qualityLevel = prevQuality;
  }

  ctx.save();ctx.translate(x,y);
  ctx.rotate(Math.sin(t*.018+x*.003)*.04);
  const applePos=[[-R*.28,-R*.48],[R*.12,-R*.58],[-R*.04,-R*.28],[R*.26,-R*.35],[-R*.36,-R*.22],[R*.04,-R*.72]];
  for(const[ax,ay] of applePos){
    ctx.fillStyle='#dd3030';ctx.strokeStyle='#880808';ctx.lineWidth=1.5;
    ctx.beginPath();ctx.arc(ax,ay,R*.095,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle='rgba(255,200,200,0.55)';
    ctx.beginPath();ctx.ellipse(ax-R*.04,ay-R*.04,R*.035,R*.025,-0.5,0,Math.PI*2);ctx.fill();
    ctx.strokeStyle='#442200';ctx.lineWidth=1.5;ctx.lineCap='round';
    ctx.beginPath();ctx.moveTo(ax,ay-R*.09);ctx.lineTo(ax+R*.02,ay-R*.15);ctx.stroke();
    ctx.fillStyle='#3a8820';
    ctx.beginPath();ctx.ellipse(ax+R*.05,ay-R*.155,R*.045,R*.025,0.5,0,Math.PI*2);ctx.fill();
  }
  ctx.restore();
}

function _drawUltraBush(ctx,x,y,R,biome,t){
  // PERF: quality=0 fast-path
  if (_qualityLevel === 0) {
    const fc = {forest:'#4e9e22',snow:'#a0c8d8',desert:'#8a7830',swamp:'#2a4e18',darkforest:'#2a0838'}[biome]||'#4e9e22';
    ctx.fillStyle = fc; ctx.strokeStyle = '#1a3008'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(x, y, R, 0, Math.PI*2); ctx.fill(); ctx.stroke();
    return;
  }
  ctx.save();ctx.translate(x,y);
  ctx.rotate(Math.sin(t*.022+x*.004)*.03);
  ctx.fillStyle='rgba(0,0,0,0.13)';
  ctx.beginPath();ctx.ellipse(R*.08,R*.45,R*.78,R*.2,0,0,Math.PI*2);ctx.fill();
  const bc={forest:['#6ac438','#4e9e22','#82dc50','#3a7a10'],snow:['#c8e8f0','#a0c8d8','#dff2ff','#7aabbb'],desert:['#b8a858','#8a7830','#d8c878','#6a5818'],swamp:['#4a7030','#2a4e18','#5a8838','#1a3008'],darkforest:['#3a1858','#2a0838','#5a2880','#180420']}[biome]||['#6ac438','#4e9e22','#82dc50','#3a7a10'];
  const _bushBlobs=[[0,0,R],[-R*.42,R*.05,R*.68],[R*.42,R*.05,R*.68],[-R*.22,-R*.22,R*.6],[R*.22,-R*.22,R*.6],[0,-R*.35,R*.52]];
  for(let _bIdx=0;_bIdx<_bushBlobs.length;_bIdx++){const[cx,cy,cr]=_bushBlobs[_bIdx];
    // quality>=2: full gradient; quality=1: flat mid-tone (saves 6 createRadialGradient calls/bush)
    const cg=_qualityLevel>=2?_resGrd('bush_'+biome+'_'+(R|0)+'_'+_bIdx,()=>{const g=ctx.createRadialGradient(cx-cr*.22,cy-cr*.25,0,cx,cy,cr);g.addColorStop(0,bc[2]);g.addColorStop(0.5,bc[0]);g.addColorStop(1,bc[1]);return g;}):null;
    ctx.fillStyle=cg||bc[0];ctx.strokeStyle=bc[3];ctx.lineWidth=2.5;
    ctx.beginPath();ctx.arc(cx,cy,cr,0,Math.PI*2);ctx.fill();ctx.stroke();
  }
  if(biome==='forest'||biome==='swamp'){
    const berryCol=biome==='forest'?'#cc2222':'#8822aa';
    for(const[bx,by] of[[-R*.18,-R*.05],[R*.28,-R*.08],[-R*.35,R*.1],[R*.08,-R*.28],[R*.42,R*.1],[-R*.08,R*.15]]){
      ctx.fillStyle=berryCol;ctx.strokeStyle='rgba(0,0,0,0.3)';ctx.lineWidth=1;
      ctx.beginPath();ctx.arc(bx,by,R*.1,0,Math.PI*2);ctx.fill();ctx.stroke();
      ctx.fillStyle='rgba(255,200,200,0.5)';
      ctx.beginPath();ctx.arc(bx-R*.04,by-R*.04,R*.035,0,Math.PI*2);ctx.fill();
    }
  }
  if(biome==='snow'){
    for(const[bx,by] of[[-R*.2,-R*.1],[R*.25,-R*.15],[R*.05,R*.1]]){
      ctx.fillStyle='#ffaacc';ctx.strokeStyle='#cc4488';ctx.lineWidth=1;
      ctx.beginPath();ctx.arc(bx,by,R*.1,0,Math.PI*2);ctx.fill();ctx.stroke();
    }
    ctx.fillStyle='rgba(220,240,255,0.52)';
    ctx.beginPath();ctx.ellipse(-R*.05,-R*.32,R*.38,R*.15,0,0,Math.PI*2);ctx.fill();
  }
  ctx.fillStyle=`rgba(255,255,255,${0.07+Math.sin(t*.04)*.04})`;
  ctx.beginPath();ctx.ellipse(-R*.2,-R*.28,R*.32,R*.18,-0.4,0,Math.PI*2);ctx.fill();
  ctx.restore();
}

function _drawUltraMushroom(ctx,x,y,R,t){
  // PERF: quality=0 fast-path
  if (_qualityLevel === 0) {
    ctx.fillStyle='#dd2200'; ctx.strokeStyle='#550800'; ctx.lineWidth=3;
    ctx.beginPath(); ctx.arc(x, y, R*.7, 0, Math.PI*2); ctx.fill(); ctx.stroke();
    return;
  }
  ctx.save();ctx.translate(x,y);
  const bob=Math.sin(t*.04)*R*.025;
  const sg=_resGrd('mush_stem_'+(R|0),()=>{const g=ctx.createLinearGradient(-R*.15,0,R*.15,0);g.addColorStop(0,'#c8b890');g.addColorStop(0.4,'#e8d8b0');g.addColorStop(1,'#a89870');return g;});
  ctx.fillStyle=sg;ctx.strokeStyle='#7a6840';ctx.lineWidth=2;
  ctx.beginPath();ctx.roundRect(-R*.15,R*.05+bob,R*.3,R*.38,4);ctx.fill();ctx.stroke();
  ctx.strokeStyle='#c0a870';ctx.lineWidth=2.5;
  ctx.beginPath();ctx.ellipse(0,R*.16+bob,R*.18,R*.06,0,0,Math.PI*2);ctx.stroke();
  // Cap gradient: cached by radius
  const capG = _resGrd('mush_cap_'+(R|0), ()=>{ const g=ctx.createRadialGradient(-R*.2,-R*.35,0,0,-R*.1,R*.5); g.addColorStop(0,'#ff6644'); g.addColorStop(0.35,'#dd2200'); g.addColorStop(0.7,'#aa1800'); g.addColorStop(1,'#660e00'); return g; });
  ctx.fillStyle=capG;ctx.strokeStyle='#550800';ctx.lineWidth=3;
  ctx.beginPath();
  ctx.moveTo(-R*.52,R*.06+bob);
  ctx.quadraticCurveTo(-R*.42,R*.06+bob,-R*.5,-R*.05+bob);
  ctx.quadraticCurveTo(-R*.22,-R*.88+bob,0,-R*.92+bob);
  ctx.quadraticCurveTo(R*.22,-R*.88+bob,R*.5,-R*.05+bob);
  ctx.quadraticCurveTo(R*.42,R*.06+bob,R*.52,R*.06+bob);
  ctx.closePath();ctx.fill();ctx.stroke();
  ctx.fillStyle='rgba(255,220,200,0.45)';
  ctx.beginPath();ctx.moveTo(-R*.52,R*.06+bob);ctx.lineTo(-R*.18,R*.09+bob);ctx.lineTo(R*.18,R*.09+bob);ctx.lineTo(R*.52,R*.06+bob);ctx.quadraticCurveTo(0,R*.2+bob,-R*.52,R*.06+bob);ctx.fill();
  ctx.fillStyle='rgba(255,255,255,0.88)';ctx.strokeStyle='rgba(200,200,200,0.3)';ctx.lineWidth=1;
  for(const[sx,sy,sr] of[[-R*.12,-R*.48+bob,R*.1],[R*.24,-R*.35+bob,R*.13],[-R*.3,-R*.25+bob,R*.09],[R*.05,-R*.62+bob,R*.08],[R*.32,-R*.18+bob,R*.07]]){
    ctx.beginPath();ctx.arc(sx,sy,sr,0,Math.PI*2);ctx.fill();ctx.stroke();
  }
  ctx.fillStyle='rgba(255,200,180,0.38)';
  ctx.beginPath();ctx.ellipse(-R*.18,-R*.55+bob,R*.16,R*.1,-0.4,0,Math.PI*2);ctx.fill();
  ctx.save();ctx.globalAlpha=0.3+Math.sin(t*.06)*.14;ctx.fillStyle='#44ff88';
  ctx.beginPath();ctx.arc(0,-R*.1+bob,R*.55,0,Math.PI*2);ctx.fill();ctx.restore();
  ctx.restore();
}

function _drawUltraCrystal(ctx,x,y,R,t){
  // PERF: quality=0 fast-path
  if (_qualityLevel === 0) {
    ctx.fillStyle='#2266cc'; ctx.strokeStyle='#2255bb'; ctx.lineWidth=2;
    ctx.beginPath(); ctx.arc(x, y, R*.88, 0, Math.PI*2); ctx.fill(); ctx.stroke();
    return;
  }
  ctx.save();ctx.translate(x,y);
  const pulse=Math.sin(t*.07)*.1+0.9;
  const cgg=_resGrd('crystal_glow_'+(R|0),()=>{ const g=ctx.createRadialGradient(0,0,0,0,0,R*1.4); g.addColorStop(0,'rgba(100,200,255,0.32)'); g.addColorStop(1,'rgba(60,120,200,0)'); return g; });
  ctx.fillStyle=cgg;ctx.beginPath();ctx.arc(0,0,R*1.4,0,Math.PI*2);ctx.fill();
  const _crShards=[{x:-R*.2,y:0,h:R*.88,w:R*.18,a:-0.15,c1:'#aaeeff',c2:'#2266cc'},{x:R*.08,y:R*.05,h:R*1.05,w:R*.22,a:0.05,c1:'#ddeeff',c2:'#1144aa'},{x:R*.32,y:0,h:R*.72,w:R*.16,a:0.2,c1:'#88ccff',c2:'#3388dd'}];
  for(let _si=0;_si<_crShards.length;_si++){const sh=_crShards[_si];
    ctx.save();ctx.translate(sh.x,sh.y);ctx.rotate(sh.a);
    const shg=_resGrd('crystal_shard_'+(R|0)+'_'+_si,()=>{ const g=ctx.createLinearGradient(-sh.w,-sh.h,sh.w,0); g.addColorStop(0,sh.c1); g.addColorStop(0.4,sh.c1); g.addColorStop(0.7,sh.c2); g.addColorStop(1,'#001144'); return g; });
    ctx.fillStyle=shg;ctx.strokeStyle='#2255bb';ctx.lineWidth=2;ctx.globalAlpha=0.92;
    ctx.beginPath();ctx.moveTo(0,-sh.h*pulse);ctx.lineTo(sh.w,0);ctx.lineTo(sh.w*.6,sh.h*.28);ctx.lineTo(-sh.w*.6,sh.h*.28);ctx.lineTo(-sh.w,0);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.fillStyle='rgba(220,240,255,0.55)';
    ctx.beginPath();ctx.moveTo(-sh.w*.4,-sh.h*.7*pulse);ctx.lineTo(-sh.w*.1,-sh.h*.9*pulse);ctx.lineTo(-sh.w*.05,-sh.h*.4*pulse);ctx.closePath();ctx.fill();
    ctx.restore();
  }
  ctx.save();ctx.rotate(t*.05);
  ctx.strokeStyle='rgba(180,240,255,0.85)';ctx.lineWidth=1.5;ctx.lineCap='round';
  for(let i=0;i<4;i++){const a=i*Math.PI/2;ctx.beginPath();ctx.moveTo(0,-R*.88*pulse);ctx.lineTo(Math.cos(a+Math.PI/2)*R*.18,-R*.88*pulse+Math.sin(a+Math.PI/2)*R*.18);ctx.stroke();}
  ctx.restore();ctx.restore();
}

function _drawUltraHive(ctx,x,y,R,t){
  // PERF: quality=0 fast-path
  if (_qualityLevel === 0) {
    ctx.fillStyle='#d4960a'; ctx.strokeStyle='#5a3600'; ctx.lineWidth=3;
    ctx.beginPath(); ctx.ellipse(x, y, R*.68, R*.82, 0, 0, Math.PI*2); ctx.fill(); ctx.stroke();
    return;
  }
  ctx.save();ctx.translate(x,y);
  ctx.rotate(Math.sin(t*.03+x*.002)*.06);
  ctx.strokeStyle='#8a6020';ctx.lineWidth=2;ctx.lineCap='round';
  ctx.beginPath();ctx.moveTo(0,-R*.85);ctx.lineTo(0,-R*1.35);ctx.stroke();
  ctx.beginPath();ctx.moveTo(-R*.2,-R*.82);ctx.lineTo(-R*.08,-R*1.28);ctx.stroke();
  ctx.beginPath();ctx.moveTo(R*.2,-R*.82);ctx.lineTo(R*.08,-R*1.28);ctx.stroke();
  const hg=_resGrd('hive_'+(R|0),()=>{ const g=ctx.createRadialGradient(-R*.18,-R*.22,0,0,-R*.05,R*.75); g.addColorStop(0,'#f5c842'); g.addColorStop(0.4,'#d4960a'); g.addColorStop(0.75,'#8a5a00'); g.addColorStop(1,'#4a2800'); return g; });
  ctx.fillStyle=hg;ctx.strokeStyle='#5a3600';ctx.lineWidth=4;
  ctx.beginPath();ctx.ellipse(0,-R*.05,R*.68,R*.82,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.strokeStyle='rgba(0,0,0,0.18)';ctx.lineWidth=2;
  for(let i=-2;i<=2;i++){const bY=i*R*.26-R*.05;const bW=Math.min(R*.65,Math.sqrt(Math.max(0,(R*.65)**2-(bY*1.1)**2)));ctx.beginPath();ctx.moveTo(-bW,bY);ctx.lineTo(bW,bY);ctx.stroke();}
  ctx.strokeStyle='rgba(180,100,0,0.32)';ctx.lineWidth=1.5;
  for(const[hx,hy] of[[0,-R*.3],[R*.18,-R*.12],[-R*.18,-R*.12],[0,R*.1],[R*.22,R*.22],[-R*.22,R*.22],[0,-R*.5]]){
    const hr=R*.14;ctx.beginPath();
    for(let i=0;i<6;i++){const a=i/6*Math.PI*2+Math.PI/6;ctx.lineTo(hx+Math.cos(a)*hr,hy+Math.sin(a)*hr);}
    ctx.closePath();ctx.stroke();
  }
  ctx.fillStyle='#2a1200';ctx.strokeStyle='#1a0800';ctx.lineWidth=2;
  ctx.beginPath();ctx.ellipse(R*.12,R*.22,R*.14,R*.1,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  const drip=(Math.sin(t*.04)+1)*.5;
  ctx.fillStyle='#f0a020';ctx.strokeStyle='#c07010';ctx.lineWidth=1.5;
  ctx.beginPath();ctx.ellipse(R*.12,R*.32+drip*R*.12,R*.06,R*.06+drip*R*.06,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle='#f5c842';
  for(let i=0;i<3;i++){
    const ba=t*.08+i*2.094;const br=R*(.82+Math.sin(t*.12+i)*.14);
    const bx2=Math.cos(ba)*br;const by2=Math.sin(ba)*br*.6-R*.1;
    ctx.beginPath();ctx.ellipse(bx2,by2,R*.06,R*.04,ba,0,Math.PI*2);ctx.fill();
    ctx.strokeStyle='rgba(0,0,0,0.45)';ctx.lineWidth=0.8;
    ctx.beginPath();ctx.moveTo(bx2-R*.04,by2-R*.04);ctx.lineTo(bx2+R*.04,by2-R*.04);ctx.stroke();
  }
  ctx.save();ctx.globalAlpha=0.18+Math.sin(t*.06)*.08;ctx.fillStyle='#ffcc00';
  ctx.beginPath();ctx.arc(0,-R*.05,R*.82,0,Math.PI*2);ctx.fill();ctx.restore();
  ctx.restore();
}

// Bake procedural resources once (moomoo/sploop style) — blit instead of 20+ path ops per tree per frame.
const _resBakeCache = new Map();
function _getBakedResource(type, biome, R) {
  const q = type === 'apple' ? 2 : (_qualityLevel >= 2 ? 2 : 1);
  const key = type + '|' + (biome || '') + '|' + (R | 0) + '|' + q;
  let baked = _resBakeCache.get(key);
  if (baked) return baked;
  const pad = Math.ceil(Math.max(24, R * 2.4));
  const size = pad * 2;
  const cnv = document.createElement('canvas');
  cnv.width = size;
  cnv.height = size;
  const c = cnv.getContext('2d');
  _bakingResource = true;
  try {
    if (type === 'wood') _drawUltraTree(c, pad, pad, R, biome, 0, 1);
    else if (type === 'stone') _drawUltraRock(c, pad, pad, R, biome, 1);
    else if (type === 'gold') _drawUltraGold(c, pad, pad, R, biome, 0);
    else if (type === 'apple') _drawUltraAppleTree(c, pad, pad, R, 0, 1);
    else if (type === 'bush') _drawUltraBush(c, pad, pad, R, biome, 0);
    else if (type === 'mushroom') _drawUltraMushroom(c, pad, pad, R, 0);
    else if (type === 'crystal') _drawUltraCrystal(c, pad, pad, R, 0);
    else if (type === 'hive') _drawUltraHive(c, pad, pad, R, 0);
    else _drawUltraTree(c, pad, pad, R, biome, 0, 1);
  } catch (_be) {
    _bakingResource = false;
    return null;
  }
  _bakingResource = false;
  baked = { cnv: cnv, pad: pad };
  _resBakeCache.set(key, baked);
  return baked;
}

// ============================================================
// DRAWING HELPERS
// ============================================================


// Draw HP bar helper — moomoo.io style chunky bar
function drawHpBar(x, y, hp, maxHp, width, above, alwaysShow) {
  if (!(maxHp > 0)) return;
  const pct = Math.max(0, Math.min(1, hp / maxHp));
  // PERF: skip entirely for full-health entities — saves 4 draw calls per full-HP mob/player
  if (pct >= 1 && !alwaysShow) return;
  const yy = above ? y - above : y;
  const hw = width / 2;
  const h = 9;
  ctx.fillStyle = 'rgba(0,0,0,0.72)';
  ctx.beginPath(); ctx.roundRect(x - hw - 2, yy - 2, width + 4, h + 4, 3); ctx.fill();
  // PERF: use pre-built 256-step color table — zero string alloc vs rgb(${r},${g},40) per call
  ctx.fillStyle = _bHpColors[Math.min(255, pct * 255 | 0)];
  if (pct > 0) {
    ctx.beginPath(); ctx.roundRect(x - hw, yy, width * pct, h, 2); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.22)';
    ctx.beginPath(); ctx.roundRect(x - hw + 1, yy + 1, Math.max(0, width * pct - 2), 2, 1); ctx.fill();
  }
  ctx.strokeStyle = '#1a1a1a'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.roundRect(x - hw - 2, yy - 2, width + 4, h + 4, 3); ctx.stroke();
}

function _getWmOC(tier, _mp, tpL, tpD, tpA, tpB) {
  if (_wmOC.has(tier)) return _wmOC.get(tier);
  const blades = [4,4,6,6,6,8][tier]||4;

  // Base disc (100×100, center at 50,50) — completely different shape per tier
  const baseOC = createRenderCanvas(100, 100);
  const bc = baseOC.getContext('2d');
  bc.translate(50, 50);
  switch(tier){
    case 0:{ // Tahta — rough wooden platform
      const sb=bc.createRadialGradient(0,3,6,0,3,42); sb.addColorStop(0,'#9b6a38'); sb.addColorStop(1,'#5c3a1a');
      bc.fillStyle=sb; bc.strokeStyle='#3a1e06'; bc.lineWidth=4;
      bc.beginPath(); bc.arc(0,0,40,0,Math.PI*2); bc.fill(); bc.stroke();
      bc.strokeStyle='rgba(0,0,0,0.2)'; bc.lineWidth=2;
      for(let i=0;i<6;i++){bc.beginPath();bc.moveTo(Math.cos(i*Math.PI/3)*16,Math.sin(i*Math.PI/3)*16);bc.lineTo(Math.cos(i*Math.PI/3)*38,Math.sin(i*Math.PI/3)*38);bc.stroke();}
      const mb=bc.createRadialGradient(-4,-4,0,0,0,22); mb.addColorStop(0,'#c8944c'); mb.addColorStop(1,'#7a4a1e');
      bc.fillStyle=mb; bc.strokeStyle='#3a1e06'; bc.lineWidth=4;
      bc.beginPath(); bc.arc(0,0,22,0,Math.PI*2); bc.fill(); bc.stroke();
      break;}
    case 1:{ // Altın — ornate gold platform with decorative ring
      const sb=bc.createRadialGradient(0,2,8,0,2,42); sb.addColorStop(0,'#ffe082'); sb.addColorStop(0.6,'#FFD700'); sb.addColorStop(1,'#8B6914');
      bc.fillStyle=sb; bc.strokeStyle='#5a3000'; bc.lineWidth=4;
      bc.beginPath(); bc.arc(0,0,40,0,Math.PI*2); bc.fill(); bc.stroke();
      bc.strokeStyle='rgba(255,255,200,0.4)'; bc.lineWidth=1.5;
      for(let i=0;i<8;i++){bc.beginPath();bc.moveTo(0,0);bc.lineTo(Math.cos(i*Math.PI/4)*38,Math.sin(i*Math.PI/4)*38);bc.stroke();}
      bc.strokeStyle='#c9920c'; bc.lineWidth=2; bc.beginPath(); bc.arc(0,0,28,0,Math.PI*2); bc.stroke();
      // ornate bolts
      bc.fillStyle='#fff9c4'; for(let i=0;i<8;i++){bc.beginPath();bc.arc(Math.cos(i*Math.PI/4)*28,Math.sin(i*Math.PI/4)*28,3,0,Math.PI*2);bc.fill();}
      const mb=bc.createRadialGradient(-4,-4,0,0,0,20); mb.addColorStop(0,'#ffe082'); mb.addColorStop(1,'#c9920c');
      bc.fillStyle=mb; bc.strokeStyle='#5a3000'; bc.lineWidth=4;
      bc.beginPath(); bc.arc(0,0,20,0,Math.PI*2); bc.fill(); bc.stroke();
      break;}
    case 2:{ // Elmas — crystal hexagonal base
      bc.fillStyle='rgba(13,71,161,0.5)'; bc.strokeStyle='#0288d1'; bc.lineWidth=4;
      bc.beginPath(); for(let i=0;i<6;i++){const a=i*Math.PI/3;bc.lineTo(Math.cos(a)*40,Math.sin(a)*40);} bc.closePath(); bc.fill(); bc.stroke();
      // facet lines
      bc.strokeStyle='rgba(179,229,252,0.45)'; bc.lineWidth=1.5;
      for(let i=0;i<6;i++){bc.beginPath();bc.moveTo(0,0);bc.lineTo(Math.cos(i*Math.PI/3)*38,Math.sin(i*Math.PI/3)*38);bc.stroke();}
      bc.strokeStyle='rgba(179,229,252,0.7)'; bc.lineWidth=2; bc.beginPath(); bc.arc(0,0,22,0,Math.PI*2); bc.stroke();
      const mb=bc.createRadialGradient(-4,-4,0,0,0,18); mb.addColorStop(0,'rgba(255,255,255,0.95)'); mb.addColorStop(0.4,'rgba(179,229,252,0.9)'); mb.addColorStop(1,'rgba(40,130,200,0.6)');
      bc.fillStyle=mb; bc.strokeStyle='#0288d1'; bc.lineWidth=3;
      bc.beginPath(); bc.arc(0,0,18,0,Math.PI*2); bc.fill(); bc.stroke();
      break;}
    case 3:{ // Ametist — arcane circle with runic inscriptions
      bc.fillStyle='rgba(74,20,140,0.6)'; bc.strokeStyle='#aa00ff'; bc.lineWidth=4;
      bc.beginPath(); bc.arc(0,0,40,0,Math.PI*2); bc.fill(); bc.stroke();
      // inner rings
      bc.strokeStyle='rgba(206,147,216,0.5)'; bc.lineWidth=2;
      bc.beginPath(); bc.arc(0,0,30,0,Math.PI*2); bc.stroke();
      bc.beginPath(); bc.arc(0,0,18,0,Math.PI*2); bc.stroke();
      // rune marks
      bc.strokeStyle='rgba(234,128,252,0.55)'; bc.lineWidth=1.5;
      for(let i=0;i<6;i++){const a=i*Math.PI/3;bc.beginPath();bc.moveTo(Math.cos(a)*18,Math.sin(a)*18);bc.lineTo(Math.cos(a)*30,Math.sin(a)*30);bc.stroke();}
      const mb=bc.createRadialGradient(-3,-3,0,0,0,16); mb.addColorStop(0,'#e040fb'); mb.addColorStop(1,'#4a148c');
      bc.fillStyle=mb; bc.strokeStyle='#aa00ff'; bc.lineWidth=3;
      bc.beginPath(); bc.arc(0,0,16,0,Math.PI*2); bc.fill(); bc.stroke();
      break;}
    case 4:{ // Reidite — sci-fi tech platform (square + hex circuit)
      bc.fillStyle='rgba(0,60,0,0.7)'; bc.strokeStyle='#00e676'; bc.lineWidth=4;
      bc.beginPath(); bc.roundRect(-38,-38,76,76,8); bc.fill(); bc.stroke();
      // circuit grid
      bc.strokeStyle='rgba(0,230,118,0.3)'; bc.lineWidth=1;
      for(let i=-28;i<=28;i+=14){bc.beginPath();bc.moveTo(i,-38);bc.lineTo(i,38);bc.stroke();bc.beginPath();bc.moveTo(-38,i);bc.lineTo(38,i);bc.stroke();}
      bc.strokeStyle='#00e676'; bc.lineWidth=2; bc.beginPath(); bc.arc(0,0,24,0,Math.PI*2); bc.stroke();
      // LED nodes
      bc.fillStyle='#b9f6ca'; for(let i=0;i<4;i++){const a=i*Math.PI/2;bc.beginPath();bc.arc(Math.cos(a)*24,Math.sin(a)*24,4,0,Math.PI*2);bc.fill();}
      const mb=bc.createRadialGradient(-3,-3,0,0,0,16); mb.addColorStop(0,'#b9f6ca'); mb.addColorStop(1,'#003300');
      bc.fillStyle=mb; bc.strokeStyle='#00e676'; bc.lineWidth=3;
      bc.beginPath(); bc.arc(0,0,16,0,Math.PI*2); bc.fill(); bc.stroke();
      break;}
    case 5:{ // Nihai — celestial star mandala platform
      // outer star
      bc.fillStyle='rgba(26,35,126,0.5)'; bc.beginPath(); bc.arc(0,0,42,0,Math.PI*2); bc.fill();
      bc.strokeStyle='rgba(197,202,233,0.7)'; bc.lineWidth=2;
      bc.beginPath(); for(let i=0;i<8;i++){const a=i*Math.PI/4,r=i%2===0?40:24;bc.lineTo(Math.cos(a)*r,Math.sin(a)*r);} bc.closePath(); bc.fill(); bc.stroke();
      // inner rings
      for(const r of[30,20]){bc.beginPath();bc.arc(0,0,r,0,Math.PI*2);bc.stroke();}
      // ray lines
      bc.strokeStyle='rgba(197,202,233,0.4)'; bc.lineWidth=1;
      for(let i=0;i<8;i++){bc.beginPath();bc.moveTo(0,0);bc.lineTo(Math.cos(i*Math.PI/4)*38,Math.sin(i*Math.PI/4)*38);bc.stroke();}
      const mb=bc.createRadialGradient(-3,-3,0,0,0,15); mb.addColorStop(0,'#fff'); mb.addColorStop(0.4,'rgba(197,202,233,0.9)'); mb.addColorStop(1,'rgba(121,134,203,0.6)');
      bc.fillStyle=mb; bc.strokeStyle='rgba(197,202,233,0.9)'; bc.lineWidth=3;
      bc.beginPath(); bc.arc(0,0,15,0,Math.PI*2); bc.fill(); bc.stroke();
      break;}
  }

  // Single blade (70×40, arm y-center at y=20) — different shape per tier
  const sailH=[40,40,44,44,44,44][tier];
  const sailOC = createRenderCanvas(70, sailH);
  const sc = sailOC.getContext('2d');
  sc.translate(0, sailH/2);
  switch(tier){
    case 0:{ // Wooden plank sail
      const arm=sc.createLinearGradient(0,-4,56,-4); arm.addColorStop(0,'#7a4a1e'); arm.addColorStop(0.5,'#9b6a38'); arm.addColorStop(1,'#7a4a1e');
      sc.fillStyle=arm; sc.strokeStyle='#3a1e06'; sc.lineWidth=2;
      sc.beginPath(); sc.roundRect(0,-5,54,10,2); sc.fill(); sc.stroke();
      sc.fillStyle='#c8a870'; sc.strokeStyle='#5c3a1a'; sc.lineWidth=1.5;
      sc.beginPath(); sc.roundRect(14,-20,34,16,2); sc.fill(); sc.stroke();
      // plank lines
      sc.strokeStyle='rgba(0,0,0,0.15)'; sc.lineWidth=1;
      for(const x of[23,34]){sc.beginPath();sc.moveTo(x,-20);sc.lineTo(x,-5);sc.stroke();}
      break;}
    case 1:{ // Gold ornate sail with decorative border
      const arm=sc.createLinearGradient(0,-4,56,-4); arm.addColorStop(0,'#8B6914'); arm.addColorStop(0.5,'#c9a027'); arm.addColorStop(1,'#8B6914');
      sc.fillStyle=arm; sc.strokeStyle='#5a3000'; sc.lineWidth=2;
      sc.beginPath(); sc.roundRect(0,-5,56,10,2); sc.fill(); sc.stroke();
      const sail=sc.createLinearGradient(14,-22,50,-22); sail.addColorStop(0,'#c9920c'); sail.addColorStop(0.3,'#FFD700'); sail.addColorStop(0.6,'#ffe082'); sail.addColorStop(1,'#c9920c');
      sc.fillStyle=sail; sc.strokeStyle='#5a3000'; sc.lineWidth=1.5;
      sc.beginPath(); sc.roundRect(14,-22,38,18,3); sc.fill(); sc.stroke();
      sc.strokeStyle='rgba(255,255,200,0.6)'; sc.lineWidth=1;
      for(const x of[24,38]){sc.beginPath();sc.moveTo(x,-22);sc.lineTo(x,-5);sc.stroke();}
      // gold rivet
      sc.fillStyle='#fff9c4'; sc.beginPath(); sc.arc(52,-4,3,0,Math.PI*2); sc.fill();
      break;}
    case 2:{ // Crystal diamond-shaped blade
      const arm=sc.createLinearGradient(0,-4,56,-4); arm.addColorStop(0,'#1565c0'); arm.addColorStop(0.5,'#42a5f5'); arm.addColorStop(1,'#1565c0');
      sc.fillStyle=arm; sc.strokeStyle='#0a2d6b'; sc.lineWidth=2;
      sc.beginPath(); sc.roundRect(0,-4,56,8,2); sc.fill(); sc.stroke();
      // kite-shaped crystal blade
      const cg=sc.createLinearGradient(14,-24,52,-24); cg.addColorStop(0,'rgba(40,130,200,0.6)'); cg.addColorStop(0.3,'rgba(255,255,255,0.96)'); cg.addColorStop(0.7,'rgba(179,229,252,0.9)'); cg.addColorStop(1,'rgba(40,130,200,0.6)');
      sc.fillStyle=cg; sc.strokeStyle='#0288d1'; sc.lineWidth=1.5;
      sc.beginPath(); sc.moveTo(14,-2); sc.lineTo(34,-24); sc.lineTo(54,-2); sc.lineTo(34,4); sc.closePath(); sc.fill(); sc.stroke();
      sc.strokeStyle='rgba(255,255,255,0.8)'; sc.lineWidth=1;
      sc.beginPath(); sc.moveTo(20,-4); sc.lineTo(34,-20); sc.lineTo(48,-4); sc.stroke();
      break;}
    case 3:{ // Amethyst curved crescent blade
      const arm=sc.createLinearGradient(0,-4,56,-4); arm.addColorStop(0,'#4a148c'); arm.addColorStop(0.5,'#9c27b0'); arm.addColorStop(1,'#4a148c');
      sc.fillStyle=arm; sc.strokeStyle='#2c0050'; sc.lineWidth=2;
      sc.beginPath(); sc.roundRect(0,-4,56,8,2); sc.fill(); sc.stroke();
      const ag=sc.createLinearGradient(14,-26,52,4); ag.addColorStop(0,'rgba(74,20,140,0)'); ag.addColorStop(0.3,'#9c27b0'); ag.addColorStop(0.6,'#e040fb'); ag.addColorStop(1,'rgba(234,128,252,0.8)');
      sc.fillStyle=ag; sc.strokeStyle='#7b1fa2'; sc.lineWidth=1.5;
      sc.beginPath(); sc.moveTo(14,-2); sc.quadraticCurveTo(30,-28,52,-8); sc.quadraticCurveTo(42,6,28,4); sc.quadraticCurveTo(22,4,14,-2); sc.closePath(); sc.fill(); sc.stroke();
      sc.strokeStyle='rgba(234,128,252,0.75)'; sc.lineWidth=1;
      sc.beginPath(); sc.moveTo(16,0); sc.quadraticCurveTo(32,-22,50,-6); sc.stroke();
      sc.fillStyle='#ea80fc'; sc.beginPath(); sc.arc(36,-14,3,0,Math.PI*2); sc.fill();
      break;}
    case 4:{ // Reidite curved tech turbine blade
      const arm=sc.createLinearGradient(0,-4,56,-4); arm.addColorStop(0,'#1b5e20'); arm.addColorStop(0.5,'#43a047'); arm.addColorStop(1,'#1b5e20');
      sc.fillStyle=arm; sc.strokeStyle='#003300'; sc.lineWidth=2;
      sc.beginPath(); sc.roundRect(0,-4,56,8,2); sc.fill(); sc.stroke();
      const pg=sc.createLinearGradient(14,-24,52,4); pg.addColorStop(0,'rgba(0,77,0,0.5)'); pg.addColorStop(0.4,'#00c853'); pg.addColorStop(0.7,'#b9f6ca'); pg.addColorStop(1,'rgba(0,200,83,0.6)');
      sc.fillStyle=pg; sc.strokeStyle='#00e676'; sc.lineWidth=1.5;
      sc.beginPath(); sc.moveTo(14,-2); sc.quadraticCurveTo(28,-26,52,-10); sc.quadraticCurveTo(46,6,30,4); sc.closePath(); sc.fill(); sc.stroke();
      // circuit lines
      sc.strokeStyle='rgba(185,246,202,0.65)'; sc.lineWidth=0.8;
      sc.beginPath(); sc.moveTo(18,0); sc.lineTo(28,-16); sc.lineTo(44,-8); sc.stroke();
      // LED tip
      sc.fillStyle='#b9f6ca'; sc.beginPath(); sc.arc(46,-10,3,0,Math.PI*2); sc.fill();
      break;}
    case 5:{ // Nihai — rainbow triangular celestial blade
      const arm=sc.createLinearGradient(0,-4,56,-4); arm.addColorStop(0,'#3949ab'); arm.addColorStop(0.5,'#7986cb'); arm.addColorStop(1,'#3949ab');
      sc.fillStyle=arm; sc.strokeStyle='#1a237e'; sc.lineWidth=2;
      sc.beginPath(); sc.roundRect(0,-4,56,8,2); sc.fill(); sc.stroke();
      // rainbow blade
      const ng=sc.createLinearGradient(14,-26,54,4); ng.addColorStop(0,'hsl(0,100%,60%)'); ng.addColorStop(0.25,'hsl(90,100%,60%)'); ng.addColorStop(0.5,'hsl(180,100%,65%)'); ng.addColorStop(0.75,'hsl(270,100%,65%)'); ng.addColorStop(1,'hsl(330,100%,60%)');
      sc.fillStyle=ng; sc.strokeStyle='rgba(255,255,255,0.6)'; sc.lineWidth=1.5;
      sc.beginPath(); sc.moveTo(14,-2); sc.lineTo(36,-26); sc.lineTo(54,-2); sc.lineTo(36,4); sc.closePath(); sc.fill(); sc.stroke();
      sc.strokeStyle='rgba(255,255,255,0.85)'; sc.lineWidth=1;
      sc.beginPath(); sc.moveTo(20,-2); sc.lineTo(36,-22); sc.lineTo(50,-2); sc.stroke();
      sc.fillStyle='rgba(255,255,255,0.9)'; sc.beginPath(); sc.arc(36,-16,3.5,0,Math.PI*2); sc.fill();
      break;}
  }

  // Hub center (30×30)
  const hubOC = createRenderCanvas(30, 30);
  const hc = hubOC.getContext('2d');
  hc.translate(15, 15);
  switch(tier){
    case 0:{ hc.fillStyle='#7a4a1e'; hc.strokeStyle='#3a1e06'; hc.lineWidth=2.5; hc.beginPath(); hc.arc(0,0,10,0,Math.PI*2); hc.fill(); hc.stroke(); hc.fillStyle='rgba(255,255,255,0.15)'; hc.beginPath(); hc.arc(-2,-2,4,0,Math.PI*2); hc.fill(); break;}
    case 1:{ const ch=hc.createRadialGradient(-3,-3,0,0,0,11); ch.addColorStop(0,'#ffe082'); ch.addColorStop(1,'#8B6914'); hc.fillStyle=ch; hc.strokeStyle='#5a3000'; hc.lineWidth=2.5; hc.beginPath(); hc.arc(0,0,11,0,Math.PI*2); hc.fill(); hc.stroke(); hc.fillStyle='#fff9c4'; hc.beginPath(); hc.arc(-2,-2,4,0,Math.PI*2); hc.fill(); break;}
    case 2:{ const ch=hc.createRadialGradient(-3,-3,0,0,0,11); ch.addColorStop(0,'rgba(255,255,255,0.98)'); ch.addColorStop(0.5,'rgba(179,229,252,0.95)'); ch.addColorStop(1,'rgba(40,130,200,0.7)'); hc.fillStyle=ch; hc.strokeStyle='#0288d1'; hc.lineWidth=2.5; hc.beginPath(); hc.arc(0,0,11,0,Math.PI*2); hc.fill(); hc.stroke(); hc.strokeStyle='rgba(255,255,255,0.7)'; hc.lineWidth=1; hc.beginPath(); hc.moveTo(0,-11); hc.lineTo(0,11); hc.stroke(); hc.beginPath(); hc.moveTo(-11,0); hc.lineTo(11,0); hc.stroke(); break;}
    case 3:{ hc.fillStyle='#9c27b0'; hc.strokeStyle='#aa00ff'; hc.lineWidth=2.5; hc.beginPath(); hc.arc(0,0,11,0,Math.PI*2); hc.fill(); hc.stroke(); hc.fillStyle='#e040fb'; hc.beginPath(); hc.arc(0,0,5,0,Math.PI*2); hc.fill(); hc.fillStyle='rgba(74,20,140,0.8)'; hc.beginPath(); hc.arc(0,0,2.5,0,Math.PI*2); hc.fill(); break;}
    case 4:{ const ch=hc.createRadialGradient(-3,-3,0,0,0,11); ch.addColorStop(0,'#b9f6ca'); ch.addColorStop(1,'#003300'); hc.fillStyle=ch; hc.strokeStyle='#00e676'; hc.lineWidth=2.5; hc.beginPath(); hc.arc(0,0,11,0,Math.PI*2); hc.fill(); hc.stroke(); hc.fillStyle='#fff'; hc.beginPath(); hc.arc(0,0,3,0,Math.PI*2); hc.fill(); break;}
    case 5:{ const ch=hc.createRadialGradient(-2,-2,0,0,0,12); ch.addColorStop(0,'#fff'); ch.addColorStop(0.4,'rgba(197,202,233,0.95)'); ch.addColorStop(1,'rgba(57,73,171,0.6)'); hc.fillStyle=ch; hc.strokeStyle='rgba(197,202,233,0.9)'; hc.lineWidth=2.5; hc.beginPath(); hc.arc(0,0,12,0,Math.PI*2); hc.fill(); hc.stroke(); hc.fillStyle='rgba(255,255,255,0.8)'; hc.beginPath(); for(let i=0;i<6;i++){const a=i*Math.PI/3,r=i%2===0?7:4;hc.lineTo(Math.cos(a)*r,Math.sin(a)*r);} hc.closePath(); hc.fill(); break;}
  }

  const cache = { base: baseOC, sail: sailOC, hub: hubOC, blades };
  _wmOC.set(tier, cache);
  return cache;
}

// ── Static building body cache ────────────────────────────────────────────────
// Pre-renders the immutable parts of each building (per type+tier) ONCE to an
// OffscreenCanvas.  Every subsequent frame we do a single drawImage() instead
// of re-creating 8-17 gradient objects.  Flush the entry on upgrade to force
// a re-render with the new tier palette.
const _wmOC = new Map();
const _bldSC = new Map();
const _B_TIER_PALETTES = [
  ['#b0b0b0','#787878','#e0e0e0','#9e9e9e','#333333','#aaaaaa'],
  ['#f5c842','#c9920c','#fff9c4','#f57f17','#5a3000','#ffd700'],
  ['#64b5f6','#1565c0','#e3f2fd','#0288d1','#0a2d6b','#42a8f5'],
  ['#ba68c8','#6a1b9a','#f3e5f5','#9c27b0','#2c0050','#e040fb'],
  ['#66bb6a','#1b5e20','#b9f6ca','#00c853','#003300','#00e676'],
  ['#e8eaf6','#7986cb','#ffffff','#c5cae9','#1a237e','#ffffff'],
];
function _getBldSC(key, w, h, cx, cy, drawFn) {
  if (_bldSC.has(key)) return _bldSC.get(key);
  const oc = createRenderCanvas(w, h);
  const c  = oc.getContext('2d');
  c.translate(cx, cy);
  drawFn(c);
  _bldSC.set(key, oc);
  return oc;
}

function drawBuilding(b, ghost) {
  ctx.save();
  let sX = 0, sY = 0;
  if (b.shake > 0) { sX = (Math.random()-0.5)*5; sY = (Math.random()-0.5)*5; b.shake--; }
  ctx.translate(b.x + sX, b.y + sY);
  if (ghost) {
    ctx.globalAlpha = 0.65;
  } else {
    if (typeof b.life === 'number' && b.life >= 0 && b.life < 24) {
      // ── TAMING.IO / IO SIGNATURE ELASTIC POP-IN SPRING ANIMATION ──
      const t = b.life / 24;
      const spring = 1 + Math.sin(t * Math.PI * 2.2) * (1 - t) * 0.38;
      const scale = Math.max(0.1, t < 0.2 ? (t / 0.2) * spring : spring);
      ctx.scale(scale, scale);

      // Expanding soft white placement shockwave ring
      if (b.life < 18) {
        const ringT = b.life / 18;
        const alpha = (1 - ringT) * 0.6;
        const radius = 18 + ringT * 60;
        ctx.save();
        ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
        ctx.lineWidth = 4 * (1 - ringT);
        ctx.beginPath();
        ctx.arc(0, 0, radius, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    }
    // ── VURUŞ ESNEMESİ (HIT WOBBLE DEFORMATION) ──
    if (b.hitTimer > 0) {
      b.hitTimer--;
      const wobbleProgress = b.hitTimer / 15;
      const wobbleX = 1 + Math.sin(b.hitTimer * 0.9) * 0.15 * wobbleProgress;
      const wobbleY = 1 - Math.sin(b.hitTimer * 0.9) * 0.15 * wobbleProgress;
      ctx.scale(wobbleX, wobbleY);
    }
  }

  const _bTier = _getTier(b);
  const _TP = _B_TIER_PALETTES[_bTier] || _B_TIER_PALETTES[0];
  const [tpL, tpD, tpA, tpAD, tpB, tpG] = _TP;

  if (b.type === 3) { // ══ SPIKE (KAZIK / DİKEN) — Premium Asset & Büyük Boyut (Gölgesiz) ══
    const spikeImg = _getBuildSprite('spike');
    if (spikeImg && spikeImg.complete && spikeImg.naturalWidth > 0) {
      ctx.drawImage(spikeImg, -56, -56, 112, 112);
    } else {
      ctx.drawImage(_getBldSC('sp_'+_bTier, 90, 90, 45, 45, (c) => {
        for(let i=0;i<4;i++){
          c.save(); c.rotate(i*Math.PI/2+Math.PI/4);
          c.fillStyle='#7a4a1e'; c.strokeStyle='#3a1e06'; c.lineWidth=2;
          c.beginPath(); c.moveTo(-5,5); c.lineTo(-3,-22); c.lineTo(0,-32); c.lineTo(3,-22); c.lineTo(5,5); c.closePath(); c.fill(); c.stroke();
          c.restore();
        }
        c.fillStyle='#5c3a1a'; c.strokeStyle='#2a0e06'; c.lineWidth=2;
        c.beginPath(); c.arc(0,0,8,0,Math.PI*2); c.fill(); c.stroke();
      }), -45, -45);
    }

  } else if (b.type === 4) { // ══ WINDMILL / DEĞİRMEN — 2 Parçalı & Sürekli Dönen Pervane (130x130, Gölgesiz) ══
    const baseImg = _getBuildSprite('windmill_base');
    const bladeImg = _getBuildSprite('windmill_blades');
    if (baseImg && baseImg.complete && baseImg.naturalWidth > 0) {
      // 1. Değirmen Gövdesi (Büyük Boyut: 130x130)
      ctx.drawImage(baseImg, -65, -65, 130, 130);
      // 2. Değirmen Üstünde Sürekli Dönen Pervane (60 FPS Akıcı Dönüş, 130x130)
      if (bladeImg && bladeImg.complete && bladeImg.naturalWidth > 0) {
        ctx.save();
        const rotAngle = ((b.life || 0) + globalTime) * 0.038;
        ctx.rotate(rotAngle);
        ctx.drawImage(bladeImg, -65, -65, 130, 130);
        ctx.restore();
      }
    } else {
      const _mp = [
        { arm0:'#6d4c41',arm1:'#8d6e63',body0:'#a1887f',body1:'#5d4037',bord:'#3e2723', sail0:'#f5f0e8',sail1:'#fffde7',sS:'#8d6e63' },
        { arm0:'#8B6914',arm1:'#c9a027',body0:'#c9a027',body1:'#8B6914',bord:'#5a3000', sail0:'#ffe082',sail1:'#fff9c4',sS:'#c9920c' },
        { arm0:'#1565c0',arm1:'#42a5f5',body0:'#1976d2',body1:'#0d47a1',bord:'#0a2d6b', sail0:'#e3f2fd',sail1:'#bbdefb',sS:'#1565c0' },
        { arm0:'#6a1b9a',arm1:'#ab47bc',body0:'#7b1fa2',body1:'#4a148c',bord:'#2c0050', sail0:'#f3e5f5',sail1:'#e1bee7',sS:'#7b1fa2' },
        { arm0:'#1b5e20',arm1:'#43a047',body0:'#2e7d32',body1:'#1b5e20',bord:'#003300', sail0:'#b9f6ca',sail1:'#69f0ae',sS:'#1b5e20' },
        { arm0:'#3949ab',arm1:'#7986cb',body0:'#9fa8da',body1:'#3f51b5',bord:'#1a237e', sail0:'#ffffff',sail1:'#e8eaf6',sS:'#3949ab' },
      ][_bTier];
      const _wmc = _getWmOC(_bTier, _mp, tpL, tpD, tpA, tpB);
      ctx.drawImage(_wmc.base, -58, -58);
      const _blCount = _wmc.blades;
      const _sailH = _wmc.sail.height;
      ctx.save(); ctx.rotate(b.life * 0.05);
      for (let i = 0; i < _blCount; i++) {
        ctx.save(); ctx.rotate(i * Math.PI * 2 / _blCount);
        ctx.drawImage(_wmc.sail, 0, -_sailH/2);
        ctx.restore();
      }
      ctx.restore();
      ctx.drawImage(_wmc.hub, -15, -15);
    }

  } else if (b.type === 5) { // ══ BOOST PAD / HIZ PEDİ — Büyük Boyut (130x130, Çizgisiz & Şık) ══
    const bpImg = _getBuildSprite('boostpad');
    ctx.save();
    ctx.rotate(b.angle || 0);
    if (bpImg && bpImg.complete && bpImg.naturalWidth > 0) {
      ctx.drawImage(bpImg, -65, -65, 130, 130);
      const pulse = 0.5 + 0.5 * Math.sin(b.life * 0.15);
      ctx.fillStyle = `rgba(255,255,255,${0.20 + pulse * 0.20})`;
      ctx.beginPath(); ctx.arc(0, 0, 16, 0, Math.PI * 2); ctx.fill();
    } else {
      ctx.drawImage(_getBldSC('bp_'+_bTier, 130, 90, 65, 45, (c) => {
        const wg=c.createLinearGradient(-54,-36,54,36); wg.addColorStop(0,'#4a90e2'); wg.addColorStop(0.5,'#50e3c2'); wg.addColorStop(1,'#357abd');
        c.fillStyle=wg; c.strokeStyle='#1a365d'; c.lineWidth=4;
        c.beginPath(); c.roundRect(-54,-36,108,72,8); c.fill(); c.stroke();
      }), -65, -45);
    }
    ctx.restore();

  } else if (b.type === 6) { // ══ TRAP / TUZAK (Ayı Tuzağı) — Büyük ve Belirgin Boyut (156x156) ══
    const trapImg = _getBuildSprite('beartrap');
    if (trapImg && trapImg.complete && trapImg.naturalWidth > 0) {
      ctx.drawImage(trapImg, -78, -78, 156, 156);
    } else {
      ctx.drawImage(_getBldSC('tr_'+_bTier, 156, 156, 78, 78, (c) => {
        c.fillStyle='#8a6020'; c.strokeStyle='#3a1e06'; c.lineWidth=5;
        c.beginPath(); c.arc(0,0,50,0,Math.PI*2); c.fill(); c.stroke();
        c.fillStyle='#1a0808'; c.beginPath(); c.arc(0,0,36,0,Math.PI*2); c.fill();
      }), -78, -78);
    }

  } else if (b.type === 7) { // ══ TURRET / TARET — Premium Asset (116x116, Gölgesiz) ══
    const turretImg = _getBuildSprite('turret');
    if (turretImg && turretImg.complete && turretImg.naturalWidth > 0) {
      ctx.drawImage(turretImg, -58, -58, 116, 116);
      
      const barrelA = b._barrelAngle || b.angle || 0;
      ctx.save();
      ctx.rotate(barrelA);
      ctx.fillStyle = '#1e293b';
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.roundRect(10, -7, 30, 14, 3); ctx.fill(); ctx.stroke();
      if ((b._muzzleFlash || 0) > 0) {
        b._muzzleFlash--;
        ctx.fillStyle = '#ffaa00';
        ctx.beginPath(); ctx.arc(42, 0, 10, 0, Math.PI * 2); ctx.fill();
      }
      ctx.restore();
    } else {
      ctx.drawImage(_getBldSC('tu_'+_bTier, 100, 90, 50, 46, (c) => {
        c.fillStyle='#888'; c.strokeStyle='#333'; c.lineWidth=2.5;
        c.beginPath(); c.roundRect(-10,-10,20,20,3); c.fill(); c.stroke();
      }), -50, -46);
    }

  } else if (b.type === 8) { // ══ WALL / DOOR (KAPI & DUVAR) — Premium Asset (115x115, Gölgesiz) ══
    const doorImg = _getBuildSprite('door');
    if (doorImg && doorImg.complete && doorImg.naturalWidth > 0) {
      ctx.drawImage(doorImg, -57, -57, 115, 115);
    } else {
      ctx.drawImage(_getBldSC('wa3_'+_bTier, 80, 80, 40, 40, (c) => {
        const pg0=c.createLinearGradient(-36,-34,36,34); pg0.addColorStop(0,'#c28040'); pg0.addColorStop(0.5,'#9b6a38'); pg0.addColorStop(1,'#7a4a1e');
        c.fillStyle=pg0; c.strokeStyle='#3a1e06'; c.lineWidth=4;
        c.beginPath(); c.roundRect(-36,-34,72,68,4); c.fill(); c.stroke();
      }), -40, -40);
    }

  } else if (b.type === 9) { // ══ HEAL PAD / CASTLE (ŞİFA PEDİ & KALE) — Premium Asset (130x130, Gölgesiz) ══
    const healImg = _getBuildSprite('healpad');
    if (healImg && healImg.complete && healImg.naturalWidth > 0) {
      // Canlı yeşil iyileşme aurası
      const pulseH = 0.5 + 0.5 * Math.sin(b.life * 0.1);
      ctx.fillStyle = `rgba(46, 204, 113, ${0.14 + pulseH * 0.14})`;
      ctx.beginPath(); ctx.arc(0, 0, 68, 0, Math.PI * 2); ctx.fill();
      ctx.drawImage(healImg, -65, -65, 130, 130);
    } else {
      ctx.drawImage(_getBldSC('ca_'+_bTier, 140, 150, 70, 80, (c) => {
        c.fillStyle='#7a4a1e'; c.strokeStyle='#3a1e06'; c.lineWidth=4;
        c.beginPath(); c.roundRect(-52,-52,104,104,4); c.fill(); c.stroke();
      }), -70, -80);
    }

  } else if (b.type === 10) { // ══ CAMPFIRE / KAMP ATEŞİ — different fire type per tier (Gölgesiz) ══
    const cf_t=b.life;
    ctx.drawImage(_getBldSC('cf_'+_bTier, 80, 80, 40, 40, (c) => {
      switch(_bTier) {
        case 0: { // Tahta — simple crossed logs + stone ring
          c.fillStyle='#888'; c.strokeStyle='#444'; c.lineWidth=1.5;
          for(let i=0;i<8;i++){const a=i/8*Math.PI*2;c.save();c.translate(Math.cos(a)*18,Math.sin(a)*18);c.rotate(a);c.beginPath();c.ellipse(0,0,5,3.5,0,0,Math.PI*2);c.fill();c.stroke();c.restore();}
          c.strokeStyle='#5a3010'; c.lineWidth=6; c.lineCap='round';
          c.beginPath();c.moveTo(-14,8);c.lineTo(14,-6);c.stroke();
          c.beginPath();c.moveTo(14,8);c.lineTo(-14,-6);c.stroke();
          break; }
        case 1: { // Altın — gold stone pit (ornate ring + cross logs + gold stones)
          c.fillStyle='#FFD700'; c.strokeStyle='#5a3000'; c.lineWidth=2;
          for(let i=0;i<6;i++){const a=i*Math.PI/3;c.save();c.translate(Math.cos(a)*18,Math.sin(a)*18);c.rotate(a);c.beginPath();c.ellipse(0,0,7,5,0,0,Math.PI*2);c.fill();c.stroke();c.restore();}
          c.strokeStyle='#6b4010'; c.lineWidth=6; c.lineCap='round';
          c.beginPath();c.moveTo(-14,8);c.lineTo(14,-6);c.stroke();
          c.beginPath();c.moveTo(14,8);c.lineTo(-14,-6);c.stroke();
          c.strokeStyle='#8B5E3C'; c.lineWidth=4;
          c.beginPath();c.moveTo(0,10);c.lineTo(0,-10);c.stroke();
          c.fillStyle='#fff9c4';
          for(let i=0;i<4;i++){const a=i*Math.PI/2;c.beginPath();c.arc(Math.cos(a)*18,Math.sin(a)*18,3.5,0,Math.PI*2);c.fill();}
          break; }
        case 2: { // Elmas — crystal blue-flame fire (crystal ring + glowing gem logs)
          c.fillStyle='rgba(179,229,252,0.6)'; c.strokeStyle='#0288d1'; c.lineWidth=2;
          for(let i=0;i<6;i++){const a=i*Math.PI/3;c.save();c.translate(Math.cos(a)*18,Math.sin(a)*18);c.rotate(a+Math.PI/2);c.fillStyle='rgba(179,229,252,0.9)';c.strokeStyle='#0288d1';c.lineWidth=1;c.beginPath();c.moveTo(-3,5);c.lineTo(0,-8);c.lineTo(3,5);c.closePath();c.fill();c.stroke();c.restore();}
          c.strokeStyle='#1565c0'; c.lineWidth=5; c.lineCap='round';
          c.beginPath();c.moveTo(-14,8);c.lineTo(14,-6);c.stroke();
          c.beginPath();c.moveTo(14,8);c.lineTo(-14,-6);c.stroke();
          c.strokeStyle='rgba(179,229,252,0.7)'; c.lineWidth=3;
          c.beginPath();c.moveTo(-12,8);c.lineTo(12,-6);c.stroke();
          c.beginPath();c.moveTo(12,8);c.lineTo(-12,-6);c.stroke();
          c.fillStyle='rgba(179,229,252,0.9)'; c.beginPath(); c.moveTo(-4,-8); c.lineTo(0,-16); c.lineTo(4,-8); c.closePath(); c.fill();
          break; }
        case 3: { // Ametist — runic altar flame (stone ring + carved runes + altar stones)
          c.fillStyle='#4a148c'; c.strokeStyle='#aa00ff'; c.lineWidth=2;
          for(let i=0;i<6;i++){const a=i*Math.PI/3;c.save();c.translate(Math.cos(a)*18,Math.sin(a)*18);c.rotate(a);c.beginPath();c.ellipse(0,0,7,5,0,0,Math.PI*2);c.fill();c.stroke();c.fillStyle='#ea80fc';c.beginPath();c.moveTo(-2,-3);c.lineTo(0,-8);c.lineTo(2,-3);c.closePath();c.fill();c.restore();}
          // runic ring
          c.strokeStyle='rgba(234,128,252,0.5)'; c.lineWidth=1.5; c.beginPath(); c.arc(0,0,14,0,Math.PI*2); c.stroke();
          c.strokeStyle='rgba(206,147,216,0.4)'; c.lineWidth=1;
          for(let i=0;i<6;i++){const a=i*Math.PI/3;c.beginPath();c.moveTo(Math.cos(a)*6,Math.sin(a)*6);c.lineTo(Math.cos(a)*14,Math.sin(a)*14);c.stroke();}
          // dark altar logs
          c.strokeStyle='#4a148c'; c.lineWidth=5; c.lineCap='round';
          c.beginPath();c.moveTo(-12,8);c.lineTo(12,-6);c.stroke();
          c.beginPath();c.moveTo(12,8);c.lineTo(-12,-6);c.stroke();
          c.fillStyle='#ea80fc'; c.beginPath(); c.arc(0,0,5,0,Math.PI*2); c.fill();
          c.fillStyle='rgba(74,20,140,0.8)'; c.beginPath(); c.arc(0,0,3,0,Math.PI*2); c.fill();
          break; }
        case 4: { // Reidite — ancient bonfire on altar stones (3 standing stones + tech log)
          // 3 standing stones
          for(const[sx,sy,sw,sh] of[[-16,-4,8,14],[8,-4,8,14],[-4,-12,10,8]]){
            c.fillStyle='#2e7d32'; c.strokeStyle='#003300'; c.lineWidth=2;
            c.beginPath(); c.roundRect(sx,sy,sw,sh,2); c.fill(); c.stroke();
            // circuit line on stone
            c.strokeStyle='#00e676'; c.lineWidth=1;
            c.beginPath(); c.moveTo(sx+2,sy+2); c.lineTo(sx+sw-2,sy+sh-2); c.stroke();
          }
          c.strokeStyle='#00c853'; c.lineWidth=5; c.lineCap='round';
          c.beginPath();c.moveTo(-14,8);c.lineTo(14,-6);c.stroke();
          c.beginPath();c.moveTo(14,8);c.lineTo(-14,-6);c.stroke();
          // green reidite stones ring
          c.fillStyle='#66bb6a'; c.strokeStyle='#003300'; c.lineWidth=1.5;
          for(let i=0;i<6;i++){const a=i*Math.PI/3;c.save();c.translate(Math.cos(a)*18,Math.sin(a)*18);c.rotate(a);c.beginPath();c.ellipse(0,0,6,4,0,0,Math.PI*2);c.fill();c.stroke();c.fillStyle='#b9f6ca';c.beginPath();c.arc(0,-2,2,0,Math.PI*2);c.fill();c.restore();}
          break; }
        case 5: { // Nihai — celestial star beacon (8 crystal columns + rainbow center)
          // 8 gem crystal columns
          for(let i=0;i<8;i++){
            const a=i*Math.PI/4; c.save(); c.translate(Math.cos(a)*20,Math.sin(a)*20); c.rotate(a+Math.PI/2);
            const hue=i/8*360; c.fillStyle=`hsla(${hue},100%,72%,0.9)`; c.strokeStyle=`hsla(${hue},100%,82%,0.6)`; c.lineWidth=1;
            c.beginPath(); c.moveTo(-3,4); c.lineTo(0,-10); c.lineTo(3,4); c.closePath(); c.fill(); c.stroke();
            c.restore();
          }
          // inner mandala platform
          c.strokeStyle='rgba(197,202,233,0.5)'; c.lineWidth=1.5; c.beginPath(); c.arc(0,0,14,0,Math.PI*2); c.stroke();
          c.strokeStyle='rgba(197,202,233,0.3)'; c.lineWidth=1;
          for(let i=0;i<8;i++){const a=i*Math.PI/4;c.beginPath();c.moveTo(0,0);c.lineTo(Math.cos(a)*12,Math.sin(a)*12);c.stroke();}
          // rainbow logs
          for(let i=0;i<2;i++){
            const hue1=i*180, hue2=(i*180+120)%360;
            const gl=c.createLinearGradient(-14,8+i*4,14,-6+i*4); gl.addColorStop(0,`hsl(${hue1},100%,60%)`); gl.addColorStop(1,`hsl(${hue2},100%,60%)`);
            c.strokeStyle=gl; c.lineWidth=5; c.lineCap='round';
            c.beginPath(); c.moveTo(-14,8+i*4-(i?16:0)); c.lineTo(14,-6+i*4-(i?16:0)); c.stroke();
          }
          break; }
      }
    }), -30, -30);
    // Dynamic: animated fire
    const cf_fl=Math.sin(cf_t*0.15)*3, cf_fl2=Math.sin(cf_t*0.22+1)*2;
    const og10=ctx.createRadialGradient(0,-5+cf_fl,0,0,0,22);
    og10.addColorStop(0,tpA+'f2');og10.addColorStop(0.4,tpAD+'cc');og10.addColorStop(1,'rgba(255,30,0,0)');
    ctx.fillStyle=og10;ctx.beginPath();ctx.ellipse(0,-6+cf_fl,12,18,0,0,Math.PI*2);ctx.fill();
    const ig10=ctx.createRadialGradient(0,-8+cf_fl2,0,0,-4+cf_fl2,12);
    ig10.addColorStop(0,'rgba(255,255,220,1)');ig10.addColorStop(0.5,tpA+'cc');ig10.addColorStop(1,'rgba(255,80,0,0)');
    ctx.save(); if(_qualityLevel>=2){ctx.shadowColor=tpG; ctx.shadowBlur=20;}
    ctx.fillStyle=ig10;ctx.beginPath();ctx.ellipse(0,-10+cf_fl2,7,13,0,0,Math.PI*2);ctx.fill();ctx.restore();
    ctx.save();ctx.globalAlpha=0.07;ctx.fillStyle=tpG;ctx.beginPath();ctx.arc(0,0,180,0,Math.PI*2);ctx.fill();ctx.restore();
    ctx.save();ctx.globalAlpha=0.75;ctx.fillStyle=tpA;ctx.beginPath();
    for(let i=0;i<4;i++){const ea=cf_t*0.08+i*2.1,er=4+Math.sin(cf_t*0.12+i)*3;ctx.arc(Math.cos(ea)*er,-8+Math.sin(ea)*3,1.5,0,Math.PI*2);}
    ctx.fill();ctx.restore();
  }

  ctx.globalAlpha = 1;
  ctx.restore();
}

// ── sploop.io / moomoo.io MOB ENGINE ──
function _spParse(hex) {
  const h = (hex || '#888').replace('#', '');
  return [parseInt(h.slice(0, 2), 16) || 0, parseInt(h.slice(2, 4), 16) || 0, parseInt(h.slice(4, 6), 16) || 0];
}
function _spRgb(r, g, b) { return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')'; }
// ============================================================
function _mL(hex,a){const[r,g,b]=_spParse(hex);return _spRgb(Math.min(255,r+a),Math.min(255,g+a),Math.min(255,b+a));}
function _mD(hex,a){const[r,g,b]=_spParse(hex);return _spRgb(Math.max(0,r-a),Math.max(0,g-a),Math.max(0,b-a));}
function _mLw(R){return Math.max(3.5,R*0.11);}
function _mShadow(ctx, R) {
  // Mob shadows completely disabled for crisp Taming.io style and max performance
  return;
}
function _mBody(ctx,R,col,out,lw){
  lw=lw||_mLw(R);
  ctx.fillStyle=_mD(col,18);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.arc(0,0,R,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=col;ctx.strokeStyle='none';
  ctx.beginPath();ctx.ellipse(-R*0.08,-R*0.08,R*0.9,R*0.9,0,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;ctx.fillStyle='none';
  ctx.beginPath();ctx.arc(0,0,R,0,Math.PI*2);ctx.stroke();
  ctx.fillStyle='rgba(255,255,255,0.22)';ctx.strokeStyle='none';
  ctx.beginPath();ctx.ellipse(-R*0.28,-R*0.32,R*0.32,R*0.18,-0.5,0,Math.PI*2);ctx.fill();
}
function _mEyes(ctx,R,eyeCol){
  const es=R*0.22,ex=R*0.4,lw=_mLw(R);
  for(const ey of[-R*0.22,R*0.22]){
    ctx.fillStyle='#fff';ctx.strokeStyle='#111';ctx.lineWidth=lw;
    ctx.beginPath();ctx.arc(ex,ey,es,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle=eyeCol||'#222';ctx.beginPath();ctx.arc(ex+es*0.18,ey,es*0.6,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='#000';ctx.beginPath();ctx.arc(ex+es*0.26,ey,es*0.32,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='rgba(255,255,255,0.92)';ctx.beginPath();ctx.arc(ex+es*0.04,ey-es*0.38,es*0.2,0,Math.PI*2);ctx.fill();
  }
}
function _mBrows(ctx,R){const es=R*0.22,ex=R*0.4,lw=Math.max(3,R*0.1);ctx.strokeStyle='#111';ctx.lineWidth=lw;ctx.lineCap='round';for(const s of[-1,1]){ctx.beginPath();ctx.moveTo(ex-es*0.75,s*(R*0.22-es*0.95));ctx.lineTo(ex+es*0.65,s*(R*0.22-es*0.48));ctx.stroke();}}
function _mSnout(ctx,R,col,nostrils){
  const lw=_mLw(R);
  ctx.fillStyle=_mL(col,38);ctx.strokeStyle='#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(R*0.7,0,R*0.26,R*0.19,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,60);ctx.strokeStyle='none';
  ctx.beginPath();ctx.ellipse(R*0.66,-R*0.04,R*0.12,R*0.07,0,0,Math.PI*2);ctx.fill();
  if(nostrils!==false){ctx.fillStyle='rgba(0,0,0,0.55)';for(const s of[-1,1]){ctx.beginPath();ctx.ellipse(R*0.74,s*R*0.07,R*0.06,R*0.044,0.2*s,0,Math.PI*2);ctx.fill();}}
}
function _mEarRound(ctx,R,col,out,s){
  const lw=_mLw(R),ex=-R*0.62,ey=s*R*0.78;
  ctx.fillStyle=_mD(col,12);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.arc(ex,ey,R*0.3,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,28);ctx.beginPath();ctx.arc(ex,ey,R*0.2,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#ff9999';ctx.beginPath();ctx.arc(ex,ey,R*0.1,0,Math.PI*2);ctx.fill();
}
function _mEarPoint(ctx,R,col,out,s,len){
  len=len||1;const lw=_mLw(R);
  ctx.fillStyle=_mD(col,10);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.moveTo(-R*0.48,s*R*0.58);ctx.lineTo(-R*(0.72+0.5*len),s*R*1.22);ctx.lineTo(-R*0.26,s*R*0.84);ctx.closePath();ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,55);ctx.beginPath();ctx.moveTo(-R*0.5,s*R*0.62);ctx.lineTo(-R*(0.68+0.33*len),s*R*1.1);ctx.lineTo(-R*0.3,s*R*0.82);ctx.closePath();ctx.fill();
  ctx.fillStyle='#ffaaaa';ctx.beginPath();ctx.moveTo(-R*0.52,s*R*0.66);ctx.lineTo(-R*(0.64+0.2*len),s*R*0.98);ctx.lineTo(-R*0.34,s*R*0.8);ctx.closePath();ctx.fill();
}
function _mEarLong(ctx,R,col,out,s){const lw=_mLw(R);ctx.fillStyle=_mD(col,8);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;ctx.beginPath();ctx.ellipse(-R*0.4,s*R*1.5,R*0.18,R*0.56,-0.14*s,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle='#ff9999';ctx.beginPath();ctx.ellipse(-R*0.4,s*R*1.5,R*0.09,R*0.38,-0.14*s,0,Math.PI*2);ctx.fill();}
function _mTail(ctx,R,col,t){
  const wag=Math.sin(t*0.13)*R*0.34;
  ctx.strokeStyle=_mD(col,18);ctx.lineWidth=Math.max(5,R*0.16);ctx.lineCap='round';
  ctx.beginPath();ctx.moveTo(-R*0.72,0);ctx.quadraticCurveTo(-R*1.22,wag,-R*1.58,-wag*0.4);ctx.stroke();
  ctx.strokeStyle=_mL(col,22);ctx.lineWidth=Math.max(2.5,R*0.08);
  ctx.beginPath();ctx.moveTo(-R*0.72,0);ctx.quadraticCurveTo(-R*1.18,wag*0.9,-R*1.52,-wag*0.35);ctx.stroke();
}
function _mFoxTail(ctx,R,col,out,t){
  const wag=Math.sin(t*0.1)*R*0.38;
  ctx.strokeStyle=_mD(col,18);ctx.lineWidth=Math.max(5,R*0.17);ctx.lineCap='round';
  ctx.beginPath();ctx.moveTo(-R*0.68,0);ctx.lineTo(-R*1.08,wag*0.55);ctx.stroke();
  const lw=_mLw(R);
  ctx.fillStyle=_mL(col,35);ctx.strokeStyle=_mD(col,14);ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(-R*1.34,wag,R*0.42,R*0.3,0.5,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,18);ctx.beginPath();ctx.ellipse(-R*1.32,wag,R*0.28,R*0.2,0.5,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#fff';ctx.beginPath();ctx.ellipse(-R*1.42,wag,R*0.22,R*0.16,0.5,0,Math.PI*2);ctx.fill();
}

function _mTusks(ctx,R){ctx.fillStyle='#f4ecd0';ctx.strokeStyle='#444';ctx.lineWidth=Math.max(2,R*0.07);for(const s of[-1,1]){ctx.beginPath();ctx.moveTo(R*0.58,s*R*0.14);ctx.quadraticCurveTo(R*0.9,s*R*0.24,R*1.02,s*R*0.09);ctx.quadraticCurveTo(R*0.92,s*R*0.4,R*0.7,s*R*0.28);ctx.closePath();ctx.fill();ctx.stroke();}}
function _mWings(ctx,R,col,t){
  const fp=Math.sin(t*0.25)*R*0.3,lw=_mLw(R);
  for(const s of[-1,1]){
    ctx.fillStyle=_mD(col,10);ctx.strokeStyle='#111';ctx.lineWidth=lw;
    ctx.beginPath();ctx.moveTo(0,-R*0.1);ctx.quadraticCurveTo(s*R*0.9,-R*0.98+fp,s*R*1.8,-R*0.46+fp);ctx.quadraticCurveTo(s*R*1.3,R*0.42,s*R*0.46,R*0.22);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.strokeStyle=_mD(col,24);ctx.lineWidth=Math.max(1.5,R*0.05);
    ctx.beginPath();ctx.moveTo(s*R*0.62,-R*0.24+fp*0.5);ctx.lineTo(s*R*1.44,-R*0.38+fp*0.85);ctx.stroke();
    ctx.beginPath();ctx.moveTo(s*R*0.42,R*0.06+fp*0.22);ctx.lineTo(s*R*1.16,-R*0.04+fp*0.55);ctx.stroke();
    ctx.beginPath();ctx.moveTo(s*R*0.28,R*0.18+fp*0.1);ctx.lineTo(s*R*0.88,R*0.24+fp*0.3);ctx.stroke();
  }
}
function _mSpiderLegs(ctx,R,col){
  ctx.strokeStyle=_mD(col,32);ctx.lineWidth=Math.max(2.5,R*0.09);ctx.lineCap='round';
  const angs=[-0.3,-0.62,-0.96,-1.28];
  for(const s of[-1,1])for(const a of angs){
    const bx=Math.cos(a)*R*0.78,by=s*Math.sin(Math.abs(a))*R*0.78;
    const kx=Math.cos(a)*R*1.38,ky=s*Math.sin(Math.abs(a))*R*1.62;
    const ex=Math.cos(a)*R*1.88,ey=s*Math.sin(Math.abs(a))*R*1.36;
    ctx.beginPath();ctx.moveTo(bx,by);ctx.lineTo(kx,ky);ctx.lineTo(ex,ey);ctx.stroke();
    ctx.fillStyle=_mD(col,40);ctx.beginPath();ctx.arc(kx,ky,R*0.055,0,Math.PI*2);ctx.fill();
  }
}
function _mClaws(ctx,R,col,out){const lw=_mLw(R);for(const s of[-1,1]){ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;ctx.beginPath();ctx.ellipse(R*0.62,s*R*0.78,R*0.3,R*0.15,0.38*s,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(R*0.8,s*R*0.68);ctx.quadraticCurveTo(R*1.08,s*R*0.52,R*1.18,s*R*0.42);ctx.quadraticCurveTo(R*1.1,s*R*0.3,R*0.96,s*R*0.44);ctx.closePath();ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(R*0.8,s*R*0.68);ctx.quadraticCurveTo(R*1.04,s*R*0.8,R*1.16,s*R*0.76);ctx.quadraticCurveTo(R*1.1,s*R*0.6,R*0.96,s*R*0.62);ctx.closePath();ctx.fill();ctx.stroke();}}
function _mStinger(ctx,R,col,t){const wag=Math.sin(t*0.08)*R*0.05;ctx.strokeStyle=_mD(col,22);ctx.lineWidth=Math.max(4,R*0.14);ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-R*0.65,0);ctx.quadraticCurveTo(-R*1.28,R*0.5+wag,-R*1.62,-R*0.58);ctx.quadraticCurveTo(-R*1.4,-R*1.18,-R*0.85,-R*1.28);ctx.stroke();ctx.fillStyle='#ff3300';ctx.strokeStyle='#111';ctx.lineWidth=Math.max(2,R*0.07);ctx.beginPath();ctx.moveTo(-R*0.82,-R*1.25);ctx.lineTo(-R*0.66,-R*1.52);ctx.lineTo(-R*0.94,-R*1.42);ctx.closePath();ctx.fill();ctx.stroke();}
function _mCrabClaws(ctx,R,col,out){const lw=_mLw(R);for(const s of[-1,1]){ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;ctx.beginPath();ctx.ellipse(R*0.7,s*R*0.82,R*0.36,R*0.18,0.32*s,0,Math.PI*2);ctx.fill();ctx.stroke();for(const off of[0,0.55]){ctx.beginPath();ctx.moveTo(R*0.84,s*R*0.72);ctx.quadraticCurveTo(R*(1.08+off*0.18),s*R*(0.54+off*0.26),R*(1.2+off*0.1),s*R*(0.44+off*0.32));ctx.quadraticCurveTo(R*1.0,s*R*(0.5+off*0.18),R*0.88,s*R*(0.64-off*0.05));ctx.closePath();ctx.fill();ctx.stroke();}}}
function _mBirdWings(ctx,R,col,out,t){
  const fp=Math.sin(t*0.22)*R*0.28,lw=_mLw(R);
  for(const s of[-1,1]){
    ctx.fillStyle=_mD(col,12);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
    ctx.beginPath();ctx.moveTo(0,s*R*0.12);ctx.quadraticCurveTo(s*R*0.74,-R*0.74+fp,s*R*1.52,-R*0.38+fp);ctx.quadraticCurveTo(s*R*1.12,R*0.32,s*R*0.42,R*0.22);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.strokeStyle=_mD(col,26);ctx.lineWidth=Math.max(1.5,R*0.05);
    ctx.beginPath();ctx.moveTo(s*R*0.98,-R*0.2+fp*0.72);ctx.lineTo(s*R*1.38,-R*0.3+fp*0.92);ctx.stroke();
    ctx.beginPath();ctx.moveTo(s*R*0.78,R*0.02+fp*0.52);ctx.lineTo(s*R*1.16,-R*0.1+fp*0.72);ctx.stroke();
    ctx.beginPath();ctx.moveTo(s*R*0.54,R*0.18+fp*0.3);ctx.lineTo(s*R*0.9,R*0.12+fp*0.5);ctx.stroke();
  }
}

// ── Individual mob shapes ─────────────────────────────────────

function _drawWolf(ctx,R,col,out,eyeCol,t){
  const lw=_mLw(R);
  _mTail(ctx,R,col,t);
  for(const s of[-1,1]){ctx.fillStyle=_mD(col,12);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;ctx.beginPath();ctx.ellipse(-R*0.52,s*R*0.56,R*0.24,R*0.32,0.3*s,0,Math.PI*2);ctx.fill();ctx.stroke();}
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(0,0,R*1.0,R*0.78,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,28);ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(R*0.14,0,R*0.56,R*0.44,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=_mD(col,16);ctx.strokeStyle=out||'#111';ctx.lineWidth=Math.max(2,R*0.07);
  ctx.beginPath();ctx.ellipse(-R*0.22,0,R*0.44,R*0.56,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle='rgba(255,255,255,0.18)';ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(-R*0.38,-R*0.24,R*0.22,R*0.14,-0.4,0,Math.PI*2);ctx.fill();
  for(const s of[-1,1])_mEarPoint(ctx,R,col,out,s,0.95);
  ctx.fillStyle=_mL(col,10);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(R*0.38,0,R*0.42,R*0.5,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle='rgba(255,255,255,0.16)';ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(R*0.22,-R*0.2,R*0.18,R*0.1,-0.3,0,Math.PI*2);ctx.fill();
  _mSnout(ctx,R,col,false);_mEyes(ctx,R,eyeCol||'#ffdd00');_mBrows(ctx,R);
  ctx.fillStyle='#fff';ctx.strokeStyle='#333';ctx.lineWidth=Math.max(1.5,R*0.05);
  for(const s of[-1,1]){ctx.beginPath();ctx.moveTo(R*0.58,s*R*0.08);ctx.lineTo(R*0.7,s*R*0.24);ctx.lineTo(R*0.78,s*R*0.08);ctx.closePath();ctx.fill();ctx.stroke();}
}

function _drawBear(ctx,R,col,out,eyeCol,t){
  const lw=_mLw(R);
  _mTail(ctx,R,_mD(col,8),t);
  for(const s of[-1,1]){ctx.fillStyle=_mD(col,14);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;ctx.beginPath();ctx.ellipse(-R*0.48,s*R*0.64,R*0.32,R*0.38,0.2*s,0,Math.PI*2);ctx.fill();ctx.stroke();}
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(0,0,R*1.0,R*0.88,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.strokeStyle=_mD(col,20);ctx.lineWidth=Math.max(2,R*0.06);ctx.lineCap='round';
  for(const[fx,fy,fa]of[[-R*0.5,-R*0.5,0.4],[-R*0.1,-R*0.72,0.1],[R*0.2,-R*0.62,0.3],[-R*0.6,R*0.4,0.5]]){
    ctx.beginPath();ctx.moveTo(fx,fy);ctx.lineTo(fx+Math.cos(fa)*R*0.2,fy+Math.sin(fa)*R*0.2);ctx.stroke();
  }
  ctx.fillStyle=_mL(col,34);ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(R*0.22,0,R*0.52,R*0.62,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='rgba(255,255,255,0.2)';ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(-R*0.3,-R*0.3,R*0.28,R*0.15,-0.4,0,Math.PI*2);ctx.fill();
  for(const s of[-1,1])_mEarRound(ctx,R,col,out,s);
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(R*0.36,0,R*0.48,R*0.56,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,18);ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(R*0.22,-R*0.18,R*0.2,R*0.12,-0.2,0,Math.PI*2);ctx.fill();
  _mSnout(ctx,R,col);_mEyes(ctx,R,eyeCol||'#442200');_mBrows(ctx,R);
}

function _drawFox(ctx,R,col,out,eyeCol,t){
  _mFoxTail(ctx,R,col,out,t);
  for(const s of[-1,1])_mEarPoint(ctx,R,col,out,s,1.15);
  const lw=_mLw(R);
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(0,0,R*0.96,R*0.72,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle='#fff';ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(R*0.28,0,R*0.46,R*0.4,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(R*0.36,0,R*0.38,R*0.46,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle='rgba(255,255,255,0.72)';ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(R*0.52,0,R*0.28,R*0.32,0,0,Math.PI*2);ctx.fill();
  _mSnout(ctx,R,col,false);_mEyes(ctx,R,eyeCol||'#ff8800');
}

function _drawRabbit(ctx,R,col,out,eyeCol){
  const lw=_mLw(R);
  for(const s of[-1,1])_mEarLong(ctx,R,col,out,s);
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(0,0,R*0.9,R*0.82,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle='#fff';ctx.strokeStyle='#ccc';ctx.lineWidth=Math.max(2,R*0.06);
  ctx.beginPath();ctx.arc(-R*0.82,0,R*0.24,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,30);ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(R*0.1,0,R*0.5,R*0.52,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#ff8899';ctx.strokeStyle='#cc5566';ctx.lineWidth=Math.max(1.5,R*0.05);
  ctx.beginPath();ctx.ellipse(R*0.68,0,R*0.12,R*0.09,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  _mEyes(ctx,R*0.9,eyeCol||'#cc44cc');
}

function _drawBat(ctx,R,col,out,eyeCol,t){
  _mWings(ctx,R,col,t);
  const lw=_mLw(R);
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.arc(0,0,R,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,22);ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(-R*0.1,-R*0.1,R*0.44,R*0.38,0,0,Math.PI*2);ctx.fill();
  for(const s of[-1,1])_mEarPoint(ctx,R,col,out,s,0.72);
  _mEyes(ctx,R*0.88,eyeCol||'#ff3300');
  ctx.fillStyle='#fff';ctx.strokeStyle='#333';ctx.lineWidth=Math.max(1.5,R*0.05);
  for(const s of[-1,1]){ctx.beginPath();ctx.moveTo(R*0.52,s*R*0.07);ctx.lineTo(R*0.62,s*R*0.2);ctx.lineTo(R*0.72,s*R*0.07);ctx.closePath();ctx.fill();ctx.stroke();}
}

function _drawSpider(ctx,R,col,out,eyeCol){
  _mSpiderLegs(ctx,R,col);
  const lw=_mLw(R);
  ctx.fillStyle=_mD(col,10);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(-R*0.28,0,R*0.72,R*0.88,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle='rgba(255,255,255,0.12)';ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(-R*0.42,-R*0.25,R*0.3,R*0.18,-0.3,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='rgba(255,30,0,0.7)';
  ctx.beginPath();ctx.arc(-R*0.22,0,R*0.18,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.arc(-R*0.5,0,R*0.14,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(R*0.38,0,R*0.38,R*0.46,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  const es=R*0.1;
  for(const[ex,ey]of[[R*0.52,-R*0.22],[R*0.52,R*0.22],[R*0.32,-R*0.3],[R*0.32,R*0.3]]){
    ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(ex,ey,es,0,Math.PI*2);ctx.fill();
    ctx.fillStyle=eyeCol||'#ff0000';ctx.beginPath();ctx.arc(ex+es*0.2,ey,es*0.62,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='#000';ctx.beginPath();ctx.arc(ex+es*0.3,ey,es*0.3,0,Math.PI*2);ctx.fill();
  }
  ctx.fillStyle=_mD(col,18);ctx.strokeStyle='#111';ctx.lineWidth=Math.max(2,R*0.07);
  for(const s of[-1,1]){ctx.beginPath();ctx.moveTo(R*0.7,s*R*0.08);ctx.lineTo(R*0.86,s*R*0.16);ctx.stroke();}
}

function _drawScorpion(ctx,R,col,out,eyeCol,t){
  _mStinger(ctx,R,col,t);_mClaws(ctx,R,col,out);
  const lw=_mLw(R);
  for(const[sx,sw,sh]of[[R*0.38,R*0.3,R*0.36],[R*0.08,R*0.32,R*0.4],[-R*0.24,R*0.3,R*0.36],[-R*0.52,R*0.26,R*0.3]]){
    ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
    ctx.beginPath();ctx.ellipse(sx,0,sw,sh,0,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle='rgba(255,255,255,0.1)';ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(sx,sh*-0.4,sw*0.5,sh*0.25,0,0,Math.PI*2);ctx.fill();
  }
  ctx.strokeStyle=_mD(col,28);ctx.lineWidth=Math.max(2,R*0.065);ctx.lineCap='round';
  for(const s of[-1,1])for(const px of[R*0.28,0,-R*0.24]){ctx.beginPath();ctx.moveTo(px,s*R*0.36);ctx.lineTo(px+R*0.12,s*R*0.7);ctx.lineTo(px+R*0.28,s*R*0.58);ctx.stroke();}
  _mEyes(ctx,R*0.82,eyeCol||'#ffee00');
}

function _drawSnake(ctx,R,col,out,eyeCol){
  const lw=_mLw(R);
  ctx.strokeStyle=_mD(col,15);ctx.lineWidth=R*0.56;ctx.lineCap='round';
  ctx.beginPath();ctx.arc(-R*0.24,R*0.48,R*0.56,Math.PI*0.08,Math.PI*1.22);ctx.stroke();
  ctx.strokeStyle='rgba(0,0,0,0.15)';ctx.lineWidth=R*0.08;
  for(let i=0;i<6;i++){const a=Math.PI*0.08+i*Math.PI*0.19;const cx=-R*0.24+Math.cos(a)*R*0.56,cy=R*0.48+Math.sin(a)*R*0.56;ctx.beginPath();ctx.arc(cx,cy,R*0.12,a-0.6,a+0.6);ctx.stroke();}
  ctx.fillStyle=_mL(col,8);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(R*0.36,0,R*0.52,R*0.38,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,24);ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(R*0.22,-R*0.1,R*0.22,R*0.14,-0.3,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=_mD(col,8);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(R*0.76,0,R*0.3,R*0.22,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  const es=R*0.14,ex2=R*0.5;
  for(const ey of[-R*0.15,R*0.15]){
    ctx.fillStyle='#fff';ctx.strokeStyle='#111';ctx.lineWidth=lw;ctx.beginPath();ctx.arc(ex2,ey,es,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle=eyeCol||'#ff4400';ctx.beginPath();ctx.arc(ex2+es*0.2,ey,es*0.6,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='#000';ctx.beginPath();ctx.arc(ex2+es*0.3,ey,es*0.3,0,Math.PI*2);ctx.fill();
  }
  ctx.strokeStyle='#ff1111';ctx.lineWidth=Math.max(1.5,R*0.05);ctx.lineCap='round';
  ctx.beginPath();ctx.moveTo(R*0.94,0);ctx.lineTo(R*1.18,0);ctx.stroke();
  ctx.beginPath();ctx.moveTo(R*1.18,0);ctx.lineTo(R*1.36,-R*0.11);ctx.stroke();
  ctx.beginPath();ctx.moveTo(R*1.18,0);ctx.lineTo(R*1.36,R*0.11);ctx.stroke();
}

function _drawCrab(ctx,R,col,out,eyeCol){
  const lw=_mLw(R);_mCrabClaws(ctx,R,col,out);
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(0,0,R*1.0,R*0.88,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.strokeStyle=_mD(col,20);ctx.lineWidth=Math.max(1.5,R*0.05);
  for(const gr of[-R*0.28,0,R*0.28]){ctx.beginPath();ctx.moveTo(gr,R*0.62);ctx.quadraticCurveTo(gr*0.6,-R*0.1,gr,-R*0.62);ctx.stroke();}
  ctx.fillStyle='rgba(255,255,255,0.18)';ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(-R*0.3,-R*0.32,R*0.28,R*0.16,-0.4,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle=_mD(col,22);ctx.lineWidth=Math.max(2,R*0.065);ctx.lineCap='round';
  for(const s of[-1,1])for(const[lx,ang]of[[-R*0.38,0.5],[-R*0.12,0.3],[R*0.12,0.25],[R*0.38,0.4]]){
    ctx.beginPath();ctx.moveTo(lx,s*R*0.82);ctx.lineTo(lx+Math.cos(1.4+ang*s)*R*0.6,s*R*0.82+Math.sin(1.4+ang*s)*R*0.6*s);ctx.stroke();
  }
  for(const s of[-1,1]){
    ctx.fillStyle=_mD(col,10);ctx.strokeStyle='#111';ctx.lineWidth=Math.max(2,R*0.07);
    ctx.beginPath();ctx.moveTo(R*0.34,s*R*0.44);ctx.lineTo(R*0.44,s*R*0.6);ctx.stroke();
    ctx.fillStyle='#fff';ctx.strokeStyle='#111';ctx.lineWidth=lw;ctx.beginPath();ctx.arc(R*0.44,s*R*0.62,R*0.16,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle=eyeCol||'#ff4400';ctx.beginPath();ctx.arc(R*0.5,s*R*0.62,R*0.1,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='#000';ctx.beginPath();ctx.arc(R*0.52,s*R*0.62,R*0.05,0,Math.PI*2);ctx.fill();
  }
}

function _drawToad(ctx,R,col,out,eyeCol){
  const lw=_mLw(R);
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(0,R*0.14,R*1.08,R*0.78,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,30);ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(R*0.12,R*0.2,R*0.58,R*0.5,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=_mD(col,20);ctx.strokeStyle='#111';ctx.lineWidth=Math.max(1.5,R*0.05);
  for(const[wx,wy,wr]of[[-R*0.52,-R*0.22,R*0.12],[-R*0.3,R*0.28,R*0.1],[-R*0.68,R*0.18,R*0.09],[R*0.28,-R*0.32,R*0.08]]){
    ctx.beginPath();ctx.arc(wx,wy,wr,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle=_mL(col,14);ctx.beginPath();ctx.arc(wx-wr*0.3,wy-wr*0.3,wr*0.35,0,Math.PI*2);ctx.fill();
    ctx.fillStyle=_mD(col,20);
  }
  const es=R*0.26;
  for(const ex2 of[-R*0.28,R*0.28]){
    ctx.fillStyle=_mL(col,10);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;ctx.beginPath();ctx.arc(ex2,-R*0.62,es*0.82,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle='#fff';ctx.strokeStyle='#111';ctx.lineWidth=lw;ctx.beginPath();ctx.arc(ex2,-R*0.66,es,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle=eyeCol||'#ffdd00';ctx.beginPath();ctx.arc(ex2+es*0.18,-R*0.66,es*0.6,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='#000';ctx.beginPath();ctx.arc(ex2+es*0.28,-R*0.66,es*0.32,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='rgba(255,255,255,0.85)';ctx.beginPath();ctx.arc(ex2+es*0.02,-R*0.76,es*0.2,0,Math.PI*2);ctx.fill();
  }
  ctx.strokeStyle='#111';ctx.lineWidth=Math.max(2.5,R*0.09);ctx.lineCap='round';
  ctx.beginPath();ctx.arc(R*0.24,R*0.08,R*0.44,0.22,Math.PI-0.22);ctx.stroke();
}

function _drawCroc(ctx,R,col,out,eyeCol){
  const lw=_mLw(R);
  ctx.strokeStyle=_mD(col,18);ctx.lineWidth=Math.max(6,R*0.2);ctx.lineCap='round';
  ctx.beginPath();ctx.moveTo(-R*0.65,0);ctx.quadraticCurveTo(-R*1.2,R*0.15,-R*1.72,0);ctx.stroke();
  ctx.fillStyle=_mD(col,14);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(R*0.9,0,R*0.52,R*0.22,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle='#fff';ctx.strokeStyle='#555';ctx.lineWidth=Math.max(1.5,R*0.05);
  for(const s of[-1,1])for(let ti=0;ti<4;ti++){const tx=R*(0.56+ti*0.1);ctx.beginPath();ctx.moveTo(tx,s*R*0.06);ctx.lineTo(tx+R*0.036,s*R*0.2);ctx.lineTo(tx+R*0.072,s*R*0.06);ctx.closePath();ctx.fill();ctx.stroke();}
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(0,0,R*0.88,R*0.72,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mD(col,20);ctx.strokeStyle=_mD(col,32);ctx.lineWidth=Math.max(1.5,R*0.05);
  for(const[px,py,ps]of[[-R*0.4,-R*0.52,R*0.2],[-R*0.1,-R*0.58,R*0.24],[R*0.22,-R*0.54,R*0.2],[R*0.52,-R*0.46,R*0.16]]){
    ctx.beginPath();ctx.moveTo(px-ps*0.5,py+ps*0.8);ctx.lineTo(px,py-ps*0.5);ctx.lineTo(px+ps*0.5,py+ps*0.8);ctx.closePath();ctx.fill();ctx.stroke();
  }
  const es=R*0.18;
  for(const ex2 of[-R*0.06,R*0.32]){
    ctx.fillStyle=_mL(col,12);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;ctx.beginPath();ctx.arc(ex2,-R*0.76,es,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(ex2,-R*0.78,es*0.88,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle=eyeCol||'#ff8800';ctx.beginPath();ctx.arc(ex2+es*0.18,-R*0.78,es*0.56,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='#000';ctx.beginPath();ctx.arc(ex2+es*0.26,-R*0.78,es*0.28,0,Math.PI*2);ctx.fill();
  }
}

function _drawPenguin(ctx,R,col,out,eyeCol){
  const lw=_mLw(R);_mBody(ctx,R,col,out);
  ctx.fillStyle='#fff';ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(R*0.18,0,R*0.56,R*0.72,0.12,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#ff8800';ctx.strokeStyle='#444';ctx.lineWidth=Math.max(2,R*0.07);
  ctx.beginPath();ctx.moveTo(R*0.72,-R*0.08);ctx.lineTo(R*1.0,0);ctx.lineTo(R*0.72,R*0.08);ctx.closePath();ctx.fill();ctx.stroke();
  _mEyes(ctx,R*0.82,eyeCol||'#000');
  ctx.fillStyle=_mD(col,12);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  for(const s of[-1,1]){ctx.beginPath();ctx.ellipse(-R*0.22,s*R*0.74,R*0.18,R*0.4,0.3*s,0,Math.PI*2);ctx.fill();ctx.stroke();}
}

function _drawSnowman(ctx,R,col,out,eyeCol){
  const lw=_mLw(R);
  ctx.fillStyle='#f0f5ff';ctx.strokeStyle='#aac0dd';ctx.lineWidth=lw;
  ctx.beginPath();ctx.arc(0,R*0.28,R*0.76,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle='#f6f9ff';ctx.strokeStyle='#aac0dd';ctx.lineWidth=lw;
  ctx.beginPath();ctx.arc(0,-R*0.5,R*0.55,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(-R*0.02,-R*0.98,R*0.5,R*0.14,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillRect(-R*0.3,-R*1.22,R*0.6,R*0.26);ctx.strokeRect(-R*0.3,-R*1.22,R*0.6,R*0.26);
  ctx.fillStyle='#ff8800';ctx.strokeStyle='#444';ctx.lineWidth=Math.max(1.5,R*0.05);
  ctx.beginPath();ctx.moveTo(R*0.55,-R*0.5);ctx.lineTo(R*0.88,-R*0.44);ctx.lineTo(R*0.55,-R*0.38);ctx.closePath();ctx.fill();ctx.stroke();
  ctx.fillStyle='#1a1a2a';
  for(const s of[-1,1])ctx.beginPath(),ctx.arc(R*0.3+s*R*0.12,-R*0.6,R*0.1,0,Math.PI*2),ctx.fill();
  for(let i=0;i<5;i++){const a=-0.6+i*0.3;ctx.beginPath();ctx.arc(R*0.5*Math.cos(a)-R*0.05,-R*0.5+R*0.5*Math.sin(a),R*0.06,0,Math.PI*2);ctx.fill();}
  ctx.fillStyle=eyeCol||'#ff3300';ctx.strokeStyle='#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.arc(R*0.3,-R*0.48,R*0.1,0,Math.PI*2);ctx.fill();ctx.stroke();
}

function _drawSkeleton(ctx,R,col,out,eyeCol){
  const lw=_mLw(R);
  _mBody(ctx,R,'#e8e0c6','#665544');
  ctx.strokeStyle='#8a7248';ctx.lineWidth=Math.max(2,R*0.068);
  for(const y of[-R*0.24,0,R*0.24]){ctx.beginPath();ctx.arc(R*0.1,y,R*0.44,Math.PI*0.72,Math.PI*2.28);ctx.stroke();}
  ctx.fillStyle='#f0e8d6';ctx.strokeStyle='#665544';ctx.lineWidth=lw;
  ctx.beginPath();ctx.arc(R*0.32,-R*0.06,R*0.46,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=eyeCol||'#44ff88';
  for(const ey of[-R*0.18,R*0.18]){ctx.beginPath();ctx.arc(R*0.48,ey,R*0.15,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#333';ctx.lineWidth=Math.max(1.5,R*0.055);ctx.stroke();}
  ctx.fillStyle='#f0e8d6';ctx.strokeStyle='#555';ctx.lineWidth=Math.max(1.5,R*0.05);
  for(const tx of[R*0.34,R*0.44,R*0.54,R*0.64]){ctx.beginPath();ctx.moveTo(tx,R*0.08);ctx.lineTo(tx-R*0.04,R*0.19);ctx.lineTo(tx+R*0.04,R*0.19);ctx.closePath();ctx.fill();ctx.stroke();}
}

function _drawGhost(ctx,R,col,out,eyeCol,t){
  const bob=Math.sin(t*0.07)*R*0.06;
  ctx.save();ctx.translate(0,bob);ctx.globalAlpha=0.88;const lw=_mLw(R);
  ctx.save();ctx.globalAlpha=0.22;ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,-R*0.16,R*1.14,0,Math.PI*2);ctx.fill();ctx.restore();
  ctx.fillStyle=col;ctx.strokeStyle=out||'rgba(100,100,200,0.5)';ctx.lineWidth=lw;
  ctx.beginPath();ctx.arc(0,-R*0.2,R,Math.PI,0);
  const wpts=6;
  for(let i=0;i<=wpts;i++){const x=-R+i*(R*2/wpts),wave=Math.sin(t*0.1+i)*R*0.15;if(i===0)ctx.lineTo(x,R*0.7+wave);else ctx.quadraticCurveTo(x-R/wpts*0.5,R*0.86+wave,x,R*0.7+wave);}
  ctx.lineTo(R,0);ctx.closePath();ctx.fill();ctx.stroke();
  ctx.fillStyle='rgba(255,255,255,0.18)';ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(-R*0.24,-R*0.38,R*0.44,R*0.26,-0.3,0,Math.PI*2);ctx.fill();
  _mEyes(ctx,R*0.82,eyeCol||'#8844ff');
  ctx.globalAlpha=1;ctx.restore();
}

function _drawSlime(ctx,R,col,out,eyeCol,t){
  const jig=Math.sin(t*0.14)*R*0.07,lw=_mLw(R);
  ctx.fillStyle=_mD(col,14);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(0,jig,R*1.12,R*0.8,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,28);ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(-R*0.08,jig-R*0.06,R*0.72,R*0.54,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=_mL(col,52);ctx.beginPath();ctx.ellipse(-R*0.22,jig-R*0.16,R*0.34,R*0.24,0,0,Math.PI*2);ctx.fill();
  for(const[dx,sz]of[[R*0.38,0.18],[0,0.16],[-R*0.3,0.14]]){
    const drip=Math.sin(t*0.06+dx)*R*0.09;
    ctx.fillStyle=_mD(col,6);ctx.strokeStyle=out||'#111';ctx.lineWidth=Math.max(2,R*0.06);
    ctx.beginPath();ctx.ellipse(dx,R*0.72+drip,R*sz,R*sz*1.4,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  }
  const es=R*0.2,ex=R*0.28;
  for(const ey of[-R*0.15,R*0.15]){
    ctx.fillStyle='#fff';ctx.strokeStyle='#111';ctx.lineWidth=lw;ctx.beginPath();ctx.arc(ex,ey-R*0.04,es,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle=eyeCol||'#44ff44';ctx.beginPath();ctx.arc(ex+es*0.22,ey-R*0.04,es*0.58,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='#000';ctx.beginPath();ctx.arc(ex+es*0.3,ey-R*0.04,es*0.3,0,Math.PI*2);ctx.fill();
  }
}

function _drawMushroom(ctx,R,col,out,eyeCol){
  const lw=_mLw(R);
  ctx.fillStyle='#f0e8d0';ctx.strokeStyle='#555';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(R*0.26,R*0.36,R*0.38,R*0.28,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(-R*0.06,-R*0.16,R*0.96,R*0.72,-0.14,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,28);ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(-R*0.28,-R*0.34,R*0.44,R*0.24,-0.4,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='rgba(255,255,255,0.92)';
  for(const[sx,sy,sr]of[[-R*0.22,-R*0.3,R*0.18],[R*0.28,-R*0.24,R*0.15],[-R*0.06,R*0.02,R*0.13],[R*0.04,-R*0.46,R*0.11]]){
    ctx.beginPath();ctx.arc(sx,sy,sr,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='rgba(255,255,255,0.45)';ctx.beginPath();ctx.arc(sx-sr*0.3,sy-sr*0.3,sr*0.4,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='rgba(255,255,255,0.92)';
  }
  const es=R*0.15,ex=R*0.4;
  for(const ey of[-R*0.17,R*0.17]){
    ctx.fillStyle='#fff';ctx.strokeStyle='#111';ctx.lineWidth=lw;ctx.beginPath();ctx.arc(ex,ey+R*0.38,es,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle=eyeCol||'#ff2200';ctx.beginPath();ctx.arc(ex+es*0.2,ey+R*0.38,es*0.56,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='#000';ctx.beginPath();ctx.arc(ex+es*0.28,ey+R*0.38,es*0.28,0,Math.PI*2);ctx.fill();
  }
}

function _drawGoblin(ctx,R,col,out,eyeCol){
  const lw=_mLw(R);
  for(const s of[-1,1]){
    ctx.fillStyle=_mL(col,18);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
    ctx.beginPath();ctx.ellipse(-R*0.38,s*R*1.02,R*0.2,R*0.44,0.22*s,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle='#ff9999';ctx.beginPath();ctx.ellipse(-R*0.38,s*R*1.02,R*0.1,R*0.26,0.22*s,0,Math.PI*2);ctx.fill();
  }
  _mBody(ctx,R,col,out);
  ctx.fillStyle=_mL(col,20);ctx.strokeStyle='#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.arc(R*0.6,0,R*0.2,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle='#000';for(const s of[-1,1]){ctx.beginPath();ctx.arc(R*0.66,s*R*0.07,R*0.065,0,Math.PI*2);ctx.fill();}
  _mAngryEyes(ctx,R,eyeCol||'#ffee00');
  ctx.fillStyle='#fff';ctx.strokeStyle='#333';ctx.lineWidth=Math.max(1.5,R*0.05);
  for(const[tx,ys]of[[R*0.46,-1],[R*0.54,1],[R*0.46,1],[R*0.38,-1]]){ctx.beginPath();ctx.moveTo(tx,0);ctx.lineTo(tx+R*0.04,R*0.14*ys);ctx.lineTo(tx+R*0.08,0);ctx.closePath();ctx.fill();ctx.stroke();}
}

function _drawAngryEyes(ctx,R,eyeCol){_mEyes(ctx,R,eyeCol);const es=R*0.21,ex=R*0.38,lw=Math.max(3,R*0.1);ctx.strokeStyle='#111';ctx.lineWidth=lw;ctx.lineCap='round';for(const s of[-1,1]){ctx.beginPath();ctx.moveTo(ex-es*0.7,s*(R*0.21-es*0.92));ctx.lineTo(ex+es*0.6,s*(R*0.21-es*0.46));ctx.stroke();}}
function _mAngryEyes(ctx,R,eyeCol){_drawAngryEyes(ctx,R,eyeCol);}

function _drawTreeant(ctx,R,col,out,eyeCol,t){
  const lw=_mLw(R),sway=Math.sin(t*0.04)*R*0.05;
  ctx.fillStyle=_mD(col,28);ctx.strokeStyle='#111';ctx.lineWidth=Math.max(2,R*0.06);
  for(const[rx,ry,rr,ra]of[[R*0.28,R*0.88,R*0.2,-0.28],[R*0.48,R*0.78,R*0.16,0.1],[-R*0.12,R*0.9,R*0.18,0.18]]){
    ctx.beginPath();ctx.ellipse(rx,ry,rr,rr*0.44,ra,0,Math.PI*2);ctx.fill();ctx.stroke();
  }
  _mBody(ctx,R,col,out);
  ctx.strokeStyle=_mD(col,30);ctx.lineWidth=Math.max(2,R*0.06);ctx.lineCap='round';
  for(const[ax,ay,bx,by]of[[-R*0.5,-R*0.5,R*0.14,-R*0.08],[R*0.06,-R*0.58,R*0.62,R*0.12],[-R*0.58,R*0.1,-R*0.08,R*0.62],[R*0.18,R*0.16,R*0.58,R*0.6]]){
    ctx.beginPath();ctx.moveTo(ax,ay);ctx.lineTo(bx,by);ctx.stroke();
  }
  const lc=_mL(col,36),ls=_mD(lc,18);
  for(const[lx,ly,lr]of[[-R*0.28,-R*0.86,R*0.36],[R*0.0,-R*1.0,R*0.4],[R*0.28,-R*0.86,R*0.34]]){
    ctx.fillStyle=lc;ctx.strokeStyle=ls;ctx.lineWidth=Math.max(2,R*0.07);
    ctx.beginPath();ctx.arc(lx+sway*0.5,ly,lr,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle=_mL(lc,24);ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(lx+sway*0.4,ly-lr*0.34,lr*0.36,lr*0.2,0,0,Math.PI*2);ctx.fill();
  }
  _mEyes(ctx,R*0.88,eyeCol||'#88ff44');
}

function _drawBird(ctx,R,col,out,eyeCol,t){
  const lw=_mLw(R);_mBirdWings(ctx,R,col,out,t);_mBody(ctx,R,col,out);
  ctx.fillStyle='#ffaa00';ctx.strokeStyle='#444';ctx.lineWidth=Math.max(2,R*0.07);
  ctx.beginPath();ctx.moveTo(R*0.72,-R*0.07);ctx.lineTo(R*1.06,0);ctx.lineTo(R*0.72,R*0.07);ctx.closePath();ctx.fill();ctx.stroke();
  ctx.beginPath();ctx.moveTo(R*0.96,-R*0.02);ctx.quadraticCurveTo(R*1.1,-R*0.02,R*1.08,R*0.1);ctx.stroke();
  ctx.fillStyle=_mD(col,14);ctx.strokeStyle=out||'#111';ctx.lineWidth=Math.max(1.5,R*0.05);
  for(const[cx,cy]of[[-R*0.52,-R*0.58],[-R*0.38,-R*0.72],[-R*0.66,-R*0.44]]){ctx.beginPath();ctx.ellipse(cx,cy,R*0.1,R*0.22,-0.48,0,Math.PI*2);ctx.fill();ctx.stroke();}
  _mEyes(ctx,R*0.86,eyeCol||'#ff8800');
}

function _drawGolem(ctx,R,col,out,eyeCol){
  const lw=_mLw(R);_mBody(ctx,R,col,out);
  ctx.strokeStyle=_mD(col,34);ctx.lineWidth=Math.max(2,R*0.07);ctx.lineCap='round';
  ctx.beginPath();ctx.moveTo(-R*0.1,-R*0.72);ctx.lineTo(R*0.18,-R*0.18);ctx.lineTo(-R*0.06,R*0.14);ctx.stroke();
  ctx.beginPath();ctx.moveTo(R*0.28,-R*0.52);ctx.lineTo(R*0.62,-R*0.04);ctx.lineTo(R*0.18,R*0.38);ctx.stroke();
  ctx.beginPath();ctx.moveTo(-R*0.52,R*0.18);ctx.lineTo(-R*0.14,R*0.58);ctx.stroke();
  ctx.strokeStyle=_mD(col,22);ctx.lineWidth=Math.max(1.5,R*0.05);
  for(const[px,py,pr]of[[-R*0.24,-R*0.4,R*0.32],[R*0.16,R*0.22,R*0.26],[-R*0.38,R*0.38,R*0.2]]){ctx.beginPath();ctx.arc(px,py,pr,0,Math.PI*2);ctx.stroke();}
  if(_qualityLevel>=1){ctx.save();ctx.globalAlpha=0.42;ctx.shadowColor=eyeCol||'#ff8800';ctx.shadowBlur=24;ctx.fillStyle=eyeCol||'#ff8800';for(const ey of[-R*0.22,R*0.22]){ctx.beginPath();ctx.arc(R*0.42,ey,R*0.2,0,Math.PI*2);ctx.fill();}ctx.restore();}
  ctx.fillStyle=eyeCol||'#ff8800';
  for(const ey of[-R*0.22,R*0.22]){ctx.beginPath();ctx.arc(R*0.42,ey,R*0.18,0,Math.PI*2);ctx.fill();ctx.fillStyle='rgba(255,255,255,0.55)';ctx.beginPath();ctx.arc(R*0.36,ey-R*0.08,R*0.07,0,Math.PI*2);ctx.fill();ctx.fillStyle=eyeCol||'#ff8800';}
}

function _drawBoar(ctx,R,col,out,eyeCol,t){
  _mTail(ctx,R,col,t);_mBody(ctx,R,col,out);
  ctx.fillStyle=_mD(col,28);ctx.strokeStyle=out||'#111';ctx.lineWidth=Math.max(2,R*0.07);
  for(const[bx,by,br]of[[-R*0.58,0,R*0.16],[-R*0.45,-R*0.32,R*0.13],[-R*0.45,R*0.32,R*0.13],[-R*0.28,-R*0.46,R*0.1],[-R*0.28,R*0.46,R*0.1]]){ctx.beginPath();ctx.arc(bx,by,br,0,Math.PI*2);ctx.fill();ctx.stroke();}
  _mTusks(ctx,R);_mSnout(ctx,R,col);_mEyes(ctx,R,eyeCol||'#cc4400');_mBrows(ctx,R);
}

function _drawYeti(ctx,R,col,out,eyeCol,t){
  const lw=_mLw(R),sway=Math.sin(t*0.06)*R*0.04;
  for(const s of[-1,1]){
    ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
    ctx.beginPath();ctx.ellipse(s*R*0.76,R*0.28,R*0.36,R*0.66,-0.22*s,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle=_mD(col,10);ctx.beginPath();ctx.arc(s*R*0.88,R*0.76,R*0.24,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.strokeStyle='#c8d8f8';ctx.lineWidth=Math.max(1.5,R*0.05);ctx.lineCap='round';
    for(let ci=0;ci<3;ci++){const ca=-0.4+ci*0.4;ctx.beginPath();ctx.moveTo(s*R*0.86+Math.cos(ca)*R*0.2,R*0.76+Math.sin(ca)*R*0.2);ctx.lineTo(s*R*0.86+Math.cos(ca)*R*0.38,R*0.76+Math.sin(ca)*R*0.36);ctx.stroke();}
  }
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.arc(0,0,R,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,26);ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(-R*0.14,0,R*0.52,R*0.58,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#f2f6ff';ctx.strokeStyle=out||'#aac';ctx.lineWidth=Math.max(1.5,R*0.05);
  ctx.beginPath();ctx.ellipse(R*0.16,R*0.1,R*0.36,R*0.44,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  for(const s of[-1,1])_mEarRound(ctx,R,col,out,s);
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.arc(-R*0.18+sway,-R*0.06,R*0.48,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,20);ctx.beginPath();ctx.ellipse(-R*0.3,-R*0.08,R*0.22,R*0.16,0,0,Math.PI*2);ctx.fill();
  _mSnout(ctx,R*0.86,col);_mEyes(ctx,R*0.82,eyeCol||'#00ccff');
  ctx.save();ctx.globalAlpha=0.18+Math.sin(t*0.1)*0.07;ctx.fillStyle='#88ccff';
  ctx.beginPath();ctx.ellipse(R*0.78+sway,-R*0.04,R*0.26,R*0.14,0.3,0,Math.PI*2);ctx.fill();ctx.restore();
}

function _drawVampire(ctx,R,col,out,eyeCol,t){
  const lw=_mLw(R);
  ctx.save();ctx.globalAlpha=0.88;
  const capeSwing=Math.sin(t*0.06)*R*0.06;
  ctx.fillStyle='#1a0a2a';ctx.strokeStyle='#0a0414';ctx.lineWidth=lw;
  ctx.beginPath();ctx.moveTo(-R*0.3,-R*0.62);ctx.quadraticCurveTo(-R*1.2,capeSwing,-R*1.18,R*0.72+capeSwing);ctx.quadraticCurveTo(-R*0.52,R*0.92,R*0.1,R*0.76);ctx.quadraticCurveTo(R*0.5,R*0.58,R*0.32,-R*0.52);ctx.closePath();ctx.fill();ctx.stroke();
  ctx.fillStyle='#6a0a20';ctx.strokeStyle='none';
  ctx.beginPath();ctx.moveTo(-R*0.24,-R*0.54);ctx.quadraticCurveTo(-R*0.9,capeSwing*0.8,-R*0.88,R*0.6+capeSwing*0.8);ctx.quadraticCurveTo(-R*0.42,R*0.78,R*0.04,R*0.66);ctx.quadraticCurveTo(R*0.36,R*0.5,R*0.24,-R*0.44);ctx.closePath();ctx.fill();
  ctx.restore();
  _mBody(ctx,R,col,out);
  ctx.fillStyle=_mL(col,28);ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(R*0.14,0,R*0.52,R*0.6,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=_mD(col,22);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.moveTo(-R*0.44,-R*0.58);ctx.lineTo(-R*0.24,-R*0.88);ctx.lineTo(-R*0.04,-R*0.58);ctx.closePath();ctx.fill();ctx.stroke();
  _mEyes(ctx,R,eyeCol||'#cc0044');
  ctx.fillStyle='#fff';ctx.strokeStyle='#bbb';ctx.lineWidth=Math.max(1.5,R*0.05);
  for(const s of[-1,1]){ctx.beginPath();ctx.moveTo(R*0.3,s*R*0.06);ctx.lineTo(R*0.36,s*R*0.2);ctx.lineTo(R*0.42,s*R*0.06);ctx.closePath();ctx.fill();ctx.stroke();}
}

function _drawWerewolf(ctx,R,col,out,eyeCol,t){
  const lw=_mLw(R);
  _mTail(ctx,R,col,t);
  for(const s of[-1,1]){
    ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
    ctx.beginPath();ctx.moveTo(-R*0.34,s*R*0.62);ctx.lineTo(-R*0.76,s*R*1.22);ctx.lineTo(-R*0.12,s*R*0.84);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.fillStyle=_mL(col,40);ctx.beginPath();ctx.moveTo(-R*0.34,s*R*0.64);ctx.lineTo(-R*0.68,s*R*1.12);ctx.lineTo(-R*0.16,s*R*0.82);ctx.closePath();ctx.fill();
  }
  _mBody(ctx,R,col,out);
  ctx.fillStyle=_mL(col,26);ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(R*0.1,0,R*0.44,R*0.56,0,0,Math.PI*2);ctx.fill();
  for(const s of[-1,1]){
    ctx.fillStyle=_mD(col,8);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
    ctx.beginPath();ctx.ellipse(s*R*0.72,R*0.32,R*0.17,R*0.42,-0.3*s,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.strokeStyle='#c0c8d0';ctx.lineWidth=Math.max(2,R*0.07);ctx.lineCap='round';
    for(let ci=0;ci<3;ci++){const ca=-0.38+ci*0.38;ctx.beginPath();ctx.moveTo(s*R*0.66+Math.cos(ca)*R*0.36,R*0.56+Math.sin(ca)*R*0.2);ctx.lineTo(s*R*0.66+Math.cos(ca)*R*0.54,R*0.56+Math.sin(ca)*R*0.36);ctx.stroke();}
  }
  _mSnout(ctx,R,col,false);_mEyes(ctx,R,eyeCol||'#ff4400');_mBrows(ctx,R);
  ctx.strokeStyle=_mD(col,28);ctx.lineWidth=Math.max(1.5,R*0.054);ctx.lineCap='round';
  ctx.beginPath();ctx.moveTo(-R*0.2,-R*0.34);ctx.lineTo(R*0.06,-R*0.06);ctx.stroke();
  ctx.beginPath();ctx.moveTo(-R*0.3,R*0.12);ctx.lineTo(-R*0.06,R*0.44);ctx.stroke();
}

function _drawMinotaur(ctx,R,col,out,eyeCol,t){
  const lw=_mLw(R);
  for(const s of[-1,1]){
    ctx.fillStyle='#d4b440';ctx.strokeStyle='#443300';ctx.lineWidth=Math.max(2.5,R*0.09);ctx.lineCap='round';
    ctx.beginPath();ctx.moveTo(-R*0.42,s*R*0.76);ctx.quadraticCurveTo(-R*0.98,s*R*1.34,-R*0.56,s*R*1.5);ctx.quadraticCurveTo(-R*0.16,s*R*1.36,-R*0.18,s*R*0.94);ctx.closePath();ctx.fill();ctx.stroke();
  }
  _mBody(ctx,R,col,out);
  ctx.strokeStyle=_mD(col,28);ctx.lineWidth=Math.max(2,R*0.07);ctx.lineCap='round';
  ctx.beginPath();ctx.moveTo(-R*0.28,-R*0.66);ctx.lineTo(R*0.08,-R*0.18);ctx.stroke();
  ctx.beginPath();ctx.moveTo(R*0.08,-R*0.18);ctx.lineTo(R*0.24,R*0.3);ctx.stroke();
  ctx.beginPath();ctx.moveTo(-R*0.42,R*0.16);ctx.lineTo(-R*0.08,R*0.62);ctx.stroke();
  ctx.fillStyle=_mL(col,36);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(R*0.62,0,R*0.3,R*0.24,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle='rgba(0,0,0,0.55)';for(const s of[-1,1]){ctx.beginPath();ctx.ellipse(R*0.72,s*R*0.08,R*0.075,R*0.052,0.2*s,0,Math.PI*2);ctx.fill();}
  ctx.strokeStyle='#bb8800';ctx.lineWidth=Math.max(2.5,R*0.08);ctx.beginPath();ctx.arc(R*0.66,0,R*0.08,0,Math.PI*1.6);ctx.stroke();
  _mEyes(ctx,R*0.82,eyeCol||'#ff4400');_mBrows(ctx,R);
}

function _drawDrake(ctx,R,col,out,eyeCol,t){
  const lw=_mLw(R),tSwing=Math.sin(t*0.1)*R*0.15;
  ctx.strokeStyle=_mD(col,18);ctx.lineWidth=Math.max(4,R*0.14);ctx.lineCap='round';
  ctx.beginPath();ctx.moveTo(-R*0.68,0);ctx.quadraticCurveTo(-R*1.18,tSwing,-R*1.58,tSwing*0.46);ctx.stroke();
  ctx.fillStyle=_mD(col,22);ctx.strokeStyle=out||'#111';ctx.lineWidth=Math.max(1.5,R*0.05);
  for(const[sx,sy,sh]of[[-R*0.54,-R*0.72,R*0.23],[-R*0.24,-R*0.76,R*0.28],[R*0.08,-R*0.74,R*0.23]]){
    ctx.beginPath();ctx.moveTo(sx-sh*0.36,sy+sh*0.9);ctx.lineTo(sx,sy-sh*0.5);ctx.lineTo(sx+sh*0.36,sy+sh*0.9);ctx.closePath();ctx.fill();ctx.stroke();
  }
  for(const s of[-1,1]){ctx.fillStyle=_mL(col,14);ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;ctx.beginPath();ctx.ellipse(-R*0.08,s*R*0.72,R*0.32,R*0.15,0.38*s,0,Math.PI*2);ctx.fill();ctx.stroke();}
  _mBody(ctx,R,col,out);
  ctx.fillStyle=_mL(col,20);ctx.strokeStyle='none';ctx.beginPath();ctx.ellipse(R*0.14,0,R*0.62,R*0.54,0,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle=_mD(col,28);ctx.lineWidth=Math.max(1.5,R*0.05);
  for(const s of[-1,1])for(const sx of[-R*0.3,0,R*0.3]){ctx.beginPath();ctx.arc(sx,s*R*0.5,R*0.14,s*0.2,s*(Math.PI-0.2));ctx.stroke();}
  ctx.fillStyle=col;ctx.strokeStyle=out||'#111';ctx.lineWidth=lw;
  ctx.beginPath();ctx.ellipse(R*0.48,0,R*0.44,R*0.34,0,0,Math.PI*2);ctx.fill();ctx.stroke();
  ctx.fillStyle=_mL(col,28);ctx.beginPath();ctx.ellipse(R*0.64,0,R*0.22,R*0.15,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#f0f0e0';ctx.strokeStyle='#555';ctx.lineWidth=Math.max(1.5,R*0.05);
  for(const s of[-1,1])for(let ti=0;ti<3;ti++){const tx=R*(0.66+ti*0.1);ctx.beginPath();ctx.moveTo(tx,s*R*0.05);ctx.lineTo(tx+R*0.038,s*R*0.18);ctx.lineTo(tx+R*0.076,s*R*0.05);ctx.closePath();ctx.fill();ctx.stroke();}
  _mEyes(ctx,R*0.8,eyeCol||'#88ff44');
}

// ── Main shape dispatcher (Foolproof, Guaranteed 100% Visible Fallback) ──────
function drawMobShape(ctx, R, col, out, eyeCol, shape, t, e) {
  col = col || '#6b4932';
  out = out || '#28170d';
  eyeCol = eyeCol || '#ffcc66';
  t = t || 0;
  const lw = Math.max(2.5, R * 0.08);

  ctx.save();
  if (shape === 'scorpion' || shape === 'akrep') {
    // 8 Jointed Legs
    ctx.strokeStyle = out; ctx.lineWidth = lw;
    for (let s of [-1, 1]) {
      for (let i = -1; i <= 2; i++) {
        ctx.beginPath();
        ctx.moveTo(0, s * R * 0.4);
        ctx.lineTo(i * 8 - 4, s * R * 1.3);
        ctx.stroke();
      }
    }
    // Body & Claws & Stinger
    _mBody(ctx, R * 0.9, col, out, lw);
    if (typeof _mClaws === 'function') _mClaws(ctx, R, col, out);
    if (typeof _mStinger === 'function') _mStinger(ctx, R, col, t);
    _mEyes(ctx, R * 0.8, eyeCol);
  } else if (shape === 'spider' || shape === 'orumcek' || shape === 'örümcek') {
    // 8 Spider Legs
    if (typeof _mSpiderLegs === 'function') _mSpiderLegs(ctx, R, col);
    // Abdomen & Cephalothorax
    ctx.fillStyle = col; ctx.strokeStyle = out; ctx.lineWidth = lw;
    ctx.beginPath(); ctx.arc(-R * 0.4, 0, R * 0.75, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.arc(R * 0.35, 0, R * 0.55, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    // 4 glowing spider eyes
    for (let ey of [-R * 0.15, -R * 0.05, R * 0.05, R * 0.15]) {
      ctx.fillStyle = eyeCol;
      ctx.beginPath(); ctx.arc(R * 0.65, ey, R * 0.09, 0, Math.PI * 2); ctx.fill();
    }
  } else if (shape === 'bear' || shape === 'ayi') {
    // Massive round bear body + round ears + paws
    if (typeof _mEarRound === 'function') {
      _mEarRound(ctx, R, col, out, -1);
      _mEarRound(ctx, R, col, out, 1);
    }
    _mBody(ctx, R * 1.05, col, out, lw);
    ctx.fillStyle = col; ctx.strokeStyle = out; ctx.lineWidth = lw;
    for (let s of [-1, 1]) {
      ctx.beginPath(); ctx.ellipse(R * 0.7, s * R * 0.75, R * 0.35, R * 0.25, s * 0.4, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    }
    _mEyes(ctx, R * 0.85, eyeCol);
  } else {
    // Wolf / Canine
    if (typeof _mTail === 'function') _mTail(ctx, R, col, t);
    if (typeof _mEarPoint === 'function') {
      _mEarPoint(ctx, R, col, out, -1);
      _mEarPoint(ctx, R, col, out, 1);
    }
    _mBody(ctx, R, col, out, lw);
    if (typeof _mPaws === 'function') _mPaws(ctx, R, col, out);
    _mEyes(ctx, R, eyeCol);
  }
  ctx.restore();
}
// ============================================================
// ANIMATED SKELETAL MOB ASSETS & RENDER ENGINE (Wolf, Scorpion, Bear, Spider)
// ============================================================
const _MOB_ASSETS = {
  // Kurt (Wolf)
  kurt_govde: new Image(),
  kurt_kafa: new Image(),
  kurt_kafa_acik: new Image(),
  kurt_kuyruk: new Image(),
  kurt_pati: new Image(),

  // Akrep (Scorpion)
  akrep_govde: new Image(),
  akrep_kafa: new Image(),
  akrep_bacak: new Image(),
  akrep_kuyruk: new Image(),
  akrep_igne: new Image(),
  akrep_kol_ust: new Image(),
  akrep_kol_alt: new Image(),
  akrep_kiskac_dis: new Image(),
  akrep_kiskac_ic: new Image(),

  // Ayı (Bear)
  bear_govde: new Image(),
  bear_kafa: new Image(),
  bear_kafa_acik: new Image(),
  bear_kol: new Image(),
  bear_pence: new Image(),
  bear_bacak: new Image(),
  bear_kuyruk: new Image(),
  bear_cizik: new Image(),

  // Örümcek (Spider)
  spider_abdomen: new Image(),
  spider_kafa: new Image(),
  spider_bacak: new Image(),
  spider_pedipalp: new Image(),
  spider_dis: new Image(),
  spider_ag_mermi: new Image(),
  spider_ag_tuzak: new Image()
};

const _MOB_ASSET_BASE = '/mobassets/';
_MOB_ASSETS.kurt_govde.src = _MOB_ASSET_BASE + 'kurt_govde.png';
_MOB_ASSETS.kurt_kafa.src = _MOB_ASSET_BASE + 'kurt_kafa.png';
_MOB_ASSETS.kurt_kafa_acik.src = _MOB_ASSET_BASE + 'kurt_kafa_acik.png';
_MOB_ASSETS.kurt_kuyruk.src = _MOB_ASSET_BASE + 'kurt_kuyruk.png';
_MOB_ASSETS.kurt_pati.src = _MOB_ASSET_BASE + 'kurt_pati.png';

_MOB_ASSETS.akrep_govde.src = _MOB_ASSET_BASE + 'akrep_govde.png';
_MOB_ASSETS.akrep_kafa.src = _MOB_ASSET_BASE + 'akrep_kafa.png';
_MOB_ASSETS.akrep_bacak.src = _MOB_ASSET_BASE + 'akrep_bacak.png';
_MOB_ASSETS.akrep_kuyruk.src = _MOB_ASSET_BASE + 'akrep_kuyruk.png';
_MOB_ASSETS.akrep_igne.src = _MOB_ASSET_BASE + 'akrep_igne.png';
_MOB_ASSETS.akrep_kol_ust.src = _MOB_ASSET_BASE + 'akrep_kol_ust.png';
_MOB_ASSETS.akrep_kol_alt.src = _MOB_ASSET_BASE + 'akrep_kol_alt.png';
_MOB_ASSETS.akrep_kiskac_dis.src = _MOB_ASSET_BASE + 'akrep_kiskac_dis.png';
_MOB_ASSETS.akrep_kiskac_ic.src = _MOB_ASSET_BASE + 'akrep_kiskac_ic.png';

_MOB_ASSETS.bear_govde.src = _MOB_ASSET_BASE + 'bear_govde.png';
_MOB_ASSETS.bear_kafa.src = _MOB_ASSET_BASE + 'bear_kafa.png';
_MOB_ASSETS.bear_kafa_acik.src = _MOB_ASSET_BASE + 'bear_kafa_acik.png';
_MOB_ASSETS.bear_kol.src = _MOB_ASSET_BASE + 'bear_kol.png';
_MOB_ASSETS.bear_pence.src = _MOB_ASSET_BASE + 'bear_pence.png';
_MOB_ASSETS.bear_bacak.src = _MOB_ASSET_BASE + 'bear_bacak.png';
_MOB_ASSETS.bear_kuyruk.src = _MOB_ASSET_BASE + 'bear_kuyruk.png';
_MOB_ASSETS.bear_cizik.src = _MOB_ASSET_BASE + 'bear_cizik.png';

_MOB_ASSETS.spider_abdomen.src = _MOB_ASSET_BASE + 'spider_abdomen.png';
_MOB_ASSETS.spider_kafa.src = _MOB_ASSET_BASE + 'spider_kafa.png';
_MOB_ASSETS.spider_bacak.src = _MOB_ASSET_BASE + 'spider_bacak.png';
_MOB_ASSETS.spider_pedipalp.src = _MOB_ASSET_BASE + 'spider_pedipalp.png';
_MOB_ASSETS.spider_dis.src = _MOB_ASSET_BASE + 'spider_dis.png';
_MOB_ASSETS.spider_ag_mermi.src = _MOB_ASSET_BASE + 'spider_ag_mermi.png';
_MOB_ASSETS.spider_ag_tuzak.src = _MOB_ASSET_BASE + 'spider_ag_tuzak.png';

const _mobWebProjectiles = [];
const _mobWebTraps = [];
const _mobScratchEffects = [];
const _mobWebCooldowns = new Map();

function spawnMobAttackEffect(type, x, y, angle, targetX, targetY) {
  if (type === 'spider' || type === 'orumcek' || type === 'örümcek' || type === 'spider_web') {
    const ang = angle !== undefined ? angle : (targetX !== undefined && targetY !== undefined ? Math.atan2(targetY - y, targetX - x) : 0);
    _mobWebProjectiles.push({ x, y, vx: Math.cos(ang) * 14, vy: Math.sin(ang) * 14, angle: ang, life: 35, active: true, targetX, targetY });
    playSound(420, 0.08, 'triangle', 0.2);
  } else if (type === 'bear' || type === 'ayi') {
    _mobScratchEffects.push({ x: targetX || x, y: targetY || y, angle: angle || 0, life: 25, maxLife: 25 });
    shake(12); playSound(110, 0.2, 'sawtooth', 0.4);
  }
}

function updateAndDrawMobAttackEffects(ctx) {
  // 1. Web Traps
  for (let i = _mobWebTraps.length - 1; i >= 0; i--) {
    const wt = _mobWebTraps[i];
    wt.life--;
    if (wt.life <= 0) {
      _mobWebTraps.splice(i, 1);
      continue;
    }
    const alpha = Math.min(1, wt.life / 20);
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(wt.x, wt.y);
    if (_MOB_ASSETS.spider_ag_tuzak.complete && _MOB_ASSETS.spider_ag_tuzak.naturalWidth > 0) {
      ctx.drawImage(_MOB_ASSETS.spider_ag_tuzak, -45, -45, 90, 90);
    } else {
      ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(0, 0, 35, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.restore();
    if (Math.hypot(wt.x - player.x, wt.y - player.y) < 45) {
      player.vx *= 0.72; player.vy *= 0.72;
    }
  }

  // 2. Web Projectiles
  for (let i = _mobWebProjectiles.length - 1; i >= 0; i--) {
    const wp = _mobWebProjectiles[i];
    wp.x += wp.vx;
    wp.y += wp.vy;
    wp.life--;
    ctx.save();
    ctx.translate(wp.x, wp.y);
    ctx.rotate(wp.angle);
    if (_MOB_ASSETS.spider_ag_mermi.complete && _MOB_ASSETS.spider_ag_mermi.naturalWidth > 0) {
      ctx.drawImage(_MOB_ASSETS.spider_ag_mermi, -25, -25, 50, 50);
    } else {
      ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(0, 0, 12, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();

    // Check hit on player — 1.5s Complete Root + Damage on Impact
    if (wp.active && Math.hypot(wp.x - player.x, wp.y - player.y) < 48) {
      wp.active = false;
      player._webRootTimer = 90; // 90 frames = 1.5 seconds rooted
      player.vx = 0; player.vy = 0;
      player.momX = 0; player.momY = 0;
      const webDmg = wp.dmg || 16;
      player.hp = Math.max(0, player.hp - webDmg);
      updateHpBar();
      triggerDmgFlash();
      shake(10);
      floatingTexts.push({ x: player.x, y: player.y - 65, text: `🕸️ -${webDmg} HP  AĞA YAKALANDIN! (1.5s)`, alpha: 1, life: 65, color: '#ffffff', big: true });
      playSound(140, 0.2, 'sawtooth', 0.4);
      if (player.hp <= 0 && !_isDying) die();
    }
    if (wp.life <= 0 || !wp.active) _mobWebProjectiles.splice(i, 1);
  }

  // 3. Bear Claw Scratch Effects
  for (let i = _mobScratchEffects.length - 1; i >= 0; i--) {
    const sc = _mobScratchEffects[i];
    sc.life--;
    const alpha = sc.life / sc.maxLife;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(sc.x, sc.y);
    ctx.rotate(sc.angle);
    if (_MOB_ASSETS.bear_cizik.complete && _MOB_ASSETS.bear_cizik.naturalWidth > 0) {
      ctx.drawImage(_MOB_ASSETS.bear_cizik, -65, -65, 130, 130);
    } else {
      ctx.strokeStyle = 'rgba(255,50,0,0.85)'; ctx.lineWidth = 6;
      ctx.beginPath(); ctx.moveTo(-45, -45); ctx.lineTo(45, 45); ctx.stroke();
    }
    ctx.restore();
    if (sc.life <= 0) _mobScratchEffects.splice(i, 1);
  }
}

function _drawSpriteWolf(ctx, e, R, isMoving, state, animTimer, attackTimer, flash) {
  if (!_MOB_ASSETS.kurt_govde.complete || _MOB_ASSETS.kurt_govde.naturalWidth === 0 ||
      !_MOB_ASSETS.kurt_kafa.complete || _MOB_ASSETS.kurt_kafa.naturalWidth === 0) {
    return false;
  }
  ctx.save();
  const scale = R / 28;
  ctx.scale(scale, scale);
  ctx.rotate(Math.PI / 2);

  const attackDuration = 55;
  const attackProg = state === 'attack' ? (attackTimer / attackDuration) : 0;
  let stretchY = 0;
  let headStretchY = 0;
  let isBiting = false;

  if (state === 'attack') {
    if (attackProg < 0.3) {
      const w = attackProg / 0.3;
      stretchY = w * 8;
      headStretchY = w * 6;
    } else if (attackProg < 0.6) {
      const s = (attackProg - 0.3) / 0.3;
      const strike = Math.sin(s * Math.PI);
      stretchY = -strike * 18;
      headStretchY = -strike * 28;
      isBiting = true;
    } else {
      const r = (attackProg - 0.6) / 0.4;
      stretchY = -18 * (1 - r);
      headStretchY = -28 * (1 - r);
    }
  }

  const bodyBob = isMoving && state !== 'attack' ? Math.sin(animTimer * 2) * 2 : Math.sin(animTimer) * 1.5;

  // 1. Paws
  if (_MOB_ASSETS.kurt_pati.complete && _MOB_ASSETS.kurt_pati.naturalWidth > 0) {
    const paws = [
      { x: -22, y: -15, phase: 0 },
      { x: 22, y: -15, phase: Math.PI },
      { x: -24, y: 25, phase: Math.PI },
      { x: 24, y: 25, phase: 0 }
    ];
    paws.forEach(paw => {
      const moveAnim = isMoving && state !== 'attack' ? Math.sin(animTimer + paw.phase) * 12 : 0;
      ctx.drawImage(_MOB_ASSETS.kurt_pati, paw.x - 20, (paw.y + moveAnim) - 20, 40, 40);
    });
  }

  // 2. Tail
  if (_MOB_ASSETS.kurt_kuyruk.complete && _MOB_ASSETS.kurt_kuyruk.naturalWidth > 0) {
    ctx.save();
    let tailSwing = isMoving ? Math.sin(animTimer) * 0.4 : Math.sin(animTimer * 0.5) * 0.2;
    if (state === 'attack') tailSwing = 0;
    ctx.translate(0, 32 + bodyBob);
    ctx.rotate(tailSwing);
    ctx.drawImage(_MOB_ASSETS.kurt_kuyruk, -60, -20, 120, 120);
    ctx.restore();
  }

  // 3. Body
  ctx.save();
  ctx.translate(0, stretchY + bodyBob);
  ctx.drawImage(_MOB_ASSETS.kurt_govde, -60, -60, 120, 120);
  ctx.restore();

  // 4. Head
  ctx.save();
  ctx.translate(0, stretchY + bodyBob + headStretchY - 10);
  const currentHead = (isBiting && _MOB_ASSETS.kurt_kafa_acik.complete && _MOB_ASSETS.kurt_kafa_acik.naturalWidth > 0) ? _MOB_ASSETS.kurt_kafa_acik : _MOB_ASSETS.kurt_kafa;
  ctx.drawImage(currentHead, -50, -50, 100, 100);
  ctx.restore();

  // Fast GPU flash without expensive ctx.filter
  if (flash) {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
    ctx.beginPath(); ctx.arc(0, 0, 48, 0, Math.PI * 2); ctx.fill();
  }

  ctx.restore();
  return true;
}

function _drawSpriteScorpion(ctx, e, R, isMoving, state, animTimer, attackTimer, flash) {
  if (!_MOB_ASSETS.akrep_govde.complete || _MOB_ASSETS.akrep_govde.naturalWidth === 0 ||
      !_MOB_ASSETS.akrep_kafa.complete || _MOB_ASSETS.akrep_kafa.naturalWidth === 0) {
    return false;
  }
  ctx.save();
  const scale = R / 32;
  ctx.scale(scale, scale);
  ctx.rotate(Math.PI / 2);

  const attackDuration = 70;
  const attackProg = state === 'attack' ? (attackTimer / attackDuration) : 0;

  // 1. Legs (8 Legs)
  if (_MOB_ASSETS.akrep_bacak.complete && _MOB_ASSETS.akrep_bacak.naturalWidth > 0) {
    for (let i = 0; i < 4; i++) {
      for (let side = -1; side <= 1; side += 2) {
        const yOffset = (i - 1.5) * 14;
        const legPhase = (i + (side === -1 ? 2 : 0)) * Math.PI / 2;
        ctx.save();
        ctx.translate(side * 14, yOffset);
        if (side === -1) ctx.scale(-1, 1);
        ctx.rotate(Math.sin(animTimer * 2 + legPhase) * (isMoving ? 0.38 : 0.05));
        ctx.drawImage(_MOB_ASSETS.akrep_bacak, -15, -30, 60, 60);
        ctx.restore();
      }
    }
  }

  // 2. Tail (6 Segments + Stinger)
  ctx.save();
  let tailBaseAngle = Math.sin(animTimer * 0.5) * 0.1;
  if (state === 'attack') {
    if (attackProg < 0.4) {
      tailBaseAngle = (attackProg / 0.4) * Math.PI * 0.35;
    } else {
      const strikeProg = (attackProg - 0.4) / 0.6;
      const strikeForce = Math.sin(strikeProg * Math.PI);
      tailBaseAngle = Math.PI * 0.35 - strikeForce * Math.PI * 1.5;
    }
  }
  ctx.translate(0, 32);
  ctx.rotate(tailBaseAngle);

  const tailSegments = 6;
  for (let t = 0; t < tailSegments; t++) {
    let segAngle = 0;
    if (state === 'attack') {
      if (attackProg < 0.4) {
        segAngle = (attackProg / 0.4) * 0.18;
      } else {
        const strikeProg = (attackProg - 0.4) / 0.6;
        const sf = Math.sin(strikeProg * Math.PI);
        segAngle = -sf * 0.25;
        if (t > 2) segAngle *= 1.6;
      }
    } else {
      segAngle = Math.sin(animTimer * 0.8 + t * 0.5) * 0.08;
    }
    ctx.rotate(segAngle);
    const segScale = 1 - (t * 0.1);
    ctx.save(); ctx.scale(segScale, segScale);
    if (_MOB_ASSETS.akrep_kuyruk.complete && _MOB_ASSETS.akrep_kuyruk.naturalWidth > 0) ctx.drawImage(_MOB_ASSETS.akrep_kuyruk, -20, -20, 40, 40);
    ctx.restore();
    ctx.translate(0, 14);
  }

  if (state === 'attack') {
    const stingerAngle = attackProg < 0.4 ? 0 : -Math.sin(((attackProg - 0.4) / 0.6) * Math.PI) * 0.6;
    ctx.rotate(stingerAngle);
  }
  if (_MOB_ASSETS.akrep_igne.complete && _MOB_ASSETS.akrep_igne.naturalWidth > 0) ctx.drawImage(_MOB_ASSETS.akrep_igne, -20, -25, 40, 40);
  ctx.restore();

  // 3. Body & Head
  ctx.save();
  ctx.drawImage(_MOB_ASSETS.akrep_govde, -50, -50, 100, 100);
  ctx.translate(0, -32);
  ctx.drawImage(_MOB_ASSETS.akrep_kafa, -30, -30, 60, 60);
  ctx.restore();

  // 4. Pincers
  for (let side = -1; side <= 1; side += 2) {
    ctx.save();
    let shoulderAngle = side * 0.4;
    let elbowAngle = side * -0.6;
    let pincerAngle = 0;
    const shoulderX = side * 18;
    const shoulderY = -34;

    if (state === 'attack') {
      if (attackProg < 0.4) {
        const w = attackProg / 0.4;
        shoulderAngle += side * w * 0.3;
        elbowAngle -= side * w * 0.3;
        pincerAngle = w * 0.6;
      } else {
        const s = (attackProg - 0.4) / 0.6;
        const strike = Math.sin(s * Math.PI);
        shoulderAngle -= side * 0.6 * strike;
        elbowAngle += side * strike * 0.9;
        pincerAngle = 0.6 - (strike * 0.8);
      }
    }

    ctx.translate(shoulderX, shoulderY);
    ctx.rotate(shoulderAngle);
    if (side === -1) ctx.scale(-1, 1);
    if (_MOB_ASSETS.akrep_kol_ust.complete && _MOB_ASSETS.akrep_kol_ust.naturalWidth > 0) ctx.drawImage(_MOB_ASSETS.akrep_kol_ust, -15, -20, 30, 40);

    ctx.translate(0, -18);
    ctx.rotate(elbowAngle);
    if (_MOB_ASSETS.akrep_kol_alt.complete && _MOB_ASSETS.akrep_kol_alt.naturalWidth > 0) ctx.drawImage(_MOB_ASSETS.akrep_kol_alt, -15, -20, 30, 40);

    ctx.translate(0, -18);
    ctx.save();
    ctx.rotate(pincerAngle);
    if (_MOB_ASSETS.akrep_kiskac_dis.complete && _MOB_ASSETS.akrep_kiskac_dis.naturalWidth > 0) ctx.drawImage(_MOB_ASSETS.akrep_kiskac_dis, -15, -25, 30, 50);
    ctx.restore();

    ctx.save();
    ctx.rotate(-pincerAngle * 0.5);
    if (_MOB_ASSETS.akrep_kiskac_ic.complete && _MOB_ASSETS.akrep_kiskac_ic.naturalWidth > 0) ctx.drawImage(_MOB_ASSETS.akrep_kiskac_ic, -10, -20, 20, 40);
    ctx.restore();

    ctx.restore();
  }

  if (flash) {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
    ctx.beginPath(); ctx.arc(0, 0, 50, 0, Math.PI * 2); ctx.fill();
  }

  ctx.restore();
  return true;
}

function _drawSpriteBear(ctx, e, R, isMoving, state, animTimer, attackTimer, flash) {
  if (!_MOB_ASSETS.bear_govde.complete || _MOB_ASSETS.bear_govde.naturalWidth === 0) {
    return false;
  }
  ctx.save();
  const scale = R / 36;
  ctx.scale(scale, scale);
  ctx.rotate(Math.PI / 2);

  const aDur = 75;
  const aProg = state === 'attack' ? (attackTimer / aDur) : 0;
  const bodySway = isMoving ? Math.sin(animTimer) * 0.1 : 0;
  let bY = 0; let aLift = 0; let aSmash = 0; let hY = 0; let roar = false;

  if (state === 'attack') {
    if (aProg < 0.4) {
      const w = Math.sin((aProg / 0.4) * (Math.PI / 2));
      bY = w * 8; aLift = w * 32; hY = -w * 6;
    } else if (aProg < 0.65) {
      const s = (aProg - 0.4) / 0.25;
      const strike = Math.max(0, Math.sin(s * Math.PI));
      bY = 8 - (strike * 20); aLift = 32 * (1 - s); aSmash = strike; hY = strike * 18; roar = true;
    } else {
      const r = (aProg - 0.65) / 0.35;
      bY = -12 * (1 - Math.pow(1 - r, 2));
    }
  } else if (isMoving) {
    bY = Math.abs(Math.sin(animTimer * 2)) * 3;
  } else {
    bY = Math.sin(animTimer) * 1.5;
  }

  ctx.rotate(bodySway);

  // 1. Back legs
  if (_MOB_ASSETS.bear_bacak.complete && _MOB_ASSETS.bear_bacak.naturalWidth > 0) {
    for (let s = -1; s <= 1; s += 2) {
      ctx.save();
      const lMv = isMoving ? Math.sin(animTimer + (s === 1 ? Math.PI : 0)) * 12 : 0;
      ctx.translate(s * 22 + (s * aLift * 0.2), 35 + bY + lMv);
      if (s === -1) ctx.scale(-1, 1);
      ctx.drawImage(_MOB_ASSETS.bear_bacak, -30, -30, 60, 60);
      ctx.restore();
    }
  }

  // 2. Tail
  if (_MOB_ASSETS.bear_kuyruk.complete && _MOB_ASSETS.bear_kuyruk.naturalWidth > 0) {
    ctx.save();
    ctx.translate(0, 48 + bY);
    ctx.drawImage(_MOB_ASSETS.bear_kuyruk, -20, -20, 40, 40);
    ctx.restore();
  }

  // 3. Body
  ctx.save();
  ctx.translate(0, bY);
  ctx.drawImage(_MOB_ASSETS.bear_govde, -60, -60, 120, 120);

  // 4. Head
  ctx.translate(0, -25 + hY);
  const kafaImg = (roar && _MOB_ASSETS.bear_kafa_acik.complete && _MOB_ASSETS.bear_kafa_acik.naturalWidth > 0) ? _MOB_ASSETS.bear_kafa_acik : _MOB_ASSETS.bear_kafa;
  if (kafaImg.complete && kafaImg.naturalWidth > 0) {
    ctx.drawImage(kafaImg, -40, -40, 80, 80);
  }
  ctx.restore();

  // 5. Arms & Claws
  if (_MOB_ASSETS.bear_pence.complete && _MOB_ASSETS.bear_pence.naturalWidth > 0) {
    for (let s = -1; s <= 1; s += 2) {
      ctx.save();
      ctx.translate(s * 26, -10 + bY);
      let handX = s * 6;
      let handY = 26 + aLift;
      if (isMoving) handY += Math.sin(animTimer + (s === -1 ? Math.PI : 0)) * 14;
      if (state === 'attack' && aSmash > 0) {
        handY -= aSmash * 42;
        handX -= s * aSmash * 18;
      }
      ctx.save();
      ctx.translate(handX, handY);
      let pawAng = s * 0.2;
      if (aSmash > 0) pawAng = -s * 0.8 * aSmash;
      ctx.rotate(pawAng);
      if (s === -1) ctx.scale(-1, 1);
      ctx.drawImage(_MOB_ASSETS.bear_pence, -30, -25, 60, 60);
      ctx.restore();
      ctx.restore();
    }
  }

  if (flash) {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
    ctx.beginPath(); ctx.arc(0, 0, 56, 0, Math.PI * 2); ctx.fill();
  }

  ctx.restore();
  return true;
}

function _drawSpriteSpider(ctx, e, R, isMoving, state, animTimer, attackTimer, flash) {
  if (!_MOB_ASSETS.spider_abdomen.complete || _MOB_ASSETS.spider_abdomen.naturalWidth === 0) {
    return false;
  }
  ctx.save();
  const scale = R / 30;
  ctx.scale(scale, scale);
  ctx.rotate(Math.PI / 2);

  const attackDuration = 65;
  const attackProg = state === 'attack' ? (attackTimer / attackDuration) : 0;
  let rearing = 0; let lunge = 0;

  if (state === 'attack') {
    if (attackProg < 0.4) {
      rearing = Math.sin((attackProg / 0.4) * (Math.PI / 2));
    } else if (attackProg < 0.65) {
      const s = (attackProg - 0.4) / 0.25;
      lunge = Math.sin(s * Math.PI);
      rearing = 1 - s;
    }
  }

  const bodyY = (rearing * 12) - (lunge * 20);

  // Legs
  if (_MOB_ASSETS.spider_bacak.complete && _MOB_ASSETS.spider_bacak.naturalWidth > 0) {
    const legs = [
      { s: -1, x: -12, y: -15, r: -0.2, f: true },
      { s: -1, x: -14, y: -5,  r: 0,    f: true },
      { s: -1, x: -14, y: 5,   r: 0.2,  f: false },
      { s: -1, x: -12, y: 15,  r: 0.5,  f: false },
      { s: 1,  x: 12,  y: -15, r: 0.2,  f: true },
      { s: 1,  x: 14,  y: -5,  r: 0,    f: true },
      { s: 1,  x: 14,  y: 5,   r: -0.2, f: false },
      { s: 1,  x: 12,  y: 15,  r: -0.5, f: false }
    ];
    legs.forEach((leg, i) => {
      ctx.save();
      ctx.translate(leg.x, bodyY + leg.y);
      const moveAnim = isMoving ? Math.sin(animTimer + i) * 0.3 : 0;
      const liftAnim = leg.f ? (rearing * 0.6) : 0;
      ctx.rotate(leg.r + moveAnim + (leg.s * liftAnim));
      if (leg.s === -1) ctx.scale(-1, 1);
      ctx.drawImage(_MOB_ASSETS.spider_bacak, -10, -20, 60, 60);
      ctx.restore();
    });
  }

  // Body (Abdomen & Head)
  ctx.save();
  ctx.translate(0, bodyY);
  ctx.drawImage(_MOB_ASSETS.spider_abdomen, -35, -30, 70, 85);
  ctx.translate(0, -28 - (rearing * 5));
  if (_MOB_ASSETS.spider_kafa.complete && _MOB_ASSETS.spider_kafa.naturalWidth > 0) {
    ctx.drawImage(_MOB_ASSETS.spider_kafa, -31, -29, 62, 56);
  }
  // Head details sit above the body so the face remains readable at game scale.
  const faceWave = Math.sin(animTimer * 1.8) * 0.08;
  if (_MOB_ASSETS.spider_pedipalp.complete && _MOB_ASSETS.spider_pedipalp.naturalWidth > 0) {
    for (const side of [-1, 1]) {
      ctx.save();
      ctx.translate(side * 18, 13);
      ctx.rotate(side * (0.28 + faceWave));
      ctx.drawImage(_MOB_ASSETS.spider_pedipalp, -7, -24, 18, 36);
      ctx.restore();
    }
  }
  if (_MOB_ASSETS.spider_dis.complete && _MOB_ASSETS.spider_dis.naturalWidth > 0) {
    ctx.save();
    ctx.translate(3, 21 + (lunge * 4));
    ctx.rotate(lunge * 0.16);
    ctx.drawImage(_MOB_ASSETS.spider_dis, -9, -7, 18, 18);
    ctx.restore();
  }
  ctx.restore();

  if (flash) {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
    ctx.beginPath(); ctx.arc(0, 0, 46, 0, Math.PI * 2); ctx.fill();
  }

  ctx.restore();
  return true;
}

// ── Main enemy draw entry point ───────────────────────────────
function drawEnemy(e) {
  if (!e) return;
  // FIX: Ensure all mob properties are valid to prevent invisible mobs
  if (typeof e.x !== 'number' || isNaN(e.x)) e.x = Number(e._targetX) || 0;
  if (typeof e.y !== 'number' || isNaN(e.y)) e.y = Number(e._targetY) || 0;
  if (!(e.radius > 0) || isNaN(e.radius)) e.radius = 46;
  if (!e.color) e.color = '#6b4932';
  if (!e.outline) e.outline = '#28170d';
  if (!e.eyes) e.eyes = '#ffcc66';
  if (!e.shape) e.shape = 'wolf';
  if (!e.hp) e.hp = 100;
  if (!e.maxHp) e.maxHp = 100;
  
  const flash = e.hitFlash > 0;
  const R = e.radius;
  const shape = e.shape || 'wolf';

  const isMoving = Math.hypot(e.vx || 0, e.vy || 0) > 0.4;
  e.animTimer = (e.animTimer || 0) + (isMoving ? 0.22 : 0.05);

  const dur = (shape === 'scorpion' || shape === 'akrep') ? 70 : ((shape === 'bear' || shape === 'ayi') ? 75 : ((shape === 'spider' || shape === 'orumcek' || shape === 'örümcek') ? 65 : 55));

  // Auto-trigger attack animation if close to player or spider at range
  const distToPlayer = Math.hypot(e.x - player.x, e.y - player.y);
  const now = Date.now();
  if (e.state !== 'attack' && distToPlayer < (e.radius + player.radius + 32)) {
    if (now - (e._lastAtkAnimTime || 0) > 1600) {
      e.state = 'attack';
      e.attackTimer = 0;
      e._lastAtkAnimTime = now;
      if (shape === 'bear' || shape === 'ayi') {
        spawnMobAttackEffect('bear', e.x, e.y, Math.atan2(player.y - e.y, player.x - e.x), player.x, player.y);
      }
    }
  } else if (e.state !== 'attack' && (shape === 'spider' || shape === 'orumcek' || shape === 'örümcek') && distToPlayer < 300 && distToPlayer > 70) {
    if (now - (e._lastWebAnimTime || 0) > 5000) {
      e.state = 'attack';
      e.attackTimer = 0;
      e._lastWebAnimTime = now;
      spawnMobAttackEffect('spider_web', e.x, e.y, Math.atan2(player.y - e.y, player.x - e.x), player.x, player.y);
    }
  }

  if (e.state === 'attack') {
    e.attackTimer = (e.attackTimer || 0) + 0.8;
    if (e.attackTimer >= dur) {
      e.state = isMoving ? 'walk' : 'idle';
      e.attackTimer = 0;
    }
  } else {
    e.state = isMoving ? 'walk' : 'idle';
  }

  let angle = e.angle;
  if (e.state === 'attack' || (e.vx === 0 && e.vy === 0)) {
    angle = Math.atan2(player.y - e.y, player.x - e.x);
  } else if (e.vx !== 0 || e.vy !== 0) {
    angle = Math.atan2(e.vy, e.vx);
  }
  if (angle == null) angle = 0;
  e.angle = angle;

  ctx.save();
  ctx.translate(e.x, e.y);
  ctx.rotate(angle);

  let _mobDrawn = false;
  try {
    if (shape === 'wolf' || shape === 'kurt') {
      _mobDrawn = _drawSpriteWolf(ctx, e, R, isMoving, e.state, e.animTimer, e.attackTimer, flash);
    } else if (shape === 'scorpion' || shape === 'akrep') {
      _mobDrawn = _drawSpriteScorpion(ctx, e, R, isMoving, e.state, e.animTimer, e.attackTimer, flash);
    } else if (shape === 'bear' || shape === 'ayi') {
      _mobDrawn = _drawSpriteBear(ctx, e, R, isMoving, e.state, e.animTimer, e.attackTimer, flash);
    } else if (shape === 'spider' || shape === 'orumcek' || shape === 'örümcek') {
      _mobDrawn = _drawSpriteSpider(ctx, e, R, isMoving, e.state, e.animTimer, e.attackTimer, flash);
    }
  } catch (_mErr) {
    _mobDrawn = false;
  }
  if (!_mobDrawn) {
    try {
      drawMobShape(ctx, R, e.color, e.outline, e.eyes, shape, globalTime, e);
    } catch (_shapeErr) {
      ctx.save();
      ctx.fillStyle = e.color || '#6b4932';
      ctx.strokeStyle = e.outline || '#28170d';
      ctx.lineWidth = Math.max(2, R * 0.08);
      ctx.beginPath(); ctx.arc(0, 0, R, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.fillStyle = e.eyes || '#ffcc66';
      ctx.beginPath(); ctx.arc(R * 0.3, -R * 0.18, Math.max(3, R * 0.1), 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    }
  }

  ctx.restore();

  // HP bar
  drawHpBar(e.x, e.y - R - 14, e.hp, e.maxHp, Math.max(55, R * 1.6), 0);

  // Aggro alert — red speech bubble "!" when first aggroed (one-shot pulse)
  if (e.provoked) {
    if (!e._wasProvoked) { e._wasProvoked = true; e._aggroPulse = 40; }
    if (e._aggroPulse > 0) {
      const ap = e._aggroPulse / 40;
      e._aggroPulse--;
      const bx = e.x, by = e.y - R - 34 - ap * 14;
      ctx.save();
      try {
        ctx.globalAlpha = ap * 0.96;
        // Bubble body
        const bw = 24, bh = 28;
        ctx.fillStyle = '#e82200';
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.roundRect(bx - bw * 0.5, by - bh * 0.5, bw, bh, 7);
        ctx.fill();
        ctx.stroke();
        // Bubble tail
        ctx.fillStyle = '#e82200';
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(bx - 5, by + bh * 0.5 - 2);
        ctx.lineTo(bx, by + bh * 0.5 + 9);
        ctx.lineTo(bx + 5, by + bh * 0.5 - 2);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        // "!" text
        ctx.fillStyle = '#fff';
        ctx.font = `bold ${Math.round(15 + ap * 4)}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('!', bx, by + 1);
      } finally {
        ctx.restore();
      }
    }
  } else {
    e._aggroPulse = 0; e._wasProvoked = false;
  }
}


// ============================================================
// ACCESSORY DRAWING FUNCTIONS
// ============================================================
function drawPlayerWings(ctx, wingId, t) {
  const c = _WING_COLORS[wingId]; if (!c) return;
  // PERF: cache wing render to OffscreenCanvas — avoids createLinearGradient every frame per player
  // Wings flap at ~6Hz; re-render every 3 frames (~20Hz) is imperceptible
  let _wEnt = _WING_OC_CACHE.get(wingId);
  if (!_wEnt || t - _wEnt.age >= 3) {
    const _osz = 130;
    if (!_wEnt) { _wEnt = { oc: createRenderCanvas(_osz, _osz), age: -99 }; _WING_OC_CACHE.set(wingId, _wEnt); }
    const _wc = _wEnt.oc.getContext('2d');
    _wc.imageSmoothingEnabled = true; _wc.imageSmoothingQuality = 'high';
    _wc.clearRect(0, 0, _osz, _osz);
    _wc.save(); _wc.translate(65, 65);
    const flap = Math.sin(t * 0.1) * 11;
    for (const side of [-1, 1]) {
      _wc.save(); _wc.scale(1, side);
      const g = _wc.createLinearGradient(-8, 0, -55, 0); g.addColorStop(0, c[0]); g.addColorStop(1, c[1]);
      _wc.fillStyle = g; _wc.strokeStyle = c[2]; _wc.lineWidth = 2;
      if (wingId === 'w_bat') {
        _wc.beginPath(); _wc.moveTo(-8,-5); _wc.lineTo(-28,-22+flap); _wc.lineTo(-38,-12+flap*.7); _wc.lineTo(-52,-20+flap); _wc.lineTo(-48,3+flap*.3); _wc.quadraticCurveTo(-30,14,-8,8); _wc.closePath(); _wc.fill(); _wc.stroke();
      } else {
        _wc.beginPath(); _wc.moveTo(-5,-8+flap*.2); _wc.quadraticCurveTo(-30,-30+flap,-52,-14+flap*.4); _wc.quadraticCurveTo(-34,10+flap*.2,-5,8); _wc.closePath(); _wc.fill(); _wc.stroke();
        if (wingId === 'w_angel') { _wc.strokeStyle='rgba(200,220,255,.38)'; _wc.lineWidth=1; for(let i=0;i<3;i++){_wc.beginPath();_wc.moveTo(-5-i*10,3-i*2);_wc.quadraticCurveTo(-15-i*9,-8-i*4,-24-i*7,-3-i*2);_wc.stroke();} }
        if (wingId === 'w_dragon') { _wc.fillStyle='rgba(60,180,30,.85)'; for(let i=0;i<3;i++){const wx=-18-i*11,wy=-24+i*7+flap*(.75-i*.18);_wc.beginPath();_wc.moveTo(wx-4,wy+4);_wc.lineTo(wx,wy-8);_wc.lineTo(wx+4,wy+4);_wc.closePath();_wc.fill();} }
      }
      _wc.restore();
    }
    _wc.restore();
    _wEnt.age = t;
  }
  // Both wing halves (upper + lower) on the back of the character — local space only
  ctx.drawImage(_wEnt.oc, -65, -65);
}
function drawPlayerHat(ctx, hatId, t, r) {
  if (r === undefined) r = player.radius;
  ctx.save(); ctx.translate(0, -r);
  if (hatId === 'h_party') {
    ctx.fillStyle='#e84444'; ctx.strokeStyle='#880000'; ctx.lineWidth=2;
    ctx.beginPath(); ctx.moveTo(-12,8); ctx.lineTo(0,-20); ctx.lineTo(12,8); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle='#ff0'; ctx.beginPath(); ctx.arc(0,-22,4,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='rgba(255,255,255,.85)'; ctx.beginPath(); ctx.ellipse(0,8,13,4,0,0,Math.PI*2); ctx.fill();
  } else if (hatId === 'h_cowboy') {
    ctx.fillStyle='#8b5e2b'; ctx.strokeStyle='#3a1a08'; ctx.lineWidth=2;
    ctx.beginPath(); ctx.ellipse(0,4,18,5,0,0,Math.PI*2); ctx.fill(); ctx.stroke();
    ctx.fillRect(-11,-10,22,14); ctx.strokeRect(-11,-10,22,14);
    ctx.strokeStyle='#f5c842'; ctx.lineWidth=2; ctx.beginPath(); ctx.moveTo(-10,-2); ctx.lineTo(10,-2); ctx.stroke();
  } else if (hatId === 'h_viking') {
    ctx.fillStyle='#888'; ctx.strokeStyle='#444'; ctx.lineWidth=2;
    ctx.beginPath(); ctx.ellipse(0,-4,16,10,0,Math.PI,0); ctx.fill(); ctx.stroke();
    ctx.fillStyle='#f5f0dc'; ctx.strokeStyle='#666'; ctx.lineWidth=1.5;
    for(const s of[-1,1]){ctx.save();ctx.scale(s,1);ctx.beginPath();ctx.moveTo(-14,-4);ctx.quadraticCurveTo(-22,-12,-18,-24);ctx.quadraticCurveTo(-10,-12,-8,-6);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();}
  } else if (hatId === 'h_santa') {
    ctx.fillStyle='#cc2222'; ctx.strokeStyle='#880000'; ctx.lineWidth=2;
    ctx.beginPath(); ctx.moveTo(-12,6); ctx.quadraticCurveTo(0,-4,10,-24); ctx.quadraticCurveTo(18,-20,12,6); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle='#fff'; ctx.beginPath(); ctx.ellipse(0,6,14,4,0,0,Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.arc(10,-24,4,0,Math.PI*2); ctx.fill();
  } else if (hatId === 'h_wizard') {
    ctx.fillStyle='#5a2880'; ctx.strokeStyle='#2a0a50'; ctx.lineWidth=2;
    ctx.beginPath(); ctx.moveTo(-14,6); ctx.lineTo(0,-28); ctx.lineTo(14,6); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.ellipse(0,6,15,5,0,0,Math.PI*2); ctx.fill(); ctx.stroke();
    ctx.fillStyle='#f5c842'; for(let i=0;i<5;i++){ctx.save();ctx.translate(0,-12);ctx.rotate(i*Math.PI*.4+t*.03);ctx.beginPath();ctx.moveTo(0,-5);ctx.lineTo(1.5,2);ctx.lineTo(-1.5,2);ctx.closePath();ctx.fill();ctx.restore();}
  } else if (hatId === 'h_crown') {
    ctx.fillStyle='#f5c842'; ctx.strokeStyle='#a07800'; ctx.lineWidth=2;
    ctx.beginPath(); ctx.moveTo(-14,4); ctx.lineTo(-14,-8); ctx.lineTo(-6,-2); ctx.lineTo(0,-16); ctx.lineTo(6,-2); ctx.lineTo(14,-8); ctx.lineTo(14,4); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle=`rgba(255,220,0,${.25+Math.sin(t*.08)*.1})`; ctx.beginPath(); ctx.arc(0,-5,18,0,Math.PI*2); ctx.fill();
  }
  ctx.restore();
}
function drawPlayerFace(ctx, faceId) {
  if (faceId === 'f_mustache') {
    ctx.fillStyle='#3a2010'; ctx.strokeStyle='#1a0808'; ctx.lineWidth=1.5;
    for(const s of[-1,1]){ctx.save();ctx.scale(1,s);ctx.beginPath();ctx.moveTo(10,2);ctx.quadraticCurveTo(3,0,2,7);ctx.quadraticCurveTo(7,10,10,6);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();}
  } else if (faceId === 'f_glasses') {
    ctx.strokeStyle='#333'; ctx.lineWidth=2;
    ctx.beginPath(); ctx.arc(10,-8,7,0,Math.PI*2); ctx.stroke(); ctx.beginPath(); ctx.arc(10,8,7,0,Math.PI*2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(10,-1); ctx.lineTo(10,1); ctx.stroke();
    ctx.fillStyle='rgba(100,200,255,.18)'; ctx.beginPath(); ctx.arc(10,-8,7,0,Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.arc(10,8,7,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#222'; ctx.beginPath(); ctx.arc(12,-8,4,0,Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.arc(12,8,4,0,Math.PI*2); ctx.fill();
  } else if (faceId === 'f_tusks') {
    ctx.fillStyle='#f5f0dc'; ctx.strokeStyle='#999'; ctx.lineWidth=1.5;
    for(const s of[-1,1]){ctx.save();ctx.scale(1,s);ctx.beginPath();ctx.moveTo(6,7);ctx.quadraticCurveTo(3,16,4,22);ctx.quadraticCurveTo(8,18,9,9);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();}
  } else if (faceId === 'f_angry') {
    ctx.strokeStyle='#1a0808'; ctx.lineWidth=4; ctx.lineCap='round';
    // Symmetric angry brows — one above each eye (y=-8 and y=8)
    ctx.beginPath(); ctx.moveTo(4,-14); ctx.lineTo(14,-9); ctx.stroke(); // brow above upper eye
    ctx.beginPath(); ctx.moveTo(4,14); ctx.lineTo(14,9); ctx.stroke();   // brow above lower eye
    ctx.fillStyle='rgba(220,30,30,.5)'; ctx.beginPath(); ctx.arc(10,-8,5,0,Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.arc(10,8,5,0,Math.PI*2); ctx.fill();
  } else if (faceId === 'f_mask') {
    // Centered ninja mask on the front of the face (symmetric on Y axis)
    ctx.fillStyle='#1a1a2a'; ctx.strokeStyle='#000'; ctx.lineWidth=1.5;
    ctx.beginPath(); ctx.rect(2, -11, 22, 22); ctx.fill(); ctx.stroke();
    ctx.strokeStyle='rgba(255,255,255,.12)'; ctx.lineWidth=1;
    ctx.beginPath(); ctx.moveTo(3,-4); ctx.lineTo(23,-4); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(3,4); ctx.lineTo(23,4); ctx.stroke();
  }
}
function drawPlayerCape(ctx, t, r) {
  if (r === undefined) r = player.radius;
  const cw = Math.sin(t * .05) * 8;
  const cg = ctx.createLinearGradient(-r, 0, -r-40, 0); cg.addColorStop(0,'rgba(130,20,200,.92)'); cg.addColorStop(1,'rgba(80,0,130,.25)');
  ctx.fillStyle=cg; ctx.strokeStyle='rgba(80,0,150,.5)'; ctx.lineWidth=1.5;
  ctx.beginPath(); ctx.moveTo(-r+4,-18); ctx.lineTo(-r+4,0); ctx.quadraticCurveTo(-r-28,16+cw,-r-18,38+cw*.5); ctx.quadraticCurveTo(-r-6,46,-r+4,32+cw*.3); ctx.lineTo(-r+4,18); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.strokeStyle='rgba(200,150,255,.35)'; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(-r+4,0); ctx.quadraticCurveTo(-r-26,14+cw,-r-16,36+cw*.5); ctx.stroke();
}
function drawPlayerTail(ctx, t, r) {
  if (r === undefined) r = player.radius;
  const sw = Math.sin(t * .1) * 9;
  ctx.strokeStyle='#cc2222'; ctx.lineWidth=5; ctx.lineCap='round';
  ctx.beginPath(); ctx.moveTo(-r+4,8); ctx.quadraticCurveTo(-r-20,24+sw,-r-12,42+sw*.5); ctx.quadraticCurveTo(-r,50,-r+10,40+sw*.3); ctx.stroke();
  ctx.fillStyle='#cc2222'; ctx.strokeStyle='#880000'; ctx.lineWidth=2;
  const tx=-r+10, ty=40+sw*.3;
  ctx.beginPath(); ctx.moveTo(tx-4,ty-4); ctx.lineTo(tx,ty+6); ctx.lineTo(tx+4,ty-4); ctx.closePath(); ctx.fill(); ctx.stroke();
}
function drawPlayerHalo(ctx, t, r) {
  if (r === undefined) r = player.radius;
  ctx.save(); ctx.translate(0, -r - 28);
  const p = .22 + Math.sin(t * .07) * .08;
  const hg = ctx.createRadialGradient(0,0,12,0,0,32); hg.addColorStop(0,`rgba(255,220,0,${p})`); hg.addColorStop(1,'rgba(255,200,0,0)');
  ctx.fillStyle=hg; ctx.beginPath(); ctx.arc(0,0,32,0,Math.PI*2); ctx.fill();
  ctx.strokeStyle='#f5c842'; ctx.lineWidth=5;
  if (_glowOk) { ctx.shadowColor='#ffe080'; ctx.shadowBlur=12; }
  ctx.beginPath(); ctx.ellipse(0,0,17,6,0,0,Math.PI*2); ctx.stroke();
  if (_glowOk) ctx.shadowBlur=0;
  ctx.restore();
}
function drawPlayerBackpack(ctx, r) {
  if (r === undefined) r = player.radius;
  const bx = -r - 20;
  ctx.fillStyle='#7a4a20'; ctx.strokeStyle='#3a1a0a'; ctx.lineWidth=2;
  ctx.fillRect(bx,-16,22,32); ctx.strokeRect(bx,-16,22,32);
  ctx.fillStyle='#8b5a28'; ctx.fillRect(bx+2,-2,18,14); ctx.strokeRect(bx+2,-2,18,14);
  ctx.strokeStyle='#5a3010'; ctx.lineWidth=3; ctx.beginPath(); ctx.moveTo(bx+22,-12); ctx.lineTo(-r+6,0); ctx.lineTo(bx+22,16); ctx.stroke();
}

// ============================================================
// PLAYER SKIN DRAWING SYSTEM — 18 unique canvas-drawn skins
// ============================================================
const GENERATED_SKIN_STYLES = {
  skin_aurora:['#65f5d8','#164c68','#d8fff5'], skin_storm:['#79a9ff','#1a2d72','#e5efff'], skin_magma:['#ff704d','#6d160e','#ffe0a3'], skin_void:['#bd7cff','#241044','#f4d9ff'], skin_solar:['#ffd45a','#9b3e10','#fff5b8'], skin_moon:['#b6c8ff','#293768','#f0f4ff'], skin_emerald:['#64e08a','#18542e','#dcffe5'], skin_sapphire:['#55c7ef','#144f78','#d8f7ff'], skin_ruby:['#ff5c70','#6d1425','#ffe1e5'], skin_amethyst:['#d081ff','#4b1c72','#f6ddff'], skin_cyber:['#5affd1','#123638','#d8fff7'], skin_steam:['#d8a878','#5a3420','#fff0d4'], skin_icefire:['#75eaff','#6c2416','#fff0bf'], skin_thunder:['#fff06a','#3b327d','#ffffdc'], skin_blossom:['#ff9fc7','#6b2851','#ffe7f2'], skin_reef:['#6de0c0','#1a5960','#d9fff6'], skin_desert:['#e6b35f','#70401b','#fff0b0'], skin_frostwolf:['#b7ecff','#254d72','#f0fcff'], skin_shadow:['#a58aff','#1d173c','#e5ddff'], skin_chroma:['#ff83df','#30205e','#ffffff']
};
function drawGeneratedSkinBody(c, R, sk, t, fl) {
  const style = GENERATED_SKIN_STYLES[sk];
  if (!style) return false;
  const [primary, dark, shine] = style;
  const pulse = .75 + Math.sin(t * .08) * .12;
  c.save(); c.shadowColor = fl ? '#fff' : primary; c.shadowBlur = 12 * pulse;
  const body = c.createRadialGradient(-R*.25, -R*.3, 2, 0, 0, R*1.2);
  body.addColorStop(0, fl ? '#fff' : shine); body.addColorStop(.34, fl ? '#fff' : primary); body.addColorStop(1, fl ? '#ccc' : dark);
  c.fillStyle = body; c.strokeStyle = fl ? '#fff' : shine; c.lineWidth = 3;
  c.beginPath(); c.arc(0, 0, R, 0, Math.PI*2); c.fill(); c.stroke(); c.shadowBlur = 0;
  c.fillStyle = fl ? '#fff' : dark;
  c.beginPath(); c.moveTo(-R*.75,-R*.55); c.lineTo(-R*.38,-R*1.05); c.lineTo(-R*.05,-R*.58); c.closePath(); c.fill();
  c.beginPath(); c.moveTo(R*.05,-R*.58); c.lineTo(R*.42,-R*1.05); c.lineTo(R*.75,-R*.55); c.closePath(); c.fill();
  for (const s of [-1, 1]) { c.fillStyle='#fff'; c.beginPath(); c.ellipse(R*.25,s*R*.18,R*.15,R*.13,0,0,Math.PI*2); c.fill(); c.fillStyle=fl?'#fff':primary; c.beginPath(); c.arc(R*.29,s*R*.18,R*.08,0,Math.PI*2); c.fill(); c.fillStyle=fl?'#fff':shine; c.beginPath(); c.arc(R*.34,s*R*.18,R*.035,0,Math.PI*2); c.fill(); }
  c.fillStyle = fl ? '#fff' : dark; c.beginPath(); c.ellipse(R*.63,0,R*.22,R*.15,0,0,Math.PI*2); c.fill(); c.fillStyle=fl?'#fff':shine; c.beginPath(); c.arc(R*.72,0,R*.055,0,Math.PI*2); c.fill();
  for (let i=0;i<5;i++) { const a=t*.025+i*Math.PI*.4; c.fillStyle=fl?'#fff':shine; c.globalAlpha=.45+Math.sin(t*.1+i)*.2; c.beginPath(); c.arc(Math.cos(a)*R*1.15,Math.sin(a)*R*1.15,R*.045,0,Math.PI*2); c.fill(); }
  c.globalAlpha=1; c.restore(); return true;
}
function drawSkinBody(c,R,sk,t,fl){
  // fl=flash(hit-white), sk=skinId, t=globalTime, R=radius
  // All skins drawn at (0,0) facing right (+X direction)
  if(GENERATED_SKIN_STYLES[sk]){
    drawGeneratedSkinBody(c,R,sk,t,fl);
  } else if(sk==='panda'){
    // 1. EARS — drawn first so body covers the base (ears behind body)
    c.fillStyle=fl?'#aaa':'#111';c.strokeStyle='#000';c.lineWidth=3;
    c.beginPath();c.arc(-R*.82,-R*.2,R*.26,0,Math.PI*2);c.fill();c.stroke();c.beginPath();c.arc(-R*.82,R*.2,R*.26,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#fff';c.beginPath();c.arc(-R*.82,-R*.2,R*.12,0,Math.PI*2);c.fill();c.beginPath();c.arc(-R*.82,R*.2,R*.12,0,Math.PI*2);c.fill();
    // 2. Body circle on top of ear bases
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#f5f5f5');bg.addColorStop(1,fl?'#ccc':'#ddd');
    c.fillStyle=bg;c.strokeStyle='#222';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // 3. Eyes/face in front
    c.fillStyle=fl?'#aaa':'#111';c.beginPath();c.ellipse(R*.26,-R*.27,R*.2,R*.16,-0.3,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(R*.26,R*.27,R*.2,R*.16,0.3,0,Math.PI*2);c.fill();
    c.fillStyle='#fff';c.beginPath();c.arc(R*.3,-R*.27,R*.1,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.3,R*.27,R*.1,0,Math.PI*2);c.fill();
    c.fillStyle='#000';c.beginPath();c.arc(R*.34,-R*.27,R*.06,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.34,R*.27,R*.06,0,Math.PI*2);c.fill();
    // Muzzle
    c.fillStyle=fl?'#eee':'#eee';c.strokeStyle='#ccc';c.lineWidth=2;c.beginPath();c.ellipse(R*.62,0,R*.24,R*.18,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#222';c.beginPath();c.ellipse(R*.72,0,R*.08,R*.06,0,0,Math.PI*2);c.fill();
  } else if(sk==='fox'){
    // 1. EARS behind body (back-side position)
    for(const s of[-1,1]){
      c.fillStyle=fl?'#eee':'#f07030';c.strokeStyle='#602010';c.lineWidth=3;
      c.beginPath();c.moveTo(-R*.82,s*R*.2);c.lineTo(-R*1.35,s*R*.52);c.lineTo(-R*.72,s*R*.7);c.closePath();c.fill();c.stroke();
      c.fillStyle='#ffaabb';c.beginPath();c.moveTo(-R*.86,s*R*.24);c.lineTo(-R*1.2,s*R*.49);c.lineTo(-R*.78,s*R*.62);c.closePath();c.fill();
    }
    // 2. Body circle
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#f07030');bg.addColorStop(1,fl?'#ccc':'#c04820');
    c.fillStyle=bg;c.strokeStyle='#602010';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // 3. Muzzle + eyes in front
    c.fillStyle=fl?'#eee':'#f8f0e8';c.strokeStyle='#ddd';c.lineWidth=2;c.beginPath();c.ellipse(R*.6,0,R*.26,R*.2,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#111';c.beginPath();c.ellipse(R*.74,0,R*.09,R*.07,0,0,Math.PI*2);c.fill();
    c.fillStyle='#fff';c.beginPath();c.arc(R*.22,-R*.22,R*.1,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.22,R*.22,R*.1,0,Math.PI*2);c.fill();
    c.fillStyle='#c07000';c.beginPath();c.arc(R*.25,-R*.22,R*.07,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.25,R*.22,R*.07,0,Math.PI*2);c.fill();
    c.fillStyle='#000';c.beginPath();c.arc(R*.28,-R*.22,R*.04,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.28,R*.22,R*.04,0,Math.PI*2);c.fill();
    // Animated bushy tail (behind — drawn last but tail is at rear of body, not covering eyes)
    const tw=Math.sin(t*.07)*R*.3;
    c.strokeStyle=fl?'#eee':'#f07030';c.lineWidth=R*.4;c.lineCap='round';c.beginPath();c.moveTo(-R*.6,0);c.quadraticCurveTo(-R*1.4,tw,-R*1.8,-tw*.5);c.stroke();
    c.strokeStyle='#fff';c.lineWidth=R*.16;c.beginPath();c.moveTo(-R*1.4,tw*.8);c.lineTo(-R*1.8,-tw*.5);c.stroke();
  } else if(sk==='wolf'){
    // 1. EARS behind body (back-side position)
    for(const s of[-1,1]){
      c.fillStyle=fl?'#aaa':'#556677';c.strokeStyle='#223344';c.lineWidth=3;
      c.beginPath();c.moveTo(-R*.78,s*R*.2);c.lineTo(-R*1.38,s*R*.47);c.lineTo(-R*.68,s*R*.73);c.closePath();c.fill();c.stroke();
      c.fillStyle='#cc8888';c.beginPath();c.moveTo(-R*.83,s*R*.25);c.lineTo(-R*1.2,s*R*.44);c.lineTo(-R*.73,s*R*.63);c.closePath();c.fill();
    }
    // 2. Body circle
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#667788');bg.addColorStop(1,fl?'#ccc':'#334455');
    c.fillStyle=bg;c.strokeStyle='#223344';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // 3. Muzzle + fangs + eyes in front
    c.fillStyle=fl?'#ddd':'#99aabb';c.strokeStyle='#778899';c.lineWidth=2;c.beginPath();c.ellipse(R*.58,0,R*.26,R*.2,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#fff';c.strokeStyle='#ccc';c.lineWidth=1;
    for(const s of[-1,1]){c.beginPath();c.moveTo(R*.66+s*R*.06,R*.06);c.lineTo(R*.7+s*R*.06,R*.18);c.lineTo(R*.74+s*R*.06,R*.06);c.closePath();c.fill();}
    c.fillStyle='#111';c.beginPath();c.ellipse(R*.72,0,R*.09,R*.07,0,0,Math.PI*2);c.fill();
    c.fillStyle='#fff';c.beginPath();c.arc(R*.22,-R*.22,R*.11,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.22,R*.22,R*.11,0,Math.PI*2);c.fill();
    c.fillStyle='#ffaa00';c.beginPath();c.arc(R*.25,-R*.22,R*.08,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.25,R*.22,R*.08,0,Math.PI*2);c.fill();
    c.fillStyle='#000';c.beginPath();c.arc(R*.28,-R*.22,R*.05,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.28,R*.22,R*.05,0,Math.PI*2);c.fill();
  } else if(sk==='rabbit'){
    // 1. EARS behind body (back-side, horizontal long ears)
    for(const s of[-1,1]){
      c.fillStyle=fl?'#ddd':'#ccccdd';c.strokeStyle='#8888aa';c.lineWidth=3;c.beginPath();c.ellipse(-R*1.18,s*R*.2,R*.42,R*.16,s*.18,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='#ffaabb';c.beginPath();c.ellipse(-R*1.18,s*R*.2,R*.28,R*.08,s*.18,0,Math.PI*2);c.fill();
    }
    // 2. Body circle
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#ddddee');bg.addColorStop(1,fl?'#ccc':'#aaaacc');
    c.fillStyle=bg;c.strokeStyle='#8888aa';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // 3. Eyes + nose + whiskers in front
    c.fillStyle='#fff';c.beginPath();c.arc(R*.22,-R*.2,R*.11,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.22,R*.2,R*.11,0,Math.PI*2);c.fill();
    c.fillStyle='#ff6688';c.beginPath();c.arc(R*.26,-R*.2,R*.08,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.26,R*.2,R*.08,0,Math.PI*2);c.fill();
    c.fillStyle='#000';c.beginPath();c.arc(R*.29,-R*.2,R*.04,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.29,R*.2,R*.04,0,Math.PI*2);c.fill();
    c.fillStyle='#ff8899';c.beginPath();c.ellipse(R*.65,0,R*.09,R*.07,0,0,Math.PI*2);c.fill();
    c.strokeStyle='rgba(0,0,0,0.3)';c.lineWidth=1.5;
    for(const s of[-1,1]){c.beginPath();c.moveTo(R*.6,s*R*.06);c.lineTo(R*.9,s*R*.12);c.stroke();}
  } else if(sk==='croc'){
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#3a7a28');bg.addColorStop(1,fl?'#ccc':'#1a4a10');
    c.fillStyle=bg;c.strokeStyle='#0a2806';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Scale texture arcs
    c.strokeStyle='rgba(0,0,0,0.28)';c.lineWidth=1.5;
    for(let row=0;row<3;row++){const yr=[-R*.3,0,R*.3][row];for(let col=0;col<4;col++){const xr=-R*.5+col*R*.33+(row%2?R*.17:0);c.beginPath();c.arc(xr,yr,R*.15,0,Math.PI,true);c.stroke();}}
    // Long snout
    c.fillStyle=fl?'#adc':'#3a7a28';c.strokeStyle='#0a2806';c.lineWidth=4;c.beginPath();c.ellipse(R*.76,0,R*.33,R*.2,0,0,Math.PI*2);c.fill();c.stroke();
    // Teeth
    c.fillStyle='#f5f0dc';c.strokeStyle='#ccc';c.lineWidth=1;
    for(const s of[-1,1])for(let i=0;i<3;i++){const tx=R*.56+i*R*.14;c.beginPath();c.moveTo(tx,s*R*.14);c.lineTo(tx+R*.05,s*R*.24);c.lineTo(tx+R*.1,s*R*.14);c.closePath();c.fill();}
    c.fillStyle='#0a2806';c.beginPath();c.ellipse(R*.88,-R*.07,R*.05,R*.04,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(R*.88,R*.07,R*.05,R*.04,0,0,Math.PI*2);c.fill();
    // Slit eyes
    c.fillStyle='#ffcc00';c.beginPath();c.ellipse(R*.2,-R*.3,R*.12,R*.09,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(R*.2,R*.3,R*.12,R*.09,0,0,Math.PI*2);c.fill();
    c.fillStyle='#000';c.beginPath();c.ellipse(R*.24,-R*.3,R*.04,R*.09,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(R*.24,R*.3,R*.04,R*.09,0,0,Math.PI*2);c.fill();
  } else if(sk==='frog'){
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#55cc44');bg.addColorStop(1,fl?'#ccc':'#228820');
    c.fillStyle=bg;c.strokeStyle='#116610';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Spots
    c.fillStyle='rgba(0,0,0,0.15)';c.beginPath();c.arc(-R*.3,R*.2,R*.14,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.1,R*.4,R*.11,0,Math.PI*2);c.fill();
    // Bulging eyes on top of head
    c.fillStyle=fl?'#aec':'#55cc44';c.strokeStyle='#116610';c.lineWidth=3;
    c.beginPath();c.arc(-R*.32,-R*.88,R*.24,0,Math.PI*2);c.fill();c.stroke();c.beginPath();c.arc(R*.32,-R*.88,R*.24,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#fff';c.beginPath();c.arc(-R*.32,-R*.88,R*.18,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.32,-R*.88,R*.18,0,Math.PI*2);c.fill();
    c.fillStyle='#000';c.beginPath();c.arc(-R*.3,-R*.86,R*.1,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.3,-R*.86,R*.1,0,Math.PI*2);c.fill();
    // Wide grin
    c.strokeStyle='#116610';c.lineWidth=3;c.lineCap='round';c.beginPath();c.arc(R*.5,0,R*.25,Math.PI*1.3,Math.PI*1.7);c.stroke();
    c.fillStyle='#ff8899';c.beginPath();c.ellipse(R*.74,0,R*.12,R*.08,0.2,0,Math.PI*2);c.fill();
  } else if(sk==='polarbear'){
    // 1. EARS behind body (back-side position)
    c.fillStyle=fl?'#eee':'#eef8ff';c.strokeStyle='#99bbcc';c.lineWidth=3;
    c.beginPath();c.arc(-R*.82,-R*.2,R*.22,0,Math.PI*2);c.fill();c.stroke();c.beginPath();c.arc(-R*.82,R*.2,R*.22,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#ffeecc';c.beginPath();c.arc(-R*.82,-R*.2,R*.11,0,Math.PI*2);c.fill();c.beginPath();c.arc(-R*.82,R*.2,R*.11,0,Math.PI*2);c.fill();
    // 2. Body circle
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#ffffff');bg.addColorStop(1,fl?'#ddd':'#ddeeff');
    c.fillStyle=bg;c.strokeStyle='#99bbcc';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // 3. Muzzle + eyes in front
    c.fillStyle=fl?'#eee':'#f0f8ff';c.strokeStyle='#bbccdd';c.lineWidth=2;c.beginPath();c.ellipse(R*.6,0,R*.26,R*.2,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#222';c.beginPath();c.ellipse(R*.72,0,R*.1,R*.08,0,0,Math.PI*2);c.fill();
    c.fillStyle='#111';c.beginPath();c.arc(R*.22,-R*.22,R*.08,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.22,R*.22,R*.08,0,Math.PI*2);c.fill();
    c.fillStyle='rgba(255,255,255,0.6)';c.beginPath();c.arc(R*.24,-R*.25,R*.03,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.24,R*.19,R*.03,0,Math.PI*2);c.fill();
  } else if(sk==='penguin'){
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#555':'#333344');bg.addColorStop(1,fl?'#222':'#111122');
    c.fillStyle=bg;c.strokeStyle='#000011';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // White belly
    c.fillStyle=fl?'#eee':'#f8f8f8';c.strokeStyle='#cccccc';c.lineWidth=2;c.beginPath();c.ellipse(R*.15,0,R*.44,R*.6,0,0,Math.PI*2);c.fill();c.stroke();
    // Orange beak
    c.fillStyle='#ff9922';c.strokeStyle='#cc6600';c.lineWidth=2;c.beginPath();c.moveTo(R*.68,-R*.08);c.lineTo(R*.92,0);c.lineTo(R*.68,R*.08);c.closePath();c.fill();c.stroke();
    c.fillStyle='#fff';c.beginPath();c.arc(R*.3,-R*.26,R*.1,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.3,R*.26,R*.1,0,Math.PI*2);c.fill();
    c.fillStyle='#000';c.beginPath();c.arc(R*.33,-R*.26,R*.07,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.33,R*.26,R*.07,0,Math.PI*2);c.fill();
  } else if(sk==='shark'){
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#7799bb');bg.addColorStop(1,fl?'#ccc':'#445577');
    c.fillStyle=bg;c.strokeStyle='#334466';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // White underbelly
    c.fillStyle=fl?'#eee':'#eef5ff';c.strokeStyle='#ccddee';c.lineWidth=2;c.beginPath();c.ellipse(R*.12,0,R*.55,R*.3,0,0,Math.PI*2);c.fill();c.stroke();
    // Dorsal fin on top
    c.fillStyle=fl?'#aaa':'#556688';c.strokeStyle='#334466';c.lineWidth=3;c.beginPath();c.moveTo(-R*.1,-R*.9);c.lineTo(R*.12,-R*1.52);c.lineTo(R*.42,-R*.9);c.closePath();c.fill();c.stroke();
    // Snout
    c.fillStyle=fl?'#aac':'#6688aa';c.strokeStyle='#334466';c.lineWidth=3;c.beginPath();c.ellipse(R*.72,0,R*.3,R*.18,0,0,Math.PI*2);c.fill();c.stroke();
    // Triangle teeth
    c.fillStyle='#fff';c.strokeStyle='#ddd';c.lineWidth=1;
    for(let i=0;i<4;i++){const tx=R*.54+i*R*.13;c.beginPath();c.moveTo(tx,-R*.1);c.lineTo(tx+R*.065,0);c.lineTo(tx+R*.13,-R*.1);c.closePath();c.fill();}
    c.fillStyle='#111';c.beginPath();c.arc(R*.28,-R*.35,R*.09,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.28,R*.35,R*.09,0,Math.PI*2);c.fill();
  } else if(sk==='lion'){
    // Dark golden mane (drawn first, behind body)
    const mr=R*1.28;const mg=c.createRadialGradient(0,0,R*.5,0,0,mr);
    mg.addColorStop(0,fl?'#ccc':'#b87820');mg.addColorStop(1,fl?'#888':'#7a4808');
    c.fillStyle=mg;c.beginPath();c.arc(0,0,mr,0,Math.PI*2);c.fill();
    c.strokeStyle='rgba(0,0,0,0.2)';c.lineWidth=3;
    for(let i=0;i<10;i++){const a=i/10*Math.PI*2;c.beginPath();c.moveTo(Math.cos(a)*R*.85,Math.sin(a)*R*.85);c.lineTo(Math.cos(a)*mr,Math.sin(a)*mr);c.stroke();}
    // Golden body
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#f5c050');bg.addColorStop(1,fl?'#ccc':'#d4940a');
    c.fillStyle=bg;c.strokeStyle='#8a5a00';c.lineWidth=4;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle=fl?'#eee':'#e8b040';c.strokeStyle='#8a5a00';c.lineWidth=2;c.beginPath();c.ellipse(R*.58,0,R*.28,R*.22,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#aa3322';c.beginPath();c.ellipse(R*.72,0,R*.1,R*.09,0,0,Math.PI*2);c.fill();
    c.fillStyle='#fff';c.beginPath();c.arc(R*.22,-R*.25,R*.12,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.22,R*.25,R*.12,0,Math.PI*2);c.fill();
    c.fillStyle='#cc8800';c.beginPath();c.arc(R*.26,-R*.25,R*.09,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.26,R*.25,R*.09,0,Math.PI*2);c.fill();
    c.fillStyle='#000';c.beginPath();c.arc(R*.29,-R*.25,R*.05,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.29,R*.25,R*.05,0,Math.PI*2);c.fill();
    // Fierce angled eyebrows
    c.strokeStyle='#8a5a00';c.lineWidth=3;c.lineCap='round';
    c.beginPath();c.moveTo(R*.11,-R*.38);c.lineTo(R*.32,-R*.32);c.stroke();c.beginPath();c.moveTo(R*.11,R*.38);c.lineTo(R*.32,R*.32);c.stroke();
  } else if(sk==='dragon'){
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#2a6020');bg.addColorStop(1,fl?'#ccc':'#0a3010');
    c.fillStyle=bg;c.strokeStyle='#052008';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Scale texture
    c.strokeStyle='rgba(0,0,0,0.3)';c.lineWidth=1.5;
    for(let row=0;row<4;row++){const yr=[-R*.45,-R*.15,R*.15,R*.45][row];for(let col=0;col<5;col++){const xr=-R*.6+col*R*.3+(row%2?R*.15:0);c.beginPath();c.arc(xr,yr,R*.13,Math.PI,0,true);c.stroke();}}
    // Mini wings behind body
    c.fillStyle=fl?'#aec':'#1a4a10';c.strokeStyle='#052008';c.lineWidth=2;
    for(const s of[-1,1]){c.save();c.scale(1,s);c.beginPath();c.moveTo(-R*.2,-R*.58);c.quadraticCurveTo(-R*.78,-R*1.18,-R*.58,-R*1.58);c.quadraticCurveTo(-R*.2,-R*1.18,-R*.1,-R*.58);c.closePath();c.fill();c.stroke();c.restore();}
    // Horns
    c.fillStyle=fl?'#eee':'#aa8830';c.strokeStyle='#664400';c.lineWidth=2;
    c.beginPath();c.moveTo(-R*.08,-R*.84);c.lineTo(-R*.22,-R*1.42);c.lineTo(R*.06,-R*.84);c.closePath();c.fill();c.stroke();
    c.beginPath();c.moveTo(R*.12,-R*.84);c.lineTo(R*.36,-R*1.42);c.lineTo(R*.5,-R*.84);c.closePath();c.fill();c.stroke();
    // Snout with nostrils
    c.fillStyle=fl?'#aec':'#2a6020';c.strokeStyle='#052008';c.lineWidth=3;c.beginPath();c.ellipse(R*.67,0,R*.3,R*.2,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#000';c.beginPath();c.ellipse(R*.79,-R*.07,R*.06,R*.05,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(R*.79,R*.07,R*.06,R*.05,0,0,Math.PI*2);c.fill();
    // Golden slit eyes
    c.fillStyle='#ffcc00';c.beginPath();c.ellipse(R*.22,-R*.28,R*.13,R*.1,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(R*.22,R*.28,R*.13,R*.1,0,0,Math.PI*2);c.fill();
    c.fillStyle='#000';c.beginPath();c.ellipse(R*.26,-R*.28,R*.04,R*.09,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(R*.26,R*.28,R*.04,R*.09,0,0,Math.PI*2);c.fill();
  } else if(sk==='skull'){
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#f0ece4');bg.addColorStop(1,fl?'#ccc':'#c8c4b8');
    c.fillStyle=bg;c.strokeStyle='#888880';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Cracks
    c.strokeStyle='rgba(0,0,0,0.25)';c.lineWidth=2;c.lineCap='round';
    c.beginPath();c.moveTo(-R*.1,-R*.9);c.lineTo(R*.05,-R*.4);c.lineTo(-R*.15,-R*.1);c.stroke();c.beginPath();c.moveTo(R*.3,-R*.8);c.lineTo(R*.15,-R*.5);c.stroke();
    // Hollow eye sockets
    c.fillStyle=fl?'#888':'#111';c.beginPath();c.ellipse(R*.2,-R*.28,R*.2,R*.16,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(R*.2,R*.28,R*.2,R*.16,0,0,Math.PI*2);c.fill();
    c.fillStyle='rgba(150,0,255,0.4)';c.beginPath();c.ellipse(R*.2,-R*.28,R*.1,R*.08,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(R*.2,R*.28,R*.1,R*.08,0,0,Math.PI*2);c.fill();
    // Nasal cavity
    c.fillStyle=fl?'#888':'#222';c.beginPath();c.arc(R*.56,0,R*.12,0,Math.PI*2);c.fill();c.beginPath();c.moveTo(R*.52,-R*.06);c.lineTo(R*.6,-R*.06);c.lineTo(R*.56,R*.06);c.closePath();c.fill();
    // Teeth row
    c.fillStyle=fl?'#eee':'#e8e4dc';c.strokeStyle='#888880';c.lineWidth=1.5;
    for(let i=0;i<4;i++){const tx=R*.32+i*R*.12;c.fillRect(tx,R*.08,R*.1,R*.22);c.strokeRect(tx,R*.08,R*.1,R*.22);}
  } else if(sk==='ninja'){
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#444':'#1a1a22');bg.addColorStop(1,fl?'#222':'#080810');
    c.fillStyle=bg;c.strokeStyle='#000008';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Mask band clipped to circle
    c.save();c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.clip();
    c.fillStyle=fl?'#555':'#111122';c.fillRect(-R,-R*.18,R*2,R*.36);c.restore();
    // Glowing cyan eyes
    c.save();if(_qualityLevel>=1){c.shadowColor='#00ffff';c.shadowBlur=12;}c.fillStyle='#00ffee';
    c.beginPath();c.ellipse(R*.22,-R*.22,R*.15,R*.09,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(R*.22,R*.22,R*.15,R*.09,0,0,Math.PI*2);c.fill();c.restore();
    c.fillStyle='#000';c.beginPath();c.ellipse(R*.28,-R*.22,R*.06,R*.09,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(R*.28,R*.22,R*.06,R*.09,0,0,Math.PI*2);c.fill();
    // Shuriken symbol
    c.fillStyle='rgba(150,150,180,0.35)';c.strokeStyle='rgba(200,200,255,0.3)';c.lineWidth=1;
    for(let i=0;i<4;i++){const a=i*Math.PI/2+Math.PI/4;c.save();c.rotate(a);c.beginPath();c.moveTo(-R*.04,-R*.04);c.lineTo(0,-R*.22);c.lineTo(R*.04,-R*.04);c.closePath();c.fill();c.stroke();c.restore();}
  } else if(sk==='robot'){
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#aabbcc');bg.addColorStop(1,fl?'#ccc':'#667788');
    c.fillStyle=bg;c.strokeStyle='#334455';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Panel ring and bolts
    c.strokeStyle='rgba(50,70,90,0.5)';c.lineWidth=2;c.beginPath();c.arc(0,0,R*.7,0,Math.PI*2);c.stroke();
    c.fillStyle='#556677';for(const a of[0,Math.PI/2,Math.PI,Math.PI*3/2]){c.beginPath();c.arc(Math.cos(a)*R*.78,Math.sin(a)*R*.78,R*.09,0,Math.PI*2);c.fill();}
    // Scanning visor
    const vg=fl?'rgba(100,200,255,0.5)':`rgba(0,${185+Math.round(Math.sin(t*.06)*55)},255,0.9)`;
    c.fillStyle='#111';c.strokeStyle='#334455';c.lineWidth=3;
    c.beginPath();c.roundRect(R*.08,-R*.42,R*.72,R*.24,R*.05);c.fill();c.stroke();
    c.fillStyle=vg;c.beginPath();c.roundRect(R*.11,-R*.39,R*.66,R*.18,R*.04);c.fill();
    // Mouth grill
    c.strokeStyle='#334455';c.lineWidth=2;c.beginPath();c.roundRect(R*.2,R*.16,R*.5,R*.2,3);c.stroke();
    for(let i=0;i<4;i++){c.beginPath();c.moveTo(R*.26+i*R*.12,R*.18);c.lineTo(R*.26+i*R*.12,R*.34);c.stroke();}
    // Antenna
    c.strokeStyle='#556677';c.lineWidth=3;c.lineCap='round';c.beginPath();c.moveTo(0,-R*.88);c.lineTo(0,-R*1.22);c.stroke();
    c.fillStyle=fl?'#aaa':'rgba(0,200,255,0.9)';c.beginPath();c.arc(0,-R*1.22,R*.09,0,Math.PI*2);c.fill();
  } else if(sk==='phoenix'){
    // Radial flame aura
    const fg=c.createRadialGradient(0,0,R*.3,0,0,R*1.4);fg.addColorStop(0,'rgba(255,200,0,0.5)');fg.addColorStop(0.5,'rgba(255,80,0,0.25)');fg.addColorStop(1,'rgba(255,0,0,0)');
    c.fillStyle=fg;c.beginPath();c.arc(0,0,R*1.4,0,Math.PI*2);c.fill();
    // Flame feather wings
    for(const s of[-1,1]){c.save();c.scale(1,s);for(let i=0;i<5;i++){const fa=(-Math.PI*.28-i*.14)+Math.sin(t*.06+i)*.08;const fr=R*(.78+i*.1);c.fillStyle=`rgba(255,${115-i*18},0,${.78-i*.08})`;c.beginPath();c.moveTo(0,0);c.quadraticCurveTo(Math.cos(fa+.3)*fr*.55,Math.sin(fa+.3)*fr*.5,Math.cos(fa)*fr,Math.sin(fa)*fr);c.quadraticCurveTo(Math.cos(fa-.2)*fr*.65,Math.sin(fa-.2)*fr*.5,0,0);c.fill();}c.restore();}
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#ff8800');bg.addColorStop(1,fl?'#ccc':'#cc2200');
    c.fillStyle=bg;c.strokeStyle='#880000';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Fire crown
    c.fillStyle=fl?'#ffd':'#ffaa00';c.strokeStyle='#cc6600';c.lineWidth=2;
    for(let i=0;i<5;i++){const fa=-Math.PI*.7+i*.34+Math.sin(t*.08+i)*.06;const fh=R*(.38+i%2*.18);c.beginPath();c.moveTo(Math.cos(fa-.1)*R*.78,Math.sin(fa-.1)*R*.78);c.lineTo(Math.cos(fa)*(R*.78+fh),Math.sin(fa)*(R*.78+fh));c.lineTo(Math.cos(fa+.1)*R*.78,Math.sin(fa+.1)*R*.78);c.closePath();c.fill();c.stroke();}
    c.fillStyle='#fff';c.beginPath();c.arc(R*.22,-R*.22,R*.1,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.22,R*.22,R*.1,0,Math.PI*2);c.fill();
    c.fillStyle='#ffcc00';c.beginPath();c.arc(R*.25,-R*.22,R*.07,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.25,R*.22,R*.07,0,Math.PI*2);c.fill();
    c.fillStyle='#000';c.beginPath();c.arc(R*.28,-R*.22,R*.04,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.28,R*.22,R*.04,0,Math.PI*2);c.fill();
  } else if(sk==='yeti'){
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#aaccee');bg.addColorStop(1,fl?'#ccc':'#6699bb');
    c.fillStyle=bg;c.strokeStyle='#4477aa';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Shaggy fur ring
    c.fillStyle=fl?'#cce':'#88aacc';c.strokeStyle='#4477aa';c.lineWidth=2;
    for(let i=0;i<16;i++){const a=i/16*Math.PI*2;const fr=R*(1.04+Math.sin(i*2.3)*.11);c.beginPath();c.arc(Math.cos(a)*fr*.88,Math.sin(a)*fr*.88,R*.17,0,Math.PI*2);c.fill();}
    c.fillStyle=fl?'#dde':'#99bbdd';c.strokeStyle='#4477aa';c.lineWidth=2;c.beginPath();c.ellipse(R*.6,0,R*.25,R*.18,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#3366aa';c.beginPath();c.ellipse(R*.72,0,R*.09,R*.07,0,0,Math.PI*2);c.fill();
    // Menacing red eyes
    c.fillStyle='#fff';c.beginPath();c.arc(R*.22,-R*.22,R*.1,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.22,R*.22,R*.1,0,Math.PI*2);c.fill();
    c.fillStyle='#ff2200';c.beginPath();c.arc(R*.25,-R*.22,R*.07,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.25,R*.22,R*.07,0,Math.PI*2);c.fill();
    c.fillStyle='#000';c.beginPath();c.arc(R*.28,-R*.22,R*.04,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.28,R*.22,R*.04,0,Math.PI*2);c.fill();
  } else if(sk==='octopus'){
    // Animated tentacles (behind)
    c.strokeStyle=fl?'#eee':'#8833cc';c.lineWidth=R*.26;c.lineCap='round';
    for(let i=0;i<6;i++){const a=(i/6*Math.PI*2)+Math.PI*.2;const wv=Math.sin(t*.06+i)*R*.2;const ex=Math.cos(a)*R*1.7+wv*Math.sin(a+Math.PI/2);const ey=Math.sin(a)*R*1.7-wv*Math.cos(a+Math.PI/2);c.beginPath();c.moveTo(Math.cos(a)*R*.5,Math.sin(a)*R*.5);c.quadraticCurveTo(Math.cos(a)*R*1.1+wv*.5,Math.sin(a)*R*1.1+wv*.5,ex,ey);c.stroke();}
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#cc66ff');bg.addColorStop(1,fl?'#ccc':'#881aaa');
    c.fillStyle=bg;c.strokeStyle='#550088';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Sucker spots
    c.fillStyle='rgba(200,100,255,0.35)';for(let i=0;i<5;i++){const a=i/5*Math.PI*2;c.beginPath();c.arc(Math.cos(a)*R*.55,Math.sin(a)*R*.55,R*.1,0,Math.PI*2);c.fill();}
    // Big cute eyes
    c.fillStyle='#fff';c.beginPath();c.arc(R*.24,-R*.24,R*.16,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.24,R*.24,R*.16,0,Math.PI*2);c.fill();
    c.fillStyle='#440066';c.beginPath();c.arc(R*.28,-R*.24,R*.11,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.28,R*.24,R*.11,0,Math.PI*2);c.fill();
    c.fillStyle='#000';c.beginPath();c.arc(R*.32,-R*.24,R*.06,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.32,R*.24,R*.06,0,Math.PI*2);c.fill();
    c.fillStyle='rgba(255,255,255,0.8)';c.beginPath();c.arc(R*.3,-R*.27,R*.04,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.3,R*.21,R*.04,0,Math.PI*2);c.fill();
    // Beak mouth
    c.fillStyle='#550088';c.strokeStyle='#330066';c.lineWidth=2;c.beginPath();c.moveTo(R*.56,-R*.08);c.lineTo(R*.72,0);c.lineTo(R*.56,R*.08);c.closePath();c.fill();c.stroke();
  } else if(sk==='kiz_sakura'){
    // ── SAKURA KIZ ─────────────────────────────────────────────
    const fl2=Math.sin(t*0.08)*0.5+0.5;
    // Cat ears (behind body)
    for(const s of[-1,1]){
      c.fillStyle=fl?'#e8b0c0':'#e87fa0';c.strokeStyle='#b03060';c.lineWidth=2.5;
      c.beginPath();c.moveTo(-R*.78,s*R*.2);c.lineTo(-R*1.18,s*R*.58);c.lineTo(-R*.65,s*R*.7);c.closePath();c.fill();c.stroke();
      c.fillStyle='#ffcce0';c.beginPath();c.moveTo(-R*.82,s*R*.26);c.lineTo(-R*1.06,s*R*.51);c.lineTo(-R*.71,s*R*.6);c.closePath();c.fill();
    }
    // Body — soft pink gradient
    const bg=c.createRadialGradient(-R*.15,-R*.18,0,0,0,R);
    bg.addColorStop(0,fl?'#fff':'#fceef5');bg.addColorStop(0.55,fl?'#ffc':'#f9c8da');bg.addColorStop(1,fl?'#fbb':'#e87fa0');
    c.fillStyle=bg;c.strokeStyle='#b03060';c.lineWidth=4;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Animated cherry blossom petals orbiting body
    c.fillStyle=`rgba(255,180,210,${0.38+fl2*.35})`;
    for(let i=0;i<6;i++){const pa=t*0.025+i*Math.PI/3;const pr=R*(0.64+Math.sin(t*0.06+i)*.09);c.beginPath();c.ellipse(Math.cos(pa)*pr,Math.sin(pa)*pr,R*.075,R*.048,pa,0,Math.PI*2);c.fill();}
    // Flower crown at back
    const fcx=-R*.38,fcy=-R*.76;
    for(let p=0;p<5;p++){const pa2=p*Math.PI*.4;c.fillStyle=['#ff88bb','#ffaacc','#ff66aa','#ffbbdd','#ee44aa'][p];c.beginPath();c.arc(fcx+Math.cos(pa2)*R*.1,fcy+Math.sin(pa2)*R*.1,R*.065,0,Math.PI*2);c.fill();}
    c.fillStyle='#ffdd44';c.beginPath();c.arc(fcx,fcy,R*.072,0,Math.PI*2);c.fill();
    // Blush marks
    for(const s of[-1,1]){c.fillStyle='rgba(255,110,140,.22)';c.beginPath();c.ellipse(R*.44,s*R*.38,R*.13,R*.075,0.3*s,0,Math.PI*2);c.fill();}
    // Big sparkly anime eyes
    for(const s of[-1,1]){
      c.fillStyle='#fff';c.beginPath();c.ellipse(R*.28,s*R*.24,R*.175,R*.13,0,0,Math.PI*2);c.fill();
      c.fillStyle='#ee5588';c.beginPath();c.ellipse(R*.3,s*R*.24,R*.125,R*.105,0,0,Math.PI*2);c.fill();
      c.fillStyle='#cc0044';c.beginPath();c.ellipse(R*.32,s*R*.24,R*.08,R*.082,0,0,Math.PI*2);c.fill();
      c.fillStyle='#000';c.beginPath();c.arc(R*.34,s*R*.24,R*.05,0,Math.PI*2);c.fill();
      c.fillStyle='rgba(255,255,255,.9)';c.beginPath();c.arc(R*.28,s*R*.195,R*.038,0,Math.PI*2);c.fill();
      c.fillStyle='rgba(255,255,255,.5)';c.beginPath();c.arc(R*.36,s*R*.275,R*.022,0,Math.PI*2);c.fill();
      c.strokeStyle='#880033';c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(R*.16,s*R*.13);c.lineTo(R*.12,s*R*.085);c.stroke();
      c.beginPath();c.moveTo(R*.24,s*R*.115);c.lineTo(R*.23,s*R*.065);c.stroke();
      c.beginPath();c.moveTo(R*.32,s*R*.115);c.lineTo(R*.33,s*R*.065);c.stroke();
      c.beginPath();c.moveTo(R*.38,s*R*.13);c.lineTo(R*.41,s*R*.085);c.stroke();
    }
    // Pink nose + mouth
    c.fillStyle='#e07090';c.beginPath();c.ellipse(R*.64,0,R*.08,R*.062,0,0,Math.PI*2);c.fill();
    c.strokeStyle='#cc4466';c.lineWidth=2;c.lineCap='round';
    c.beginPath();c.arc(R*.7,R*.04,R*.11,Math.PI*1.1,Math.PI*1.88);c.stroke();
  } else if(sk==='kiz_deniz'){
    // ── DENİZ KIZI ─────────────────────────────────────────────
    const fl2=Math.sin(t*0.07)*0.5+0.5;
    // Pearl/shell crown at back
    for(let i=0;i<7;i++){
      const pa=(-Math.PI*.6)+(i-3)*(Math.PI*.155);const pr=R*1.08;
      c.fillStyle=fl?'#d8eef8':'rgba(200,238,255,0.88)';c.strokeStyle='rgba(80,180,210,0.7)';c.lineWidth=1.5;
      c.beginPath();c.arc(Math.cos(pa)*pr-R*.1,Math.sin(pa)*pr-R*.04,R*.1,0,Math.PI*2);c.fill();c.stroke();
      c.fillStyle='rgba(255,255,255,0.4)';c.beginPath();c.arc(Math.cos(pa)*pr-R*.12,Math.sin(pa)*pr-R*.07,R*.04,0,Math.PI*2);c.fill();
    }
    // Body — teal/turquoise gradient
    const bg=c.createRadialGradient(-R*.14,-R*.18,0,0,0,R);
    bg.addColorStop(0,fl?'#fff':'#88eee0');bg.addColorStop(0.45,fl?'#cef':'#3ac8b8');bg.addColorStop(0.85,fl?'#9ac':'#009898');bg.addColorStop(1,fl?'#68a':'#006868');
    c.fillStyle=bg;c.strokeStyle='#006666';c.lineWidth=4;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Scale texture
    c.strokeStyle='rgba(0,70,70,0.2)';c.lineWidth=1.2;
    for(let row=0;row<4;row++){const yr=[-R*.42,-R*.14,R*.14,R*.42][row];for(let col=0;col<5;col++){const xr=-R*.56+col*R*.28+(row%2?R*.14:0);c.beginPath();c.arc(xr,yr,R*.13,Math.PI,0,true);c.stroke();}}
    // Shimmer highlight
    const sg=c.createRadialGradient(-R*.22,-R*.32,0,-R*.18,-R*.26,R*.52);
    sg.addColorStop(0,`rgba(255,255,255,${0.18+fl2*.12})`);sg.addColorStop(1,'rgba(255,255,255,0)');
    c.fillStyle=sg;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();
    // Aqua eyes
    for(const s of[-1,1]){
      c.fillStyle='#fff';c.beginPath();c.ellipse(R*.27,s*R*.24,R*.18,R*.135,0,0,Math.PI*2);c.fill();
      c.fillStyle='#00d8d0';c.beginPath();c.ellipse(R*.29,s*R*.24,R*.13,R*.108,0,0,Math.PI*2);c.fill();
      c.fillStyle='#008890';c.beginPath();c.ellipse(R*.31,s*R*.24,R*.082,R*.09,0,0,Math.PI*2);c.fill();
      c.fillStyle='#000';c.beginPath();c.arc(R*.33,s*R*.24,R*.052,0,Math.PI*2);c.fill();
      c.fillStyle='rgba(255,255,255,.92)';c.beginPath();c.arc(R*.27,s*R*.2,R*.04,0,Math.PI*2);c.fill();
      c.fillStyle='rgba(255,255,255,.48)';c.beginPath();c.arc(R*.36,s*R*.27,R*.02,0,Math.PI*2);c.fill();
      c.strokeStyle='rgba(0,100,110,0.8)';c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(R*.16,s*R*.13);c.lineTo(R*.12,s*R*.085);c.stroke();
      c.beginPath();c.moveTo(R*.36,s*R*.12);c.lineTo(R*.39,s*R*.075);c.stroke();
    }
    // Coral muzzle
    c.fillStyle=fl?'#ade':'#62dac8';c.strokeStyle='#008888';c.lineWidth=2;c.beginPath();c.ellipse(R*.63,0,R*.22,R*.16,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#cc5566';c.beginPath();c.ellipse(R*.745,0,R*.075,R*.062,0,0,Math.PI*2);c.fill();
    // Bubble orbit
    for(let i=0;i<5;i++){const bx=Math.cos(t*0.04+i*1.257)*R*(0.62+i*.1),by=Math.sin(t*0.05+i*1.257)*R*(0.58+i*.09);c.strokeStyle=`rgba(180,240,255,${0.28+fl2*.2})`;c.lineWidth=1.5;c.beginPath();c.arc(bx,by,R*(.048+i*.01),0,Math.PI*2);c.stroke();}
  } else if(sk==='kiz_ates'){
    // ── ATEŞ CADISI ────────────────────────────────────────────
    const fl2=Math.sin(t*0.12)*0.5+0.5;
    // Flame crown (animated, behind body)
    for(let i=0;i<8;i++){
      const fa=(-Math.PI*.68)+(i-3.5)*(Math.PI*.165);
      const fh=R*(0.5+Math.sin(t*0.12+i*.9)*0.24);
      const fx=Math.cos(fa)*R*.72-R*.1,fy=Math.sin(fa)*R*.72;
      c.fillStyle=fl?'#ffa':i%2===0?`rgba(255,${90+Math.round(fl2*120)},0,0.88)`:`rgba(255,50,0,0.72)`;
      c.beginPath();c.moveTo(fx,fy);c.lineTo(fx+Math.cos(fa-.35)*fh,fy+Math.sin(fa-.35)*fh);c.lineTo(fx,fy+fh*1.1);c.lineTo(fx+Math.cos(fa+.35)*fh,fy+Math.sin(fa+.35)*fh);c.closePath();c.fill();
    }
    // Body — fire red/orange
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);
    bg.addColorStop(0,fl?'#fff':'#ff8828');bg.addColorStop(0.38,fl?'#fcc':'#cc3300');bg.addColorStop(0.78,fl?'#a44':'#8a1000');bg.addColorStop(1,fl?'#800':'#5a0000');
    c.fillStyle=bg;c.strokeStyle='#5a0000';c.lineWidth=4;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Fire rune marks
    c.strokeStyle=`rgba(255,${160+Math.round(fl2*95)},0,0.52)`;c.lineWidth=1.8;c.lineCap='round';
    c.beginPath();c.moveTo(-R*.32,R*.22);c.lineTo(-R*.16,R*.06);c.lineTo(-R*.32,-R*.08);c.lineTo(-R*.16,-R*.24);c.stroke();
    c.beginPath();c.moveTo(-R*.52,-R*.12);c.lineTo(-R*.36,0);c.lineTo(-R*.52,R*.12);c.stroke();
    // Glowing fire eyes
    for(const s of[-1,1]){
      c.fillStyle='rgba(0,0,0,.65)';c.beginPath();c.ellipse(R*.28,s*R*.24,R*.175,R*.13,0,0,Math.PI*2);c.fill();
      const eg=c.createRadialGradient(R*.28,s*R*.24,0,R*.28,s*R*.24,R*.135);
      eg.addColorStop(0,`rgba(255,220,80,${0.82+fl2*.18})`);eg.addColorStop(0.5,`rgba(255,90,0,${0.7+fl2*.3})`);eg.addColorStop(1,'rgba(180,0,0,0.4)');
      c.fillStyle=eg;c.beginPath();c.ellipse(R*.28,s*R*.24,R*.138,R*.105,0,0,Math.PI*2);c.fill();
      c.fillStyle='#000';c.beginPath();c.arc(R*.32,s*R*.24,R*.042,0,Math.PI*2);c.fill();
      c.fillStyle=`rgba(255,240,160,${0.6+fl2*.4})`;c.beginPath();c.arc(R*.27,s*R*.2,R*.038,0,Math.PI*2);c.fill();
      c.strokeStyle='#ff4400';c.lineWidth=2.5;c.lineCap='round';
      c.beginPath();c.moveTo(R*.12,s*R*.135);c.lineTo(R*.38,s*(R*.15-s*.055));c.stroke();
      c.beginPath();c.moveTo(R*.14,s*R*.13);c.lineTo(R*.1,s*R*.08);c.stroke();
      c.beginPath();c.moveTo(R*.37,s*R*.12);c.lineTo(R*.41,s*R*.075);c.stroke();
    }
    // Dark muzzle + smirk
    c.fillStyle=fl?'#c44':'#8a1800';c.strokeStyle='#5a0000';c.lineWidth=2;c.beginPath();c.ellipse(R*.63,0,R*.22,R*.16,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#ff2200';c.beginPath();c.ellipse(R*.745,0,R*.082,R*.065,0,0,Math.PI*2);c.fill();
    c.strokeStyle='#ff5500';c.lineWidth=2;c.lineCap='round';
    c.beginPath();c.arc(R*.74,R*.045,R*.115,Math.PI*1.1,Math.PI*1.62);c.stroke();
    // Outer glow
    c.save();c.shadowColor='#ff4400';c.shadowBlur=16*(0.4+fl2*.6);
    c.strokeStyle=`rgba(255,80,0,${0.16+fl2*.18})`;c.lineWidth=5;c.beginPath();c.arc(0,0,R+2,0,Math.PI*2);c.stroke();c.restore();
  } else if(sk==='kiz_buz'){
    // ── BUZ PRENSESİ ───────────────────────────────────────────
    const fl2=Math.sin(t*0.06)*0.5+0.5;
    // Ice crystal crown (behind body)
    for(let i=0;i<8;i++){
      const ca=(-Math.PI*.62)+(i-3.5)*(Math.PI*.155);
      const ch=R*(0.32+Math.sin(i*1.35)*0.18+Math.sin(t*0.05+i)*0.08);
      const cx=Math.cos(ca)*R*.84-R*.1,cy=Math.sin(ca)*R*.84;
      c.fillStyle=fl?'#eef':'rgba(175,232,255,0.82)';c.strokeStyle=`rgba(80,196,255,${0.5+fl2*.3})`;c.lineWidth=1.5;
      c.beginPath();c.moveTo(cx,cy);c.lineTo(cx-R*.038,cy+ch*.52);c.lineTo(cx,cy+ch);c.lineTo(cx+R*.038,cy+ch*.52);c.closePath();c.fill();c.stroke();
      c.fillStyle='rgba(255,255,255,0.45)';c.beginPath();c.moveTo(cx-R*.016,cy+ch*.18);c.lineTo(cx,cy+ch*.44);c.lineTo(cx+R*.016,cy+ch*.18);c.closePath();c.fill();
    }
    // Body — icy blue
    const bg=c.createRadialGradient(-R*.18,-R*.22,0,0,0,R);
    bg.addColorStop(0,fl?'#fff':'#eef9ff');bg.addColorStop(0.38,fl?'#ccf':'#c0ecff');bg.addColorStop(0.75,fl?'#aaf':'#88ccee');bg.addColorStop(1,fl?'#88f':'#4488aa');
    c.fillStyle=bg;c.strokeStyle='#3377aa';c.lineWidth=4;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Snowflake pattern on body
    c.strokeStyle=`rgba(160,224,255,${0.48+fl2*.3})`;c.lineWidth=1.6;c.lineCap='round';
    for(let i=0;i<6;i++){const sa=i*Math.PI/3;c.beginPath();c.moveTo(0,0);c.lineTo(Math.cos(sa)*R*.4,Math.sin(sa)*R*.4);c.stroke();}
    for(let i=0;i<6;i++){const sa=i*Math.PI/3+Math.PI/6;const sb=R*.26;c.beginPath();c.moveTo(Math.cos(sa)*sb*.5,Math.sin(sa)*sb*.5);c.lineTo(Math.cos(sa)*sb,Math.sin(sa)*sb);c.stroke();}
    // Shimmer
    const sg=c.createRadialGradient(-R*.28,-R*.35,0,-R*.2,-R*.26,R*.5);
    sg.addColorStop(0,`rgba(255,255,255,${0.28+fl2*.16})`);sg.addColorStop(1,'rgba(255,255,255,0)');
    c.fillStyle=sg;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();
    // Icy eyes
    for(const s of[-1,1]){
      c.fillStyle='#fff';c.beginPath();c.ellipse(R*.27,s*R*.24,R*.18,R*.135,0,0,Math.PI*2);c.fill();
      c.fillStyle='#7af8ff';c.beginPath();c.ellipse(R*.29,s*R*.24,R*.132,R*.108,0,0,Math.PI*2);c.fill();
      c.fillStyle='#00aacc';c.beginPath();c.ellipse(R*.31,s*R*.24,R*.082,R*.09,0,0,Math.PI*2);c.fill();
      c.fillStyle='#003344';c.beginPath();c.arc(R*.33,s*R*.24,R*.052,0,Math.PI*2);c.fill();
      c.fillStyle='rgba(255,255,255,.92)';c.beginPath();c.arc(R*.275,s*R*.196,R*.04,0,Math.PI*2);c.fill();
      c.fillStyle='rgba(255,255,255,.5)';c.beginPath();c.arc(R*.37,s*R*.274,R*.022,0,Math.PI*2);c.fill();
      c.strokeStyle=`rgba(160,224,255,${0.38+fl2*.28})`;c.lineWidth=0.9;
      for(let ax=0;ax<3;ax++){const ang=ax*Math.PI/3;c.beginPath();c.moveTo(R*.31-Math.cos(ang)*R*.03,s*R*.24-Math.sin(ang)*R*.03);c.lineTo(R*.31+Math.cos(ang)*R*.03,s*R*.24+Math.sin(ang)*R*.03);c.stroke();}
      c.strokeStyle='#4488aa';c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(R*.15,s*R*.13);c.lineTo(R*.11,s*R*.085);c.stroke();
      c.beginPath();c.moveTo(R*.36,s*R*.12);c.lineTo(R*.4,s*R*.075);c.stroke();
    }
    // Frosted muzzle
    c.fillStyle=fl?'#def':'#c0eaf8';c.strokeStyle='#3377aa';c.lineWidth=2;c.beginPath();c.ellipse(R*.63,0,R*.22,R*.16,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#88ccdd';c.beginPath();c.ellipse(R*.745,0,R*.08,R*.064,0,0,Math.PI*2);c.fill();
    // Ice sparkle orbit
    for(let i=0;i<6;i++){const ix=Math.cos(t*0.04+i*1.047)*R*(0.56+i*.09),iy=Math.sin(t*0.05+i*1.047)*R*(0.54+i*.085);c.fillStyle=`rgba(190,236,255,${0.45+fl2*.38})`;c.beginPath();c.arc(ix,iy,R*.038,0,Math.PI*2);c.fill();}
    // Cold aura glow
    c.save();c.shadowColor='#00ccff';c.shadowBlur=12*(0.3+fl2*.7);
    c.strokeStyle=`rgba(170,228,255,${0.14+fl2*.12})`;c.lineWidth=4;c.beginPath();c.arc(0,0,R+1,0,Math.PI*2);c.stroke();c.restore();
  } else if(sk==='kiz_orman'){
    // ── ORMAN PERİSİ ───────────────────────────────────────────
    const fl2=Math.sin(t*0.08)*0.5+0.5;
    // Leaf crown (behind)
    for(let i=0;i<9;i++){
      const la=(-Math.PI*.68)+(i-4)*(Math.PI*.132);
      const lx=Math.cos(la)*R*.9-R*.1,ly=Math.sin(la)*R*.9;
      c.fillStyle=fl?'#aea':(['#4aaa20','#5ab830','#3a8a14','#88cc40','#2a7a10','#66bb28','#44990e'][i%7]);
      c.strokeStyle='#1a5a08';c.lineWidth=1.4;
      c.save();c.translate(lx,ly);c.rotate(la+Math.PI*.5);
      c.beginPath();c.ellipse(0,-R*.14,R*.09,R*.2,0,0,Math.PI*2);c.fill();c.stroke();
      c.strokeStyle='rgba(200,255,160,0.5)';c.lineWidth=0.8;c.beginPath();c.moveTo(0,-R*.04);c.lineTo(0,-R*.24);c.stroke();c.restore();
    }
    // Small flowers in crown
    for(let i=0;i<4;i++){
      const la=(-Math.PI*.55)+(i-1.5)*(Math.PI*.18);
      const lx=Math.cos(la)*R*.9-R*.1,ly=Math.sin(la)*R*.9;
      for(let p=0;p<5;p++){const pa=p*Math.PI*.4;c.fillStyle=['#ff88bb','#ffaa44','#ff6688','#aaff44','#ffcc00'][i];c.beginPath();c.arc(lx+Math.cos(pa)*R*.07,ly+Math.sin(pa)*R*.07,R*.048,0,Math.PI*2);c.fill();}
      c.fillStyle='#ffee00';c.beginPath();c.arc(lx,ly,R*.058,0,Math.PI*2);c.fill();
    }
    // Body — emerald green
    const bg=c.createRadialGradient(-R*.12,-R*.14,0,0,0,R);
    bg.addColorStop(0,fl?'#fff':'#d0f090');bg.addColorStop(0.38,fl?'#cec':'#88cc50');bg.addColorStop(0.78,fl?'#8b8':'#4aaa20');bg.addColorStop(1,fl?'#484':'#2a7814');
    c.fillStyle=bg;c.strokeStyle='#1a5a08';c.lineWidth=4;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Vine patterns
    c.strokeStyle='rgba(20,90,10,0.28)';c.lineWidth=2;c.lineCap='round';
    c.beginPath();c.moveTo(-R*.56,R*.28);c.quadraticCurveTo(-R*.2,R*.52,R*.1,R*.3);c.stroke();
    c.beginPath();c.moveTo(-R*.48,-R*.28);c.quadraticCurveTo(-R*.12,-R*.52,R*.18,-R*.28);c.stroke();
    // Small leaves on body
    for(const[lx2,ly2,la2]of[[-R*.42,R*.14,0.55],[-R*.3,-R*.36,-0.6],[R*.1,R*.44,0.8]]){
      c.fillStyle='#3aaa14';c.strokeStyle='#1a5a08';c.lineWidth=1;
      c.save();c.translate(lx2,ly2);c.rotate(la2);c.beginPath();c.ellipse(0,0,R*.1,R*.062,0,0,Math.PI*2);c.fill();c.stroke();c.restore();
    }
    // Bright fairy-green eyes
    for(const s of[-1,1]){
      c.fillStyle='#fff';c.beginPath();c.ellipse(R*.27,s*R*.24,R*.175,R*.13,0,0,Math.PI*2);c.fill();
      c.fillStyle='#44cc44';c.beginPath();c.ellipse(R*.29,s*R*.24,R*.125,R*.105,0,0,Math.PI*2);c.fill();
      c.fillStyle='#007700';c.beginPath();c.ellipse(R*.31,s*R*.24,R*.078,R*.088,0,0,Math.PI*2);c.fill();
      c.fillStyle='#000';c.beginPath();c.arc(R*.33,s*R*.24,R*.05,0,Math.PI*2);c.fill();
      c.fillStyle='rgba(255,255,255,.9)';c.beginPath();c.arc(R*.275,s*R*.196,R*.038,0,Math.PI*2);c.fill();
      c.fillStyle='rgba(255,255,255,.45)';c.beginPath();c.arc(R*.36,s*R*.276,R*.02,0,Math.PI*2);c.fill();
      c.strokeStyle='#1a5a08';c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(R*.15,s*R*.13);c.lineTo(R*.11,s*R*.085);c.stroke();
      c.beginPath();c.moveTo(R*.36,s*R*.12);c.lineTo(R*.4,s*R*.075);c.stroke();
    }
    // Green muzzle + smile
    c.fillStyle=fl?'#bfb':'#88cc60';c.strokeStyle='#1a5a08';c.lineWidth=2;c.beginPath();c.ellipse(R*.63,0,R*.22,R*.16,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#4a9a24';c.beginPath();c.ellipse(R*.745,0,R*.074,R*.06,0,0,Math.PI*2);c.fill();
    c.strokeStyle='#1a5a08';c.lineWidth=2.5;c.lineCap='round';c.beginPath();c.arc(R*.7,R*.042,R*.115,Math.PI*1.12,Math.PI*1.88);c.stroke();
    // Fairy sparkles
    for(let i=0;i<7;i++){const fx=Math.cos(t*0.04+i*0.898)*R*(0.62+Math.sin(t*.06+i)*.14),fy=Math.sin(t*0.04+i*0.898)*R*(0.62+Math.sin(t*.07+i)*.13);c.fillStyle=`rgba(${100+i*18},255,${80+i*14},${(0.5+fl2*.42)*(1-i*.1)})`;c.beginPath();c.arc(fx,fy,R*.042,0,Math.PI*2);c.fill();}
  } else if(sk==='kiz_vampir'){
    // ── VAMPİR KIZ ─────────────────────────────────────────────
    const fl2=Math.sin(t*0.09)*0.5+0.5;
    // Bat ears (behind body)
    for(const s of[-1,1]){
      c.fillStyle=fl?'#553':'#1a001a';c.strokeStyle='#7700cc';c.lineWidth=2.5;
      c.beginPath();c.moveTo(-R*.72,s*R*.2);c.lineTo(-R*1.28,s*R*.66);c.lineTo(-R*1.08,s*R*.22);c.lineTo(-R*1.28,-s*R*.02);c.closePath();c.fill();c.stroke();
      c.fillStyle='#330048';c.beginPath();c.moveTo(-R*.76,s*R*.24);c.lineTo(-R*1.14,s*R*.56);c.lineTo(-R*.99,s*R*.28);c.lineTo(-R*1.12,s*R*.06);c.closePath();c.fill();
      c.fillStyle=`rgba(180,0,255,${0.22+fl2*.18})`;c.beginPath();c.arc(-R*1.02,s*R*.34,R*.078,0,Math.PI*2);c.fill();
    }
    // Body — deep purple
    const bg=c.createRadialGradient(-R*.12,-R*.14,0,0,0,R);
    bg.addColorStop(0,fl?'#888':'#4a0062');bg.addColorStop(0.38,fl?'#666':'#2c0044');bg.addColorStop(0.78,fl?'#444':'#18002a');bg.addColorStop(1,fl?'#222':'#080012');
    c.fillStyle=bg;c.strokeStyle='#7700cc';c.lineWidth=4;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Moon crescent marking
    c.fillStyle=`rgba(180,0,255,${0.18+fl2*.14})`;c.strokeStyle='rgba(200,100,255,0.36)';c.lineWidth=1;
    c.beginPath();c.arc(-R*.28,R*.1,R*.34,Math.PI*.28,Math.PI*1.82);c.arc(-R*.3,R*.08,R*.24,Math.PI*1.82,Math.PI*.28,true);c.closePath();c.fill();c.stroke();
    // Glowing purple/crimson vampire eyes
    for(const s of[-1,1]){
      c.fillStyle='#050008';c.beginPath();c.ellipse(R*.28,s*R*.24,R*.175,R*.135,0,0,Math.PI*2);c.fill();
      const eg=c.createRadialGradient(R*.28,s*R*.24,0,R*.28,s*R*.24,R*.136);
      eg.addColorStop(0,`rgba(255,60,255,${0.9+fl2*.1})`);eg.addColorStop(0.4,`rgba(180,0,200,${0.7+fl2*.3})`);eg.addColorStop(1,'rgba(80,0,80,0.28)');
      c.fillStyle=eg;c.beginPath();c.ellipse(R*.28,s*R*.24,R*.132,R*.105,0,0,Math.PI*2);c.fill();
      c.fillStyle='#000';c.beginPath();c.arc(R*.32,s*R*.24,R*.042,0,Math.PI*2);c.fill();
      c.fillStyle=`rgba(255,160,255,${0.5+fl2*.42})`;c.beginPath();c.arc(R*.272,s*R*.196,R*.038,0,Math.PI*2);c.fill();
      c.save();c.shadowColor='#cc00ff';c.shadowBlur=9*(0.4+fl2*.6);
      c.strokeStyle=`rgba(200,50,255,${0.56+fl2*.36})`;c.lineWidth=1;c.beginPath();c.ellipse(R*.28,s*R*.24,R*.175,R*.135,0,0,Math.PI*2);c.stroke();c.restore();
      c.strokeStyle='#7700aa';c.lineWidth=2.2;c.lineCap='round';
      c.beginPath();c.moveTo(R*.12,s*R*.135);c.lineTo(R*.08,s*R*.08);c.stroke();
      c.beginPath();c.moveTo(R*.37,s*R*.12);c.lineTo(R*.42,s*R*.07);c.stroke();
    }
    // Pale dark muzzle + fangs
    c.fillStyle=fl?'#aaa':'#1e0030';c.strokeStyle='#7700cc';c.lineWidth=2;c.beginPath();c.ellipse(R*.63,0,R*.22,R*.16,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#eee0ff';c.strokeStyle='#9900cc';c.lineWidth=1;
    for(const s of[-1,1]){c.beginPath();c.moveTo(R*.56+s*R*.066,R*.07);c.lineTo(R*.61+s*R*.066,R*.19);c.lineTo(R*.65+s*R*.066,R*.07);c.closePath();c.fill();c.stroke();}
    c.fillStyle='rgba(130,0,130,.48)';c.beginPath();c.ellipse(R*.74,0,R*.072,R*.058,0,0,Math.PI*2);c.fill();
    // Purple aura
    c.save();c.shadowColor='#9900ff';c.shadowBlur=18*(0.3+fl2*.7);
    c.strokeStyle=`rgba(140,0,255,${0.14+fl2*.14})`;c.lineWidth=5;c.beginPath();c.arc(0,0,R+2,0,Math.PI*2);c.stroke();c.restore();
  } else if(sk==='kiz_neon'){
    // ── NEON SAVAŞÇI ───────────────────────────────────────────
    const fl2=Math.sin(t*0.15)*0.5+0.5;
    const hue=(t*1.8)%360;
    // Circuit headgear (behind body)
    c.strokeStyle=`hsl(${hue},100%,62%)`;c.lineWidth=2;c.lineCap='square';
    c.beginPath();c.moveTo(-R*.82,-R*.3);c.lineTo(-R*.52,-R*.3);c.lineTo(-R*.52,-R*.56);c.lineTo(-R*.22,-R*.56);c.stroke();
    c.beginPath();c.moveTo(-R*.82,R*.3);c.lineTo(-R*.52,R*.3);c.lineTo(-R*.52,R*.56);c.lineTo(-R*.22,R*.56);c.stroke();
    for(const[nx,ny]of[[-R*.82,-R*.3],[-R*.52,-R*.56],[-R*.82,R*.3],[-R*.52,R*.56]]){
      c.fillStyle=`hsl(${(hue+120)%360},100%,72%)`;c.strokeStyle='#000';c.lineWidth=1;c.beginPath();c.arc(nx,ny,R*.062,0,Math.PI*2);c.fill();c.stroke();
    }
    // Body — dark cyberpunk
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);
    bg.addColorStop(0,fl?'#778':'#141028');bg.addColorStop(0.42,fl?'#556':'#0d0820');bg.addColorStop(1,fl?'#334':'#050510');
    c.fillStyle=bg;c.strokeStyle=`hsl(${hue},100%,58%)`;c.lineWidth=3;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Neon circuit lines on body
    c.strokeStyle=`hsla(${hue},100%,68%,${0.48+fl2*.28})`;c.lineWidth=1.5;c.lineCap='round';
    c.beginPath();c.moveTo(-R*.52,R*.22);c.lineTo(-R*.22,R*.22);c.lineTo(-R*.22,R*.44);c.lineTo(R*.08,R*.44);c.stroke();
    c.beginPath();c.moveTo(-R*.48,-R*.26);c.lineTo(-R*.18,-R*.26);c.lineTo(-R*.18,-R*.47);c.lineTo(R*.04,-R*.47);c.stroke();
    c.beginPath();c.moveTo(-R*.62,0);c.lineTo(-R*.32,0);c.stroke();
    c.beginPath();c.moveTo(-R*.32,-R*.44);c.lineTo(-R*.32,R*.44);c.stroke();
    for(const[nx2,ny2]of[[-R*.22,R*.22],[-R*.22,R*.44],[-R*.22,-R*.26],[-R*.32,0],[-R*.32,-R*.44]]){
      c.fillStyle=`hsla(${(hue+180)%360},100%,72%,${0.65+fl2*.28})`;c.beginPath();c.arc(nx2,ny2,R*.042,0,Math.PI*2);c.fill();
    }
    // Neon headband arc
    c.strokeStyle=`hsl(${(hue+180)%360},100%,68%)`;c.lineWidth=3;
    c.beginPath();c.arc(0,0,R*.98,Math.PI*.64,Math.PI*1.02);c.stroke();
    // Big neon eyes
    for(const s of[-1,1]){
      c.fillStyle='#070814';c.beginPath();c.ellipse(R*.28,s*R*.24,R*.175,R*.135,0,0,Math.PI*2);c.fill();
      const eg=c.createRadialGradient(R*.28,s*R*.24,0,R*.28,s*R*.24,R*.136);
      eg.addColorStop(0,`hsl(${hue},100%,82%)`);eg.addColorStop(0.5,`hsl(${hue},100%,52%)`);eg.addColorStop(1,'rgba(0,0,5,0.5)');
      c.fillStyle=eg;c.beginPath();c.ellipse(R*.28,s*R*.24,R*.132,R*.105,0,0,Math.PI*2);c.fill();
      c.fillStyle='#000';c.beginPath();c.arc(R*.32,s*R*.24,R*.044,0,Math.PI*2);c.fill();
      c.save();c.shadowColor=`hsl(${hue},100%,70%)`;c.shadowBlur=10;
      c.fillStyle=`hsla(${hue},100%,88%,0.82)`;c.beginPath();c.arc(R*.272,s*R*.196,R*.034,0,Math.PI*2);c.fill();c.restore();
      c.strokeStyle=`hsl(${(hue+90)%360},100%,62%)`;c.lineWidth=1.5;c.lineCap='round';
      c.beginPath();c.moveTo(R*.15,s*R*.13);c.lineTo(R*.1,s*R*.08);c.stroke();
      c.beginPath();c.moveTo(R*.37,s*R*.12);c.lineTo(R*.42,s*R*.075);c.stroke();
    }
    // Dark muzzle neon trim
    c.fillStyle='#0d0820';c.strokeStyle=`hsl(${hue},100%,58%)`;c.lineWidth=1.5;c.beginPath();c.ellipse(R*.63,0,R*.22,R*.16,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle=`hsl(${(hue+90)%360},100%,62%)`;c.beginPath();c.ellipse(R*.745,0,R*.065,R*.055,0,0,Math.PI*2);c.fill();
    // Neon glow outer ring
    c.save();c.shadowColor=`hsl(${hue},100%,62%)`;c.shadowBlur=20*(0.3+fl2*.7);
    c.strokeStyle=`hsla(${hue},100%,70%,${0.18+fl2*.15})`;c.lineWidth=5;c.beginPath();c.arc(0,0,R+2,0,Math.PI*2);c.stroke();c.restore();
  } else if(sk==='kiz_samurai'){
    // ── SAMURAİ KIZ ────────────────────────────────────────────
    const fl2=Math.sin(t*0.07)*0.5+0.5;
    // Kabuto helmet cheek guards (behind)
    for(const s of[-1,1]){
      c.fillStyle=fl?'#c44':'#880000';c.strokeStyle='#3a0000';c.lineWidth=2.5;
      c.beginPath();c.moveTo(-R*.7,s*R*.2);c.lineTo(-R*1.22,s*R*.32);c.lineTo(-R*1.2,s*R*.7);c.lineTo(-R*.72,s*R*.62);c.closePath();c.fill();c.stroke();
      c.strokeStyle='#c8a040';c.lineWidth=1.5;
      c.beginPath();c.moveTo(-R*.7,s*R*.2);c.lineTo(-R*1.22,s*R*.32);c.stroke();
      c.beginPath();c.moveTo(-R*.72,s*R*.62);c.lineTo(-R*1.2,s*R*.7);c.stroke();
      for(let ri=1;ri<4;ri++){c.beginPath();c.moveTo(-R*.74,s*(R*.22+ri*R*.1));c.lineTo(-R*1.18,s*(R*.32+ri*R*.1));c.stroke();}
    }
    // Kabuto back plate
    c.fillStyle=fl?'#c44':'#660000';c.strokeStyle='#3a0000';c.lineWidth=3;
    c.beginPath();c.arc(-R*.58,0,R*.56,Math.PI*.38,Math.PI*1.62);c.lineTo(-R*.75,0);c.closePath();c.fill();c.stroke();
    c.strokeStyle='#c8a040';c.lineWidth=1.5;
    c.beginPath();c.arc(-R*.58,0,R*.5,Math.PI*.42,Math.PI*1.58);c.stroke();
    for(let i=0;i<3;i++){c.strokeStyle='rgba(200,160,60,.56)';c.lineWidth=1;c.beginPath();c.arc(-R*.58,0,R*(0.28+i*.08),Math.PI*.48,Math.PI*1.52);c.stroke();}
    // Body — dark lacquer armor
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);
    bg.addColorStop(0,fl?'#c44':'#580808');bg.addColorStop(0.36,fl?'#a00':'#380000');bg.addColorStop(0.76,fl?'#800':'#1e0000');bg.addColorStop(1,fl?'#600':'#0e0000');
    c.fillStyle=bg;c.strokeStyle='#380000';c.lineWidth=4;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Gold armor plates
    c.fillStyle='#c8a040';c.strokeStyle='#8b6914';c.lineWidth=1.5;
    for(const [sa,ea] of [[Math.PI*1.48,Math.PI*1.7],[Math.PI*1.28,Math.PI*1.48],[Math.PI*.5,Math.PI*.72]]){
      c.beginPath();c.arc(0,0,R,sa,ea,false);c.arc(0,0,R*.74,ea,sa,true);c.closePath();c.fill();c.stroke();
    }
    // Red lacings detail
    c.strokeStyle='#cc2200';c.lineWidth=1.2;c.lineCap='round';
    for(const [x1,y1,x2,y2] of [[-R*.18,R*.72,-R*.18,R*.52],[-R*.04,R*.76,-R*.04,R*.56],[R*.1,R*.72,R*.1,R*.52],[-R*.18,-R*.72,-R*.18,-R*.52]]){
      c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();
    }
    // Fierce dark eyes
    for(const s of[-1,1]){
      c.fillStyle='#fff';c.beginPath();c.ellipse(R*.26,s*R*.24,R*.17,R*.108,s*.18,0,Math.PI*2);c.fill();
      c.fillStyle='#1a0606';c.beginPath();c.ellipse(R*.29,s*R*.24,R*.1,R*.09,s*.18,0,Math.PI*2);c.fill();
      c.fillStyle='#000';c.beginPath();c.arc(R*.32,s*R*.24,R*.06,0,Math.PI*2);c.fill();
      c.fillStyle='rgba(255,255,255,.65)';c.beginPath();c.arc(R*.272,s*R*.2,R*.03,0,Math.PI*2);c.fill();
      c.strokeStyle='#3a0000';c.lineWidth=2.8;c.lineCap='round';
      c.beginPath();c.moveTo(R*.1,s*(R*.14+s*.07));c.lineTo(R*.37,s*(R*.17-s*.055));c.stroke();
      c.lineWidth=1.5;
      c.beginPath();c.moveTo(R*.13,s*R*.13);c.lineTo(R*.09,s*R*.08);c.stroke();
      c.beginPath();c.moveTo(R*.37,s*R*.12);c.lineTo(R*.42,s*R*.07);c.stroke();
    }
    // Armored muzzle
    c.fillStyle=fl?'#a44':'#380808';c.strokeStyle='#c8a040';c.lineWidth=2;c.beginPath();c.ellipse(R*.63,0,R*.22,R*.16,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#180000';c.beginPath();c.ellipse(R*.745,0,R*.082,R*.065,0,0,Math.PI*2);c.fill();
    // Gold shimmer
    c.save();c.shadowColor='#c8a040';c.shadowBlur=10*(0.3+fl2*.7);
    c.strokeStyle=`rgba(200,160,64,${0.14+fl2*.12})`;c.lineWidth=4;c.beginPath();c.arc(0,0,R+1,0,Math.PI*2);c.stroke();c.restore();
  } else if(sk==='kiz_karanlik'){
    // ── GECE KRALİÇESİ ─────────────────────────────────────────
    const fl2=Math.sin(t*0.05)*0.5+0.5;
    const hue2=(t*0.9)%360;
    // Star/gem crown (behind)
    for(let i=0;i<8;i++){
      const ca=(-Math.PI*.62)+(i-3.5)*(Math.PI*.155);
      const cr=R*(0.88+Math.sin(i*1.12+t*0.038)*0.1);
      const cx=Math.cos(ca)*cr-R*.08,cy=Math.sin(ca)*cr;
      const cs=R*(0.07+Math.sin(i*.72)*0.04);
      c.fillStyle=fl?'#aaa':`hsl(${(hue2+i*42)%360},80%,72%)`;c.strokeStyle='rgba(0,0,0,.38)';c.lineWidth=0.8;
      c.beginPath();
      for(let pt=0;pt<8;pt++){const ang2=pt*Math.PI/4+(pt%2===0?0:Math.PI/8);const r2=pt%2===0?cs*2.4:cs*.9;c.lineTo(cx+Math.cos(ang2)*r2,cy+Math.sin(ang2)*r2);}
      c.closePath();c.fill();c.stroke();
    }
    // Body — night galaxy
    const bg=c.createRadialGradient(-R*.12,-R*.14,0,0,0,R);
    bg.addColorStop(0,fl?'#335':'#1c0b3c');bg.addColorStop(0.38,fl?'#224':'#100522');bg.addColorStop(0.78,fl?'#113':'#070218');bg.addColorStop(1,fl?'#002':'#030010');
    c.fillStyle=bg;c.strokeStyle=`hsl(${hue2},72%,42%)`;c.lineWidth=4;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Galaxy swirl arcs
    c.save();c.globalAlpha=0.32;
    for(let ring=0;ring<4;ring++){
      const h3=(hue2+ring*55)%360;
      c.strokeStyle=`hsl(${h3},80%,62%)`;c.lineWidth=1.6*(1-ring*.16);
      const startA=t*0.022*(ring%2===0?1:-1.4);
      c.beginPath();c.arc(0,0,R*(0.18+ring*.2),startA,startA+Math.PI*(1.38-ring*.09));c.stroke();
    }
    c.restore();
    // Star dust
    for(let i=0;i<16;i++){
      const sa=i*0.3927+t*0.012,sr=R*(0.08+i*.06);
      if(sr>R*.88)continue;
      const sbr=0.35+Math.sin(t*0.09+i)*0.42;
      c.fillStyle=`rgba(${200+Math.round(Math.sin(i)*52)},${198+Math.round(Math.cos(i)*52)},255,${sbr})`;
      c.beginPath();c.arc(Math.cos(sa)*sr,Math.sin(sa)*sr,R*.024,0,Math.PI*2);c.fill();
    }
    // Galaxy starry eyes
    for(const s of[-1,1]){
      c.fillStyle='#05021c';c.beginPath();c.ellipse(R*.28,s*R*.24,R*.18,R*.136,0,0,Math.PI*2);c.fill();
      const eg=c.createRadialGradient(R*.28,s*R*.24,0,R*.28,s*R*.24,R*.138);
      eg.addColorStop(0,`hsl(${hue2},100%,92%)`);eg.addColorStop(0.3,`hsl(${(hue2+65)%360},82%,52%)`);eg.addColorStop(0.7,`hsl(${(hue2+185)%360},90%,30%)`);eg.addColorStop(1,'rgba(0,0,12,0.8)');
      c.fillStyle=eg;c.beginPath();c.ellipse(R*.28,s*R*.24,R*.14,R*.11,0,0,Math.PI*2);c.fill();
      for(let st=0;st<4;st++){const sta=t*0.035+st*Math.PI*.5;const str=R*.072;c.fillStyle='rgba(255,255,255,.66)';c.beginPath();c.arc(R*.28+Math.cos(sta)*str,s*R*.24+Math.sin(sta)*str,R*.016,0,Math.PI*2);c.fill();}
      c.fillStyle='rgba(0,0,0,.58)';c.beginPath();c.arc(R*.31,s*R*.24,R*.056,0,Math.PI*2);c.fill();
      c.fillStyle=`rgba(255,255,255,${0.6+fl2*.38})`;c.beginPath();c.arc(R*.272,s*R*.196,R*.04,0,Math.PI*2);c.fill();
      c.save();c.shadowColor=`hsl(${hue2},100%,70%)`;c.shadowBlur=9;
      c.strokeStyle=`hsla(${hue2},82%,72%,${0.48+fl2*.38})`;c.lineWidth=1;c.beginPath();c.ellipse(R*.28,s*R*.24,R*.18,R*.136,0,0,Math.PI*2);c.stroke();c.restore();
      c.strokeStyle=`hsl(${hue2},80%,62%)`;c.lineWidth=1.6;c.lineCap='round';
      c.beginPath();c.moveTo(R*.14,s*R*.13);c.lineTo(R*.1,s*R*.08);c.stroke();
      c.beginPath();c.moveTo(R*.36,s*R*.12);c.lineTo(R*.41,s*R*.075);c.stroke();
    }
    // Dark muzzle
    c.fillStyle='#070218';c.strokeStyle=`hsl(${hue2},72%,42%)`;c.lineWidth=2;c.beginPath();c.ellipse(R*.63,0,R*.22,R*.16,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle=`hsl(${hue2},82%,62%)`;c.beginPath();c.ellipse(R*.745,0,R*.074,R*.06,0,0,Math.PI*2);c.fill();
    // Galaxy glow
    c.save();c.shadowColor=`hsl(${hue2},100%,62%)`;c.shadowBlur=18*(0.3+fl2*.7);
    c.strokeStyle=`hsla(${hue2},100%,72%,${0.14+fl2*.12})`;c.lineWidth=5;c.beginPath();c.arc(0,0,R+2,0,Math.PI*2);c.stroke();c.restore();
  } else if(sk==='kiz_peri'){
    // ── GÖKKUŞAĞI PERİSİ ───────────────────────────────────────
    const fl2=Math.sin(t*0.08)*0.5+0.5;
    const hue=(t*2.4)%360;
    // Butterfly wings (behind body)
    for(const s of[-1,1]){
      const wg=c.createLinearGradient(-R,s*R*.5,-R*1.82,s*R*1.0);
      wg.addColorStop(0,`hsla(${(hue+s*45)%360},90%,72%,0.72)`);wg.addColorStop(0.5,`hsla(${(hue+s*90+120)%360},100%,82%,0.48)`);wg.addColorStop(1,'rgba(255,255,255,0.06)');
      c.fillStyle=wg;c.strokeStyle=`hsla(${hue},82%,66%,0.66)`;c.lineWidth=1.8;
      c.beginPath();c.moveTo(-R*.66,s*R*.2);c.quadraticCurveTo(-R*1.62,s*R*.3,-R*1.82,s*R*.82);c.quadraticCurveTo(-R*1.72,s*R*1.18,-R*1.22,s*R*.92);c.quadraticCurveTo(-R*.96,s*R*.72,-R*.7,s*R*.32);c.closePath();c.fill();c.stroke();
      c.strokeStyle=`hsla(${(hue+s*65)%360},100%,78%,0.42)`;c.lineWidth=1.4;
      c.beginPath();c.moveTo(-R*.82,s*R*.42);c.quadraticCurveTo(-R*1.32,s*R*.52,-R*1.54,s*R*.76);c.stroke();
      c.beginPath();c.moveTo(-R*.88,s*R*.58);c.quadraticCurveTo(-R*1.22,s*R*.72,-R*1.38,s*R*.92);c.stroke();
      // Wing veins
      c.strokeStyle=`hsla(${(hue+120)%360},100%,80%,0.25)`;c.lineWidth=0.8;
      c.beginPath();c.moveTo(-R*.8,s*R*.35);c.lineTo(-R*1.6,s*R*.75);c.stroke();
    }
    // Body — rainbow iridescent
    const bg=c.createRadialGradient(-R*.12,-R*.14,0,0,0,R);
    bg.addColorStop(0,fl?'#fff':`hsl(${hue},92%,90%)`);bg.addColorStop(0.28,fl?'#ffe':`hsl(${(hue+45)%360},88%,80%)`);bg.addColorStop(0.58,fl?'#ffc':`hsl(${(hue+90)%360},86%,72%)`);bg.addColorStop(0.84,fl?'#ff8':`hsl(${(hue+130)%360},82%,64%)`);bg.addColorStop(1,fl?'#ff4':`hsl(${(hue+165)%360},78%,56%)`);
    c.fillStyle=bg;c.strokeStyle=`hsl(${hue},82%,56%)`;c.lineWidth=3;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // Fairy dust on body
    for(let i=0;i<10;i++){
      const sa=t*0.032+i*0.628,sr=R*(0.14+i*.07);if(sr>R*.88)continue;
      c.fillStyle=`hsla(${(hue+i*36)%360},100%,82%,${0.46+Math.sin(t*.12+i)*.38})`;
      c.beginPath();c.arc(Math.cos(sa)*sr,Math.sin(sa)*sr,R*.032,0,Math.PI*2);c.fill();
    }
    // Rainbow crown sparkles
    for(let i=0;i<8;i++){
      const ca=(-Math.PI*.62)+(i-3.5)*(Math.PI*.145);
      const cx=Math.cos(ca)*R*.9-R*.06,cy=Math.sin(ca)*R*.9;
      c.fillStyle=fl?'#fff':`hsl(${(hue+i*32)%360},100%,82%)`;c.strokeStyle='rgba(255,255,255,0.5)';c.lineWidth=0.8;c.beginPath();c.arc(cx,cy,R*.095,0,Math.PI*2);c.fill();c.stroke();
      c.strokeStyle=`hsla(${(hue+i*32)%360},100%,88%,${0.48+fl2*.38})`;c.lineWidth=0.9;
      c.beginPath();c.moveTo(cx,cy-R*.13);c.lineTo(cx,cy+R*.13);c.stroke();
      c.beginPath();c.moveTo(cx-R*.13,cy);c.lineTo(cx+R*.13,cy);c.stroke();
    }
    // Blush marks
    for(const s of[-1,1]){c.fillStyle=`hsla(${(hue+90)%360},78%,76%,.2)`;c.beginPath();c.ellipse(R*.44,s*R*.38,R*.13,R*.076,0.3*s,0,Math.PI*2);c.fill();}
    // Big sparkling rainbow eyes
    for(const s of[-1,1]){
      c.fillStyle='#fff';c.beginPath();c.ellipse(R*.27,s*R*.24,R*.182,R*.138,0,0,Math.PI*2);c.fill();
      const eg=c.createRadialGradient(R*.27,s*R*.24,0,R*.27,s*R*.24,R*.14);
      eg.addColorStop(0,`hsl(${hue},100%,92%)`);eg.addColorStop(0.38,`hsl(${(hue+62)%360},92%,66%)`);eg.addColorStop(0.76,`hsl(${(hue+125)%360},86%,52%)`);eg.addColorStop(1,'rgba(80,0,160,0.4)');
      c.fillStyle=eg;c.beginPath();c.ellipse(R*.27,s*R*.24,R*.132,R*.108,0,0,Math.PI*2);c.fill();
      c.fillStyle='#1a0032';c.beginPath();c.arc(R*.31,s*R*.24,R*.052,0,Math.PI*2);c.fill();
      c.fillStyle='rgba(255,255,255,.95)';c.beginPath();c.arc(R*.258,s*R*.196,R*.04,0,Math.PI*2);c.fill();
      c.fillStyle='rgba(255,255,255,.5)';c.beginPath();c.arc(R*.36,s*R*.274,R*.022,0,Math.PI*2);c.fill();
      c.strokeStyle=`hsl(${hue},82%,56%)`;c.lineWidth=1.6;c.lineCap='round';
      c.beginPath();c.moveTo(R*.14,s*R*.13);c.lineTo(R*.1,s*R*.085);c.stroke();
      c.beginPath();c.moveTo(R*.22,s*R*.115);c.lineTo(R*.2,s*R*.065);c.stroke();
      c.beginPath();c.moveTo(R*.34,s*R*.115);c.lineTo(R*.38,s*R*.065);c.stroke();
    }
    // White muzzle + smile
    c.fillStyle=fl?'#fff':`hsl(${hue},62%,90%)`;c.strokeStyle=`hsl(${hue},72%,62%)`;c.lineWidth=2;c.beginPath();c.ellipse(R*.63,0,R*.22,R*.16,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle=`hsl(${(hue+125)%360},82%,66%)`;c.beginPath();c.ellipse(R*.745,0,R*.074,R*.062,0,0,Math.PI*2);c.fill();
    c.strokeStyle=`hsl(${hue},72%,56%)`;c.lineWidth=2.5;c.lineCap='round';c.beginPath();c.arc(R*.7,R*.042,R*.115,Math.PI*1.12,Math.PI*1.88);c.stroke();
    // Orbiting rainbow sparkle ring
    for(let i=0;i<12;i++){const ra=i*Math.PI/6+t*0.042;const rr=R*(0.9+Math.sin(t*.062+i)*.065);c.fillStyle=`hsla(${(hue+i*30)%360},100%,78%,${0.28+fl2*.28})`;c.beginPath();c.arc(Math.cos(ra)*rr,Math.sin(ra)*rr,R*.032,0,Math.PI*2);c.fill();}
    // Rainbow glow
    c.save();c.shadowColor=`hsl(${hue},100%,70%)`;c.shadowBlur=20*(0.3+fl2*.7);
    c.strokeStyle=`hsla(${hue},100%,76%,${0.18+fl2*.15})`;c.lineWidth=5;c.beginPath();c.arc(0,0,R+2,0,Math.PI*2);c.stroke();c.restore();
  } else {
    // DEFAULT — Kahverengi Ayı Savaşçı
    // 1. EARS — placed at back-side of head so they clearly poke out past the body circle
    c.fillStyle=fl?'#cba':'#a07040';c.strokeStyle='#3a2010';c.lineWidth=3;
    c.beginPath();c.arc(-R*.68,-R*.78,R*.28,0,Math.PI*2);c.fill();c.stroke();c.beginPath();c.arc(-R*.68,R*.78,R*.28,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#cc8866';c.beginPath();c.arc(-R*.68,-R*.78,R*.14,0,Math.PI*2);c.fill();c.beginPath();c.arc(-R*.68,R*.78,R*.14,0,Math.PI*2);c.fill();
    // 2. Body circle
    const bg=c.createRadialGradient(-R*.1,-R*.1,0,0,0,R);bg.addColorStop(0,fl?'#fff':'#d4a574');bg.addColorStop(1,fl?'#ccc':'#8b6040');
    c.fillStyle=bg;c.strokeStyle='#3a2010';c.lineWidth=5;c.beginPath();c.arc(0,0,R,0,Math.PI*2);c.fill();c.stroke();
    // 3. Muzzle + eyes in front
    c.fillStyle=fl?'#ddd':'#c4966a';c.strokeStyle='#7a5030';c.lineWidth=2;c.beginPath();c.ellipse(R*.6,0,R*.28,R*.22,0,0,Math.PI*2);c.fill();c.stroke();
    c.fillStyle='#111';c.beginPath();c.ellipse(R*.72,0,R*.1,R*.08,0,0,Math.PI*2);c.fill();
    c.fillStyle='#fff';c.beginPath();c.arc(R*.22,-R*.22,R*.1,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.22,R*.22,R*.1,0,Math.PI*2);c.fill();
    c.fillStyle='#331a00';c.beginPath();c.arc(R*.26,-R*.22,R*.07,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.26,R*.22,R*.07,0,Math.PI*2);c.fill();
    c.fillStyle='#000';c.beginPath();c.arc(R*.29,-R*.22,R*.04,0,Math.PI*2);c.fill();c.beginPath();c.arc(R*.29,R*.22,R*.04,0,Math.PI*2);c.fill();
  }
}

// ── Arm colour utilities — module-level so no closure is created per frame ──
// _hexDimColor: darken a #rrggbb hex string by scalar `amt` (0=black, 1=same).
function _hexDimColor(hex, amt) {
  const r=parseInt(hex.slice(1,3),16), g=parseInt(hex.slice(3,5),16), b=parseInt(hex.slice(5,7),16);
  const h=(v)=>Math.round(Math.min(255,Math.max(0,v))).toString(16).padStart(2,'0');
  return '#'+h(r*amt)+h(g*amt)+h(b*amt);
}
// Cache: only recompute armDark when the skin changes (not every frame).
let _cachedArmSkin = null, _cachedArmDark = '';
function drawSkinHand(c, skin, armCol, armDark, sign) {
  if (_qualityLevel >= 2) {
    const ag = c.createRadialGradient(-4, sign * -4, 0, 0, 0, 16);
    ag.addColorStop(0, armCol); ag.addColorStop(0.55, armCol); ag.addColorStop(1, armDark);
    c.fillStyle = ag;
  } else {
    c.fillStyle = armCol;
  }
  c.strokeStyle = 'rgba(0,0,0,0.62)'; c.lineWidth = 2.2;
  c.beginPath(); c.ellipse(8, 0, 18, 13, 0.12 * sign, 0, Math.PI * 2); c.fill(); c.stroke();
  const accent = SKIN_HAND_ACCENTS[skin] || GENERATED_SKIN_STYLES[skin]?.[2] || armDark;
  c.strokeStyle = accent; c.lineWidth = 1.5; c.lineCap = 'round';
  c.beginPath(); c.arc(8, 0, 9, -1.05 + sign * 0.12, 0.35 + sign * 0.12); c.stroke();
  if (_qualityLevel >= 1) {
    c.fillStyle = 'rgba(255,255,255,0.22)';
    c.beginPath(); c.ellipse(2, -3 * sign, 7, 4, 0.2 * sign, 0, Math.PI * 2); c.fill();
  }
}

function drawPlayer() {
  ctx.save(); ctx.translate(player.x, player.y);

  // Ground shadow — PERF: cache gradient (params only change if radius changes, which is rare)
  if (_qualityLevel > 0) {
    if (!drawPlayer._shadowGrd || drawPlayer._shadowR !== player.radius) {
      const _g = ctx.createRadialGradient(player.radius*0.18, player.radius*0.52, 0, player.radius*0.1, player.radius*0.45, player.radius*0.88);
      _g.addColorStop(0, 'rgba(0,0,0,0.28)'); _g.addColorStop(1, 'rgba(0,0,0,0)');
      drawPlayer._shadowGrd = _g; drawPlayer._shadowR = player.radius;
    }
    ctx.fillStyle = drawPlayer._shadowGrd;
    ctx.beginPath(); ctx.ellipse(player.radius*0.12, player.radius*0.52, player.radius*0.88, player.radius*0.28, 0, 0, Math.PI*2); ctx.fill();
  }

  // HP bar above player — always visible
  drawHpBar(0, player.radius + 14, player.hp, player.maxHp, 64, 0, true);

  // Name + 12-sided rank badge (own player) — deferred to screen-space pass
  // PERF: pool-based push — reuse pre-allocated object instead of new {} each frame
  if (_ntPoolIdx < _NT_OBJ_POOL.length) {
    const _nto = _NT_OBJ_POOL[_ntPoolIdx++];
    _nto.wx = player.x; _nto.wy = player.y - player.radius - 32;
    _nto.name = player.name; _nto.rankId = _myRankId ?? 0;
    _nto.hpRatio = player.hp / player.maxHp; _nto.isOwn = true;
    _pendingNameTags.push(_nto);
  }

  ctx.rotate(player.angle);

  // -- Halo (above everything, before rotation effects) --
  if (playerAcc.aksesuarlar === 'a_halo') drawPlayerHalo(ctx, globalTime);
  // -- Cape (behind body) --
  if (playerAcc.aksesuarlar === 'a_cape') drawPlayerCape(ctx, globalTime);
  // -- Tail (behind body) --
  if (playerAcc.aksesuarlar === 'a_tail') drawPlayerTail(ctx, globalTime);
  // -- Wings (behind body) — drawn in local space so they always face the character's back
  if (playerAcc.kanatlar && playerAcc.kanatlar !== 'w_none') {
    drawPlayerWings(ctx, playerAcc.kanatlar, globalTime);
  }
  // -- Backpack (behind body) --
  if (playerAcc.aksesuarlar === 'a_backpack') drawPlayerBackpack(ctx);

  ctx.save();

  let swingAngle = 0;
  if (player.isAttacking && player.attackTimer > 0) {
    const prog = player.attackTimer / player.attackDuration; // 0→1 over attack duration
    if (player.weapon >= 3) {
      swingAngle = Math.sin(prog * Math.PI) * 0.2;
    } else {
      // Asymmetric swing: reach peak at PEAK_T (fast strike), return slowly after.
      // prog goes 0→1; remap squishes 0→PEAK_T to 0→1 fast, PEAK_T→1 to 1→0 slow.
      const PEAK_T = player.weapon === 2 ? 0.30 : 0.20;
      const remap = prog < PEAK_T
        ? prog / PEAK_T
        : 1.0 - (prog - PEAK_T) / (1.0 - PEAK_T);
      swingAngle = Math.sin(remap * Math.PI * 0.5) * (player.weapon === 2 ? (Math.PI / 1.2) : (Math.PI / 1.5));
    }
  }

  // Draw clean .io-style weapon swing arc (kavis cizgisi)
  if (player.isAttacking && player.weapon < 3 && player.attackTimer > 0) {
    const _swProg = player.attackTimer / (player.attackDuration || ATTACK_DUR[player.weapon] || 20);
    _drawWeaponSlashArc(ctx, _swProg, player.weapon);
  }

  ctx.rotate(swingAngle);

  // Draw weapon — skin veya tier bazlı görünüm
  if (player.weapon === 1) {
    const axeSkin = playerAcc && playerAcc.baltalar && playerAcc.baltalar !== 'ba_none' ? playerAcc.baltalar : null;
    const _axeTier = (axeSkin && axeSkin.startsWith('ba_tier_')) ? Math.max(_wepTier(_axeXP), parseInt(axeSkin.replace('ba_tier_', '')) || 0) : _wepTier(_axeXP);
    const _axeImage = _weaponSprite('axe', _axeTier);
    if (_axeImage) _drawWeaponSprite(ctx, _axeImage, 'axe');
    else if (axeSkin) drawAxeSkin(ctx, axeSkin, globalTime);
    else drawAxeByTier(ctx, _axeTier, globalTime);
  } else if (player.weapon === 2) {
    const swordSkin = playerAcc && playerAcc.kiliclar && playerAcc.kiliclar !== 'ki_none' ? playerAcc.kiliclar : null;
    const _swordTier = (swordSkin && swordSkin.startsWith('ki_tier_')) ? Math.max(_wepTier(_swordXP), parseInt(swordSkin.replace('ki_tier_', '')) || 0) : _wepTier(_swordXP);
    const _swordImage = _weaponSprite('sword', _swordTier);
    if (_swordImage) _drawWeaponSprite(ctx, _swordImage, 'sword');
    else if (swordSkin) drawSwordSkin(ctx, swordSkin, globalTime);
    else drawSwordByTier(ctx, _swordTier, globalTime);
  }

  // ── Arms (detailed — forearm + fist, skin-matched) ──
  const armCol = SKIN_ARM_COLORS[_playerSkin] || player.color;
  // Reuse cached dark shade — only recompute if skin changed
  if (armCol !== _cachedArmSkin) {
    _cachedArmSkin = armCol;
    _cachedArmDark = armCol.startsWith('#') ? _hexDimColor(armCol, 0.7) : armCol;
  }
  const armDark = _cachedArmDark;

  for (let _ai = 0; _ai < 2; _ai++) {
    const ay = _ai === 0 ? -13 : 20, sign = _ai === 0 ? -1 : 1;
    const armX = player.weapon === 2 ? 38 : 30;
    const armY = ay - (player.weapon === 2 ? 2 : 0);
    ctx.save(); ctx.translate(armX, armY);
    drawSkinHand(ctx, _playerSkin, armCol, armDark, sign);
    // Finger detail lines (quality 2 only — 3 extra stroke calls per arm)
    if (_qualityLevel >= 2) {
      ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 1.2; ctx.lineCap = 'round';
      for(const fx of [8,14,20]){ ctx.beginPath();ctx.moveTo(fx,-8);ctx.lineTo(fx,8);ctx.stroke(); }
    }
    ctx.restore();
  }
  ctx.restore();

  // Skin body — PERF: shared OC cache per skin, avoids createRadialGradient every frame
  {
    const _playerImage = !player.hitFlash ? _playerSprite(_playerSkin) : null;
    if (_playerImage) {
      _drawCenteredSprite(ctx, _playerImage, player.radius * 3.6);
    } else {
      const _lbsk = _playerSkin + '_nfl';
      let _lbEnt = _BODY_OC_CACHE.get(_lbsk);
      const _lbR = player.radius, _lbcw = (_lbR * 3.6) | 0;
      if (!_lbEnt || _lbEnt.oc.width !== _lbcw || globalTime - _lbEnt.age >= 6) {
        if (!_lbEnt || _lbEnt.oc.width !== _lbcw) { _lbEnt = { oc: createRenderCanvas(_lbcw, _lbcw), age: -99 }; _BODY_OC_CACHE.set(_lbsk, _lbEnt); }
        const _lbc = _lbEnt.oc.getContext('2d');
        _lbc.imageSmoothingEnabled = true; _lbc.imageSmoothingQuality = 'high';
        _lbc.clearRect(0, 0, _lbcw, _lbcw);
        _lbc.save(); _lbc.translate(_lbcw >> 1, _lbcw >> 1);
        drawSkinBody(_lbc, _lbR, _playerSkin, globalTime, false);
        _lbc.restore();
        _lbEnt.age = globalTime;
      }
      ctx.drawImage(_lbEnt.oc, -(_lbcw >> 1), -(_lbcw >> 1));
    }
  }

  // -- Face accessories (drawn over eyes, follows facing direction) --
  if (playerAcc.yuz && playerAcc.yuz !== 'f_none') drawPlayerFace(ctx, playerAcc.yuz);
  // -- Hat (centered above head, does not rotate with player) --
  if (playerAcc.sapkalar && playerAcc.sapkalar !== 'h_none') {
    ctx.save(); ctx.rotate(-player.angle);
    drawPlayerHat(ctx, playerAcc.sapkalar, globalTime);
    ctx.restore();
  }

  // Ensure eyes are rendered on top of any ears/parts (moved after hat/face)
  drawSkinEyesOverlay(ctx, player.radius, _playerSkin, false);

  // ── TRAP FREEZE visual — web chains drawn over player when caught ──
  if (_trapCaughtBy) {
    const t = globalTime * 0.06;
    const R = player.radius + 6;
    ctx.save();
    ctx.rotate(-player.angle); // counter-rotate so web stays world-aligned
    // Pulsing web ring
    ctx.globalAlpha = 0.65 + 0.25 * Math.sin(t * 4);
    ctx.strokeStyle = '#cc88ff';
    ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(0, 0, R, 0, Math.PI * 2); ctx.stroke();
    // 8 web strands radiating out
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2 + t;
      const midX = Math.cos(a + 0.2) * R * 0.58;
      const midY = Math.sin(a + 0.2) * R * 0.58;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(midX, midY, Math.cos(a) * R, Math.sin(a) * R);
      ctx.stroke();
    }
    // Cross lines
    ctx.lineWidth = 1.5;
    ctx.globalAlpha = 0.45;
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * R, Math.sin(a) * R);
      ctx.lineTo(Math.cos(a + Math.PI / 4) * R * 0.7, Math.sin(a + Math.PI / 4) * R * 0.7);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  // ── SPIDER WEB ROOT VISUAL (1.5s immobilization - slightly larger than player) ──
  if (player._webRootTimer > 0) {
    const t = globalTime * 0.08;
    const R = player.radius + 6;
    ctx.save();
    ctx.rotate(-player.angle);
    if (_MOB_ASSETS.spider_ag_tuzak.complete && _MOB_ASSETS.spider_ag_tuzak.naturalWidth > 0) {
      ctx.globalAlpha = 0.90;
      ctx.drawImage(_MOB_ASSETS.spider_ag_tuzak, -R, -R, R * 2, R * 2);
    }
    ctx.globalAlpha = 0.85 + 0.15 * Math.sin(t * 6);
    ctx.strokeStyle = 'rgba(255,255,255,0.95)';
    ctx.lineWidth = 2.2;
    ctx.beginPath(); ctx.arc(0, 0, R * 0.9, 0, Math.PI * 2); ctx.stroke();
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2 + t * 0.3;
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a) * R, Math.sin(a) * R); ctx.stroke();
    }
    ctx.restore();
  }

  // ── GOLD KING CROWN (Local Player Bounty Target) ──
  if (typeof _bountyId !== 'undefined' && _bountyId && _bountyId === _mySocketId) {
    const _nowMs = Date.now();
    const _bc_y = -player.radius - 38 + Math.sin(_nowMs * 0.005) * 5;
    ctx.save();
    ctx.rotate(-player.angle);
    ctx.font = '28px serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = '#ffd700';
    ctx.shadowBlur = 10;
    ctx.strokeText('👑', 0, _bc_y);
    ctx.fillText('👑', 0, _bc_y);
    ctx.shadowBlur = 0;
    ctx.restore();
  }

  ctx.restore();
}

// ─── Smooth interpolation for remote players ─────────────────────────────────
// Snapshot interpolation buffer (65ms delay) for silky-smooth, jitter-free remote player rendering
let _lastInterpTime = performance.now();
function _interpOtherPlayers() {
  const now = performance.now();
  const dt = Math.min((now - _lastInterpTime) / 1000, 0.1);
  _lastInterpTime = now;
  const wallNow = Date.now();
  const renderTime = wallNow - 65; // 65ms render delay buffer

  _otherPlayers.forEach((p) => {
    // If trapped by a trap building, keep at trapped contact position (can be pushed by players!)
    if (p._trappedBy) {
      const _trb = _buildingsMap.get(p._trappedBy) || buildings.find(b => (b._netId === p._trappedBy || b.id === p._trappedBy || b._bLid === p._trappedBy));
      if (_trb && _trb.hp > 0) {
        const destX = Number.isFinite(p._trappedX) ? p._trappedX : _trb.x;
        const destY = Number.isFinite(p._trappedY) ? p._trappedY : _trb.y;
        p.x += (destX - p.x) * Math.min(1, dt * 25);
        p.y += (destY - p.y) * Math.min(1, dt * 25);
        p.vx = 0;
        p.vy = 0;
      } else {
        p._trappedBy = null;
        p._trappedX = undefined;
        p._trappedY = undefined;
      }
    }

    // PERF: skip full interp for players far outside visible area
    const _opDx = (p._targetX !== undefined ? p._targetX : (p._sx !== undefined ? p._sx : p.x)) - player.x;
    const _opDy = (p._targetY !== undefined ? p._targetY : (p._sy !== undefined ? p._sy : p.y)) - player.y;
    if (_opDx * _opDx + _opDy * _opDy > 2800 * 2800) {
      if (p._targetX !== undefined) { p.x = p._targetX; p.y = p._targetY; }
      else if (p._sx !== undefined) { p.x = p._sx; p.y = p._sy; }
      if (p._targetAngle !== undefined) p.angle = p._targetAngle;
      return;
    }

    // Snapshot interpolation: search buffer for the two surrounding snapshots
    const snaps = p._snapshots;
    let interpolated = false;
    if (snaps && snaps.length >= 2) {
      for (let i = snaps.length - 1; i >= 1; i--) {
        const s1 = snaps[i];
        const s0 = snaps[i - 1];
        if (renderTime >= s0.t && renderTime <= s1.t) {
          const span = s1.t - s0.t;
          const ratio = span > 0 ? (renderTime - s0.t) / span : 0;
          const targetX = s0.x + (s1.x - s0.x) * ratio;
          const targetY = s0.y + (s1.y - s0.y) * ratio;

          let da = s1.a - s0.a;
          while (da > Math.PI) da -= Math.PI * 2;
          while (da < -Math.PI) da += Math.PI * 2;
          const targetAngle = s0.a + da * ratio;

          const distSq = (targetX - p.x) * (targetX - p.x) + (targetY - p.y) * (targetY - p.y);
          if (distSq > 350 * 350) {
            p.x = targetX;
            p.y = targetY;
          } else {
            // Direct smooth convergence onto interpolated trajectory
            const converge = 1 - Math.exp(-38 * dt);
            p.x += (targetX - p.x) * converge;
            p.y += (targetY - p.y) * converge;
          }
          let angDiff = targetAngle - (p.angle || 0);
          while (angDiff > Math.PI) angDiff -= Math.PI * 2;
          while (angDiff < -Math.PI) angDiff += Math.PI * 2;
          p.angle = (p.angle || 0) + angDiff * (1 - Math.exp(-32 * dt));

          interpolated = true;
          break;
        }
      }
    }

    if (!interpolated) {
      // Smooth extrapolation using actual packet velocity without wild multiplier
      const targetX = p._targetX !== undefined ? p._targetX : (p._sx !== undefined ? p._sx : p.x);
      const targetY = p._targetY !== undefined ? p._targetY : (p._sy !== undefined ? p._sy : p.y);
      const timeSincePacket = Math.min((wallNow - (p._lastPacketTime || wallNow)) / 1000, 0.08);
      const extX = targetX + (p.vx || 0) * (timeSincePacket * 2.5);
      const extY = targetY + (p.vy || 0) * (timeSincePacket * 2.5);

      const distSq = (extX - p.x) * (extX - p.x) + (extY - p.y) * (extY - p.y);
      if (distSq > 350 * 350) {
        p.x = extX;
        p.y = extY;
      } else {
        const convergeRate = 1 - Math.exp(-28 * dt);
        p.x += (extX - p.x) * convergeRate;
        p.y += (extY - p.y) * convergeRate;
      }

      const targetAng = p._targetAngle !== undefined ? p._targetAngle : (p._rawAngle !== undefined ? p._rawAngle : p.angle);
      let da = targetAng - (p.angle || 0);
      while (da > Math.PI) da -= Math.PI * 2;
      while (da < -Math.PI) da += Math.PI * 2;
      p.angle = (p.angle || 0) + da * (1 - Math.exp(-28 * dt));
    }

    // 60 FPS local attackTimer advancement for smooth weapon & arm swing animation
    if (p.isAttacking) {
      const dur = p.attackDuration || ATTACK_DUR[p.weapon] || 20;
      p.attackTimer = (p.attackTimer || 0) + _dt;
      if (p.attackTimer >= dur) {
        p.isAttacking = false;
        p.attackTimer = 0;
      }
    }
  });
}

// ============================================================
// BIOME GROUND DECORATION ASSETS & RENDER SYSTEM (Taming.io Style)
// ============================================================
const _DECOR_KEYS = [
  'cakil',
  'leke_buyuk',
  'leke_uzun',
  'ufak_cali',
  'yildiz_bitki',
  'yonca'
];

const _DECOR_SIZES = {
  cakil: { w: 38, h: 38, alpha: 0.88 },
  leke_buyuk: { w: 98, h: 98, alpha: 0.70 },
  leke_uzun: { w: 86, h: 58, alpha: 0.70 },
  ufak_cali: { w: 50, h: 50, alpha: 0.95 },
  yildiz_bitki: { w: 44, h: 44, alpha: 0.95 },
  yonca: { w: 34, h: 34, alpha: 0.92 }
};

const _BIOME_DECOR_MAP = {
  forest: 'orman',
  winter: 'buzul',
  lava: 'buyulu',
  desert: 'buyulu'
};

const _BIOME_DECOR_SPRITES = new Map();

(function _initBiomeDecorSprites() {
  const biomes = ['orman', 'buzul', 'buyulu'];
  for (const b of biomes) {
    for (const d of _DECOR_KEYS) {
      const name = `${b}_${d}`;
      const img = new Image();
      img.src = `biomedecors/${name}.png`;
      _BIOME_DECOR_SPRITES.set(name, img);
    }
  }
})();

function _decorHash(cx, cy, salt) {
  let h = (Math.imul(cx, 374761393) + Math.imul(cy, 668265263) + Math.imul(salt, 1274126177)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

function drawBiomeDecors(c, scrL, scrR, scrT, scrB) {
  if (_qualityLevel === 0) return; // Low quality mode: skip decorative ground decals for maximum FPS
  const CELL_SIZE = 270; // Optimized cell size: reduces canvas state changes & drawImage calls by ~60%
  const minCX = Math.floor(scrL / CELL_SIZE);
  const maxCX = Math.ceil(scrR / CELL_SIZE);
  const minCY = Math.floor(scrT / CELL_SIZE);
  const maxCY = Math.ceil(scrB / CELL_SIZE);

  for (let cy = minCY; cy <= maxCY; cy++) {
    for (let cx = minCX; cx <= maxCX; cx++) {
      const spawnRoll = _decorHash(cx, cy, 1);
      if (spawnRoll > 0.68) continue; // 68% cell spawn rate

      const px = cx * CELL_SIZE + (0.15 + 0.70 * _decorHash(cx, cy, 2)) * CELL_SIZE;
      const py = cy * CELL_SIZE + (0.15 + 0.70 * _decorHash(cx, cy, 3)) * CELL_SIZE;

      if (Math.abs(px) > WORLD - 60 || Math.abs(py) > WORLD - 60) continue;

      const biome = getBiome(px, py);
      const prefix = _BIOME_DECOR_MAP[biome] || 'orman';

      // Type roll: 0..0.38 -> cakil, 0.38..0.66 -> yonca, 0.66..0.80 -> ufak_cali, 0.80..0.90 -> yildiz_bitki, 0.90..1.0 -> leke
      const tRoll = _decorHash(cx, cy, 4);
      let dKey = 'cakil';
      if (tRoll < 0.38) dKey = 'cakil';
      else if (tRoll < 0.66) dKey = 'yonca';
      else if (tRoll < 0.80) dKey = 'ufak_cali';
      else if (tRoll < 0.90) dKey = 'yildiz_bitki';
      else if (tRoll < 0.95) dKey = 'leke_buyuk';
      else dKey = 'leke_uzun';

      const imgKey = `${prefix}_${dKey}`;
      const img = _BIOME_DECOR_SPRITES.get(imgKey);
      if (!img || !img.complete || img.naturalWidth === 0) continue;

      const rot = _decorHash(cx, cy, 5) * Math.PI * 2;
      const scale = 0.92 + _decorHash(cx, cy, 6) * 0.22;

      if (dKey === 'cakil') {
        // ── Pebbles: natural pair or trio cluster exactly like Taming.io ──
        const angleDir = _decorHash(cx, cy, 7) * Math.PI * 2;
        const cdx = Math.cos(angleDir), cdy = Math.sin(angleDir);
        const perpX = -cdy, perpY = cdx;

        // Primary pebble
        const s1 = 46 * scale;
        c.save();
        c.globalAlpha = 1.0;
        c.translate(px, py);
        c.rotate(rot);
        c.drawImage(img, -s1 / 2, -s1 / 2, s1, s1);
        c.restore();

        // Secondary companion pebble (~24px apart)
        const s2 = 38 * scale;
        c.save();
        c.globalAlpha = 1.0;
        c.translate(px + cdx * 26 + perpX * 6, py + cdy * 26 + perpY * 6);
        c.rotate(rot + 1.2);
        c.drawImage(img, -s2 / 2, -s2 / 2, s2, s2);
        c.restore();

        // 45% chance for a 3rd trail pebble
        if (_decorHash(cx, cy, 8) < 0.45) {
          const s3 = 32 * scale;
          c.save();
          c.globalAlpha = 1.0;
          c.translate(px + cdx * 52 + perpX * 14, py + cdy * 52 + perpY * 14);
          c.rotate(rot + 2.5);
          c.drawImage(img, -s3 / 2, -s3 / 2, s3, s3);
          c.restore();
        }
      } else if (dKey === 'yonca') {
        // ── Clover: soft organic 4-leaf watermark printed on grass ──
        const s = 100 * scale;
        c.save();
        c.globalAlpha = 0.78;
        c.translate(px, py);
        c.rotate(rot);
        c.drawImage(img, -s / 2, -s / 2, s, s);
        c.restore();
      } else if (dKey === 'ufak_cali') {
        // ── Small Bush / Plant: crisp outlined 4-leaf plant ──
        const s = 60 * scale;
        c.save();
        c.globalAlpha = 1.0;
        c.translate(px, py);
        c.rotate(rot);
        c.drawImage(img, -s / 2, -s / 2, s, s);
        c.restore();
      } else if (dKey === 'yildiz_bitki') {
        // ── Star Plant: crisp outlined floral star ──
        const s = 54 * scale;
        c.save();
        c.globalAlpha = 1.0;
        c.translate(px, py);
        c.rotate(rot);
        c.drawImage(img, -s / 2, -s / 2, s, s);
        c.restore();
      } else {
        // ── Soil Patch / Stain ──
        const sw = (dKey === 'leke_buyuk' ? 125 : 115) * scale;
        const sh = (dKey === 'leke_buyuk' ? 125 : 75) * scale;
        c.save();
        c.globalAlpha = 0.48;
        c.translate(px, py);
        c.rotate(rot);
        c.drawImage(img, -sw / 2, -sh / 2, sw, sh);
        c.restore();
      }
    }
  }
}

function drawGroundDetailsDirect(c) {
  const halfW = (canvas.width / 2) / (ZOOM || 0.78) + 120;
  const halfH = (canvas.height / 2) / (ZOOM || 0.78) + 120;
  const viewCenterX = camX + canvas.width / 2;
  const viewCenterY = camY + canvas.height / 2;
  const minX = Math.floor(viewCenterX - halfW);
  const maxX = Math.ceil(viewCenterX + halfW);
  const minY = Math.floor(viewCenterY - halfH);
  const maxY = Math.ceil(viewCenterY + halfH);

  c.save();
  // Base fallback if bgCanvas not ready
  c.fillStyle = '#4d6828';
  if (minX < -WORLD) c.fillRect(minX, minY, -WORLD - minX, maxY - minY);
  if (maxX > WORLD) c.fillRect(WORLD, minY, maxX - WORLD, maxY - minY);
  if (minY < -WORLD) c.fillRect(minX, minY, maxX - minX, -WORLD - minY);
  if (maxY > WORLD) c.fillRect(minX, WORLD, maxX - minX, maxY - WORLD);

  // ── Biome Divider Line ──
  const B = BIOME_BORDER;
  c.strokeStyle = 'rgba(0, 0, 0, 0.12)';
  c.lineWidth = 2.0;
  c.strokeRect(-B, -B, B * 2, B * 2);

  // ── Procedural Biome Decors (Clover watermarks, Pebble clusters, Star plants, Bushes) ──
  drawBiomeDecors(c, minX, maxX, minY, maxY);

  // ── Map border walls softened to a light outline ──
  c.strokeStyle = 'rgba(220, 45, 45, 0.62)';
  c.lineWidth = 24;
  c.strokeRect(-WORLD, -WORLD, WORLD * 2, WORLD * 2);
  c.restore();
}

// ============================================================
// ============================================================
// UNIFIED SOLID COLLISION RESOLUTION FOR MOBS & BOSSES
// Prevents mobs & bosses from clipping or phasing through buildings & resources.
// PERF: Throttled to every 2 frames for off-screen entities to save CPU
// ============================================================
let _collisionFrameCounter = 0;
function resolveEntitySolidCollision(e, isBoss) {
  if (!e || typeof e.x !== 'number' || typeof e.y !== 'number') return;
  
  // PERF: Skip collision for off-screen entities every other frame
  const _onScreen = Math.abs(e.x - camX) < canvas.width / ZOOM * 0.7 && Math.abs(e.y - camY) < canvas.height / ZOOM * 0.7;
  if (!_onScreen) {
    _collisionFrameCounter++;
    if (_collisionFrameCounter % 2 !== 0) return;
  }
  
  const eRad = isBoss ? (e.bossR || 78) : (e.radius || 28);
  const searchR = eRad + 120;

  // 1. Nearby Buildings (Wall, Spike, Windmill, Turret, Castle, Campfire)
  if (typeof _sgQuery === 'function') {
    const nearB = _sgQuery(e.x, e.y, searchR);
    for (let i = 0; i < nearB.length; i++) {
      const b = nearB[i];
      if (!b || b.hp <= 0) continue;
      if (b.type === 5) continue; // Boost pad allows walkover
      if (b.type === 6 && !isBoss) continue; // Traps capture normal mobs
      const bRad = _BLD_RADII[b.type] || 36;
      const minD = eRad + bRad;
      const dx = e.x - b.x, dy = e.y - b.y;
      // PERF: Fast reject using squared distance before sqrt
      const d2 = dx * dx + dy * dy;
      const minD2 = minD * minD;
      if (d2 < minD2 && d2 > 0) {
        const d = Math.sqrt(d2);
        const nx = dx / d, ny = dy / d;
        const overlap = minD - d;
        e.x += nx * overlap;
        e.y += ny * overlap;
        if (typeof e.vx === 'number' && typeof e.vy === 'number') {
          const dot = e.vx * nx + e.vy * ny;
          if (dot < 0) {
            e.vx -= dot * nx;
            e.vy -= dot * ny;
            const tx = -ny, ty = nx;
            const tdot = e.vx * tx + e.vy * ty;
            e.vx = tx * tdot * 0.98;
            e.vy = ty * tdot * 0.98;
          }
        }
      }
    }
  }

  // 2. Nearby Resources (Tree, Rock, Gold, Apple Tree, Bush, Crystal, Hive)
  if (typeof _resQuery === 'function') {
    const nearRes = _resQuery(e.x, e.y, searchR);
    for (let i = 0; i < nearRes.length; i++) {
      const res = nearRes[i];
      if (!res || res._destroyed || res.hp <= 0) continue;
      const rRad = (res.radius || 38) * (_RES_COL_FRAC[res.type] || 0.65);
      const minD = eRad + rRad;
      const dx = e.x - res.x, dy = e.y - res.y;
      // PERF: Fast reject using squared distance before sqrt
      const d2 = dx * dx + dy * dy;
      const minD2 = minD * minD;
      if (d2 < minD2 && d2 > 0) {
        const d = Math.sqrt(d2);
        const nx = dx / d, ny = dy / d;
        const overlap = minD - d;
        e.x += nx * overlap;
        e.y += ny * overlap;
        if (typeof e.vx === 'number' && typeof e.vy === 'number') {
          const dot = e.vx * nx + e.vy * ny;
          if (dot < 0) {
            e.vx -= dot * nx;
            e.vy -= dot * ny;
            const tx = -ny, ty = nx;
            const tdot = e.vx * tx + e.vy * ty;
            e.vx = tx * tdot * 0.98;
            e.vy = ty * tdot * 0.98;
          }
        }
      }
    }
  }
}

// MAIN UPDATE LOOP
// ============================================================
let _gameLoopRaf = null;
function update(timestamp = 0) {
  _gameLoopRaf = requestAnimationFrame(update);
  // Let rAF match the display (60/120/144). Skipping frames under 14ms caused stutter/flicker.
  const _elapsed = _lastFrameTs ? timestamp - _lastFrameTs : 16.67;
  if (_elapsed > 0 && _elapsed < 1) return;
  _lastFrameTs = timestamp;
  try {
  // ── Delta-time: normalize to 60fps baseline so physics is frame-rate independent ──
  _dt = (_elapsed > 0 && _elapsed < 500) ? Math.min(_elapsed * 0.06, 2.0) : 1.0;
  // Friction önbelleği — frame başına bir kez hesapla, player + her enemy yeniden kullanır
  if (_dt !== _fricFrameDt) { _fricFrame = Math.pow(0.84, _dt); _fricFrameDt = _dt; }

  // ── Build background cache on first frame (fallback if pre-build missed) ──
  // Background cache is built on idle — never stall the first frames (loading screen / hitch)
  if (!_bgReady && !_bgBuildScheduled) {
    _bgBuildScheduled = true;
    const _runBg = function(){ if (!_bgReady) _buildBgCache(); };
    if (typeof requestIdleCallback === 'function') requestIdleCallback(_runBg, { timeout: 1200 });
    else setTimeout(_runBg, 80);
  }
  // ── Post-respawn/join grace: skip costly passes to prevent stutter ─────────
  if (_respawnGrace > 0) _respawnGrace--;

  // ── Adaptive quality: sample FPS via ring buffer (no push/shift GC) ────────
  if (_elapsed > 0 && _elapsed < 2000) {
    _fpsBuf[_fpsBufHead] = 1000 / _elapsed;
    _fpsBufHead = (_fpsBufHead + 1) % _FPS_BUF_SIZE;
    if (_fpsBufCount < _FPS_BUF_SIZE) _fpsBufCount++;
  }
  if (++_fpsCheckTimer >= 8) {
    _fpsCheckTimer = 0;
    try { updateUI(); } catch(_uiErr) {}
    if (_fpsBufCount >= 8) {
      let _fpsSum = 0;
      for (let _fi = 0; _fi < _fpsBufCount; _fi++) _fpsSum += _fpsBuf[_fi];
      const avgFps = _fpsSum / _fpsBufCount;
      if (++_fpsDisplayTimer >= 3) {
        _fpsDisplayTimer = 0; _fpsDisplay = avgFps | 0;
        if (_fpsEl) {
          const _fc2 = _fpsDisplay >= 55 ? '#44ff88' : _fpsDisplay >= 35 ? '#ffdd44' : '#ff4444';
          _fpsEl.textContent = '⚡ ' + _fpsDisplay + ' FPS';
          _fpsEl.style.color = _fc2;
        }
        // ── Update detailed perf panel (every 3×8=24 frames ~2.5×/sec) ──────
        if (_perfEl && _perfEl.style.display !== 'none' && window._perf) {
          const _p = window._perf;
          const _fms = _p.frameMs;
          const _tgt = 16.7;
          function _bar(ms, maxMs) {
            const pct = Math.min(ms / maxMs, 1);
            const bars = Math.round(pct * 10);
            const col = pct > 0.6 ? '#ff5555' : pct > 0.3 ? '#ffdd44' : '#44ff88';
            return `<span style="color:${col}">${'█'.repeat(bars)}${'░'.repeat(10-bars)}</span> <span style="color:#fff">${ms.toFixed(1)}ms</span>`;
          }
          function _colorMs(ms) { return ms > 10 ? '#ff5555' : ms > 5 ? '#ffdd44' : '#aaffaa'; }
          function _colorFps(f) { return f >= 55 ? '#44ff88' : f >= 30 ? '#ffdd44' : '#ff5555'; }
          const _memStr = (performance.memory) ? `<br><span style="color:#aaa">🧠 Bellek:</span> <span style="color:#88ccff">${(performance.memory.usedJSHeapSize/1048576)|0}MB / ${(performance.memory.jsHeapSizeLimit/1048576)|0}MB</span>` : '';
          const _qNames = ['🔴 Düşük (0)', '🟡 Orta (1)', '🟢 Yüksek (2)'];
          const _budgetPct = (_fms / _tgt * 100)|0;
          const _budgetCol = _budgetPct > 120 ? '#ff5555' : _budgetPct > 80 ? '#ffdd44' : '#44ff88';
          // Top bottleneck
          const _phases = [['Kamp/Boss', _p.tCamps], ['Telegraph', _p.tTelegraph], ['Zemin', _p.tGround], ['Oyuncular', _p.tPlayers], ['Render Top.', _p.renderMs]];
          _phases.sort((a,b)=>b[1]-a[1]);
          const _top = _phases[0];
          _perfEl.innerHTML =
            `<div style="color:#fff;font-weight:bold;border-bottom:1px solid #444;padding-bottom:4px;margin-bottom:6px;">📊 PERFORMANS PANELİ <span style="font-size:9px;color:#888;">(FPS'e tıkla kapat)</span></div>` +
            `<span style="color:#aaa">⚡ FPS:</span> <span style="color:${_colorFps(_fpsDisplay)};font-weight:bold">${_fpsDisplay}</span>  <span style="color:#aaa">Kare:</span> <span style="color:${_colorMs(_fms)}">${_fms}ms</span>  <span style="color:${_budgetCol}">(hedef 16ms = ${_budgetPct}%)</span><br>` +
            `<span style="color:#aaa">🎮 Kalite:</span> <span style="color:#fff">${_qNames[Math.min(_p.quality,2)]}</span><br>` +
            `<br><span style="color:#ffcc44;font-weight:bold">RENDER FAZLARI</span><br>` +
            `<span style="color:#aaa">🗺️ Kamp/Boss:</span> ${_bar(_p.tCamps, 16)}<br>` +
            `<span style="color:#aaa">⚔️ Telegraph: </span> ${_bar(_p.tTelegraph, 16)}<br>` +
            `<span style="color:#aaa">🌿 Zemin:     </span> ${_bar(_p.tGround, 16)}<br>` +
            `<span style="color:#aaa">👥 Oyuncular:</span> ${_bar(_p.tPlayers, 16)}<br>` +
            `<span style="color:#aaa">🖼️ Toplam:   </span> ${_bar(_p.renderMs, 33)}<br>` +
            `<br><span style="color:#ffcc44;font-weight:bold">NESNE SAYILARI</span><br>` +
            `<span style="color:#aaa">👾 Düşman:</span> <span style="color:#fff">${_p.eMobs}</span>  ` +
            `<span style="color:#aaa">👥 Oyuncu:</span> <span style="color:#fff">${_p.ePlayers}</span>  ` +
            `<span style="color:#aaa">🏗️ Bina:</span> <span style="color:#fff">${_p.eBuildings}</span><br>` +
            `<span style="color:#aaa">💥 Parçacık:</span> <span style="color:#fff">${_p.eParticles}</span>  ` +
            `<span style="color:#aaa">🏹 Ok/Proj:</span> <span style="color:#fff">${_p.eProjectiles}</span>  ` +
            `<span style="color:#aaa">📡 Telg:</span> <span style="color:#fff">${_p.eTelegraphs}</span><br>` +
            `<br><span style="color:#ffcc44;font-weight:bold">AĞIR İŞLEMLER</span><br>` +
            `<span style="color:#aaa">🔄 OC Yeniden Oluşturma:</span> <span style="color:${_p.ocRebuild>3?'#ff5555':_p.ocRebuild>0?'#ffdd44':'#44ff88'}">${_p.ocRebuild}/kare</span><br>` +
            `<span style="color:#aaa">🔴 En Yavaş Faz:</span> <span style="color:#ff9944">${_top[0]} (${_top[1].toFixed(1)}ms)</span>` +
            _memStr;
        }
      }
      // Adaptive quality with hysteresis — oscillating 0/1/2 made shadows pop in/out (flicker)
      const _qNow = (typeof timestamp === 'number' && timestamp) ? timestamp : performance.now();
      if (_qNow >= _qualityHoldUntil) {
        if (avgFps < 24 && _qualityLevel > 0) {
          _qualityLevel--;
          _qualityHoldUntil = _qNow + 5000;
        } else if (avgFps >= 60 && _qualityLevel < 2) {
          _qualityLevel++;
          _qualityHoldUntil = _qNow + 7000;
        }
      }
    }
  }

  // ── Deferred blood burst: process one frame at a time ──────────────────────
  if(window._deferBlood&&window._deferBlood.length>0){
    for(var _dbIdx=window._deferBlood.length-1;_dbIdx>=0;_dbIdx--){
      var _dbE=window._deferBlood[_dbIdx];
      if(--_dbE.d<=0){spawnBlood(_dbE.x,_dbE.y,_dbE.n);window._deferBlood[_dbIdx]=window._deferBlood[window._deferBlood.length-1];window._deferBlood.pop();}
    }
  }
  _nowMs = Date.now();
  const now = _nowMs;
  globalTime++;
  _pendingNameTags.length = 0;
  _ntPoolIdx = 0;
  // ── Frame-level shadow flags (cheaper to compare once than on each draw call) ──
  _shadowOk = _qualityLevel >= 1;
  _glowOk   = _qualityLevel >= 2;
  // dayTime donduruldu — gece sistemi kapalı

  // Hareket izi kaydı — pre-allocated objects recycled to avoid per-frame GC
  if (playerAcc && playerAcc.izler && playerAcc.izler !== 'iz_none') {
    const _trailMax = _qualityLevel === 0 ? 6 : _qualityLevel === 1 ? 10 : 14;
    let _tObj;
    if (_playerMoveTrail.length >= _trailMax) {
      _tObj = _playerMoveTrail.shift(); // evict oldest and reuse its object (zero alloc)
    } else {
      _tObj = _TRAIL_OBJ_POOL[_playerMoveTrail.length]; // pre-pool, no new {}
    }
    _tObj.x = player.x; _tObj.y = player.y;
    _tObj.r1 = Math.random(); _tObj.r2 = Math.random(); _tObj.r3 = Math.random();
    _playerMoveTrail.push(_tObj);
  } else if (_playerMoveTrail.length > 0) {
    _playerMoveTrail.length = 0; // clear without reallocating array
  }

  updateShake();
  // Auto-close build upgrade panel if building is dead or player walked too far away
  if (_bup_building) {
    const _bupD = Math.hypot(player.x - _bup_building.x, player.y - _bup_building.y);
    if (_bup_building.hp <= 0 || _bupD > 290) hideBuildUpgradePanel();
  }
  updateParticles();
  updateRain();
  // Auto-eat apple at critical HP
  if(_autoEatEnabled && player.hp < player.maxHp * 0.18 && player.apples > 0 && globalTime - _lastAutoEat > 180){
    _lastAutoEat = globalTime;
    player.apples--; player.hp = Math.min(player.maxHp, player.hp + 20);
    if (_connected && _socket) _socket.emit('eat_apple'); // server applies authoritative heal
    updateHpBar(); updateUI();
    floatingTexts.push({x:player.x,y:player.y-55,text:'🍎 OTO-YE +20 HP',alpha:1,life:50,color:'#88ff44'});
  }
  updateArrows();
  updateEnemyProjectiles();
  updateArmorDrops();
  playerBiome = getBiome(player.x, player.y);
  if (_shadowOk) updateAmbientParticles();
  if (globalTime % (_qualityLevel === 0 ? 10 : 4) === 0) updateCampfires();
  _interpOtherPlayers();
  let speedMult = player.speedBonus || 1;

  // Update HP bar every frame (HP changes from enemy hits / healing)
  updateHpBar();

  // dt-aware momentum decay — önbelleklenmiş değer (frame başında bir kez hesaplandı)
  const _momFric = _fricFrame;
  player.momX *= _momFric; player.momY *= _momFric;

  // ---- Saldırı döngüsü (Moomoo.io tarzı: anında vuruş + akıcı ileri-geri zincirleme döngüsü) ----
  if (!player.isAttacking && (_attackPending || _attackQueued)) {
    player.isAttacking = true;
    player.attackTimer = 1;
    _attackQueued = false;
    _swingId++;
    if (player.weapon < 3) {
      checkHits();     // Tıklama anında gecikmesiz vuruş kaydı
      _checkPvpHits(); // Anında yerel PvP tahmin vuruşu
      _mpSwing();      // Sunucuya anında swing bildirimi
    }
  }
  if (player.isAttacking) {
    const dur = player.attackDuration || ATTACK_DUR[player.weapon] || 20;
    player.attackTimer += _dt * (1 / (player.atkSpdBonus || 1));

    // Full swing cycle completes when attackTimer reaches duration (swung out and returned to hand)
    if (player.attackTimer >= dur) {
      if (_attackPending || _attackQueued) {
        // Kesintisiz şekilde bir sonraki savurmaya bağlanır (üst üste tıklama veya basılı tutma)
        player.attackTimer = 1;
        _attackQueued = false;
        _swingId++;
        if (player.weapon < 3) {
          checkHits();     // Zincirleme savurmada anında vuruş
          _checkPvpHits();
          _mpSwing();
        }
      } else {
        player.isAttacking = false;
        player.attackTimer = 0;
      }
    }
  } else {
    player.attackTimer = 0;
  }
  _wasAttacking = player.isAttacking;

  // Buildings
  for (let i = buildings.length - 1; i >= 0; i--) {
    const b = buildings[i];
    b.life++;
    if (b.hitTimer > 0) b.hitTimer--;
    if ((b._hpBarVisibleUntil || 0) > 0 && b._hpBarVisibleUntil <= globalTime) b._hpBarVisibleUntil = 0;
    if (b.hitTimer > 0) b._hpBarVisibleUntil = Math.max(b._hpBarVisibleUntil || 0, globalTime + 120);
    const dx = player.x - b.x, dy = player.y - b.y;
    const distSq = dx * dx + dy * dy;

    if (b.type === 4 && b.life % 180 === 0 && (b._ownerId === _mySocketId || (!b._ownerId && !b._remote))) {
      const _wTier = _getTier(b);
      const _wGold  = [1,1,2,3,4,6][_wTier] || 1;
      const _wScore = [10,20,40,80,150,300][_wTier] || 10;
      player.gold += _wGold; player.score = (player.score||0) + _wScore; updateUI();
    }
    if (b.type === 5) {
      // Entry zone: 80px — Exit zone: 96px (hysteresis prevents boundary flickering)
      const _boostIn  = distSq < 6400;  // 80×80
      const _boostOut = distSq > 9216;  // 96×96
      if (_boostIn) {
        if (!b._playerInBoost) {
          b._playerInBoost = true;
          // ── Tier-based impulse ──────────────────────────────────────────────
          const _spd = [28, 38, 50, 64, 82, 105][_getTier(b)] || 28;
          // Boost direction: use building angle — guard against NaN/undefined which would corrupt momX/momY
          const _ba = Number.isFinite(b.angle) ? b.angle : 0;
          const _bx = Math.cos(_ba) * _spd, _by = Math.sin(_ba) * _spd;
          player.momX = (Number.isFinite(player.momX) ? player.momX : 0) + _bx;
          player.momY = (Number.isFinite(player.momY) ? player.momY : 0) + _by;
          // ── Momentum cap: prevent stacking from multiple pads ──────────────
          const _momMag = Math.hypot(player.momX, player.momY);
          if (_momMag > 105) {
            const _scale = 105 / _momMag;
            player.momX *= _scale; player.momY *= _scale;
          }
          // ── Time-based reconciliation exception so server snap can't cancel boost ──
          player._boostUntil = Date.now() + 1500;
          playSound(480 + Math.random()*80, 0.10, 'triangle', 0.18);
        }
      } else if (_boostOut) {
        b._playerInBoost = false;
      }
    }
    // Turret: find nearest enemy OR other player and shoot
    if (b.type === 7) {
      if (b._shotTimer === undefined) b._shotTimer = 0;
      if (b._barrelAngle === undefined) b._barrelAngle = 0;
      if (b._shotTimer > 0) b._shotTimer--;
      const _tTier = _getTier(b);
      const TURRET_RANGE    = _TURRET_RANGES[_tTier]    || 340;
      const TURRET_COOLDOWN = _TURRET_COOLDOWNS[_tTier] || 70;
      let nearest = null, nearestDist = TURRET_RANGE, nearestType = 'enemy', _nearestId = null;

      // Only process turret logic for our own buildings (remote turrets run on owner's client)
      if (!b._remote) {
      // PERF: Cache target for 8 frames — avoids O(N_enemies × N_turrets) scan every frame.
      if (b._tgtTick === undefined) b._tgtTick = 0;
      if (--b._tgtTick <= 0) {
        b._tgtTick = 8;
        let _scanNearest = null, _scanNearestDist = TURRET_RANGE, _scanNearestType = 'enemy', _scanNearestId = null;
        // Check enemies — squared range for fast rejection
        const _tRangeSq = TURRET_RANGE * TURRET_RANGE;
        for (const e2 of enemies) {
          const _edx = e2.x - b.x, _edy = e2.y - b.y;
          const ed2 = _edx * _edx + _edy * _edy;
          if (ed2 < _tRangeSq) {
            const ed = Math.sqrt(ed2);
            if (ed < _scanNearestDist) { _scanNearestDist = ed; _scanNearest = e2; _scanNearestType = 'enemy'; _scanNearestId = null; }
          }
        }
        // Check camp bosses
        if (typeof CAMPS !== 'undefined' && typeof bossState !== 'undefined') {
          for (let _ci = 0; _ci < CAMPS.length; _ci++) {
            const _cp = CAMPS[_ci];
            const _bs = bossState[_cp.id];
            if (!_bs || !_bs.alive || _bs.hp <= 0) continue;
            const _bdx = _bs.x - b.x, _bdy = _bs.y - b.y;
            const _bd2 = _bdx * _bdx + _bdy * _bdy;
            const _bMaxD = TURRET_RANGE + (_cp.bossR || 50);
            if (_bd2 < _bMaxD * _bMaxD) {
              const _bd = Math.sqrt(_bd2);
              if (_bd < _scanNearestDist) {
                _scanNearestDist = _bd;
                _scanNearest = _bs;
                _scanNearestType = 'boss';
                _scanNearestId = _cp.id;
              }
            }
          }
        }
        // Check other online players (PvP turret targeting)
        if (_connected) {
          _otherPlayers.forEach((op, opId) => {
            if (!op || (op.hp ?? 100) <= 0) return;
            const _opdx = op.x - b.x, _opdy = op.y - b.y;
            const _opd2 = _opdx * _opdx + _opdy * _opdy;
            if (_opd2 < _scanNearestDist * _scanNearestDist) {
              const opd = Math.sqrt(_opd2);
              _scanNearestDist = opd; _scanNearest = op; _scanNearestType = 'player'; _scanNearestId = opId;
            }
          });
        }
        b._cachedTarget = _scanNearest ? { obj: _scanNearest, type: _scanNearestType, id: _scanNearestId } : null;
      }
      if (b._cachedTarget) { nearest = b._cachedTarget.obj; nearestType = b._cachedTarget.type; _nearestId = b._cachedTarget.id; }
      } // end !b._remote

      if (nearest) {
        b._barrelAngle = Math.atan2(nearest.y - b.y, nearest.x - b.x);
        if (b._shotTimer <= 0) {
          b._shotTimer = TURRET_COOLDOWN;
          b._muzzleFlash = 8;
          const spd = 9;
          // PvP shots: different color + emit to server
          const isPvP = nearestType === 'player';
          projectiles.push({
            x: b.x + Math.cos(b._barrelAngle)*36,
            y: b.y + Math.sin(b._barrelAngle)*36,
            vx: Math.cos(b._barrelAngle)*spd,
            vy: Math.sin(b._barrelAngle)*spd,
            dmg: Math.round(22*TIER_DMG_MULS[_tTier||0]), life: 95, owner: 'turret',
            targetType: nearestType, _targetId: _nearestId,
            color: isPvP ? '#ff6600' : '#00e5ff',
            trailColor: isPvP ? 'rgba(255,100,0,0.4)' : 'rgba(0,200,255,0.4)',
            /* Pre-allocated 6-slot ring buffer trail — replaces unshift({x,y})/pop() */
            _trail:[{x:0,y:0},{x:0,y:0},{x:0,y:0},{x:0,y:0},{x:0,y:0},{x:0,y:0}],_tH:0,_tN:0
          });
        }
      }
    }
    if (b.hp <= 0) {
      const _bIsOwn = b._ownerId === _mySocketId || (_mySocketId === null && !b._ownerId);
      floatingTexts.push({ x: b.x, y: b.y, text: '💥 Yıkıldı!', alpha: 1, life: 45, color: '#ff8800' });
      if (_bIsOwn) {
        floatingTexts.push({ x: player.x, y: player.y - 72, text: `❗ ${BTYPE_NAMES[b.type]||'Bina'} yıkıldı!`, alpha: 1, life: 75, color: '#ff4444', big: true });
        playSound(110, 0.18, 'sawtooth', 0.35);
        shake(8);
      }
      if (b._netId) _mpBuildDestroyed(b);
      if (b._netId) _buildingsMap.delete(b._netId);
      if (b.type === 10) { const _ci=_campfires.indexOf(b); if(_ci>=0){_campfires[_ci]=_campfires[_campfires.length-1];_campfires.pop();} }
      buildings.splice(i, 1);
    }
  }

  // Projectile update
  for (let i = projectiles.length - 1; i >= 0; i--) {
    const p = projectiles[i];
    /* Ring buffer write — no unshift O(N), no new {}, no pop() */
    p._trail[p._tH].x=p.x; p._trail[p._tH].y=p.y;
    p._tH=(p._tH+1)%6; if(p._tN<6)p._tN++;
    p.x += p.vx; p.y += p.vy; p.life--;
    // PERF: squared distance avoids sqrt for range + hit checks
    const _ppDx = p.x - player.x, _ppDy = p.y - player.y;
    if (p.life <= 0 || _ppDx*_ppDx + _ppDy*_ppDy > 810000) { // 900²=810000
      projectiles.splice(i, 1); continue;
    }
    // Check enemy hit
    let hit = false;
    for (let j = enemies.length - 1; j >= 0; j--) {
      const e2 = enemies[j];
      const _peDx = p.x-e2.x, _peDy = p.y-e2.y, _peR = e2.radius+8;
      if (_peDx*_peDx + _peDy*_peDy < _peR*_peR) {
        e2.hitFlash = 5; e2.provoked = true;
        spawnBlood(e2.x, e2.y, 5);
        floatingTexts.push({x: e2.x, y: e2.y - 40, text: '-' + p.dmg, alpha: 1, life: 30, color: '#00e5ff'});
        if (_connected && e2._netId) {
          _socket.emit('mob_hit_req', { mobId: e2._netId, dmg: p.dmg });
        } else {
          e2.hp -= p.dmg;
          if (e2.hp <= 0) {
            const _tScoreGain = Math.round(((e2.xpReward||e2.xp||5)*0.75) + ((e2.goldReward||e2.gold||2)*3));
            player.xp += e2.xp; player.gold += e2.gold; player.kills++;
            player.score = (player.score||0) + _tScoreGain;
            spawnBlood(e2.x, e2.y, 16);
            enemies.splice(j, 1); updateUI();
          }
        }
        hit = true; break;
      }
    }
    // Check boss hit
    if (!hit && typeof CAMPS !== 'undefined' && typeof bossState !== 'undefined') {
      for (let _bci = 0; _bci < CAMPS.length; _bci++) {
        const _cp = CAMPS[_bci];
        const _bs = bossState[_cp.id];
        if (!_bs || !_bs.alive || _bs.hp <= 0) continue;
        const _bdx = p.x - _bs.x, _bdy = p.y - _bs.y;
        const _bHitR = (_cp.bossR || 50) + 16;
        if (_bdx * _bdx + _bdy * _bdy < _bHitR * _bHitR) {
          _bs.hp = Math.max(0, _bs.hp - p.dmg);
          _bs.dmgFlashFrames = 6;
          spawnBlood(_bs.x, _bs.y, 6);
          floatingTexts.push({ x: _bs.x, y: _bs.y - 45, text: '-' + p.dmg + ' ğŸ”«', alpha: 1, life: 35, color: '#00e5ff', big: true });
          playSound(280, 0.08, 'sine', 0.22);
          if (_bs.hp <= 0 && typeof _bossDied === 'function') {
            _bossDied(_cp, _bs);
          }
          hit = true;
          break;
        }
      }
    }
    // Check other player hit (turret PvP shot)
    if (!hit && p.targetType === 'player' && p._targetId && _connected && _socket) {
      const tgt = _otherPlayers.get(p._targetId);
      if (tgt && Math.hypot(p.x - tgt.x, p.y - tgt.y) < 42) {
        _socket.emit('arrow_hit', { targetId: p._targetId, dmg: p.dmg });
        spawnBlood(tgt.x, tgt.y, 6);
        floatingTexts.push({ x: tgt.x, y: tgt.y - 40, text: '-' + p.dmg + ' 🔫', alpha: 1, life: 30, color: '#ff6600' });
        hit = true;
      }
    }
    if (hit) { projectiles.splice(i, 1); }
  }

  // Enemy frictionı da aynı önbellekten alır — frame başında tek hesap.
  const _eFricFrame = _fricFrame;

  // Rebuild spatial grid at a relaxed cadence when the scene is busy.
  // Large build-heavy bases would otherwise spend a lot of CPU on every 8th frame.
  const _sgInterval = buildings.length > 60 ? 18 : 8;
  if (++_sgRebuildTimer >= _sgInterval) { _sgRebuildTimer = 0; _sgRebuild(); }

  // Enemies
  for (let i = enemies.length - 1; i >= 0; i--) {
    const e = enemies[i];

    // ── Online mode: server-authoritative mobs — dead-reckoning + lerp ──
    if (_connected && e._netId !== undefined) {
      // PERF: skip dead-reckoning for mobs far outside AOI — server won't send updates for them
      const _mFarDx = e.x - player.x, _mFarDy = e.y - player.y;
      const _mFarD2 = _mFarDx * _mFarDx + _mFarDy * _mFarDy;
      if (_mFarD2 > 3200 * 3200) {
        // Way outside AOI: just tick hitFlash and move on
        if (e.hitFlash > 0) e.hitFlash--;
        if (e.hp <= 0 && (!_connected || e._netId === undefined)) { enemies.splice(i, 1); }
        continue;
      }
      // Server velocities are measured per 100 ms tick; convert to one render frame.
      const _drScale = _dt / 6;
      e.x += (e.vx || 0) * _drScale;
      e.y += (e.vy || 0) * _drScale;
      // Soft lerp toward server-authoritative position to correct accumulated drift
      if (e._targetX !== undefined) {
        const _tdx = e._targetX - e.x, _tdy = e._targetY - e.y;
        const _tSnapR = e.radius * 6;
        if (_tdx*_tdx + _tdy*_tdy > _tSnapR*_tSnapR) {
          e.x = e._targetX; e.y = e._targetY;
        } else {
          const _mobConverge = 1 - Math.exp(-12 * Math.max(0.005, Math.min(0.1, _dt / 60)));
          e.x += _tdx * _mobConverge;
          e.y += _tdy * _mobConverge;
        }
      }
      if (e.hitFlash > 0) e.hitFlash--;
      if (e.hp <= 0 && (!_connected || e._netId === undefined)) {
        // In online mode, server controls mob removal via mob_dead! Client only splices in offline mode.
        const _eOnScreen = Math.abs(e.x - camX) < canvas.width / ZOOM * 0.7 && Math.abs(e.y - camY) < canvas.height / ZOOM * 0.7;
        if (_eOnScreen) {
          spawnBlood(e.x, e.y, _qualityLevel === 0 ? 2 : 4);
          if (_qualityLevel >= 1) spawnGoldBurst(e.x, e.y);
        }
        enemies.splice(i, 1);
        continue;
      }

      // ── Visual collision correction — only for on-screen mobs, throttled ──
      const _onScr = Math.abs(e.x - camX) < canvas.width / ZOOM * 0.65 && Math.abs(e.y - camY) < canvas.height / ZOOM * 0.65;
      // FIX: Remove quality level check for resource collision - mobs must collide with resources on all quality levels
      // PERF: Still throttle to every 2nd frame for performance
      if (false && globalTime % 2 === 0 && _onScr) {
        // Use spatial grid — only checks buildings within 120 world units (was O(N))
        var _vcNear = _sgQuery(e.x, e.y, 120);
        for (var _jvc = 0; _jvc < _vcNear.length; _jvc++) {
          const b = _vcNear[_jvc];
          const bdx = e.x - b.x, bdy = e.y - b.y;
          const bRad = _BLD_RADII[b.type] || 36;
          const minD = e.radius + bRad;
          const bd2  = bdx * bdx + bdy * bdy;
          if (bd2 < minD * minD && bd2 > 0) {
            const bd = Math.sqrt(bd2);
            e.x += (bdx / bd) * (minD - bd) * 0.7;
            e.y += (bdy / bd) * (minD - bd) * 0.7;
          }
        }
        // Resources are static world objects. Query only nearby grid cells
        // instead of scanning every node for every visible mob.
        // FIX: Run on all quality levels to prevent mobs passing through resources
        var _resNear = _resQuery(e.x, e.y, 180);
        for (let ri = 0; ri < _resNear.length; ri++) {
          const res = _resNear[ri];
          if (!res || res.hp === undefined || res.radius === undefined) continue;
          const rdx = e.x - res.x, rdy = e.y - res.y;
          const minD = e.radius + res.radius * 0.9;
          // PERF: Component-wise fast reject — skips ~97% of resources with 2 comparisons before any multiply
          if (Math.abs(rdx) > minD || Math.abs(rdy) > minD) continue;
          const rd2  = rdx * rdx + rdy * rdy;
          if (rd2 < minD * minD && rd2 > 0) {
            const rd = Math.sqrt(rd2);
            e.x += (rdx / rd) * (minD - rd) * 0.8;
            e.y += (rdy / rd) * (minD - rd) * 0.8;
          }
        }
      }
      // ── Trap capture for online mobs — must run before continue ──────────
      // Online mobs skip the offline AI block (including trap detection below).
      // We handle traps here so server-controlled mobs still get caught.
      if (e._capturedByTrap) {
        // Verify trap still alive; release if destroyed or after 3s max hold
        var _onTrapRef = _buildingsMap.get(e._capturedByTrap) || null;
        if (_onTrapRef && _onTrapRef.hp > 0 && (!e._capturedTrapTime || now - e._capturedTrapTime < 3000)) {
          e.vx = 0; e.vy = 0;
          e.x = e._capturedTrapX; e.y = e._capturedTrapY;
          e._targetX = e._capturedTrapX; e._targetY = e._capturedTrapY;
          if (e._frozenAngle !== undefined) e.angle = e._frozenAngle;
        } else {
          e._capturedByTrap = null; e._capturedTrapX = undefined; e._capturedTrapY = undefined; e._frozenAngle = undefined; e._capturedTrapTime = undefined;
        }
      } else {
        var _onTrNear = _sgQuery(e.x, e.y, 120);
        for (var _jot = 0; _jot < _onTrNear.length; _jot++) {
          var _otb = _onTrNear[_jot];
          if (_otb.type !== 6 || _otb.hp <= 0) continue;
          var _otdx = _otb.x - e.x, _otdy = _otb.y - e.y;
          var _otd2 = _otdx * _otdx + _otdy * _otdy;
          var _otMinD = e.radius + 52; // enlarged trap trigger radius
          if (_otd2 > _otMinD * _otMinD) continue;
          // First contact — capture mob at its current position
          var _otKey = _otb._netId || _otb.id;
          e._capturedByTrap = _otKey;
          e._capturedTrapX = e.x; e._capturedTrapY = e.y;
          e._capturedTrapTime = now;
          e.vx = 0; e.vy = 0;
          e._targetX = e.x; e._targetY = e.y;
          e._frozenAngle = (e.angle !== undefined ? e.angle : 0);
          playSound(220, 0.08, 'sine', 0.22);
          if (_connected && _socket && e._netId && _otb._netId) {
            _socket.emit('mob_trap_hit', { mobId: e._netId, buildingId: _otb._netId, frozenAngle: e._frozenAngle });
          }
          break;
        }
      }
      continue; // skip all offline AI below
    }

    const dx = player.x - e.x, dy = player.y - e.y;
    const dist = Math.hypot(dx, dy);

    const spd = e.speed || 0.52;
    // Every mob can keep a unique aggro profile, but no mob should start chasing from across the map.
    // We enforce a strict close-range threshold so they only engage when the player is already in their face.
    const _baseAggro = e.aggroRange || 110;
    // FIX: Reduce aggro range significantly to prevent mobs from chasing from far away
    const _effAggro = Math.min(Math.max(50, _baseAggro * 0.25), 100);
    const _aggroRetreat = _effAggro * 1.8;
    if (!e.provoked && dist < _effAggro) e.provoked = true;
    if (e.provoked && dist > _aggroRetreat) e.provoked = false;
    if (e.provoked) {
      const _chaseScale = e.speed > 1.1 ? 0.72 : 0.82;
      if (dist < _effAggro * 1.35) {
        e.vx += (dx / dist) * spd * _dt * _chaseScale;
        e.vy += (dy / dist) * spd * _dt * _chaseScale;
      }
    } else {
      // Idle wander — roam slowly when not aggroed (timer-based, not per-frame random)
      if (!e._wanderTimer || --e._wanderTimer <= 0) {
        e._wanderTimer = 180 + Math.floor(Math.random() * 240); // 3-7 sec at 60fps
        e._wanderA = Math.random() * Math.PI * 2;
      }
      // Biome boundary: steer back toward home when leaving biome
      if (e._homeBiome) {
        const _curBiome = getBiome(e.x, e.y);
        if (_curBiome !== e._homeBiome) {
          const _hx = e._homeX || 0, _hy = e._homeY || 0;
          const _hdx = _hx - e.x, _hdy = _hy - e.y;
          const _hd = Math.sqrt(_hdx*_hdx + _hdy*_hdy) || 1;
          e._wanderA = Math.atan2(_hdy, _hdx);
          e._wanderTimer = 0;
          e.vx += (_hdx/_hd) * 0.4 * _dt;
          e.vy += (_hdy/_hd) * 0.4 * _dt;
        }
      }
          resolveEntitySolidCollision(e, false);
    e.vx += Math.cos(e._wanderA) * 0.14 * _dt;
      e.vy += Math.sin(e._wanderA) * 0.14 * _dt;
    }
    // Trap capture: if mob is held in a trap, verify trap still alive then freeze
    // PERF: cache trap ref directly on enemy — avoids O(N_buildings) find() scan every frame
    if (e._capturedByTrap) {
      if (!e._capturedTrapRef || (e._capturedTrapRef._netId || e._capturedTrapRef.id) !== e._capturedByTrap) {
        e._capturedTrapRef = _buildingsMap.get(e._capturedByTrap) || null; // O(1) — was buildings.find()
      }
      var _ct = e._capturedTrapRef && e._capturedTrapRef.hp > 0 ? e._capturedTrapRef : null;
      if (_ct) { e.vx = 0; e.vy = 0; } else { e._capturedByTrap = null; e._capturedTrapRef = null; e._capturedTrapX = undefined; e._capturedTrapY = undefined; }
    }
    // Cap mob velocity so they never rubber-band or hyper-accelerate
    const _eMaxSpd = Math.min(spd * 3.2, 2.6 + spd * 1.2);
    const _eCurSpd = Math.sqrt(e.vx*e.vx + e.vy*e.vy);
    if (_eCurSpd > _eMaxSpd) { const _eSc = _eMaxSpd/_eCurSpd; e.vx *= _eSc; e.vy *= _eSc; }
    // dt-aware friction: use pre-cached value (same for all enemies this frame)
    e.vx *= _eFricFrame; e.vy *= _eFricFrame;
    e.x += e.vx * _dt; e.y += e.vy * _dt;
    resolveEntitySolidCollision(e, !!e.isBoss);
    // Pin captured mob to trap center so it can't drift
    if (e._capturedByTrap && e._capturedTrapX !== undefined) { e.x = e._capturedTrapX; e.y = e._capturedTrapY; }

    // ── Sınır dışına çıkma engeli ────────────────────────────
    const _eBound = PLAY_RADIUS - e.radius - 8;
    if (e.x < -_eBound) { e.x = -_eBound; e.vx = Math.abs(e.vx) * 0.5; e._wanderA = Math.random() * Math.PI - Math.PI/2; }
    if (e.x >  _eBound) { e.x =  _eBound; e.vx = -Math.abs(e.vx) * 0.5; e._wanderA = Math.PI/2 + Math.random() * Math.PI - Math.PI/2; }
    if (e.y < -_eBound) { e.y = -_eBound; e.vy = Math.abs(e.vy) * 0.5; e._wanderA = Math.random() * Math.PI - Math.PI/4; }
    if (e.y >  _eBound) { e.y =  _eBound; e.vy = -Math.abs(e.vy) * 0.5; e._wanderA = -Math.PI/2 + Math.random() * Math.PI - Math.PI/4; }

    // Update facing angle — use squared speed to skip sqrt for threshold check
    const _eSpd2 = e.vx * e.vx + e.vy * e.vy;
    if (_eSpd2 > 0.0025) { // 0.05² = 0.0025
      const _eTarget = Math.atan2(e.vy, e.vx);
      if (e.angle === undefined) e.angle = _eTarget;
      let _eDa = _eTarget - e.angle;
      if (_eDa > Math.PI)  _eDa -= Math.PI * 2;
      if (_eDa < -Math.PI) _eDa += Math.PI * 2;
      e.angle += _eDa * 0.07;
    }

    // Enemy ranged attack — only fire when the target is actually nearby, not from across the zone.
    const _rangedMin = player.radius + e.radius + 26;
    const _rangedMax = Math.min(e.rangedRange || 220, 180);
    if (e.ranged && e.provoked && dist > _rangedMin && dist < _rangedMax) {
      if (!e._rangedTimer) e._rangedTimer = Math.floor(Math.random() * (e.rangedCooldown || 100));
      e._rangedTimer--;
      if (e._rangedTimer <= 0) {
        e._rangedTimer = e.rangedCooldown || 100;
        const pa = Math.atan2(player.y - e.y, player.x - e.x);
        const spd = 3.6 + Math.random() * 0.8;
        if (enemyProjectiles.length < 30)
          enemyProjectiles.push({ x: e.x + Math.cos(pa)*(e.radius+10), y: e.y + Math.sin(pa)*(e.radius+10), vx: Math.cos(pa)*spd, vy: Math.sin(pa)*spd, dmg: e.rangedDmg || 10, life: 160, color: e.projColor || '#ff4444', r: 7 + e.radius * 0.05, trail: [{x:0,y:0},{x:0,y:0},{x:0,y:0},{x:0,y:0},{x:0,y:0},{x:0,y:0}], _tH:0, _tN:0 });
        playSound(380 + Math.random()*80, 0.05, 'sine', 0.12);
      }
    }

    // Enemy attacks player — ONLY if already provoked and in close melee range
    // Frost aura — dampen nearby enemy velocity when perk is active
    if (player._frostAura && dist < 190) {
      e.vx *= 0.62; e.vy *= 0.62;
      // PERF: on-screen check before particle spawn — avoids wasting pool slots on off-screen enemies
      if (_qualityLevel >= 1 && Math.random() < 0.04) {
        const _feHW = canvas.width / ZOOM * 0.6, _feHH = canvas.height / ZOOM * 0.6;
        if (Math.abs(e.x - camX) < _feHW && Math.abs(e.y - camY) < _feHH)
          _spawnParticle(e.x+(Math.random()-0.5)*e.radius,e.y+(Math.random()-0.5)*e.radius,(Math.random()-0.5)*1.5,Math.random()*-2-0.5,2+Math.random()*2,18,'#88ccff');
      }
    }
    const mobReach = Math.min(player.radius + e.radius + 16, 84);
    const _viewPad = Math.max(110, canvas.width / (ZOOM || 0.78) * 0.8, canvas.height / (ZOOM || 0.78) * 0.8);
    const _mobVisible = Math.abs(e.x - (camX + canvas.width / 2)) < _viewPad && Math.abs(e.y - (camY + canvas.height / 2)) < _viewPad;
    // FIX: Only attack if provoked AND in range - prevents mobs from attacking from across the map
    if (e.provoked && dist < mobReach && (_mobVisible || dist < 80)) {
      player.momX += (dx/dist) * 8; player.momY += (dy/dist) * 8; // physical push-back
      if (e.hp > 0 && !_spawnProtected && (!_connected || e._netId === undefined) && now - (e.lastHit || 0) > 1600) {
        _lastDamager = e;
        e.lastHit = now;
        e.state = 'attack';
        e.attackTimer = 0;
        const reducedDmg = Math.max(1, Math.round((e.dmg || 25) * (1 - (player.armorBonus || 0))));
        player.hp = Math.max(0, player.hp - reducedDmg);
        player.lastHitEnemyTime = now;
        shake(12);
        spawnBlood(player.x, player.y, 9);
        playSound(95 + Math.floor(Math.random()*40), 0.16, 'sawtooth', 0.3);
        triggerDmgFlash();
        floatingTexts.push({ x: player.x, y: player.y - 50, text: `-${reducedDmg} HP`, alpha: 1, life: 45, color: '#ff3333', big: true });
        if (player._thorns) { const _td=Math.round(reducedDmg*0.20); e.hp-=_td; e.hitFlash=8; floatingTexts.push({x:e.x,y:e.y-22,text:'🌑 -'+_td,alpha:1,life:28,color:'#cc44ff'}); }
        updateHpBar();
        if (player.hp <= 0 && !_isDying) { die(); break; }
      }
    }

    // Enemy vs buildings — collision push-back + damage exchange
    // Spatial grid: only buildings within 120 wu checked — O(1) instead of O(N).
    var _ebNear = _sgQuery(e.x, e.y, 120);
    for (var _jeb = _ebNear.length - 1; _jeb >= 0; _jeb--) {
      const b = _ebNear[_jeb];
      const bRad = _BLD_RADII[b.type] || 36;
      const minD = e.radius + bRad;
      const _ebdx = b.x - e.x, _ebdy = b.y - e.y;
      if (Math.abs(_ebdx) > minD + 20 || Math.abs(_ebdy) > minD + 20) continue;
      const d2 = _ebdx * _ebdx + _ebdy * _ebdy;
      const _minExt = minD + 20;
      if (d2 > _minExt * _minExt || d2 === 0) continue;
      const d = Math.sqrt(d2);

      if (d < minD + 20 && d > 0) {
        const ang = Math.atan2(e.y - b.y, e.x - b.x);

        // Spike (type 3): deals heavy spike damage to mob + push-back
        if (b.type === 3) {
          const _spikeDirX = d > 0 ? (e.x - b.x) / d : ((Math.abs(e.vx) > 0.001 || Math.abs(e.vy) > 0.001) ? e.vx / Math.hypot(e.vx, e.vy) : Math.cos(e.angle || 0));
          const _spikeDirY = d > 0 ? (e.y - b.y) / d : ((Math.abs(e.vx) > 0.001 || Math.abs(e.vy) > 0.001) ? e.vy / Math.hypot(e.vx, e.vy) : Math.sin(e.angle || 0));
          const _spikePush = Math.max(0, (minD + 18) - d) * 0.9;
          if (d < minD + 20) {
            e.x += _spikeDirX * _spikePush;
            e.y += _spikeDirY * _spikePush;
            e.vx += _spikeDirX * 9; e.vy += _spikeDirY * 9;
          }
          if (!e._lastSpikeHitTime || now - e._lastSpikeHitTime > 400) {
            e._lastSpikeHitTime = now;
            const spikeTier = b.tier || 0;
            const spikeDmg = [45, 75, 110, 160, 220, 300][spikeTier] || 45;
            e.hp = Math.max(0, e.hp - spikeDmg);
            e.hitFlash = 8;
            b.shake = 5;
            spawnBlood(e.x, e.y, 6);
            playSound(140, 0.12, 'sawtooth', 0.25);
            floatingTexts.push({ x: e.x, y: e.y - 35, text: `-${spikeDmg} 🗡️`, alpha: 1, life: 35, color: '#ffcc44', big: true });
            if (_connected && _socket && e._netId) {
              _socket.emit('mob_hit_req', { mobId: e._netId, dmg: spikeDmg });
            }
          }
        }

        // Windmill (type 4): push enemy + enemy attacks wall
        if (b.type === 4) {
          if (d < minD) {
            e.x += Math.cos(ang) * (minD - d) * 0.6;
            e.y += Math.sin(ang) * (minD - d) * 0.6;
          }
          if (now - e.lastBuildHit > 1200) {
            const wallDmg = Math.round(e.dmg * 0.8);
            b.hp -= wallDmg; b.shake = 6; b.hitTimer = 60; b._hpBarVisibleUntil = globalTime + 120;
            e.lastBuildHit = now;
            floatingTexts.push({ x: b.x, y: b.y - 40, text: '-' + wallDmg, alpha: 1, life: 28, color: '#ff8844' });
          }
        }

        // Trap (type 6): mob passes through freely — no push-back.
        // First contact: capture mob and deal burst damage.
        // FIX: Ensure trap properly captures mobs and prevents them from passing through resources
        if (b.type === 6 && !e._capturedByTrap) {
          // FIX: Increase trigger distance to ensure mobs get caught
          const _trapTriggerDist = e.radius + 70;
          if (d < _trapTriggerDist && d > 0) {
            e._capturedByTrap = b._netId || b.id;
            e._capturedTrapX = e.x; e._capturedTrapY = e.y;
            e._capturedTrapTime = now;
            e.vx = 0; e.vy = 0;
            e._frozenAngle = e.angle || 0;
            const trapTier = b.tier || 0;
            const trapDmg = [35, 60, 90, 130, 180, 250][trapTier] || 35;
            e.hp = Math.max(0, e.hp - trapDmg);
            e.hitFlash = 10;
            b.shake = 6;
            spawnBlood(e.x, e.y, 8);
            playSound(220, 0.1, 'sine', 0.22);
            floatingTexts.push({ x: e.x, y: e.y - 40, text: `-${trapDmg} 🕸️`, alpha: 1, life: 40, color: '#aa44ff', big: true });
            if (_connected && _socket && e._netId && b._netId) {
              _socket.emit('mob_trap_hit', { mobId: e._netId, buildingId: b._netId, frozenAngle: e._frozenAngle });
            }
          }
        }
        // While captured: pin mob to trap, deal DOT. Released when trap destroyed.
        if (b.type === 6 && b.hp > 0) {
          var _trapKey = b._netId || b.id;
          // FIX: Only handle if this mob is captured by THIS specific trap
          if (e._capturedByTrap === _trapKey) {
            e.vx = 0; e.vy = 0;
            e.x = e._capturedTrapX; e.y = e._capturedTrapY;
            if (e._frozenAngle !== undefined) e.angle = e._frozenAngle;
            // FIX: Add DOT damage while trapped - deal damage every 1.5 seconds
            if (!e._trapDotTimer || now - e._trapDotTimer > 1500) {
              e._trapDotTimer = now;
              const trapTier = b.tier || 0;
              const trapDotDmg = [10, 18, 28, 40, 55, 75][trapTier] || 10;
              e.hp = Math.max(0, e.hp - trapDotDmg);
              e.hitFlash = 5;
              spawnBlood(e.x, e.y, 3);
              floatingTexts.push({ x: e.x, y: e.y - 30, text: `-${trapDotDmg}`, alpha: 1, life: 25, color: '#aa44ff' });
              if (_connected && _socket && e._netId) {
                _socket.emit('mob_hit_req', { mobId: e._netId, dmg: trapDotDmg });
              }
            }
          }
        }

        // Wall (type 8): solid barrier — pushes enemy back, enemy batters it over time
        if (b.type === 8) {
          if (d < minD) {
            e.x += Math.cos(ang) * (minD - d) * 0.8;
            e.y += Math.sin(ang) * (minD - d) * 0.8;
            e.vx *= 0.5; e.vy *= 0.5;
          }
          if (now - e.lastBuildHit > 1500) {
            const wallDmg = Math.max(1, Math.round(e.dmg * 0.6));
            b.hp -= wallDmg; b.shake = 5; b.hitTimer = 60; b._hpBarVisibleUntil = globalTime + 120;
            e.lastBuildHit = now;
            floatingTexts.push({ x: b.x, y: b.y - 38, text: '-' + wallDmg, alpha: 1, life: 25, color: '#cc8866' });
          }
        }

        // Castle (type 9): thick fortification — hard to breach, big push-back
        if (b.type === 9) {
          if (d < minD) {
            e.x += Math.cos(ang) * (minD - d) * 0.9;
            e.y += Math.sin(ang) * (minD - d) * 0.9;
            e.vx *= 0.3; e.vy *= 0.3;
          }
          if (now - e.lastBuildHit > 2000) {
            const castleDmg = Math.max(1, Math.round(e.dmg * 0.4));
            b.hp -= castleDmg; b.shake = 4; b.hitTimer = 60; b._hpBarVisibleUntil = globalTime + 120;
            e.lastBuildHit = now;
            floatingTexts.push({ x: b.x, y: b.y - 42, text: '-' + castleDmg, alpha: 1, life: 25, color: '#aa9966' });
          }
        }
      }
    }

    // Mob vs kaynaklar — spatial grid ile yakın kaynaklar בלבד.
    // Önceki tam resources taraması mob yoğunluğunda O(mobs × resources)
    // maliyeti oluşturuyordu; bu yol yalnızca komşu hücreleri ziyaret eder.
    if (!e.lastResHit) e.lastResHit = 0;
    const _mobResNear = _resQuery(e.x, e.y, 180);
    for (let ri = _mobResNear.length - 1; ri >= 0; ri--) {
      const res = _mobResNear[ri];
      if (!res || res._destroyed || res.hp === undefined || res.radius === undefined) continue;
      const _rrdx = e.x - res.x, _rrdy = e.y - res.y;
      const rMin = e.radius + res.radius * 0.96;
      // PERF: Component-wise fast reject replaces Manhattan sum + hypot — skips ~97% resources with 2 comparisons
      if (Math.abs(_rrdx) > rMin || Math.abs(_rrdy) > rMin) continue;
      const _rrd2 = _rrdx * _rrdx + _rrdy * _rrdy;
      if (_rrd2 >= rMin * rMin || _rrd2 === 0) continue;
      {
        const rd = Math.sqrt(_rrd2);
        const nx = _rrdx / rd, ny = _rrdy / rd; // unit vector: mob away from resource (no atan2/cos/sin)
        // Mob'u dışarı it — tam itme, kaynak içine girme tamamen engellenir
        const push = (rMin - rd) * 0.90;
        e.x += nx * push;
        e.y += ny * push;
        e.vx = e.vx * 0.5 + nx * 2.5;
        e.vy = e.vy * 0.5 + ny * 2.5;
        // Kaynağa hasar ver (1.2 saniyede bir)
        if (now - e.lastResHit > 1200) {
          const resDmg = Math.max(1, Math.round(e.dmg * 0.3));
          res.shake = 5;
          e.lastResHit = now;
          // Server-authoritative: notify server so all players see mob-caused resource damage
          if (_connected && _socket && res._netIdx !== undefined && res._netIdx >= 0) {
            _socket.emit('res_hit', { idx: res._netIdx, dmg: resDmg });
          }
        }
      }
    }

    if (e.hp <= 0) {
      if (_connected) {
        // Online: server handles kill rewards — just remove the mob visually
        spawnBlood(e.x, e.y, 12); spawnGoldBurst(e.x, e.y);
        enemies.splice(i, 1); continue;
      }
      // Offline: handle kill locally
      const xpGain = e.xpReward || 22; const goldDrop = e.goldReward || 4;
      const _loopScoreGain = Math.round(xpGain * 0.75 + goldDrop * 3);
      player.xp += xpGain; player.kills++;
      player.score = (player.score||0) + _loopScoreGain;
      updateUI(); updateXP();
      spawnBlood(e.x, e.y, 12); spawnGoldBurst(e.x, e.y);
      recordKill(); spawnLoot(e.x, e.y, goldDrop);
      enemies.splice(i, 1);
    }
  }

  // Compact destroyed resources once per simulation frame instead of splicing
  // from the middle of the array during every mob collision.
  for (let _rci = resources.length - 1; _rci >= 0; _rci--) {
    if (resources[_rci] && resources[_rci]._destroyed && !_connected) {
      _removeResourceFromGrid(resources[_rci]);
      resources.splice(_rci, 1);
    }
  }

  // ---- Mob-mob çarpışma fiziği: üst üste yığılmayı önler ----
  // PERF: More aggressive throttling — quality 0: every 5th frame, quality 1: every 3rd, quality 2: every 2nd.
  // Squared distance pre-check avoids sqrt when mobs are clearly far apart.
  const _mobColOk = !_connected && (_qualityLevel === 0 ? (globalTime % 5 === 0) : _qualityLevel === 1 ? (globalTime % 3 === 0) : (globalTime % 2 === 0));
  if (_mobColOk)
  for (let i = 0; i < enemies.length; i++) {
    for (let j = i + 1; j < enemies.length; j++) {
      const a = enemies[i], b = enemies[j];
      const ddx = b.x - a.x, ddy = b.y - a.y;
      const minD = a.radius + b.radius + 4;
      // PERF: squared-distance fast early exit — avoids Math.sqrt for distant pairs
      const dd2 = ddx * ddx + ddy * ddy;
      if (dd2 >= minD * minD) continue;
      const dd = Math.sqrt(dd2) || 0.01;
      // Online mobs: server is authoritative — skip client-side separation entirely
      // (fighting server positions causes jitter; server already separates mobs)
      if (_connected && a._netId !== undefined && b._netId !== undefined) continue;
      const _isOnline = _connected && (a._netId !== undefined || b._netId !== undefined);
      const f = (minD - dd) * (_isOnline ? 0.18 : 0.58) / dd;
      const px = ddx * f, py = ddy * f;
      // Kütleye göre it (büyük mob daha az yer değiştirir)
      const totR = a.radius + b.radius;
      const wa = b.radius / totR, wb = a.radius / totR;
      a.x -= px * wa; a.y -= py * wa;
      b.x += px * wb; b.y += py * wb;
      // Hız sönümlemesi — sadece offline modda tam etki, online'da hafif
      if (!_isOnline) {
        const relVx = b.vx - a.vx, relVy = b.vy - a.vy;
        const dot = (relVx * ddx + relVy * ddy) / dd2;
        if (dot < 0) {
          const imp = dot * 0.4;
          a.vx -= imp * ddx * wb; a.vy -= imp * ddy * wb;
          b.vx += imp * ddx * wa; b.vy += imp * ddy * wa;
        }
      }
    }
  }

  // Passive HP regen — cached interval recomputed only when regenBonus changes
  if (player.regenBonus !== _cachedRegenBonus) {
    _cachedRegenBonus = player.regenBonus;
    _cachedRegenInterval = Math.round(3000 / (player.regenBonus || 1));
  }
  if (now - lastRegenTime > _cachedRegenInterval && player.hp < player.maxHp && now - player.lastHitEnemyTime > 4000) {
    player.hp = Math.min(player.maxHp, player.hp + 1);
    lastRegenTime = now;
  }

  // Loot collection
  updateLoots();

  // Treasure chests
  updateChests();

  // Ground food collection (moomoo.io style)
  updateGroundFood();

  // Spawn protection countdown
  if (_spawnProtected) {
    _spawnProtTimer--;
    _spawnProtPulse += 0.15;
    if (_spawnProtTimer <= 0) {
      _spawnProtected = false;
      floatingTexts.push({ x: player.x, y: player.y - 80, text: '🛡️ Koruma Bitti!', alpha: 1, life: 60, color: '#ff9944' });
    }
  }

  // WASD movement (desktop)
  applyWASD();

  // ── Server correction: apply accumulated drift smoothly per frame ─────
  // Each frame: move 10% toward server position, decay remainder by 90%.
  // This spreads 30Hz server corrections across ~10 frames so there's no
  // visible jerk. Without this, every self_state packet causes an 8-unit
  // position jump 30 times/second → the classic .io stutter.

  // ── TRAP LOCK: If player touches an enemy trap, IMMEDIATELY lock them into it! ──
  if (!_trapCaughtBy) {
    for (let _bi = 0, _bLen = buildings.length; _bi < _bLen; _bi++) {
      const b = buildings[_bi];
      if (b.type !== 6 || b.hp <= 0) continue;
      const isOwn = b._ownerId === _mySocketId || (!b._ownerId && !b._remote);
      if (isOwn) continue;
      if (b.ownerClanId && player.clanId && b.ownerClanId === player.clanId) continue;
      const tdx = player.x - b.x, tdy = player.y - b.y;
      const trapTriggerR = 28; // Moomoo.io style: player must actually step inside the trap
      if (tdx * tdx + tdy * tdy <= trapTriggerR * trapTriggerR) {
        const trapId = b._netId || b.id || b._bLid;
        if (_connected && _socket && b._netId && (_trapPendingId !== trapId || Date.now() >= _trapPendingUntil)) {
          _trapPendingId = trapId;
          _trapPendingUntil = Date.now() + 1200;
          _trapCaughtX = player.x;
          _trapCaughtY = player.y;
          _socket.emit('trap_touch', { victimId: _mySocketId, buildingId: b._netId });
        }
        break;
      }
    }
  }

  // ── TRAP FREEZE: if caught in a trap, freeze firmly in place (no center teleport) ──
  if (_trapCaughtBy) {
    const _ftChk = _buildingsMap.get(_trapCaughtBy) || buildings.find(b => (b._netId === _trapCaughtBy || b.id === _trapCaughtBy || b._bLid === _trapCaughtBy));
    if (!_ftChk || _ftChk.hp <= 0) {
      // Trap destroyed or removed — auto-free player client-side
      _clearTrapLock();
      playSound(320, 0.12, 'sine', 0.22);
    } else {
      if (Number.isFinite(_trapCaughtX)) { player.x = _trapCaughtX; player.y = _trapCaughtY; }
      player.vx = 0; player.vy = 0;
      player.momX = 0; player.momY = 0;
      speedMult = 0;
    }
  }

  // ── SPIDER WEB ROOT: freeze player completely for 1.5s ──
  if (player._webRootTimer > 0) {
    player._webRootTimer--;
    speedMult = 0;
    player.vx = 0; player.vy = 0;
    player.momX = 0; player.momY = 0;
  }

  // NaN guard — prevent position corruption from boost/momentum NaN
  if (!Number.isFinite(player.momX)) player.momX = 0;
  if (!Number.isFinite(player.momY)) player.momY = 0;
  // Move player — scale by _dt so 30fps and 60fps travel same world-distance per second
  player.x += ((player.vx * speedMult) + player.momX) * _dt;
  player.y += ((player.vy * speedMult) + player.momY) * _dt;

  // Smooth client-side prediction error decay (eliminates rubberbanding snapping)
  if (typeof _posErrorX === 'number' && (Math.abs(_posErrorX) > 0.05 || Math.abs(_posErrorY) > 0.05)) {
    const _errDecay = 1 - Math.exp(-15 * Math.max(0.005, Math.min(0.1, _dt / 60)));
    player.x += _posErrorX * _errDecay;
    player.y += _posErrorY * _errDecay;
    _posErrorX *= (1 - _errDecay);
    _posErrorY *= (1 - _errDecay);
  }
  const _margin = player.radius + 10;
  const _bound = PLAY_RADIUS - _margin;
  if (player.x < -_bound) { player.x = -_bound; player.momX = 0; }
  if (player.x >  _bound) { player.x =  _bound; player.momX = 0; }
  if (player.y < -_bound) { player.y = -_bound; player.momY = 0; }
  if (player.y >  _bound) { player.y =  _bound; player.momY = 0; }

  // ── GELİŞMİŞ ÇARPIŞMA SİSTEMİ (v2) ──────────────────────────────────────
  // BİNALAR ÖNCE — en kritik katı cisimler pool dolmadan eklenir
  _solidCount = 0;
  for (let _bi = 0, _bLen = buildings.length; _bi < _bLen; _bi++) {
    const b = buildings[_bi];
    if (_BLD_RADII[b.type] === undefined || b.hp <= 0) continue;
    if (b.type === 5 || b.type === 6) continue; // Boost pads & bear traps have no solid pushout collision
    if (Math.abs(b.x - player.x) > _P_COL_R || Math.abs(b.y - player.y) > _P_COL_R) continue;
    if (_trapCaughtBy && (b._netId === _trapCaughtBy || b.id === _trapCaughtBy)) continue;
    if (_solidCount >= _SOLID_POOL.length) break;
    const _s = _SOLID_POOL[_solidCount++];
    _s.x = b.x; _s.y = b.y; _s.rad = _BLD_RADII[b.type];
    _s.type = b.type; _s.tier = b.tier || 0; _s.ownerId = b._ownerId; _s.netId = b._netId || b.id; _s.ownerClanId = b.ownerClanId;
  }
  // Kaynaklar sonra — yalnızca oyuncunun komşu grid hücrelerini sorgula.
  // Tam resources taraması her karede gereksiz O(N) maliyet oluşturuyordu.
  const _playerResNear = _resQuery(player.x, player.y, _P_COL_R);
  for (let _ri = 0, _rLen = _playerResNear.length; _ri < _rLen; _ri++) {
    const r = _playerResNear[_ri];
    if (r._destroyed) continue;
    if (_solidCount >= _SOLID_POOL.length) break;
    const _s = _SOLID_POOL[_solidCount++];
    _s.x = r.x; _s.y = r.y; _s.rad = (r.radius || 40) * (_RES_COL_FRAC[r.type] || 0.60);
    _s.type = 0; _s.tier = 0; _s.ownerId = null; _s.netId = null; _s.ownerClanId = null;
  }

  // 5 geçişli tam push — her geçiş overlap'i tam sıfırlar, içinden geçişi engeller
  for (let _pass = 0; _pass < 5; _pass++) {
    for (let _si = 0; _si < _solidCount; _si++) {
      const obj = _SOLID_POOL[_si];
      const dx = player.x - obj.x, dy = player.y - obj.y;
      const dist2 = dx * dx + dy * dy;
      const minD = player.radius + obj.rad;
      if (dist2 >= minD * minD || dist2 === 0) continue;
      const dist = Math.sqrt(dist2);
      const overlap = minD - dist;
      const nx = dx / dist, ny = dy / dist;
      // Tam push — overlap'i tamamen sıfırla
      player.x += nx * overlap;
      player.y += ny * overlap;
      if (_pass === 0) {
        // Bina yüzeyine dik hız bileşenini kes
        const dot = player.vx * nx + player.vy * ny;
        if (dot < 0) { player.vx -= dot * nx; player.vy -= dot * ny; }
        // Momentum: dik bileşeni durdur, teğet kayma yüzde 85 korunur
        const mDot = player.momX * nx + player.momY * ny;
        if (mDot < 0) { player.momX -= mDot * nx * 0.85; player.momY -= mDot * ny * 0.85; }

        // Spike (Kazık / Diken) Temas Hasarı: düşman dikenine temas eden oyuncu hasar alır
        if (obj.type === 3 && obj.ownerId && obj.ownerId !== _mySocketId && !(obj.ownerClanId && player.clanId && obj.ownerClanId === player.clanId)) {
          const _nowMs = Date.now();
          if (_nowMs - (player._lastSpikeHitTime || 0) > 320) {
            player._lastSpikeHitTime = _nowMs;
            const spikeTier = obj.tier || 0;
            const spikeDmg = Math.min(180, Math.max(20, [35, 60, 95, 140, 190, 260][spikeTier] || 45));
            player.hp = Math.max(0, player.hp - spikeDmg);
            spawnBlood(player.x, player.y, 6);
            playSound(140, 0.12, 'sawtooth', 0.28);
            floatingTexts.push({ x: player.x, y: player.y - 35, text: `-${spikeDmg} 🗡️`, alpha: 1, life: 35, color: '#ff4444', big: true });
            if (_connected && _socket && obj.netId) {
              _socket.emit('player_hit_spike', { buildingId: obj.netId, spikeOwnerId: obj.ownerId, dmg: spikeDmg });
            }
          }
        }
      }
    }
  }

  // Oyuncu ↔ Düşman çarpışması — içinden geçme engeli (karşılıklı itme)
  for (const e of enemies) {
    const dx = player.x - e.x, dy = player.y - e.y;
    // AABB erken red — Math.hypot (pahalı sqrt) sadece gerektiğinde çağrılır
    const minD = player.radius + e.radius + 2;
    if (Math.abs(dx) > minD || Math.abs(dy) > minD) continue;
    const d = Math.hypot(dx, dy) || 0.01;
    if (d < minD) {
      const nx = dx / d, ny = dy / d;
      if (_connected && e._netId !== undefined) {
        player.x += nx * (minD - d); player.y += ny * (minD - d);
      } else {
        const push = (minD - d) * 0.5;
        player.x += nx * push; player.y += ny * push;
        e.x      -= nx * push; e.y      -= ny * push;
      }
    }
  }

  // ── TRAP LOCK: keep trapped player frozen in place (no teleport to center) ─────────
  if (_trapCaughtBy) {
    const _trapB = _buildingsMap.get(_trapCaughtBy);
    if (_trapB && _trapB.hp > 0) {
      if (_trapCaughtX !== undefined) { player.x = _trapCaughtX; player.y = _trapCaughtY; }
      player.vx = 0; player.vy = 0; player.momX = 0; player.momY = 0;
    } else {
      _clearTrapLock();
    }
  }

  // Oyuncu ↔ Diğer oyuncular çarpışması — içinden geçme engeli
  // Server zaten pozisyonları düzeltiyor; burada client-side öngörü olarak da uygula
  // PERF: throttle collision to every 2 frames when 4+ players present (barely noticeable at 60fps)
  if (_connected && (_otherPlayers.size < 4 || globalTime % 2 === 0)) {
    _otherPlayers.forEach((p, opId) => {
      if (!p || typeof p.x !== 'number' || typeof p.y !== 'number' || isNaN(p.x) || isNaN(p.y)) return;
      const dx = player.x - p.x, dy = player.y - p.y;
      const d = Math.hypot(dx, dy) || 0.01;
      const minD = (player.radius || 34) + (player.radius || 34) + 4;
      if (d < minD) {
        const nx = dx / d, ny = dy / d;
        const overlap = minD - d;

        if (p._trappedBy) {
          // Trap owner / moving player pushes trapped victim (slow, smooth, Moomoo.io style)
          const pushSpeed = Math.min(overlap * 0.35, 2.0);
          p.x -= nx * pushSpeed;
          p.y -= ny * pushSpeed;
          p._trappedX = p.x;
          p._trappedY = p.y;
          // Player slides around the victim without getting stuck
          const dot = player.vx * nx + player.vy * ny;
          if (dot < 0) { player.vx -= dot * nx * 0.5; player.vy -= dot * ny * 0.5; }
        } else if (_trapCaughtBy) {
          // Local player is trapped: absorbs push smoothly
          player.x += nx * Math.min(overlap * 0.35, 2.0);
          player.y += ny * Math.min(overlap * 0.35, 2.0);
          _trapCaughtX = player.x;
          _trapCaughtY = player.y;
        } else {
          // Normal çift yönlü itme
          const push = overlap * 0.55;
          player.x += nx * push;
          player.y += ny * push;
          // Teğetsel kayma için momentumu koru
          const dot = player.vx * nx + player.vy * ny;
          if (dot < 0) { player.vx -= dot * nx * 0.7; player.vy -= dot * ny * 0.7; }
        }
      }
    });
  }

  // Camera — ilk kare için anında konumlandır, sonra yumuşak takip
  // Camera — ilk kare için anında konumlandır, sonra yumuşak takip
  if (!_camReady && canvas.width > 0) {
    camX = player.x - canvas.width / 2;
    camY = player.y - canvas.height / 2;
    _camReady = true;
  } else {
    const _camSpd = _onTrain ? 0.08 : 0.22;
    const _camFactor = Math.min(1, _camSpd * _dt);
    camX += (player.x - canvas.width/2 - camX) * _camFactor;
    camY += (player.y - canvas.height/2 - camY) * _camFactor;
  }

  // ── PC & Mobil Kamera Yakınlığı (mobilde oyuncudan daha uzakta, daha rahat çerçeve) ──
  const _baseTarget = _onTrain ? (_isMobile ? 0.56 : 0.62) : (_isMobile ? 0.50 : 0.48);
  const _zoomTarget = Math.max(0.46, Math.min(0.78, _baseTarget * _userZoomMultiplier));
  ZOOM += (_zoomTarget - ZOOM) * 0.065;

  // ── Kamera Sınır Kelepçesi: Ekran dışı / boşluk asla görünmez ──
  const _hvw = (canvas.width / 2) / (ZOOM || 0.78);
  const _hvh = (canvas.height / 2) / (ZOOM || 0.78);
  if (_hvw < WORLD) {
    const _maxCamX = WORLD - _hvw;
    camX = Math.max(-_maxCamX, Math.min(_maxCamX, camX));
  }
  if (_hvh < WORLD) {
    const _maxCamY = WORLD - _hvh;
    camY = Math.max(-_maxCamY, Math.min(_maxCamY, camY));
  }

  // Tren titreşimi — shakeMag üzerinden yönet (savaş shakeini geçersiz kılmaz)
  if (_onTrain && !_tSim.stopped && shakeMag < 2.2) shakeMag = 2.2;

  // ===== RENDER =====
  // Guard: skip rendering if canvas has no size yet (deferred resize pending)
  if (!canvas.width || !canvas.height) return;
  // ── Profiler: lightweight counters, entity snapshot every 30 frames ────
  window._perfOCCount = 0;
  window._perf.frameMs = _elapsed | 0;
  window._perf.quality = _qualityLevel;
  const _pRenderT0 = performance.now();
  if (globalTime % 30 === 0) {
    window._perf.ePlayers = _otherPlayers ? _otherPlayers.size : 0;
    window._perf.eMobs = enemies ? enemies.length : 0;
    window._perf.eParticles = particles ? particles.length : 0;
    window._perf.eBuildings = buildings ? buildings.length : 0;
    window._perf.eTelegraphs = bossTelegraphs ? bossTelegraphs.length : 0;
  }

  // Base fill (seen outside world border)
  ctx.fillStyle = '#1a0e08';
  // Image smoothing: low quality matches .io games and is much cheaper than 'medium'/'high'
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'low';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.save();
  try {
    ctx.translate(canvas.width / 2 + shakeX, canvas.height / 2 + shakeY);
  ctx.scale(ZOOM, ZOOM);
  ctx.translate(-canvas.width / 2, -canvas.height / 2);
  ctx.translate(-camX, -camY);
  // === BIOME BACKGROUNDS — blitted from pre-built offscreen cache ============
  // One drawImage replaces 14+ gradient creates per frame → huge CPU/GPU win.
  if (!_bgReady) {
    ctx.fillStyle = '#274b2a';
    ctx.fillRect(-WORLD, -WORLD, WORLD * 2, WORLD * 2);
  } else {
    ctx.drawImage(_bgCanvas, -WORLD, -WORLD, WORLD*2, WORLD*2);
  }

  // ── GROUND DETAILS: Direct world-space draw (Instant, perfectly synced with camera) ──
  drawGroundDetailsDirect(ctx);

  // NOTE: cave hook is called AFTER background so cave portals are not covered
  // BUG FIX: removed globalTime % 2 === 0 throttle — it caused caves AND bosses (drawn via the
  // same hook chain) to flicker at 30Hz (skipped every odd frame).
  if (_qualityLevel >= 1 && typeof window._drawCavesHook === 'function') window._drawCavesHook(ctx);

  // === BOSS ATTACK TELEGRAPHS — drawn above ground, below entities ===========
  let _tgSaveDepth = 0;
  try {
    const _tNow = Date.now();
    // Hard cap: never accumulate more than 8 telegraphs (prevents CPU spike from many bosses)
    if (bossTelegraphs.length > 8) bossTelegraphs.length = 8;
    // PERF: in-place swap-delete instead of filter() — no new array allocation per frame
    for (let _tgi = bossTelegraphs.length - 1; _tgi >= 0; _tgi--) {
      const _te = bossTelegraphs[_tgi];
      if (!_te || !Number.isFinite(_te.dur) || _tNow >= _te.startTime + _te.dur + 120) {
        bossTelegraphs[_tgi] = bossTelegraphs[bossTelegraphs.length - 1];
        bossTelegraphs.pop();
      }
    }
    for (const tg of bossTelegraphs) {
      if (!tg || !Number.isFinite(tg.dur) || tg.dur <= 0) continue;
      const _prog = Math.min(1, (_tNow - tg.startTime) / tg.dur);
      if (!Number.isFinite(_prog) || _prog >= 1) continue;
      const _pulse = _qualityLevel === 0 ? 0.75 : 0.5 + 0.5 * Math.sin(_tNow * 0.012);
      const _baseAlpha = 0.18 + _prog * 0.44;
      const _col = tg.color || '#ff4422';
      const _tgRadius = Math.max(1, Number.isFinite(tg.radius) ? tg.radius : 80);
      const _tgAngle = Number.isFinite(tg.angle) ? tg.angle : 0;
      ctx.save(); _tgSaveDepth++;
      ctx.translate(tg.x || 0, tg.y || 0);

      if (tg.skillType === 'circle') {
        ctx.beginPath(); ctx.arc(0, 0, _tgRadius, 0, Math.PI * 2);
        ctx.globalAlpha = _baseAlpha * 0.45; ctx.fillStyle = _col; ctx.fill();
        const _ringR = Math.max(1, _tgRadius * (0.35 + _prog * 0.65));
        ctx.beginPath(); ctx.arc(0, 0, _ringR, 0, Math.PI * 2);
        ctx.strokeStyle = _col; ctx.lineWidth = 3 + _pulse * 2;
        ctx.globalAlpha = 0.75 + _pulse * 0.25; ctx.stroke();
        ctx.beginPath(); ctx.arc(0, 0, _tgRadius, 0, Math.PI * 2);
        ctx.strokeStyle = _col; ctx.lineWidth = 2.5; ctx.globalAlpha = 0.9; ctx.stroke();

      } else if (tg.skillType === 'cone') {
        ctx.rotate(_tgAngle);
        const _arcRad = (tg.arc || 45) * Math.PI / 180;
        ctx.beginPath(); ctx.moveTo(0, 0);
        ctx.arc(0, 0, _tgRadius, -_arcRad, _arcRad); ctx.closePath();
        ctx.globalAlpha = _baseAlpha * 0.4; ctx.fillStyle = _col; ctx.fill();
        ctx.strokeStyle = _col; ctx.lineWidth = 2.5; ctx.globalAlpha = 0.85; ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, 0);
        ctx.lineTo(_tgRadius * _prog, 0);
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.globalAlpha = 0.5 * (1 - _prog); ctx.stroke();

      } else if (tg.skillType === 'line') {
        ctx.rotate(_tgAngle);
        const _ll = Math.max(1, tg.length || 400), _lw = Math.max(1, _tgRadius * 2);
        ctx.beginPath(); ctx.rect(0, -_lw / 2, _ll, _lw);
        ctx.globalAlpha = _baseAlpha * 0.4; ctx.fillStyle = _col; ctx.fill();
        ctx.strokeStyle = _col; ctx.lineWidth = 2.5; ctx.globalAlpha = 0.85; ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(_ll * _prog, 0);
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.globalAlpha = 0.6 * (1 - _prog); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(_ll - 16, -14); ctx.lineTo(_ll, 0); ctx.lineTo(_ll - 16, 14); ctx.closePath();
        ctx.globalAlpha = 0.85; ctx.fillStyle = _col; ctx.fill();
      }

      if (tg.skillName) {
        ctx.save();
        if (tg.skillType !== 'circle') ctx.rotate(-_tgAngle);
        const _labelY = -_tgRadius * 0.55 - 22;
        const _labelAlpha = _prog < 0.15 ? _prog / 0.15 : (1 - Math.max(0, (_prog - 0.6) / 0.4));
        ctx.globalAlpha = Math.max(0, _labelAlpha);
        ctx.font = 'bold 15px Nunito,Arial,sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.strokeStyle = '#000'; ctx.lineWidth = 3.5; ctx.strokeText(tg.skillName, 0, _labelY);
        ctx.fillStyle = _col; ctx.fillText(tg.skillName, 0, _labelY);
        ctx.restore();
      }

      // ── Per-boss VFX overlay (quality >= 2 only — expensive paths at quality 1 killed mobile FPS) ──
      if (_qualityLevel >= 2) {
        const _bType = tg.bossType || '';
        // Bear / Werewolf: radiating claw scratches
        if (_bType === 'bear' || _bType === 'werewolf') {
          ctx.save();
          for (let _ci = 0; _ci < 3; _ci++) {
            const _ca = (_ci - 1) * 0.28 + (_prog * 0.6);
            const _cr = _tgRadius * (0.3 + _prog * 0.6);
            ctx.globalAlpha = 0.7 * (1 - _prog);
            ctx.strokeStyle = '#ff7733'; ctx.lineWidth = 4 - _ci;
            ctx.beginPath(); ctx.moveTo(Math.cos(_ca)*_cr*0.15, Math.sin(_ca)*_cr*0.15);
            ctx.lineTo(Math.cos(_ca)*_cr, Math.sin(_ca)*_cr); ctx.stroke();
          }
          ctx.restore();
        }
        // Yeti / Crystal Golem: ice shard burst
        else if (_bType === 'yeti' || _bType === 'crystalgolem') {
          ctx.save();
          for (let _si = 0; _si < 6; _si++) {
            const _sa = _si * Math.PI / 3 + _prog * 0.4;
            const _sr = _tgRadius * (0.28 + _prog * 0.68);
            ctx.globalAlpha = 0.72 * (1 - _prog);
            ctx.strokeStyle = '#aaddff'; ctx.lineWidth = 2.5;
            ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(_sa)*_sr, Math.sin(_sa)*_sr); ctx.stroke();
            ctx.strokeStyle = 'rgba(180,230,255,0.55)'; ctx.lineWidth = 1.5; ctx.globalAlpha = 0.5*(1-_prog);
            const _bx = Math.cos(_sa)*_sr*0.55, _by = Math.sin(_sa)*_sr*0.55;
            ctx.beginPath(); ctx.moveTo(_bx, _by); ctx.lineTo(_bx+Math.cos(_sa+1.2)*_sr*0.22, _by+Math.sin(_sa+1.2)*_sr*0.22); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(_bx, _by); ctx.lineTo(_bx+Math.cos(_sa-1.2)*_sr*0.22, _by+Math.sin(_sa-1.2)*_sr*0.22); ctx.stroke();
          }
          ctx.restore();
        }
        // Falcon / ScorpionKing: wind/sand arcing spirals
        else if (_bType === 'falcon' || _bType === 'scorpionking') {
          ctx.save();
          ctx.strokeStyle = _col; ctx.lineWidth = 2;
          for (let _wi = 0; _wi < 3; _wi++) {
            const _wa = _wi * Math.PI * 2/3 + _prog * Math.PI;
            const _wr = _tgRadius * 0.52;
            ctx.globalAlpha = 0.48 * (1 - _prog);
            ctx.beginPath();
            ctx.arc(Math.cos(_wa)*_wr*0.3, Math.sin(_wa)*_wr*0.3, _wr*0.46, _wa, _wa + Math.PI * 1.25);
            ctx.stroke();
          }
          ctx.restore();
        }
        // NightLord / DarkGolem: void tendrils
        else if (_bType === 'nightlord' || _bType === 'darkGolem') {
          ctx.save();
          for (let _vi = 0; _vi < 6; _vi++) {
            const _va = _vi * Math.PI / 3 + _prog * 1.8;
            const _vr = _tgRadius * _prog * 0.88;
            ctx.globalAlpha = 0.65 * (1 - _prog * 0.5);
            ctx.strokeStyle = '#ee88ff'; ctx.lineWidth = 2.5;
            ctx.beginPath(); ctx.moveTo(0, 0);
            ctx.quadraticCurveTo(Math.cos(_va+0.9)*_vr*0.45, Math.sin(_va+0.9)*_vr*0.45, Math.cos(_va)*_vr, Math.sin(_va)*_vr);
            ctx.stroke();
          }
          ctx.restore();
        }
        // Swamp / SwampDrake: poison bubble ring
        else if (_bType === 'swamp' || _bType === 'swampdrake') {
          ctx.save();
          for (let _bi = 0; _bi < 7; _bi++) {
            const _ba = _bi * Math.PI * 2/7 + _tNow * 0.0012;
            const _br = _tgRadius * (0.18 + (_bi%3)*0.23 + _prog*0.12);
            const _bSz = 5 + (_bi%3)*4;
            ctx.globalAlpha = 0.58 * (1 - _prog);
            ctx.beginPath(); ctx.arc(Math.cos(_ba)*_br, Math.sin(_ba)*_br, _bSz, 0, Math.PI*2);
            ctx.strokeStyle = '#55ff22'; ctx.lineWidth = 2; ctx.stroke();
            ctx.globalAlpha = 0.3*(1-_prog);
            ctx.fillStyle = 'rgba(180,255,120,0.45)';
            ctx.beginPath(); ctx.arc(Math.cos(_ba)*_br - _bSz*0.22, Math.sin(_ba)*_br - _bSz*0.22, _bSz*0.32, 0, Math.PI*2); ctx.fill();
          }
          ctx.restore();
        }
      }

      ctx.globalAlpha = 1; ctx.restore(); _tgSaveDepth--;
    }
  } catch(e) { while(_tgSaveDepth-- > 0){try{ctx.restore();}catch(e2){}} if(typeof ctx!=='undefined'){try{ctx.globalAlpha=1;}catch(e2){}} }

  // === STATIC WORLD LAYER: subtle grid + biome borders + zone labels + walls =========
  // OC-cached — rebuilt only when camera moves >35% of viewport, or zoom/quality
  // Train/rail layer is intentionally disabled to match the cleaner Sploop.io aesthetic.

  // Biome borders, zone labels, and map walls are now baked into _gridOC above.


  // Viewport culling bounds — computed once and shared by every draw layer.
  // This must be set before ground food/loot/chests are rendered.
  const cullMargin = 400;
  const halfW = (canvas.width / 2) / (ZOOM || 0.55);
  const halfH = (canvas.height / 2) / (ZOOM || 0.55);
  const viewCx = camX + canvas.width / 2;
  const viewCy = camY + canvas.height / 2;
  const scrL = viewCx - halfW - cullMargin;
  const scrR = viewCx + halfW + cullMargin;
  const scrT = viewCy - halfH - cullMargin;
  const scrB = viewCy + halfH + cullMargin;
  _renderCullL = scrL; _renderCullR = scrR;
  _renderCullT = scrT; _renderCullB = scrB;

  // Layer 0: ground food pickups (moomoo.io style)
  drawGroundFood();

  // Layer 0b: loot drops (gold on ground)
  drawLoots();

  // Layer 0c: treasure chests
  drawChests();

  // Pre-filter & pre-categorize visible buildings — reuse module-level arrays (zero GC)
  _vbGround.length = 0; _vbSolid.length = 0; _vbTall.length = 0; _vbAll.length = 0;
  for (let _bFi = 0; _bFi < buildings.length; _bFi++) {
    const _bFb = buildings[_bFi];
    if (_bFb.x < scrL || _bFb.x > scrR || _bFb.y < scrT || _bFb.y > scrB) continue;
    _vbAll.push(_bFb);
    const _bFt = _bFb.type;
    if (_bFt === 5 || _bFt === 6) _vbGround.push(_bFb);
    else if (_bFt === 3 || _bFt === 4) _vbSolid.push(_bFb);
    else if (_bFt === 7 || _bFt === 8 || _bFt === 9 || _bFt === 10) _vbTall.push(_bFb);
  }

  // Layer 1: ground buildings (boost/trap) — with spawn animation
  for (let _bi = 0; _bi < _vbGround.length; _bi++) {
    const b = _vbGround[_bi];
    if (typeof b._spawnAnim === 'number' && b._spawnAnim < 1) {
      b._spawnAnim = Math.min(1, b._spawnAnim + 0.09);
      const s = 0.3 + b._spawnAnim * 0.7;
      ctx.save(); ctx.translate(b.x, b.y); ctx.scale(s, s); ctx.translate(-b.x, -b.y);
      drawBuilding(b); ctx.restore();
    } else { drawBuilding(b); }
  }

  // Safety reset before Layer 2 — clear any stray shadow/alpha/filter from previous layers
  ctx.globalAlpha = 1;
  ctx.shadowBlur = 0;
  ctx.shadowColor = 'transparent';
  ctx.filter = 'none';

  // Layer 2: resources (viewport culling + ultra biome-aware drawing)
  // PERF: Use spatial partitioning - only iterate visible grid cells
  const startCol = Math.floor(scrL / GRID_SIZE);
  const endCol = Math.floor(scrR / GRID_SIZE);
  const startRow = Math.floor(scrT / GRID_SIZE);
  const endRow = Math.floor(scrB / GRID_SIZE);
  
  for (let col = startCol; col <= endCol; col++) {
    for (let row = startRow; row <= endRow; row++) {
      const key = `${col}_${row}`;
      const cellResources = _resourceGrid[key];
      if (!cellResources || cellResources.length === 0) continue;
      
      for (let _resi = 0; _resi < cellResources.length; _resi++) {
        const res = cellResources[_resi];
        if (res._destroyed) continue;
        // Double-check culling for precision
        if (res.x < scrL || res.x > scrR || res.y < scrT || res.y > scrB) continue;
        let sX=0, sY=0;
        if (res.shake > 0) {
          const sa = res.shakeAng || 0;
          const sm = (res.shake / 5) * 4; // linear decay push-back, max 4px
          sX = Math.cos(sa) * sm; sY = Math.sin(sa) * sm;
          res.shake--;
        }
        const rx = res.x + sX, ry = res.y + sY;
        const biome = res.biome || 'forest';
        const R = res.radius;
        const t = globalTime;
        const _resourceImage = _resourceSprite(res.type, biome);

        if (_resourceImage) {
          ctx.save();
          ctx.translate(rx, ry);
          _drawCenteredSprite(ctx, _resourceImage, R * 2.6);
          ctx.restore();
        } else {
          const baked = _getBakedResource(res.type, biome, R);
          if (baked) {
            ctx.save();
            ctx.translate(rx, ry);
            if (res.type === 'wood' || res.type === 'apple' || res.type === 'bush') {
              ctx.rotate(Math.sin(t * 0.018 + rx * 0.003) * 0.028);
            }
            const drawScale = 0.82;
            ctx.drawImage(baked.cnv, -baked.pad * drawScale, -baked.pad * drawScale, baked.cnv.width * drawScale, baked.cnv.height * drawScale);
            ctx.restore();
          }
        }
      }
    }
  } // end resources grid loops

  // Layer 3: solid buildings (spikes/windmill) — with spawn animation
  for (let _bi = 0; _bi < _vbSolid.length; _bi++) {
    const b = _vbSolid[_bi];
    if (typeof b._spawnAnim === 'number' && b._spawnAnim < 1) {
      b._spawnAnim = Math.min(1, b._spawnAnim + 0.09);
      const s = 0.3 + b._spawnAnim * 0.7;
      ctx.save(); ctx.translate(b.x, b.y); ctx.scale(s, s); ctx.translate(-b.x, -b.y);
      drawBuilding(b); ctx.restore();
    } else { drawBuilding(b); }
  }

  // Layer 3a: snap connection bridges — skip when many buildings for performance
  if (buildings.length <= 28) drawBuildingConnections(_vbAll);

  // Layer 3b: tall/complex buildings (turret, wall, castle, campfire) — with spawn animation
  for (let _bi = 0; _bi < _vbTall.length; _bi++) {
    const b = _vbTall[_bi];
    if (typeof b._spawnAnim === 'number' && b._spawnAnim < 1) {
      b._spawnAnim = Math.min(1, b._spawnAnim + 0.09);
      const s = 0.3 + b._spawnAnim * 0.7;
      ctx.save(); ctx.translate(b.x, b.y); ctx.scale(s, s); ctx.translate(-b.x, -b.y);
      drawBuilding(b); ctx.restore();
    } else { drawBuilding(b); }
  }

  // Layer 4: building HP bars — visible to everyone when damaged; fade back after 2s when healthy
  for (let _bi = 0; _bi < _vbAll.length; _bi++) {
    const b = _vbAll[_bi];
    const _bMaxHp = Math.max(1, Number(b.maxHp) || Number(b.hp) || 1);
    const _bHp = Math.max(0, Math.min(_bMaxHp, Number(b.hp) || 0));
    const _hpShow = _bHp < _bMaxHp || b.hitTimer > 0 || (b._hpBarVisibleUntil || 0) > globalTime;
    if (!_hpShow) continue;
    const _bHpR = _bHp / _bMaxHp;
    const _bRad  = _BLD_RADII[b.type] || 36;
    const _bBx   = b.x, _bBy = b.y - _bRad - 18;
    const _bBw   = 66, _bBh = 9;
    const _fade = _bHp >= _bMaxHp && b.hitTimer <= 0 ? Math.max(0, 1 - ((globalTime - (b._hpBarVisibleUntil || globalTime)) / 20)) : 1;
    ctx.save();
    ctx.globalAlpha = Math.min(1, Math.max(0.15, _fade));
    ctx.fillStyle = 'rgba(0,0,0,0.72)';
    ctx.beginPath(); ctx.roundRect(_bBx - _bBw/2 - 2, _bBy - 2, _bBw + 4, _bBh + 4, 4); ctx.fill();
    const _bCol = _bHpColors[Math.min(255, _bHpR * 255 | 0)];
    if (_bHpR > 0) {
      ctx.fillStyle = _bCol;
      ctx.beginPath(); ctx.roundRect(_bBx - _bBw/2, _bBy, _bBw * _bHpR, _bBh, 3); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.22)';
      ctx.beginPath(); ctx.roundRect(_bBx - _bBw/2 + 1, _bBy + 1, Math.max(0, _bBw * _bHpR - 2), 3, 2); ctx.fill();
    }
    if (b.hitTimer > 0) {
      const _fa = Math.min(1, b.hitTimer / 20) * 0.62;
      ctx.fillStyle = `rgba(255,255,255,${_fa})`;
      ctx.beginPath(); ctx.roundRect(_bBx - _bBw/2, _bBy, _bBw * _bHpR, _bBh, 3); ctx.fill();
    }
    ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.roundRect(_bBx - _bBw/2 - 2, _bBy - 2, _bBw + 4, _bBh + 4, 4); ctx.stroke();
    ctx.restore();
  }

  // Layer 4b: other players (behind the local player)
  drawOtherPlayers();

  // Layer 5: enemies + boss — draw every mob inside the viewport
  try {
  {
    for (let _ei = 0; _ei < enemies.length; _ei++) {
      const _ee = enemies[_ei];
      if (!_ee) continue;
      if (!(_ee.radius > 0) || isNaN(_ee.radius)) _ee.radius = 46;
      const _em = _ee.radius * 3 + 80;
      if (_ee.x < scrL - _em || _ee.x > scrR + _em || _ee.y < scrT - _em || _ee.y > scrB + _em) continue;
      try { drawEnemy(_ee); } catch(_de) {}
    }
  }
  } catch(_mobRenderErr) {}

  // Mob special attack effects (Spider webs, bear claws, poison, etc.)
  try {
    updateAndDrawMobAttackEffects(ctx);
  } catch(_mobEffErr) {}

  // Ambient biome particles (behind everything)
  drawAmbientParticles();
  // Layer 5b: projectiles — single save/restore wrapping the whole batch (was one per projectile)
  if (projectiles.length > 0) {
    ctx.save();
    ctx.lineCap = 'round';
    for (let _pi = 0, _pLen = projectiles.length; _pi < _pLen; _pi++) {
      const p = projectiles[_pi];
      if(p.x<_renderCullL-80||p.x>_renderCullR+80||p.y<_renderCullT-80||p.y>_renderCullB+80) continue;
      // Draw trail
      if (_qualityLevel >= 1 && p._tN > 1) {
        var _ptLen=p._tN;
        ctx.strokeStyle = p.trailColor || 'rgba(0,200,255,0.3)';
        for (var _ti = 0; _ti < _ptLen - 1; _ti++) {
          var _ti0=(p._tH-_ptLen+_ti+12)%6, _ti1=(p._tH-_ptLen+_ti+1+12)%6;
          ctx.globalAlpha = (1 - _ti / _ptLen) * 0.5;
          ctx.lineWidth = 6 - _ti;
          ctx.beginPath();
          ctx.moveTo(p._trail[_ti0].x, p._trail[_ti0].y);
          ctx.lineTo(p._trail[_ti1].x, p._trail[_ti1].y);
          ctx.stroke();
        }
      }
      // Draw bullet
      ctx.globalAlpha = 1;
      ctx.lineWidth = 2;
      if (_qualityLevel >= 2) { ctx.shadowColor = p.color || '#00e5ff'; ctx.shadowBlur = 14; }
      ctx.fillStyle = p.color || '#00e5ff';
      ctx.strokeStyle = '#fff';
      ctx.beginPath();
      ctx.arc(p.x, p.y, 7, 0, Math.PI * 2);
      ctx.fill(); ctx.stroke();
      if (_qualityLevel >= 2) { ctx.shadowBlur = 0; }
    }
    ctx.restore();
  }

  // Layer 6a: swing hit spark at weapon tip (no arc/trail overlay)
  if (player.isAttacking && player.weapon < 3 && player.attackTimer > 0) {
    const prog = player.attackTimer / (player.attackDuration || ATTACK_DUR[player.weapon] || 20);
    const swingPeak = Math.sin(prog * Math.PI);
    const hitRange = _swingHitRange();
    if (swingPeak > 0.55 && Math.random() < 0.4) {
      const tipX = Math.cos(player.angle) * (hitRange * 0.75 + player.radius * 0.3);
      const tipY = Math.sin(player.angle) * (hitRange * 0.75 + player.radius * 0.3);
      const sparkCol = player.weapon === 2 ? '#ffffff' : '#ffe066';
      _spawnParticle(player.x+tipX+(Math.random()-0.5)*14, player.y+tipY+(Math.random()-0.5)*14, (Math.random()-0.5)*5, (Math.random()-0.5)*5-2, 2+Math.random()*2, 8+Math.random()*6, sparkCol);
    }
  }
  // Kill cam flash when player kills an enemy
  if (_killCamTimer > 0) {
    _killCamTimer--;
    const kp = _killCamTimer / 55;
    ctx.save();
    // Ring highlight at kill position (world space)
    ctx.translate(_killCamX, _killCamY);
    ctx.globalAlpha = kp * 0.7;
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(0, 0, 60 + (55-_killCamTimer)*2, 0, Math.PI*2);
    ctx.stroke();
    ctx.strokeStyle = '#ffdd00';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 40 + (55-_killCamTimer)*1.5, 0, Math.PI*2);
    ctx.stroke();
    ctx.restore();
  }

  // Layer 6b: ghost building preview (snap-aware + overlap check) — show whenever build mode active
  if (player.weapon >= 3) {
    const [_cW, _cS] = _BUILD_COSTS_MAP[player.weapon] || [0,0];
    const _canAfford = player.wood >= _cW && player.stone >= _cS;
    const _gpos = _computeGhostPos();
    const bx = _gpos.x, by = _gpos.y;

    // Snap indicator: dashed green ring around the target building
    if (_gpos.snapped && _gpos.snapTarget && !_gpos.blocked) {
      const _st = _gpos.snapTarget;
      const _sr = (_SNAP_RADII[_st.type] || 30) + 8;
      ctx.save();
      ctx.strokeStyle = 'rgba(80,255,120,0.6)';
      ctx.lineWidth = 3;
      ctx.setLineDash([7, 5]);
      if (_shadowOk) { ctx.shadowColor = '#44ff88'; ctx.shadowBlur = 8; }
      ctx.beginPath(); ctx.arc(_st.x, _st.y, _sr, 0, Math.PI * 2); ctx.stroke();
      ctx.setLineDash([]); if (_shadowOk) ctx.shadowBlur = 0;
      ctx.restore();
    }

    ctx.save();
    ctx.globalAlpha = _gpos.blocked ? 0.65 : 0.45;
    // No ctx.filter — CSS canvas filters force CPU rendering path (5-10× slower).
    // State is communicated via colored ring drawn after the ghost building.
    drawBuilding({ x: bx, y: by, type: player.weapon, angle: player.angle, life: 100, hp: 100, maxHp: 100, shake: 0, hitTimer: 0 }, true);
    if (_gpos.blocked || !_canAfford) {
      ctx.globalAlpha = 0.78;
      ctx.strokeStyle = '#ff3333'; ctx.lineWidth = 5;
      ctx.beginPath(); ctx.arc(bx, by, 52, 0, Math.PI * 2); ctx.stroke();
      ctx.globalAlpha = 0.13;
      ctx.fillStyle = '#ff0000';
      ctx.beginPath(); ctx.arc(bx, by, 52, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 0.9;
    ctx.textAlign = 'center'; ctx.font = 'bold 13px Arial';
    const _typeLabel = {3:'🗡️ Kazık',4:'⚙️ Değirmen',5:'⚡ Hız Pedi',6:'🕸️ Tuzak',7:'🔫 Taret',8:'🧱 Duvar',9:'🏰 Kale Kulesi',10:'🔥 Kamp Ateşi'}[player.weapon] || 'Yapı';
    const _costLabel = `🪵${_cW} 🪨${_cS}`;
    const _statusLabel = _gpos.blocked ? '⛔ ALAN DOLU!' : (_gpos.snapped ? '🔗 KENETLENIYOR' : '');
    ctx.strokeStyle = 'rgba(0,0,0,0.75)'; ctx.lineWidth = 3;
    ctx.fillStyle = _gpos.blocked ? '#ff5555' : (_canAfford ? '#aaffaa' : '#ff8888');
    ctx.strokeText(_typeLabel, bx, by - 52); ctx.fillText(_typeLabel, bx, by - 52);
    ctx.strokeText(_costLabel, bx, by - 37); ctx.fillText(_costLabel, bx, by - 37);
    if (_statusLabel) {
      ctx.font = 'bold 12px Arial';
      ctx.fillStyle = _gpos.blocked ? '#ff3333' : '#44ff88';
      ctx.strokeText(_statusLabel, bx, by - 22); ctx.fillText(_statusLabel, bx, by - 22);
    }
    ctx.restore();
  }

  // Arrows + enemy projectiles
  drawArrows();
  drawEnemyProjectiles();
  drawArmorDrops();
  drawLevelUpRings();
  // Layer 6c: hit particles (in world space)
  drawParticles();

  // Layer 7: player + spawn shield + local chat bubble
  if (_playerMoveTrail.length > 1 && playerAcc && playerAcc.izler && playerAcc.izler !== 'iz_none') {
    drawPlayerMovementTrail(playerAcc.izler, _playerMoveTrail);
  }
  if (!_isDying) drawPlayer();
  drawSpawnShield();
  _drawLocalChatBubble();

  // ── Train/rail layer disabled for cleaner Sploop.io feel ─────────────────

  // Layer 8: floating texts — capped + batched for perf
  // Cap: truncate oldest (O(1) instead of O(n) splice)
  if (floatingTexts.length > 10) floatingTexts.length = 10; // was 15 — fewer on-screen texts = less render work on mobile
  ctx.textAlign = 'center';
  // Pass 1: update all; swap-delete dead (O(1) per removal, no array shifting)
  for (let i = floatingTexts.length - 1; i >= 0; i--) {
    const ft = floatingTexts[i];
    ft.y -= 1.3 * _dt; ft.life -= _dt;
    if (ft.life <= 0) {
      if (_ftFreePool.length < _FT_POOL_SZ) _ftFreePool.push(ft);
      floatingTexts[i] = floatingTexts[floatingTexts.length - 1]; floatingTexts.pop();
    }
  }
  // Ekran dışı metin elenme sınırları (dünya koordinatları) — görünmeyeni çizme
  const _ftHalfW = canvas.width * 0.5 / ZOOM + 80;
  const _ftHalfH = canvas.height * 0.5 / ZOOM + 60;
  const _ftXMin = camX - _ftHalfW, _ftXMax = camX + _ftHalfW;
  const _ftYMin = camY - _ftHalfH, _ftYMax = camY + _ftHalfH;
  // Pass 2: render small texts (no shadow, no stroke — cheapest)
  ctx.font = 'bold 20px Arial';
  for (let i = 0; i < floatingTexts.length; i++) {
    const ft = floatingTexts[i];
    if (ft.big) continue;
    // Ekran dışıysa atla
    if (ft.x < _ftXMin || ft.x > _ftXMax || ft.y < _ftYMin || ft.y > _ftYMax) continue;
    ctx.globalAlpha = Math.min(1, ft.life / 28);
    ctx.fillStyle = ft.color || '#fff';
    ctx.fillText(ft.text, ft.x, ft.y);
  }
  // Pass 3: render big texts (with shadow, with stroke — fewer of these)
  // PERF: pre-computed strokeStyle lookup — avoids rgba() string allocation per text per frame
  ctx.font = 'bold 26px Arial'; ctx.lineWidth = 4;
  for (let i = 0; i < floatingTexts.length; i++) {
    const ft = floatingTexts[i];
    if (!ft.big) continue;
    if (ft.x < _ftXMin || ft.x > _ftXMax || ft.y < _ftYMin || ft.y > _ftYMax) continue;
    const _fta = Math.min(1, ft.life / 28);
    ctx.globalAlpha = _fta;
    // PERF: quantize alpha to 6 steps → reuse pre-interned string, zero GC
    ctx.strokeStyle = _FT_STROKE_LUT[Math.min(5, (_fta * 5.99) | 0)];
    ctx.fillStyle = ft.color || '#fff';
    if (_qualityLevel >= 2) { ctx.shadowColor = ft.color || '#fff'; ctx.shadowBlur = 10; }
    ctx.strokeText(ft.text, ft.x, ft.y);
    ctx.fillText(ft.text, ft.x, ft.y);
    if (_qualityLevel >= 2) ctx.shadowBlur = 0;
  }
  } finally {
    ctx.restore();
  }

  // ── Deferred name tags — screen-space pass (always on top, pixel-crisp, no ZOOM scaling) ──
  if (_pendingNameTags.length > 0) {
    ctx.save();
    try {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.imageSmoothingEnabled = false;
      const _cw2 = canvas.width / 2, _ch2 = canvas.height / 2;
      for (const _nt of _pendingNameTags) {
        const _sx = _cw2 + shakeX + ZOOM * (_nt.wx - camX - _cw2);
        const _sy = _ch2 + shakeY + ZOOM * (_nt.wy - camY - _ch2);
        // PERF: cached OC — 120 path/text ops per 10 players → 10 drawImage calls
        _drawNameTagCached(ctx, _sx, _sy, _nt.name, _nt.rankId, _nt.hpRatio, _nt.isOwn, globalTime);
      }
    } finally {
      ctx.restore();
      _pendingNameTags.length = 0;
      _ntPoolIdx = 0; // reset pool index — pool objects are reused next frame
    }
  }

  // Screen-space post-process layers
  drawRain();
  // FPS counter is now an HTML element (top-left) — no canvas drawing needed here
  _drawDashCooldown();
  drawLowHpVignette();
  // XP DOM flush — her 4 frame'de bir (her kaynak darbede layout tetiklenmez)
  if (globalTime % 4 === 0) _flushXP();
  // Minimap — composite smoothly every frame
  drawMinimap();
  // Only update perf stats every 30 frames to avoid overhead
  if (globalTime % 30 === 0) {
    window._perf.renderMs = (performance.now() - _pRenderT0) | 0;
    window._perf.ocRebuild = window._perfOCCount;
    window._perf.eProjectiles = (projectiles?projectiles.length:0)+(arrows?arrows.length:0);
  }

  checkBuildingDamage();
  _mpUpdate();
  } catch(err) {
    // RAF is already scheduled above — just log the error
    console.error('[update] frame error:', err);
  }
}

// ============================================================
// KEYBOARD (desktop)  — WASD + tüm kısayollar
// ============================================================
const _keys = {};
// Server correction accumulators — spread correction over many frames instead of one-shot jerk
window.addEventListener('keydown', e => {
  if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;

  // Keybinding listening mode in settings
  if (typeof _listeningKeybindAction !== 'undefined' && _listeningKeybindAction) {
    e.preventDefault();
    if (e.key === 'Escape') {
      _listeningKeybindAction = null;
      _updateKeybindsButtonsUI();
    } else {
      _setKeybind(_listeningKeybindAction, e.key);
    }
    return;
  }

  const k = e.key.toLowerCase();
  _keys[k] = true;

  // Q (or custom) — yemek ye
  if (_matchKey(k, _customKeybinds.eat)) eatApple();

  // E (or custom) — spike yerleştir (slot 3)
  if (_matchKey(k, _customKeybinds.spike)) {
    if (invSlots[2]) invSlots[2].dispatchEvent(new Event('mousedown'));
    if (player.weapon === 3) tryPlaceBuilding();
  }

  // F (or custom) — TUZAK (trap) yerleştir (slot 6, weapon 6)
  if (_matchKey(k, _customKeybinds.trap)) {
    if (invSlots[5]) invSlots[5].dispatchEvent(new Event('mousedown'));
    if (player.weapon === 6) tryPlaceBuilding();
  }

  // V (or custom) — HIZ PEDİ (boost pad) yerleştir (slot 5, weapon 5)
  if (_matchKey(k, _customKeybinds.boost)) {
    if (invSlots[4]) invSlots[4].dispatchEvent(new Event('mousedown'));
    if (player.weapon === 5) tryPlaceBuilding();
  }

  // N (or custom) — Değirmen (windmill) yerleştir (slot 4, weapon 4)
  if (_matchKey(k, _customKeybinds.windmill)) {
    if (invSlots[3]) invSlots[3].dispatchEvent(new Event('mousedown'));
    if (player.weapon === 4) tryPlaceBuilding();
  }

  // C (or custom) — Taret (turret) yerleştir (slot 7, weapon 7)
  if (_matchKey(k, _customKeybinds.turret)) {
    if (invSlots[6]) invSlots[6].dispatchEvent(new Event('mousedown'));
    if (player.weapon === 7) tryPlaceBuilding();
  }

  // X (or custom) — Duvar (wall) yerleştir (slot 8, weapon 8)
  if (_matchKey(k, _customKeybinds.wall)) {
    if (invSlots[7]) invSlots[7].dispatchEvent(new Event('mousedown'));
    if (player.weapon === 8) tryPlaceBuilding();
  }

  // G / Space / Custom — DASH
  if (_matchKey(k, _customKeybinds.dash) || k === 'g' || (k === ' ' && !e.repeat)) {
    e.preventDefault();
    _doDash();
  }

  // R (or custom) — ok at (bow fire)
  if (_matchKey(k, _customKeybinds.bow)) fireBowArrow();

  // 1-9 — slot seç
  if (e.key >= '1' && e.key <= '9') {
    const idx = parseInt(e.key) - 1;
    if (invSlots[idx]) invSlots[idx].dispatchEvent(new Event('mousedown'));
  }
  // 0 — slot 10 (Ok/Bow)
  if (e.key === '0') {
    const s10 = document.getElementById('slot-10');
    if (s10) s10.dispatchEvent(new Event('mousedown'));
  }

  if (e.key === 'Escape') {
    if (_qcwOpen) { closeQuickChat(); return; }
    if (_tabOpen) { closeTabScoreboard(); return; }
    const pnl = document.getElementById('snap-settings-panel');
    if (pnl && pnl.classList.contains('open')) _toggleSnapSettings();
    else window.location.href = _BASE;
  }

  // Tab — Skor tablosu (hold to view)
  if (e.key === 'Tab') { e.preventDefault(); openTabScoreboard(); }

  // Z (or custom) — Hızlı chat tekerleği
  if (_matchKey(k, _customKeybinds.chatWheel)) {
    if (_qcwOpen) { closeQuickChat(); }
    else { openQuickChat(window.innerWidth / 2, window.innerHeight / 2); }
  }
});

window.addEventListener('keyup', e => {
  _keys[e.key.toLowerCase()] = false;
  if (e.key === 'Tab') closeTabScoreboard();
});

// ============================================================
// DASH COOLDOWN INDICATOR (screen-space, bottom-right near inv)
// ============================================================
function _drawDashCooldown() {
  // PERF: OC-cached, only redrawn when cd state or canvas dimensions change.
  // Eliminates shadow/arc/text rendering on the main canvas every frame.
  const _cdState = _dashOnCd ? 'cd' : 'rdy';
  if (_cdState !== _dashCdState || canvas.width !== _dashCdW || canvas.height !== _dashCdH) {
    _dashCdState = _cdState; _dashCdW = canvas.width; _dashCdH = canvas.height;
    const _bw = 80, _bh = 64;
    _dashCdOC = createRenderCanvas(_bw, _bh);
    const dc = _dashCdOC.getContext('2d');
    const x = _bw - 20, y = _bh - 32, r = 20;
    dc.globalAlpha = 0.85;
    // Background ring
    dc.strokeStyle = 'rgba(255,255,255,0.2)'; dc.lineWidth = 4;
    dc.beginPath(); dc.arc(x, y, r, 0, Math.PI * 2); dc.stroke();
    if (_dashOnCd) {
      dc.fillStyle = 'rgba(0,0,0,0.5)';
      dc.beginPath(); dc.arc(x, y, r, 0, Math.PI * 2); dc.fill();
      dc.fillStyle = 'rgba(100,100,100,0.7)';
      dc.font = 'bold 14px Arial'; dc.textAlign = 'center'; dc.textBaseline = 'middle';
      dc.fillText('💨', x, y + 1);
    } else {
      if (_shadowOk) { dc.shadowColor = '#66ddff'; dc.shadowBlur = 14; }
      dc.strokeStyle = '#66ddff'; dc.lineWidth = 3;
      dc.beginPath(); dc.arc(x, y, r, 0, Math.PI * 2); dc.stroke();
      dc.shadowBlur = 0;
      dc.font = 'bold 14px Arial'; dc.textAlign = 'center'; dc.textBaseline = 'middle';
      dc.fillStyle = '#fff'; dc.fillText('💨', x, y + 1);
    }
    dc.font = 'bold 8px Arial'; dc.fillStyle = 'rgba(255,255,255,0.55)'; dc.textAlign = 'center';
    dc.fillText(_dashOnCd ? 'BEKLİYOR' : '[G]', x, y + r + 9);
  }
  if (_dashCdOC) {
    ctx.save(); ctx.setTransform(1,0,0,1,0,0);
    ctx.drawImage(_dashCdOC, canvas.width - 80, canvas.height - 64);
    ctx.restore();
  }
}

// ============================================================
// DASH — G tuşu / Boşluk ile 1.8 saniyelik hız patlaması
// ============================================================
let _dashOnCd = false;
function _doDash() {
  if (_dashOnCd || _isDying) return;
  _dashOnCd = true;
  const _dBtn = document.getElementById('dash-btn');
  if (_dBtn) _dBtn.classList.add('on-cd');
  const dashPow = 26;
  // Dash yönü: hareket yönü varsa onu kullan, yoksa bakış açısı
  let dashAng = player.angle;
  const mvLen = Math.hypot(player.vx, player.vy);
  if (mvLen > 0.5) dashAng = Math.atan2(player.vy, player.vx);
  player.momX += Math.cos(dashAng) * dashPow;
  player.momY += Math.sin(dashAng) * dashPow;
  floatingTexts.push({ x: player.x, y: player.y - 44, text: '💨 DASH!', alpha: 1, life: 28, color: '#88ddff' });
  playSound(660, 0.09, 'sine', 0.14);
  for (let pi = 0; pi < 12; pi++) {
    const pa = dashAng + Math.PI + (Math.random()-0.5) * 1.4;
    particles.push({ x: player.x + Math.cos(dashAng)*10, y: player.y + Math.sin(dashAng)*10,
      vx: Math.cos(pa)*6, vy: Math.sin(pa)*6,
      r: 3 + Math.random()*3, life: 16 + Math.random()*10, maxLife: 26, color: '#66bbff' });
  }
  setTimeout(() => { _dashOnCd = false; const _dBtnR=document.getElementById('dash-btn'); if(_dBtnR) _dBtnR.classList.remove('on-cd'); }, player._doubleDash ? 900 : 1800);
}

// WASD hız vektörünü her frame'de uygula
function applyWASD() {
  const spd = 5.2;
  if (_joystickActive) {
    player.vx = _joystickMoveX;
    player.vy = _joystickMoveY;
    return;
  }
  let wx = 0, wy = 0;
  if (_keys['w'] || _keys['arrowup'])    wy -= 1;
  if (_keys['s'] || _keys['arrowdown'])  wy += 1;
  if (_keys['a'] || _keys['arrowleft'])  wx -= 1;
  if (_keys['d'] || _keys['arrowright']) wx += 1;
  if (wx !== 0 || wy !== 0) {
    const len = Math.hypot(wx, wy);
    player.vx = (wx / len) * spd;
    player.vy = (wy / len) * spd;
  } else {
    // Joystick aktif değilse ve WASD yok ise dur
    // (joystick kendi vx/vy'sini set ediyor, sadece joy aktif değilse sıfırla)
    if (!_joystickActive) { player.vx = 0; player.vy = 0; }
  }
}

window.addEventListener('mousemove', e => {
  const rect = canvas.getBoundingClientRect();
  const sx = e.clientX - rect.left;
  const sy = e.clientY - rect.top;
  const mx = (sx - canvas.width / 2) / ZOOM + canvas.width / 2 + camX;
  const my = (sy - canvas.height / 2) / ZOOM + canvas.height / 2 + camY;
  player.angle = Math.atan2(my - player.y, mx - player.x);
});

// ── Bina tespiti yardımcısı ──────────────────────────────────
function _isOwnBuilding(b) {
  if (!b || b.hp <= 0) return false;
  if (b._ownerId == null || b._ownerId === '') return true;
  if (_mySocketId == null || _mySocketId === undefined) return true;
  return b._ownerId === _mySocketId;
}

function _screenToWorld(clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  const sx = ((clientX - rect.left) / rect.width) * canvas.width;
  const sy = ((clientY - rect.top) / rect.height) * canvas.height;
  return {
    x: (sx - canvas.width / 2) / ZOOM + camX + canvas.width / 2,
    y: (sy - canvas.height / 2) / ZOOM + camY + canvas.height / 2,
  };
}

function _findOwnBldAt(clientX, clientY) {
  const p = _screenToWorld(clientX, clientY);
  const HR = {3:38, 4:58, 5:50, 6:58, 7:45, 8:30, 9:64, 10:28};
  let best = null, bestD = 9999;
  const nearby = (typeof _sgQuery === 'function') ? _sgQuery(p.x, p.y, 180) : buildings;
  const candidateList = (nearby && nearby.length > 0) ? nearby : buildings;
  for (const b of candidateList) {
    if (!b || !_isOwnBuilding(b)) continue;
    const d = Math.hypot(p.x - b.x, p.y - b.y);
    const r = (HR[b.type] || 80) + 12;
    if (d <= r && d < bestD) { bestD = d; best = b; }
  }
  return best;
}

function _toggleUpgPanel(b) {
  // Upgrade panel is disabled in this build.
  hideBuildUpgradePanel();
  return false;
}

function _handleBuildInteraction(e) {
  if (!e || e.button === 2) return;
  _tryInitAudio();
  if (player.weapon === 10) { fireBowArrow(); return; }
  hideBuildUpgradePanel();
  _attackPending = true;
  _attackQueued = true;
}

canvas.addEventListener('pointerdown', e => {
  if (e.pointerType === 'mouse' && e.button !== 0) return;
  _handleBuildInteraction(e);
});
canvas.addEventListener('mousedown', e => {
  // Pointer-capable browsers already handled this input in pointerdown.
  if ('PointerEvent' in window) return;
  if (e.button === 0) _handleBuildInteraction(e);
  if (e.button === 2) { e.preventDefault(); fireBowArrow(); }
});
canvas.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('touchstart', _tryInitAudio, { once: true });
canvas.addEventListener('mouseup', e => {
  if (e.button === 0) {
    if (player.weapon >= 3) tryPlaceBuilding();
    _attackPending = false;
  }
});
window.addEventListener('blur', () => { keys = {}; });

// ============================================================
// MULTIPLAYER — WebSocket / Socket.io
// ============================================================
const _pingEl = document.getElementById('ping-display');
const _fpsEl  = document.getElementById('fps-display'); // HTML FPS counter (top-left)
const _perfEl = document.getElementById('perf-panel');
// ── Performance profiler data ────────────────────────────────────────────────
window._perf = {
  frameMs:0, renderMs:0,
  tCamps:0, tTelegraph:0, tGround:0, tBuildings:0, tPlayers:0, tEnemies:0, tParticles:0,
  ocRebuild:0, // incremented by any OffscreenCanvas rebuild this frame
  eMobs:0, ePlayers:0, eParticles:0, eProjectiles:0, eTelegraphs:0, eBuildings:0,
  quality:0, shadowBlurActive:0,
};
window._perfOCCount = 0; // reset each frame

function initMultiplayerOfflineFallback() {
  _connected = true;
  const badge = document.getElementById('ping-display');
  if (badge) {
    badge.textContent = '🏠 Çevrimdışı';
    badge.style.color = '#aaddff';
    badge.style.display = '';
  }
}

function initMultiplayer() {
  if (_GAME_MODE === 'offline') {
    // Çevrimdışı mod — sunucu bağlantısı yok
    // BUG FIX: _connected must be true in offline mode so eat_apple / res_hit
    // emit guards like `if (_connected && _socket)` don't silently block gameplay.
    // We set _connected=true and leave _socket=null; callers must guard _socket separately.
    _connected = true;
    const badge = document.getElementById('ping-display');
    if (badge) { badge.textContent = '🏠 Çevrimdışı'; badge.style.color = '#aaddff'; badge.style.display = ''; }
    if (_fpsEl) { _fpsEl.style.display = ''; _fpsEl.textContent = '⚡ -- FPS'; }
    return;
  }
  if (typeof io === 'undefined') { console.warn('Socket.io not loaded'); return; }
  _socket = io({ path: '/api/socket.io', transports: ['websocket', 'polling'], upgrade: true });
  const _connectionFallbackTimer = setTimeout(() => {
    if (!_socket.connected && !_connected) {
      initMultiplayerOfflineFallback();
      if (_pingEl) {
        _pingEl.textContent = '🏠 Çevrimdışı';
        _pingEl.style.color = '#aaddff';
        _pingEl.style.display = '';
      }
    }
  }, 5000);
  _setupInGameClan();

  // ── Stable guest ID for reconnect grace ──────────────────────────────────
  let _fbGuestId = localStorage.getItem('fb_guest_id');
  if (!_fbGuestId) { _fbGuestId = Math.random().toString(36).slice(2) + Date.now().toString(36); localStorage.setItem('fb_guest_id', _fbGuestId); }

  // ── Reconnect overlay ─────────────────────────────────────────────────────
  const _rcOverlay = document.createElement('div');
  _rcOverlay.id = '_rcOverlay';
  _rcOverlay.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.82);flex-direction:column;align-items:center;justify-content:center;color:#fff;font-family:inherit;gap:18px;display:none;';
  _rcOverlay.innerHTML = '<div style="font-size:2rem;letter-spacing:.04em;font-weight:700;text-shadow:0 0 20px #00ccff88">🌐 Yeniden Bağlanılıyor…</div><div style="font-size:1rem;color:#aad4ff;max-width:340px;text-align:center">Bağlantın kesildi. Otomatik olarak geri bağlanmaya çalışılıyor…</div><div style="width:80px;height:4px;border-radius:4px;background:#ffffff22;overflow:hidden;"><div id="_rcBar" style="height:100%;background:linear-gradient(90deg,#00ccff,#0044ff);animation:_rcAnim 1.1s linear infinite;"></div></div>';
  const _rcStyle = document.createElement('style');
  _rcStyle.textContent = '@keyframes _rcAnim{0%{width:0%;margin-left:0}50%{width:80%;margin-left:10%}100%{width:0%;margin-left:100%}}';
  document.head.appendChild(_rcStyle);
  document.body.appendChild(_rcOverlay);
  let _rcOverlayVisible = false;
  function _showRcOverlay() { if (!_rcOverlayVisible) { _rcOverlay.style.display = 'flex'; _rcOverlayVisible = true; } }
  function _hideRcOverlay() { _rcOverlay.style.display = 'none'; _rcOverlayVisible = false; }

  let _reconnectDelay = 2000;
  let _reconnectTimer = null; // store timer ID so we never run two reconnect loops

  // BUG FIX: merged two separate 'connect' handlers into one — previously the reconnect
  // delay was only reset in the second handler, so a brand-new first connection never
  // cleared a potentially stale timer, and the delay was never reset to 2 s on reconnect
  // unless the second handler ran first.
  let _pingTimer = null;
  _socket.on('connect', () => {
    clearTimeout(_connectionFallbackTimer);
    _mySocketId = _socket.id;
    _connected = true;
    // Reset reconnect state (matters on reconnect; safe to call on initial connect too)
    _reconnectDelay = 2000;
    if (_reconnectTimer) { clearTimeout(_reconnectTimer); _reconnectTimer = null; }
    _hideRcOverlay();
    if (_pingEl) { _pingEl.style.display = ''; _pingEl.style.color = ''; _pingEl.textContent = '🌐 -- ms'; }
    if (_fpsEl) { _fpsEl.style.display = ''; _fpsEl.textContent = '⚡ 60 FPS'; }
    if (_pingTimer) clearInterval(_pingTimer);
    _pingTimer = setInterval(() => { if (_connected && _socket) _socket.emit('ping_req', { t: performance.now() }); }, 1500);
    _socket.emit('ping_req', { t: performance.now() });
    const _initAxeTier = (playerAcc && playerAcc.baltalar && playerAcc.baltalar.startsWith('ba_tier_')) ? Math.max(_wepTier(_axeXP), parseInt(playerAcc.baltalar.replace('ba_tier_', '')) || 0) : _wepTier(_axeXP);
    const _initSwordTier = (playerAcc && playerAcc.kiliclar && playerAcc.kiliclar.startsWith('ki_tier_')) ? Math.max(_wepTier(_swordXP), parseInt(playerAcc.kiliclar.replace('ki_tier_', '')) || 0) : _wepTier(_swordXP);
    const _authTok = localStorage.getItem('fb_auth_token') || '';
    _socket.emit('join', {
      name: player.name, skin: _playerSkin, color: playerColor,
      axeTier: _initAxeTier, swordTier: _initSwordTier,
      x: player.x, y: player.y,
      hp: player.hp, maxHp: player.maxHp,
      mode: urlParams.get('gamemode') || 'classic',
      team: urlParams.get('team') || urlParams.get('partyCode') || '',
      clanId: _clanId,
      partyCode: urlParams.get('partyCode') || '',
      token: _authTok,
      guestId: _fbGuestId,
      acc: { a: playerAcc.aksesuarlar, y: playerAcc.yuz, s: playerAcc.sapkalar, k: playerAcc.kanatlar },
    });
  });

  _socket.on('disconnect', (reason) => {
    _connected = false;
    _otherPlayers.clear();
    if (_pingTimer) { clearInterval(_pingTimer); _pingTimer = null; }
    if (_pingEl) { _pingEl.textContent = '🌐 ⚠️ bağlantı kesildi'; _pingEl.style.color = '#ff8888'; }
    if (reason !== 'io client disconnect') {
      _showRcOverlay();
      if (_reconnectTimer) clearTimeout(_reconnectTimer); // cancel any pending reconnect
      const _doReconnect = () => {
        _reconnectTimer = null;
        if (!_connected && _socket) {
          _socket.connect();
          _reconnectDelay = Math.min(_reconnectDelay * 1.6, 12000);
        }
      };
      _reconnectTimer = setTimeout(_doReconnect, _reconnectDelay);
    }
  });

  _socket.on('welcome', ({ id, players: others, buildings: remoteBuildings, worldSeed, resHp, mobs, isHost: serverIsHost, bountyId: welcomeBountyId, airdrops: welcomeAirdrops }) => {
    _mySocketId = id;
    if (welcomeBountyId !== undefined) _bountyId = welcomeBountyId;
    if (welcomeAirdrops && Array.isArray(welcomeAirdrops)) {
      airdropsList = welcomeAirdrops.map(ad => ({ ...ad, dropY: 0, beamAlpha: 1.0, pulse: 0, shake: 0, hitFlash: 0 }));
    }
    Object.entries(others).forEach(([pid, s]) => {
      _otherPlayers.set(pid, {
        name: s.n || s.name || '?', skin: s.sk || s.skin || 'default',
        x: s.x ?? 0, y: s.y ?? 0, angle: s.a ?? s.angle ?? 0,
        hp: s.hp ?? 100, maxHp: s.mhp ?? s.maxHp ?? 100,
        attackTimer: s.atp ?? s.attackTimer ?? 0, attackDuration: s.atd ?? s.attackDuration ?? 0,
        weapon: s.w ?? s.weapon ?? 1, isAttacking: s.atk ?? s.isAttacking ?? false,
        kills: s.k ?? s.kills ?? 0, xp: s.xp ?? 0, gold: s.g ?? s.gold ?? 0, score: s.sc ?? s.score ?? 0,
        axeTier: s.at ?? s.axeTier ?? 0, swordTier: s.st ?? s.swordTier ?? 0,
        rankId: s.rk ?? s.rankId ?? 0, color: s.color || '#8B5E3A', team: s.team || '', clanId: s.clanId || '', clanTag: s.clanTag || '',
        acc: s.acc || {},
        _sx: s.x ?? 0, _sy: s.y ?? 0, _targetAngle: s.a ?? s.angle ?? 0,
        _targetX: s.x ?? 0, _targetY: s.y ?? 0, vx: s.vx || 0, vy: s.vy || 0,
        _lastPacketTime: Date.now(),
        _snapshots: [{ t: Date.now(), x: s.x ?? 0, y: s.y ?? 0, a: s.a ?? 0, vx: s.vx || 0, vy: s.vy || 0 }],
      });
    });
    // Merge remote buildings — O(1) Map.get yerine O(N) find kaldırıldı
    _buildingsMap.clear(); _campfires.length = 0;
    // Önce kendi binalarımızı map'e al
    for (let _bi=0;_bi<buildings.length;_bi++) {
      const _b=buildings[_bi];
      if (_b._netId) _buildingsMap.set(_b._netId, _b);
      if (_b.type === 10) _campfires.push(_b);
    }
    Object.entries(remoteBuildings).forEach(([bid, b]) => {
      if (!_buildingsMap.has(bid)) {
        const _nb = { x: b.x, y: b.y, type: b.type, angle: b.angle, life: 0,
          hp: b.hp, maxHp: b.maxHp, tier: b.tier || 0, shake: 0, hitTimer: 0, _netId: bid, _ownerId: b.ownerId, ownerClanId: b.ownerClanId || '', _remote: true, _spawnAnim: 0, _hpBarVisibleUntil: 0 };
        buildings.push(_nb);
        _buildingsMap.set(bid, _nb);
        if (_nb.type === 10) _campfires.push(_nb);
      }
    });
    // ── Shared world: rebuild resources from server seed ──────────────────
    if (worldSeed !== undefined) {
      _rebuildResourcesFromSeed(worldSeed, resHp || {});
      // Sync message suppressed
    }
    // ── Load server mob states ────────────────────────────────────────────
    if (mobs && Array.isArray(mobs)) {
      enemies.length = 0;
      _serverBossId = null; _serverBossName = '';
      for (const m of mobs) {
        if (!isActiveMobShape(m.shape)) continue;
        enemies.push({ _netId: m.id, x: m.x, y: m.y, _targetX: m.x, _targetY: m.y,
          vx: m.vx||0, vy: m.vy||0,
          hp: m.hp, maxHp: m.maxHp||m.hp, radius: m.radius,
          color: m.color, outline: m.outline||'#333', shape: m.shape||'goblin',
          eyes: m.eyes||'#ffee00', hitFlash: m.hitFlash||0, typeName: m.typeName||'Düşman',
          dmg: m.dmg||10, speed: 0, xpReward: m.xpReward||25, goldReward: m.goldReward||5,
          provoked: true, lastHit: 0, lastBuildHit: 0, lastSpikeHit: 0, lastResHit: 0, lastHitSwingId: -1,
          angle: 0, isBoss: m.isBoss||false });
        if (m.isBoss && !_serverBossId) {
          _serverBossId = m.id;
          _serverBossName = m.typeName || '👑 Boss';
          _updateServerBossBar(m.hp, m.maxHp||m.hp);
        }
      }
    }
    // Player count message suppressed
  });

  _socket.on('players', (states) => {
    const now = Date.now();
    // PERF: for...in avoids Object.entries() which allocates a temporary [[k,v],...] array
    // every tick (30Hz × N players = heavy GC pressure on mobile/low-end)
    for (const id in states) {
      const s = states[id];
      if (id === _mySocketId) continue;
      if (!s || typeof s !== 'object') continue; // guard against null/undefined state
      // Server now sends compact keys: n,sk,x,y,a,vx,vy,hp,mhp,w,atk,k,xp,at,st
      const sx = s.x ?? 0, sy = s.y ?? 0, sa = s.a ?? 0, svx = s.vx || 0, svy = s.vy || 0;
      // HP=0 in tick → player is dead; remove immediately without waiting for player_dead event
      if (s.hp !== undefined && s.hp <= 0) { _otherPlayers.delete(id); continue; }
      const existing = _otherPlayers.get(id);
      if (existing && typeof s.sq === 'number') {
        // Sequence check with wrap & respawn tolerance: if sequence jumps backwards by >= 500 (respawn/wrap), reset netSeq
        if (s.sq <= (existing._netSeq || 0) && ((existing._netSeq || 0) - s.sq < 500)) continue;
        existing._netSeq = s.sq;
      }
      if (existing) {
        // PERF: Snapshot circular buffer — reuse objects, zero allocation in steady state.
        // Old: push({...}) + splice() created N_players × 30Hz new objects + array reallocs/sec.
        // New: when buffer is full, shift the oldest slot out and mutate it in place, then
        // push it back. Array stays at ≤8 entries; no heap allocation after warm-up.
        if (!existing._snapshots) existing._snapshots = [];
        if (existing._snapshots.length >= 8) {
          const _old = existing._snapshots.shift(); // remove oldest (array length always tiny ≤8)
          _old.t = now; _old.x = sx; _old.y = sy; _old.a = sa; _old.vx = svx; _old.vy = svy;
          existing._snapshots.push(_old); // recycle — zero GC
        } else {
          existing._snapshots.push({ t: now, x: sx, y: sy, a: sa, vx: svx, vy: svy });
        }
        // Set real-time lerp targets & velocities
        existing._targetX = sx;
        existing._targetY = sy;
        existing._targetAngle = sa;
        existing.vx = svx;
        existing.vy = svy;
        existing._lastPacketTime = now;
        existing._sx = sx;
        existing._sy = sy;
        // Stat fields — guard all: tick state omits static fields (n, sk, color, team, acc, tiers)
        // so we must not overwrite with undefined (those come once from player_join/welcome).
        if (s.hp   !== undefined) existing.hp          = s.hp;
        if (s.mhp  !== undefined) existing.maxHp       = s.mhp;
        if (s.w    !== undefined) existing.weapon      = s.w;
        // Discrete swings are triggered strictly via 'remote_swing' event to prevent double-swings
        if (s.atd !== undefined) existing.attackDuration = s.atd;
        if (s.k    !== undefined) existing.kills       = s.k;
        if (s.xp   !== undefined) existing.xp          = s.xp;
        if (s.sk) existing.skin = s.sk;
        if (s.n) existing.name = s.n;
        if (s.at   !== undefined) existing.axeTier     = s.at;
        if (s.st   !== undefined) existing.swordTier   = s.st;
        if (s.rk   !== undefined) existing.rankId      = s.rk;
        if (s.g    !== undefined) existing.gold        = s.g;
        if (s.sc   !== undefined) existing.score       = s.sc;
        if (s.color !== undefined) existing.color      = s.color;
        if (s.team !== undefined) existing.team        = s.team;
        if (s.clanId !== undefined) existing.clanId     = s.clanId;
        if (s.clanTag !== undefined) existing.clanTag    = s.clanTag;
        if (s.acc  !== undefined) existing.acc         = s.acc;
        if (s.trappedBy !== undefined) existing._trappedBy = s.trappedBy;
        if (s.trappedX !== undefined && s.trappedX !== null) existing._trappedX = s.trappedX;
        if (s.trappedY !== undefined && s.trappedY !== null) existing._trappedY = s.trappedY;
        // Build preview position (null when not in build mode)
        existing.buildX = (typeof s.bx === 'number') ? s.bx : null;
        existing.buildY = (typeof s.by === 'number') ? s.by : null;
      } else {
        // First time seeing this player via broadcast — init render pos immediately
        const p = {
          name: s.n || 'Oyuncu', skin: s.sk || 'default', x: sx, y: sy, angle: sa,
          hp: s.hp, maxHp: s.mhp, weapon: s.w, isAttacking: s.atk, attackTimer: s.atp || 0, attackDuration: s.atd || 0,
          kills: s.k, xp: s.xp, gold: s.g || 0, score: s.sc || 0, axeTier: s.at || 0, swordTier: s.st || 0,
          rankId: s.rk ?? 0, clanId: s.clanId || '', clanTag: s.clanTag || '',
          acc: s.acc || {},
          _trappedBy: s.trappedBy || null,
          _trappedX: s.trappedX ?? undefined,
          _trappedY: s.trappedY ?? undefined,
          buildX: (typeof s.bx === 'number') ? s.bx : null,
          buildY: (typeof s.by === 'number') ? s.by : null,
          _targetX: sx, _targetY: sy, _targetAngle: sa, vx: svx, vy: svy, _lastPacketTime: now,
          _sx: sx, _sy: sy,
          _snapshots: [{ t: now, x: sx, y: sy, a: sa, vx: svx, vy: svy }],
          _netSeq: typeof s.sq === 'number' ? s.sq : 0,
        };
        _otherPlayers.set(id, p);
      }
    }
  });

  _socket.on('player_join', ({ id, state }) => {
    if (id === _mySocketId) return;
    // Briefly reduce rendering load so the join initialization doesn't tank FPS
    if (_respawnGrace < 45) _respawnGrace = 45;
    const _pjS = state;
    _otherPlayers.set(id, {
      name: _pjS.n || _pjS.name || '?', skin: _pjS.sk || _pjS.skin || 'default',
      x: _pjS.x ?? 0, y: _pjS.y ?? 0, angle: _pjS.a ?? _pjS.angle ?? 0,
      vx: _pjS.vx || 0, vy: _pjS.vy || 0,
      hp: _pjS.hp ?? 100, maxHp: _pjS.mhp ?? _pjS.maxHp ?? 100, attackTimer: _pjS.atp ?? 0, attackDuration: _pjS.atd ?? 0,
      weapon: _pjS.w ?? _pjS.weapon ?? 1, isAttacking: _pjS.atk ?? false,
      kills: _pjS.k ?? 0, xp: _pjS.xp ?? 0, gold: _pjS.g ?? 0, score: _pjS.sc ?? 0,
      axeTier: _pjS.at ?? 0, swordTier: _pjS.st ?? 0,
      rankId: _pjS.rk ?? 0, color: _pjS.color || '#8B5E3A', team: _pjS.team || '', clanId: _pjS.clanId || '', clanTag: _pjS.clanTag || '',
      acc: _pjS.acc || {},
      buildX: (typeof _pjS.bx === 'number') ? _pjS.bx : null,
      buildY: (typeof _pjS.by === 'number') ? _pjS.by : null,
      _targetX: _pjS.x ?? 0, _targetY: _pjS.y ?? 0, _targetAngle: _pjS.a ?? _pjS.angle ?? 0,
      vx: _pjS.vx || 0, vy: _pjS.vy || 0, _lastPacketTime: Date.now(),
      _sx: _pjS.x ?? 0, _sy: _pjS.y ?? 0,
      _snapshots: [{ t: Date.now(), x: _pjS.x ?? 0, y: _pjS.y ?? 0, a: _pjS.a ?? 0, vx: _pjS.vx || 0, vy: _pjS.vy || 0 }],
    });
    pushKillFeed(`🟢 ${_pjS.n || _pjS.name || '?'} oyuna katıldı!`);
  });

  _socket.on('player_left', ({ id, name }) => {
    _otherPlayers.delete(id);
    // Remove their buildings — O(N) ama seyrek event, devam etsin
    for (let i = buildings.length - 1; i >= 0; i--) {
      const _bl = buildings[i];
      if (_bl._ownerId === id) {
        if (_bl._netId) _buildingsMap.delete(_bl._netId);
        if (_bl.type === 10) { const _ci=_campfires.indexOf(_bl); if(_ci>=0){_campfires[_ci]=_campfires[_campfires.length-1];_campfires.pop();} }
        buildings.splice(i, 1);
      }
    }
    if (name) pushKillFeed(`🔴 ${name} ayrıldı`);
  });

  // PvP: we got hit by another player
  // Server is authoritative for PvP damage; apply locally for instant feedback.
  // The 'pvp_killed' event handles actual death to avoid double-die race.
  _socket.on('pvp_hit', ({ dmg, fromName }) => {
    if (_isDying) return; // already dead, ignore late hits
    const _pvpReduced = Math.max(1, Math.round(dmg * (1 - (player.armorBonus || 0))));
    player.hp = Math.max(0, player.hp - _pvpReduced);
    shake(12);
    spawnBlood(player.x, player.y, 9);
    playSound(95 + Math.floor(Math.random()*40), 0.16, 'sawtooth', 0.3);
    triggerDmgFlash();
    floatingTexts.push({ x: player.x, y: player.y - 50, text: '-' + dmg + ' ⚔️', alpha: 1, life: 35, color: '#ff3333' });
    _lastDamager = { typeName: fromName + ' (Oyuncu)' };
    updateHpBar();
    if (player.hp <= 0 && !_isDying) {
      die();
    }
  });

  // PvP: we hit someone — server authoritative confirm
  _socket.on('pvp_confirm', ({ targetId, dmg, targetName }) => {
    player.totalDmg += dmg;
    const other = _otherPlayers.get(targetId);
    if (other) {
      // ── Lag-compensation dedup ─────────────────────────────────────────────
      // If client already predicted this hit locally (<600 ms ago), skip visual
      // effects to avoid double blood/numbers on low-ping connections.
      // On high-ping connections (>600ms) the prediction was never shown, so show now.
      const _predictedAt = _pvpPredictTime.get(targetId);
      if (!_predictedAt || (Date.now() - _predictedAt) > 600) {
        spawnBlood(other.x, other.y, 8);
        floatingTexts.push({ x: other.x, y: other.y - 35, text: '-' + dmg + ' ⚔️', alpha: 1, life: 35, color: '#ff6666' });
        playSound(220 + Math.floor(Math.random()*100), 0.08, 'square', 0.15);
      }
    }
  });

  // PvP: we killed someone — remove dead player immediately from render
  _socket.on('pvp_kill_confirm', ({ targetName, targetId }) => {
    player.kills++;
    player.score = (player.score || 0) + 150;
    _killCamTimer = 55;
    updateUI(); updateXP();
    pushKillFeed(`⚔️ ${player.name} → ${targetName} öldürdü!`);
    playSound(280 + Math.floor(Math.random()*120), 0.14, 'square', 0.22);
    // Victory fanfare chord
    setTimeout(()=>playSound(523,0.10,'triangle',0.18),60);
    setTimeout(()=>playSound(659,0.10,'triangle',0.15),130);
    setTimeout(()=>playSound(784,0.12,'triangle',0.12),210);
    if (player.vampire) { player.hp = Math.min(player.maxHp, player.hp + 12); updateHpBar(); }
    // ── Dramatic kill popup ──────────────────────────────────────
    const _kn = document.getElementById('kill-notif');
    const _knMain = document.getElementById('kill-notif-main');
    const _knTarget = document.getElementById('kill-notif-target');
    const _knSub = document.getElementById('kill-notif-sub');
    if (_kn && _knMain) {
      const _streakLabels = ['','','DOUBLE KİLL! 🔥','TRİPLE KİLL! 💥','QUAD KİLL! ⚡','PENTA KİLL! 🌟'];
      const _sl = player.kills >= 2 ? (_streakLabels[Math.min(player.kills, 5)] || `${player.kills}X KİLL! 🔥`) : 'ELİMİNE EDİLDİ!';
      _knMain.textContent = _sl;
      _knTarget.textContent = '⚔️ ' + targetName;
      _knSub.textContent = `${player.kills}. kill • Skor: ${player.score||0}`;
      if (_kn._hideTimer) clearTimeout(_kn._hideTimer);
      _kn.classList.remove('show');
      _kn.style.animation = 'none';
      requestAnimationFrame(function() {
        _kn.style.animation = '';
        _kn.classList.add('show');
      });
      _kn._hideTimer = setTimeout(() => _kn.classList.remove('show'), 2100);
    }
    floatingTexts.push({ x: player.x, y: player.y - 55, text: '⚔️ KİLL!', alpha: 1, life: 55, color: '#ffdd00', big: true });
    // Kill flash
    const _kf = document.getElementById('kill-flash');
    if (_kf) {
      _kf.style.animation = 'none';
      _kf.classList.remove('active');
      requestAnimationFrame(function() { _kf.style.animation = ''; _kf.classList.add('active'); });
    }
    // Immediately hide the dead player and their buildings
    if (targetId) {
      _otherPlayers.delete(targetId);
      for (let i = buildings.length - 1; i >= 0; i--) {
        const _bl = buildings[i];
        if (_bl._ownerId === targetId) {
          if (_bl._netId) _buildingsMap.delete(_bl._netId);
          if (_bl.type === 10) { const _ci=_campfires.indexOf(_bl); if(_ci>=0){_campfires[_ci]=_campfires[_campfires.length-1];_campfires.pop();} }
          buildings.splice(i, 1);
        }
      }
    }
  });

  // Another player died (server broadcasts this to all players except the attacker)
  _socket.on('player_dead', ({ id }) => {
    _otherPlayers.delete(id);
    _myTrapVictims.delete(id); // dead players are no longer trapped
    // Remove their buildings (server already deleted them, clean up client side)
    for (let i = buildings.length - 1; i >= 0; i--) {
      const _bl = buildings[i];
      if (_bl._ownerId === id) {
        if (_bl._netId) _buildingsMap.delete(_bl._netId);
        if (_bl.type === 10) { const _ci=_campfires.indexOf(_bl); if(_ci>=0){_campfires[_ci]=_campfires[_campfires.length-1];_campfires.pop();} }
        buildings.splice(i, 1);
      }
    }
  });

  // PvP: we died to a player
  _socket.on('pvp_killed', ({ byName }) => {
    _lastDamager = { typeName: byName + ' (Oyuncu)' };
    player.hp = 0;
    die();
  });

  // ── Global PvP kill feed — server broadcasts every kill to all players ───
  _socket.on('pvp_kill_feed', ({ killer, victim, streak }) => {
    if (killer === player.name) return; // we already got pvp_kill_confirm with animation
    let msg = `⚔️ ${killer} → ${victim} öldürdü!`;
    if (streak >= 3) msg = `🔥 ${killer} [${streak}x STREAK] → ${victim}!`;
    else if (streak === 2) msg = `💢 ${killer} [DOUBLE] → ${victim}!`;
    pushKillFeed(msg);
    // Play faint distant combat sound for nearby action awareness
    if (streak >= 2) playSound(440 + streak * 55, 0.04, 'triangle', 0.12);
  });

  // ── Kill streak notification from server ─────────────────────────────────
  _socket.on('kill_streak', ({ streak, label }) => {
    showToast(`🔥 ${label}!`, 2500, streak >= 4 ? '#ff4400' : streak >= 3 ? '#ff8800' : '#ffcc00');
    // Extra haptic feedback for streaks
    if (navigator.vibrate) navigator.vibrate([30, 10, 50 + streak * 20]);
    floatingTexts.push({ x: player.x, y: player.y - 80, text: `🔥 ${label}!`, alpha: 1, life: 70, color: '#ffdd00', big: true });
  });

  // ── Server announcements — tips + events ──────────────────────────────────
  _socket.on('server_announce', ({ msg }) => {
    pushKillFeed(`📢 ${msg}`);
    showToast(msg, 5000, '#4488ff');
  });

  // ── Building limit reached — server refused placement ─────────────────────
  _socket.on('build_limit_reached', () => {
    showToast('⛔ Bina limitine ulaştın! (80 bina max)', 3000, '#ff6644');
    // Remove the ghost building that was optimistically added before the server ACK
    if (_lastPlacedClientId) {
      const ghostB = _buildingsMap.get(_lastPlacedClientId);
      if (ghostB) {
        const idx = buildings.indexOf(ghostB);
        if (idx !== -1) buildings.splice(idx, 1);
        _buildingsMap.delete(_lastPlacedClientId);
      }
      _lastPlacedClientId = null;
    }
  });

  // Server confirms building placement with authoritative ID
  // BUG FIX: server now generates IDs — remap client's temp ID to server-assigned ID
  _socket.on('build_ack', ({ clientId, serverId }) => {
    const b = _buildingsMap.get(clientId);
    if (!b) return;
    _buildingsMap.delete(clientId);
    b._netId = serverId;
    _buildingsMap.set(serverId, b);
    // Placement accepted — clear pending ID so build_limit_reached won't remove a future ghost
    if (_lastPlacedClientId === clientId) _lastPlacedClientId = null;
  });

  // Bounty target updated
  _socket.on('bounty_update', ({ id, name }) => {
    const wasBounty = _bountyId;
    _bountyId = id || null;
    if (_bountyId && _bountyId !== _mySocketId) {
      showToast(`🏆 YENİ HEDEF: ${name} — öldür +300 puan!`, 5000, '#ffd700');
    } else if (_bountyId === _mySocketId) {
      showToast(`👑 Sen hedef oldun! Herkese karşı savaş!`, 5000, '#ff4444');
    } else if (wasBounty) {
      showToast('🏆 Hedef düştü!', 2500, '#aaaaaa');
    }
  });

  // We killed the bounty target — extra reward
  _socket.on('bounty_kill_reward', ({ name, bonus }) => {
    _incQuestStat('kingKills', 1);
    _incQuestStat('kills', 1);
    player.score = (player.score || 0) + (bonus || 300);
    player.gold += (bonus || 300);
    updateUI();
    floatingTexts.push({ x: player.x, y: player.y - 80, text: `👑 KRAL AVI +${bonus || 300} 🪙!`, alpha: 1, life: 80, color: '#ffd700', big: true });
    showToast(`🏆 Altın Kralı ${name}'ı öldürdün! +${bonus || 300} Altın kazandın!`, 4500, '#ffd700');
    playSound(880, 0.18, 'triangle', 0.35);
    setTimeout(() => playSound(1100, 0.15, 'triangle', 0.28), 150);
    setTimeout(() => playSound(1320, 0.14, 'triangle', 0.22), 300);
  });

  _socket.on('bounty_killed_broadcast', ({ killer, victim, bonus }) => {
    showToast(`👑 ${killer}, Altın Kralı ${victim}'ı devirdi! (+${bonus || 300} 🪙)`, 5000, '#ffd700');
    playSound(950, 0.25, 'triangle', 0.3);
  });

  _socket.on('airdrop_spawn', (ad) => {
    if (!ad || !ad.id) return;
    const existing = airdropsList.find(a => a.id === ad.id);
    if (!existing) {
      airdropsList.push({
        ...ad,
        dropY: -450,
        beamAlpha: 1.0,
        pulse: 0,
        shake: 0,
        hitFlash: 0
      });
      playSound(660, 0.2, 'triangle', 0.35);
      setTimeout(() => playSound(880, 0.2, 'sine', 0.3), 150);
    }
  });

  _socket.on('airdrop_hit_state', ({ id, hp, maxHp }) => {
    const ad = airdropsList.find(a => a.id === id);
    if (ad) {
      ad.hp = hp;
      ad.hitFlash = 10;
      ad.shake = 6;
      spawnBuildingDebris(ad.x, ad.y + (ad.dropY || 0), 2);
    }
  });

  _socket.on('airdrop_opened', ({ id, x, y, openerName, openerId, gold, tier }) => {
    const idx = airdropsList.findIndex(a => a.id === id);
    if (idx !== -1) airdropsList.splice(idx, 1);
    if (openerId === _mySocketId) {
      _incQuestStat('airdrops', 1);
    }
    spawnGoldBurst(x, y);
    spawnGoldBurst(x, y);
    playSound(1050, 0.22, 'triangle', 0.4);
  });

  // Another player placed a building  (server broadcasts "build" event)
  _socket.on('build', ({ id, building }) => {
    const ownerId = building.ownerId || building._ownerId;
    if (ownerId === _mySocketId) return;
    if (_buildingsMap.has(id)) return; // O(1) — was buildings.find()
    const _nb = { x: building.x, y: building.y, type: building.type, angle: building.angle,
      life: 0, hp: building.hp, maxHp: building.maxHp, tier: building.tier || 0, shake: 0, hitTimer: 0,
      _netId: id, _ownerId: ownerId, ownerClanId: building.ownerClanId || '', _remote: true, _spawnAnim: 0 };
    buildings.push(_nb);
    _buildingsMap.set(id, _nb);
    if (_nb.type === 10) _campfires.push(_nb);
    const owner = _otherPlayers.get(ownerId);
    const typeNames = { 3:'Kazık', 4:'Değirmen', 5:'Hız Pedi', 6:'Tuzak', 7:'Taret', 8:'Duvar', 9:'Kale', 10:'Kamp Ateşi' };
    floatingTexts.push({ x: building.x, y: building.y - 50,
      text: `🔨 ${owner?.name || '?'}: ${typeNames[building.type] || 'Yapı'}`,
      alpha: 1, life: 50, color: '#ffcc66' });
  });

  // A building was destroyed (server broadcasts "build_destroy" event)
  _socket.on('build_destroy', ({ id }) => {
    const _bdel = _buildingsMap.get(id); // O(1) — was findIndex
    if (_bdel) {
      _buildingsMap.delete(id);
      if (_bdel.type === 10) { const _ci=_campfires.indexOf(_bdel); if(_ci>=0){_campfires[_ci]=_campfires[_campfires.length-1];_campfires.pop();} }
      const idx = buildings.indexOf(_bdel);
      if (idx >= 0) buildings.splice(idx, 1);
    }
    // Clear trap victims for this building (in case it was our trap)
    for (const [victimId, bId] of _myTrapVictims) {
      if (bId === id) _myTrapVictims.delete(victimId);
    }
    // Auto-free us if we were trapped in this building
    if (_trapCaughtBy === id) {
      _trapCaughtBy = null;
      playSound(320, 0.12, 'sine', 0.22);
    }
    // Auto-free any other player trapped in this building
    _otherPlayers.forEach((p) => {
      if (p._trappedBy === id) p._trappedBy = null;
    });
  });

  // Server sends full buildings state after respawn (or on demand)
  // Merges without duplicating — safe to call at any time
  _socket.on('buildings_sync', ({ buildings: remoteBuildings }) => {
    if (!remoteBuildings || typeof remoteBuildings !== 'object') return;
    Object.entries(remoteBuildings).forEach(([bid, b]) => {
      const ownerId = b.ownerId || b._ownerId;
      if (ownerId === _mySocketId) return;
      if (_buildingsMap.has(bid)) return; // O(1) — was buildings.find()
      const _nb = {
        x: b.x, y: b.y, type: b.type, angle: b.angle,
        life: 0, hp: b.hp, maxHp: b.maxHp, tier: b.tier || 0,
        shake: 0, hitTimer: 0,
        _netId: bid, _ownerId: ownerId, ownerClanId: b.ownerClanId || '', _remote: true, _spawnAnim: 0,
      };
      buildings.push(_nb);
      _buildingsMap.set(bid, _nb);
      if (_nb.type === 10) _campfires.push(_nb);
    });
  });

  // Ping response
  _socket.on('pong_res', (d) => {
    const t = d?.t ?? d;
    if (typeof t === 'number') {
      const rawPing = Math.max(0, Math.round(performance.now() - t));
      if (!_ping || _ping <= 0) {
        _ping = rawPing;
      } else {
        // Exponential Weighted Moving Average (EWMA): smooths out single packet jitter without lag
        _ping = Math.round(_ping * 0.75 + rawPing * 0.25);
      }
    }
    if (_pingEl) {
      const col = _ping < 45 ? '#aaffaa' : _ping < 85 ? '#ffee88' : '#ff8888';
      _pingEl.style.color = col;
      _pingEl.style.display = '';
      _pingEl.textContent = `🌐 ${_ping}ms`;
    }
  });

  // Building HP sync from server (another client damaged it) — event is "build_hp_update"
  _socket.on('build_hp_update', ({ id, hp }) => {
    const b = _buildingsMap.get(id); // O(1) — was buildings.find()
    if (!b) return;
    b.hp = hp;
    b.hitTimer = 8; b.shake = 5;
    if (hp <= 0) {
      _buildingsMap.delete(id);
      if (b.type === 10) { const _ci=_campfires.indexOf(b); if(_ci>=0){_campfires[_ci]=_campfires[_campfires.length-1];_campfires.pop();} }
      const idx = buildings.indexOf(b);
      if (idx >= 0) buildings.splice(idx, 1);
    }
  });

  // Building tier upgrade sync (another player upgraded their building)
  _socket.on('build_tier_update', ({ id, tier, maxHp, hp }) => {
    const b = _buildingsMap.get(id); // O(1) — was buildings.find()
    if (!b || b._ownerId === _mySocketId) return;
    b.tier   = Math.min(6, Math.max(0, tier || 0));
    b.maxHp  = maxHp;
    b.hp     = Math.max(1, hp);
    // Invalidate OffscreenCanvas cache so the new tier's visual is drawn on next frame
    const _bTypeKeys = {3:'sp_',5:'bp_',6:'tr_',7:'tu_',8:'wa3_',9:'ca_',10:'cf_'};
    const _bPfx = _bTypeKeys[b.type];
    if (_bPfx) { _bldSC.delete(_bPfx + b.tier); }
    if (b.type === 4) { _wmOC.delete(b.tier); }
    _bldSC.delete('tr_eye_'+b.tier);
    _bldSC.delete('ca_cyd_'+b.tier);
  });

  // Position correction from server when movement was clamped or collision pushed
  _socket.on('pos_correction', (s) => {
    if (!s || !player || player.dead || _isDying) return;
    const sx = Number(s.x);
    const sy = Number(s.y);
    if (!Number.isFinite(sx) || !Number.isFinite(sy)) return;
    if (_trapCaughtBy) {
      _trapCaughtX = sx;
      _trapCaughtY = sy;
    }
    const dist = Math.hypot(sx - player.x, sy - player.y);
    if (dist > 350) {
      player.x = sx;
      player.y = sy;
      _posErrorX = 0;
      _posErrorY = 0;
    } else if (dist > 4) {
      // Smooth error blending over ~100ms instead of snapping back to 100ms in the past
      _posErrorX = (sx - player.x) * 0.6;
      _posErrorY = (sy - player.y) * 0.6;
    }
  });

  // ⑤ CSP Reconciliation: server echoes our own state + seq back via self_state.
  _socket.on('self_state', (s) => {
    if (!s) return;
    if (typeof s.seq === 'number' && s.seq < _mpLastAckedSeq && (_mpLastAckedSeq - s.seq < 500)) return;
    if (typeof s.seq === 'number') {
      _mpLastAckedSeq = s.seq;
    }
    // Server-authoritative hp/xp/kills/resources — preserve local progress without reverting
    if (typeof s.hp === 'number') player.hp = s.hp;
    if (player.hp <= 0 && !_isDying) die();
    if (typeof s.sc === 'number') player.score = Math.max(player.score || 0, s.sc);
    if (typeof s.g === 'number') player.gold = Math.max(player.gold || 0, s.g);
    if (typeof s.apples === 'number') player.apples = Math.max(player.apples || 0, s.apples);
    if (typeof s.wood === 'number') player.wood = Math.max(player.wood || 0, s.wood);
    if (typeof s.stone === 'number') player.stone = Math.max(player.stone || 0, s.stone);
    // Reconcile if position diverges significantly (e.g. server collision push or lag spike)
    if (typeof s.x === 'number' && typeof s.y === 'number' && !player.dead && !_isDying) {
      const pDist = Math.hypot(s.x - player.x, s.y - player.y);
      if (pDist > 350) {
        player.x = s.x;
        player.y = s.y;
        _posErrorX = 0;
        _posErrorY = 0;
      } else if (pDist > 60 && Math.abs(player.vx||0) < 0.2 && Math.abs(player.vy||0) < 0.2) {
        _posErrorX = (s.x - player.x) * 0.4;
        _posErrorY = (s.y - player.y) * 0.4;
      }
    }
    updateUI();
  });

  // Helper: Starve.io-style leaderboard row renderer (Ranked by Gold)
  function _renderStarveLeaderboard(entries) {
    if (!lbRowsEl) return;
    if (!entries || !entries.length) {
      lbRowsEl.innerHTML = '<div style="color:rgba(255,255,255,0.3);text-align:center;padding:6px;font-size:10px;font-style:italic">Oyuncu aranıyor...</div>';
      return;
    }
    // Sort by gold descending
    const sorted = [...entries].sort((a, b) => {
      const gA = typeof a.gold === 'number' ? a.gold : (Number(a.score) || 0);
      const gB = typeof b.gold === 'number' ? b.gold : (Number(b.score) || 0);
      return gB - gA;
    });
    lbRowsEl.innerHTML = sorted.slice(0, 10).map((e, idx) => {
      const isMe = e.isMe || (player && (e.name === player.name || e.id === _mySocketId));
      const goldNum = typeof e.gold === 'number' ? e.gold : (Number(e.score) || 0);
      const pts = formatScore(goldNum);
      const safeName = String(e.name || 'Oyuncu').replace(/[<>]/g, '').slice(0, 13);
      return `<div class="lb-row${isMe ? ' me' : ''}">
        <span class="lb-name">${safeName}</span>
        <span class="lb-score" style="color:#ffd700;font-weight:900;"><img class="lb-gold-icon" src="asset/gold.png" alt="Altın">${pts}</span>
      </div>`;
    }).join('');
  }

  // Server-authoritative live leaderboard (broadcast every 2s)
  _socket.on('live_lb', (entries) => {
    if (!Array.isArray(entries)) return;
    var _lbSig = entries.map(e => e.name + ':' + (e.gold||e.score||0)).join('|');
    if (lbRowsEl._lastSig === _lbSig) return;
    lbRowsEl._lastSig = _lbSig;
    _renderStarveLeaderboard(entries);
  });

  // Server tells us a trap was triggered
  _socket.on('trap_triggered', ({ buildingId, victimId, bId, targetName, dmg }) => {
    const bNetId = buildingId || bId;
    const b = _buildingsMap.get(bNetId) || buildings.find(x => (x._netId === bNetId || x.id === bNetId));
    const bx = b ? b.x : player.x;
    const by = b ? b.y : player.y;
    if (victimId && victimId !== _mySocketId) {
      const victim = _otherPlayers.get(victimId);
      if (victim) {
        victim._trappedBy = bNetId;
        const vX = Number.isFinite(Number(x)) ? Number(x) : victim.x;
        const vY = Number.isFinite(Number(y)) ? Number(y) : victim.y;
        victim._trappedX = vX;
        victim._trappedY = vY;
        victim.x = vX;
        victim.y = vY;
        victim.vx = 0;
        victim.vy = 0;
      }
    }
    playSound(180 + Math.random()*60, 0.1, 'square', 0.25);
    for (let i = 0; i < 10; i++) {
      const a = Math.random() * Math.PI * 2;
      particles.push({ x: bx, y: by, vx: Math.cos(a)*5, vy: Math.sin(a)*5-2,
        r: 3+Math.random()*3, life: 20+Math.random()*12, maxLife: 32, color: '#cc88ff' });
    }
  });

  // Remote swing event from server — instant 60 FPS attack animation
  _socket.on('remote_swing', ({ id, weapon, axeTier, swordTier, angle, attackDuration }) => {
    const other = _otherPlayers.get(id);
    if (other) {
      other.weapon = weapon || other.weapon || 1;
      if (axeTier !== undefined) other.axeTier = axeTier;
      if (swordTier !== undefined) other.swordTier = swordTier;
      if (typeof angle === 'number') {
        other.angle = angle;
        other._targetAngle = angle;
      }
      other.isAttacking = true;
      other.attackTimer = 1;
      other.attackDuration = Number.isFinite(attackDuration)
        ? Math.max(1, attackDuration)
        : (ATTACK_DUR[other.weapon] || 20);
    }
  });

  // Server confirms our spike/windmill hit someone
  _socket.on('spike_dmg_confirm', ({ targetId, dmg, targetName }) => {
    player.totalDmg = (player.totalDmg || 0) + dmg; // bug fix: spike dmg was missing from stat
    const other = _otherPlayers.get(targetId);
    const sx = other ? other.x : player.x + 80;
    const sy = other ? other.y : player.y;
    floatingTexts.push({ x: sx, y: sy - 30, text: `-${dmg} 🗡️`, alpha: 1, life: 30, color: '#ffbb44' });
  });

  // Online player count update (server sends a plain number)
  _socket.on('online_count', (n) => {
    const count = (typeof n === 'object' && n !== null) ? (n.count ?? n) : n;
    if (_pingEl && _ping > 0) _pingEl.textContent = `🌐 ${_ping}ms · ${count} çevrimiçi`;
  });

  // Trap caught — server froze us in a trap
  _socket.on('trap_caught', ({ buildingId, x, y }) => {
    if (!player || player.dead) return;
    const snapX = Number.isFinite(Number(x)) ? Number(x) : player.x;
    const snapY = Number.isFinite(Number(y)) ? Number(y) : player.y;
    _trapPendingId = null;
    _trapPendingUntil = 0;
    _trapCaughtBy = buildingId;
    _trapCaughtX = snapX;
    _trapCaughtY = snapY;
    player.x = snapX;
    player.y = snapY;
    player.vx = 0; player.vy = 0; player.momX = 0; player.momY = 0;
    playSound(180, 0.18, 'sawtooth', 0.35);
  });

  // Trap freed — trap was destroyed or owner left
  _socket.on('trap_freed', ({ buildingId } = {}) => {
    if (!buildingId || _trapPendingId === buildingId) {
      _trapPendingId = null;
      _trapPendingUntil = 0;
    }
    if (!buildingId || _trapCaughtBy === buildingId) {
      _clearTrapLock();
      playSound(320, 0.12, 'sine', 0.22);
    }
    _otherPlayers.forEach((p) => {
      if (!buildingId || p._trappedBy === buildingId) p._trappedBy = null;
    });
  });

  // Spike knockback — server pushes us away from a spike we just touched
  _socket.on('spike_push', ({ dx, dy, force }) => {
    if (!player || player.dead) return;
    // Trapped players CANNOT be knocked back by spikes (server should not send this
    // when trapped, but guard client-side too for safety)
    if (_trapCaughtBy) return;
    const f = Math.min(force || 180, 260);
    player.momX = (player.momX || 0) + dx * f * 0.016;
    player.momY = (player.momY || 0) + dy * f * 0.016;
  });

  // Trap owner slowly pushed us — update our position
  _socket.on('trap_victim_push', ({ dx, dy }) => {
    if (!player || player.dead || !_trapCaughtBy) return;
    if (typeof dx !== 'number' || typeof dy !== 'number') return;
    player.x += dx;
    player.y += dy;
    _trapCaughtX = player.x;
    _trapCaughtY = player.y;
    const _bnd = PLAY_RADIUS - player.radius - 10;
    player.x = Math.max(-_bnd, Math.min(_bnd, player.x));
    player.y = Math.max(-_bnd, Math.min(_bnd, player.y));
    _trapCaughtX = player.x;
    _trapCaughtY = player.y;
    const _ptb = _buildingsMap.get(_trapCaughtBy); // O(1) — was buildings.find()
    if (_ptb) {
      const _pdist = Math.hypot(player.x - _ptb.x, player.y - _ptb.y);
      if (_pdist > (_ptb.radius || 26) + 44) {
        _trapCaughtBy = null;
        _trapCaughtX = undefined;
        _trapCaughtY = undefined;
        playSound(320, 0.12, 'sine', 0.22);
      }
    } else {
      _trapCaughtBy = null;
      _trapCaughtX = undefined;
      _trapCaughtY = undefined;
    }
  });

  // Trap owner notification — one of our trapped victims was freed
  _socket.on('trap_victim_freed', ({ victimId }) => {
    _myTrapVictims.delete(victimId);
  });

  // Boost pad received from another player's pad
  _socket.on('boost_received', ({ angle }) => {
    player.momX += Math.cos(angle) * 11;
    player.momY += Math.sin(angle) * 11;
    floatingTexts.push({ x: player.x, y: player.y - 30, text: '💨 HIZ!', alpha: 1, life: 28, color: '#ffe066' });
  });

  // ─── In-game chat (moomoo.io/sploop.io style) ───────────────────────────
  _socket.on('chat', ({ name, msg, id }) => {
    const isMe = id === _mySocketId;
    if (!isMe) {
      const op = _otherPlayers.get(id);
      if (op) { op._chatMsg = msg; op._chatExpiry = Date.now() + 4500; }
    }
    pushKillFeed(`💬 ${name}: ${msg}`);
  });

  _socket.on('quick_chat', ({ name, id, idx, x, y }) => {
    const chat = QUICK_CHATS[Number(idx)];
    if (!chat || id === _mySocketId) return;
    const op = _otherPlayers.get(id);
    const chatX = Number.isFinite(Number(x)) ? Number(x) : op?.x;
    const chatY = Number.isFinite(Number(y)) ? Number(y) : op?.y;
    if (!Number.isFinite(chatX) || !Number.isFinite(chatY)) return;
    if (op) {
      op._chatMsg = chat.emoji + ' ' + chat.text;
      op._chatExpiry = Date.now() + 4500;
    }
    floatingTexts.push({ x: chatX, y: chatY - 120, text: chat.emoji + ' ' + chat.text, alpha: 1, life: 120, color: '#ffffff', big: true });
    addKillFeed('💬 ' + (name || op?.name || 'Oyuncu') + ': ' + chat.text, '#aaffaa');
    playSound(440, 0.06, 'sine', 0.15);
  });

  // ── Resource sync: server broadcast a resource HP update ─────────────
  _socket.on('res_sync', ({ idx, hp, shake }) => {
    const res = resources[idx];
    if (!res) return;
    if (shake) {
      res.shake = Math.max(res.shake || 0, 5);
      if (!res.shakeAng) res.shakeAng = 0;
    }
  });

  // ── Resource respawn: server says resource is back ────────────────────
  _socket.on('res_respawn', ({ idx }) => {
    const res = resources[idx];
    if (!res) return;
    res.hp = res.maxHp;
    res._destroyed = false;
    res.shake = 0;
    floatingTexts.push({ x: res.x, y: res.y - res.radius - 14, text: '✨ Yenilendi!', alpha:1, life:45, color:'#aaffaa' });
  });

  function isActiveMobShape(shape) {
    if (!shape) return true;
    return true; // Never drop any active server mob
  }

  // ── New mob spawned after we joined — full visual data ────────────────
  _socket.on('mob_spawn', (m) => {
    if (!m || !m.id || !isActiveMobShape(m.shape)) return;
    const now = Date.now();
    const already = enemies.find(en => en._netId === m.id);
    if (already) return;
    enemies.push({ _netId: m.id, x: m.x, y: m.y, _targetX: m.x, _targetY: m.y,
      vx: m.vx||0, vy: m.vy||0,
      hp: m.hp, maxHp: m.maxHp||m.hp, radius: m.radius||36,
      color: m.color||'#4a7a28', outline: m.outline||'#1a3a08',
      shape: m.shape||'goblin', eyes: m.eyes||'#ffee00',
      hitFlash: 0, typeName: m.typeName||'Düşman',
      dmg: m.dmg||10, speed: 0, xpReward: m.xpReward||25, goldReward: m.goldReward||5,
      provoked: true, lastHit: 0, lastBuildHit: 0, lastSpikeHit: 0, lastResHit: 0, lastHitSwingId: -1,
      angle: 0, _lastSeen: now, isBoss: m.isBoss||false });
    // Boss bar: show when a server boss mob spawns
    if (m.isBoss && !_serverBossId) {
      _serverBossId = m.id;
      _serverBossName = m.typeName || '👑 Boss';
      _updateServerBossBar(m.hp, m.maxHp||m.hp);
    }
  });

  // ── Mob states from server (authoritative, all players receive) ───────
  _socket.on('mob_states', (mobs) => {
    if (!Array.isArray(mobs)) return;
    // PERF: reuse module-level map — was new Map() every 50ms (20Hz GC pressure eliminated)
    _enemyLocalMap.clear();
    for (const e of enemies) { if (e._netId) _enemyLocalMap.set(e._netId, e); }
    // Update existing or add new — NEVER remove mobs that aren't in this partial update.
    // Partial updates only include CHANGED mobs; stationary mobs are omitted intentionally.
    // Removal only happens via mob_dead event or periodic mob_ids full sync.
    const now = Date.now();
    for (const m of mobs) {
      if (!isActiveMobShape(m.shape)) continue;
      const ex = _enemyLocalMap.get(m.id);
      if (ex) {
        ex._targetX = m.x; ex._targetY = m.y;
        ex.vx = m.vx||0; ex.vy = m.vy||0;
        ex.hp = m.hp;
        if (typeof m.maxHp === 'number') ex.maxHp = m.maxHp;
        if (m.hitFlash > 0) ex.hitFlash = m.hitFlash;
        if (m.angle != null) ex.angle = m.angle;
        else if (m.vx !== 0 || m.vy !== 0) ex.angle = Math.atan2(m.vy, m.vx);
        ex._lastSeen = now;
        if (!ex.color && m.color) { ex.color = m.color; ex.outline = m.outline; ex.shape = m.shape||'wolf'; ex.eyes = m.eyes||'#ffee00'; ex.radius = m.radius||46; }
      } else if (m.id) {
        enemies.push({ _netId: m.id, x: m.x, y: m.y, _targetX: m.x, _targetY: m.y,
          vx: m.vx||0, vy: m.vy||0,
          hp: m.hp || 100, maxHp: m.maxHp||m.hp||100, radius: m.radius||46,
          color: m.color||'#6b4932', outline: m.outline||'#28170d', shape: m.shape||'wolf',
          eyes: m.eyes||'#ffcc66', hitFlash: m.hitFlash||0, typeName: m.typeName||'🐺 Kurt',
          dmg: m.dmg||28, speed: 0, xpReward: m.xpReward||50, goldReward: m.goldReward||20,
          provoked: true, lastHit: 0, lastBuildHit: 0, lastSpikeHit: 0, lastResHit: 0, lastHitSwingId: -1,
          angle: m.angle||0, _lastSeen: now, isBoss: m.isBoss||false });
        if (m.isBoss && !_serverBossId) {
          _serverBossId = m.id;
          _serverBossName = m.typeName || '👑 Boss';
          _updateServerBossBar(m.hp, m.maxHp||m.hp);
        }
      }
    }
  });

  // ── BINARY mob_states decoder — replaces JSON parse overhead at 20Hz ──────
  // Server sends mob_states_b: [count:u16, per_mob: idx:u16 x:f32 y:f32 vx:f32 vy:f32 ang:f32 hp:u16]
  // 20 mobs = 2 + 20×24 = 482 bytes binary vs ~2000 bytes JSON.
  _socket.on('mob_states_b', (buf) => {
    let ab;
    if (buf instanceof ArrayBuffer) { ab = buf; }
    else if (ArrayBuffer.isView(buf)) { ab = buf.buffer; }
    else return;
    const dv = new DataView(ab, (buf.byteOffset || 0));
    if (dv.byteLength < 2) return;
    let off = 0;
    const count = dv.getUint16(off, true); off += 2;
    _enemyLocalMap.clear();
    for (const e of enemies) { if (e._netId) _enemyLocalMap.set(e._netId, e); }
    const now = Date.now();
    for (let i = 0; i < count; i++) {
      if (off + 24 > dv.byteLength) break;
      const idx = dv.getUint16(off, true); off += 2;
      const x   = dv.getFloat32(off, true); off += 4;
      const y   = dv.getFloat32(off, true); off += 4;
      const vx  = dv.getFloat32(off, true); off += 4;
      const vy  = dv.getFloat32(off, true); off += 4;
      const ang = dv.getFloat32(off, true); off += 4;
      const hp  = dv.getUint16(off, true);  off += 2;
      const id  = _mobIdArr[idx];
      if (!id) continue;
      const ex = _enemyLocalMap.get(id);
      if (ex) {
        ex._targetX = x; ex._targetY = y;
        ex.vx = vx; ex.vy = vy; ex.hp = hp;
        if (ang > -9000) ex.angle = ang;
        else if (vx !== 0 || vy !== 0) ex.angle = Math.atan2(vy, vx);
        ex._lastSeen = now;
      } else {
        const mobNum = parseInt(String(id).replace(/\D/g, '')) || 1;
        const typeIndex = (mobNum - 1) % 4;
        const defaultTypes = [
          { shape: 'wolf', color: '#6b4932', outline: '#28170d', eyes: '#ffcc66', typeName: '🐺 Kurt', radius: 46, maxHp: 300, dmg: 28 },
          { shape: 'scorpion', color: '#4a2818', outline: '#1a0d06', eyes: '#ff4400', typeName: '🦂 Akrep', radius: 52, maxHp: 520, dmg: 46 },
          { shape: 'bear', color: '#4a2f1b', outline: '#1a1008', eyes: '#ffaa00', typeName: '🐻 Ayı', radius: 65, maxHp: 950, dmg: 72 },
          { shape: 'spider', color: '#2a1a38', outline: '#0f0814', eyes: '#ff1100', typeName: '🕷️ Örümcek', radius: 48, maxHp: 380, dmg: 34 }
        ];
        const tDef = defaultTypes[typeIndex] || defaultTypes[0];
        const newMob = {
          _netId: id, x: x, y: y, _targetX: x, _targetY: y,
          vx: vx, vy: vy, hp: hp || tDef.maxHp, maxHp: tDef.maxHp, radius: tDef.radius,
          color: tDef.color, outline: tDef.outline, shape: tDef.shape,
          eyes: tDef.eyes, hitFlash: 0, typeName: tDef.typeName,
          dmg: tDef.dmg, speed: 0, xpReward: 80, goldReward: 35,
          provoked: true, lastHit: 0, lastBuildHit: 0, lastSpikeHit: 0, lastResHit: 0, lastHitSwingId: -1,
          angle: ang > -9000 ? ang : 0, _lastSeen: now, isBoss: false
        };
        enemies.push(newMob);
        _enemyLocalMap.set(id, newMob);
      }
    }
  });

  // ── Periodic full mob ID sync — removes truly stale local mobs ────────
  _socket.on('mob_ids', (ids) => {
    if (!Array.isArray(ids)) return;
    _mobIdArr = ids; // keep for binary mob_states_b index decoding
      if (ids.length === 0) return;
    const idSet = new Set(ids);
    for (let i = enemies.length - 1; i >= 0; i--) {
      if (enemies[i]._netId && !idSet.has(enemies[i]._netId)) enemies.splice(i, 1);
    }
    // Orphaned boss bar cleanup: hide if tracked boss is no longer in the mob list
    if (_serverBossId && !idSet.has(_serverBossId)) _hideServerBossBar();
  });

  // ── Kill reward for the player who dealt the killing blow ─────────────
  _socket.on('mob_kill_reward', ({ xp, gold, score, typeName }) => {
    const _bcScoreGain = score || Math.round(xp * 0.75 + gold * 3);
    player.xp += xp; player.kills++;
    player.gold += gold;
    player.score = (player.score||0) + _bcScoreGain;
    _playerLevelKills++; _checkPlayerLevel();
    updateUI(); updateXP();
    _killCamTimer = 40; _killCamX = player.x; _killCamY = player.y;
    if (player.vampire) { player.hp = Math.min(player.maxHp, player.hp + 12); updateHpBar(); floatingTexts.push({ x: player.x, y: player.y - 40, text: '🧛 +12 HP', alpha: 1, life: 35, color: '#cc55ff' }); }
    if(Math.random()<0.22) spawnArmorDrop(player.x, player.y);
    floatingTexts.push({ x: player.x, y: player.y - 55, text: `⚔️ +${xp} XP  +${_bcScoreGain}⭐`, alpha: 1, life: 50, color: '#ffe555' });
  });

  // ── Instant mob HP/hitFlash update on hit ─────────────────────────────
  _socket.on('mob_update', (m) => {
    if (!m || !m.id) return;
    const e = enemies.find(en => en._netId === m.id);
    if (!e) return;
    if (typeof m.hp === 'number') {
      e.hp = m.hp;
      // Boss bar: live HP update
      if (m.id === _serverBossId) _updateServerBossBar(m.hp, e.maxHp);
    }
    if (typeof m.hitFlash === 'number' && m.hitFlash > 0) e.hitFlash = m.hitFlash;
    if (typeof m.x === 'number') { e._targetX = m.x; e._targetY = m.y; }
    if (typeof m.angle === 'number') e.angle = m.angle;
  });

  // ── Mob tuzak dondurma sync — sunucu otoriteli, tüm yakın oyuncular görür ──
  // Tuzak sahibi olmayan oyuncular da mobun donduğunu anında görür.
  _socket.on('mob_trapped', ({ mobId, buildingId, x, y, frozenAngle }) => {
    const e = enemies.find(en => en._netId === mobId);
    if (!e) return;
    if (e._capturedByTrap) return; // zaten dondurulmuş (kendi tuzağımız tetikledi)
    e._capturedByTrap = buildingId;
    e._capturedTrapX = x; e._capturedTrapY = y;
    e._frozenAngle = (frozenAngle !== undefined ? frozenAngle : (e.angle || 0));
    e.vx = 0; e.vy = 0;
    e.x = x; e.y = y;
    e._targetX = x; e._targetY = y;
    // Buz kristali parçacıkları
    if (_qualityLevel >= 1) {
      for (let _ti = 0; _ti < 6; _ti++) {
        const _ta = Math.random() * Math.PI * 2;
        _spawnParticle(x + Math.cos(_ta) * 12, y + Math.sin(_ta) * 12,
          Math.cos(_ta) * 1.8, Math.sin(_ta) * 1.8 - 0.6,
          3 + Math.random() * 3, 18 + Math.random() * 12, '#88ddff');
      }
    }
    playSound(220, 0.06, 'sine', 0.18);
  });

  // ── Mob tuzaktan serbest kalma sync ────────────────────────────────────
  _socket.on('mob_freed', ({ mobId }) => {
    const e = enemies.find(en => en._netId === mobId);
    if (!e) return;
    e._capturedByTrap = null;
    e._capturedTrapX = undefined;
    e._capturedTrapY = undefined;
    e._frozenAngle = undefined;
    e._capturedTrapTime = undefined;
  });

  _socket.on('boss_telegraph', (d) => {
    if (!d || !d.mobId) return;
    // Cap to prevent CPU spike: 3 on mobile (fewer ctx ops), 6 on desktop
    const _tgCap = _isMobile ? 3 : 6;
    if (bossTelegraphs.length < _tgCap) bossTelegraphs.push({ ...d, startTime: Date.now() });
  });

  _socket.on('mob_trap_freed', ({ mobId }) => {
    const e = enemies.find(en => en._netId === mobId);
    if (!e) return;
    const fx = e._capturedTrapX || e.x;
    const fy = e._capturedTrapY || e.y;
    e._capturedByTrap = null;
    e._capturedTrapRef = null;
    e._capturedTrapX = undefined; e._capturedTrapY = undefined;
    e._frozenAngle = undefined;
    if (_qualityLevel >= 1) {
      for (let _ti = 0; _ti < 5; _ti++) {
        const _ta = Math.random() * Math.PI * 2;
        _spawnParticle(fx + Math.cos(_ta) * 14, fy + Math.sin(_ta) * 14,
          Math.cos(_ta) * 2.2, Math.sin(_ta) * 2.2 - 0.4,
          3 + Math.random() * 2, 14 + Math.random() * 10, '#ffcc44');
      }
    }
    playSound(340, 0.07, 'triangle', 0.15);
  });

  // ── Mob died — remove immediately, don't wait for next bulk tick ─────
  _socket.on('mob_dead', ({ id }) => {
    const idx = enemies.findIndex(en => en._netId === id);
    if (idx !== -1) {
      const e = enemies[idx];
      spawnBlood(e.x, e.y, 4); // was 12 — fewer particles = less CPU spike on rapid kills
      spawnGoldBurst(e.x, e.y);
      if (e.shape === 'wolf') _incQuestStat('wolves', 1);
      else if (e.shape === 'bear') _incQuestStat('bears', 1);
      else if (e.shape === 'scorpion') _incQuestStat('scorpions', 1);
      else if (e.shape === 'spider') _incQuestStat('spiders', 1);
      enemies.splice(idx, 1);
    }
    // Boss bar: hide if the boss was killed
    if (id === _serverBossId) _hideServerBossBar();
  });

  // ── Mob attacks player (server-authoritative damage & animation) ───────
  _socket.on('mob_attack', ({ id, targetId, dmg, hp, typeName, shape, isWeb, x, y, angle, targetX, targetY }) => {
    if (isWeb && id) {
      const _now = Date.now();
      const _lastWeb = _mobWebCooldowns.get(id) || 0;
      if (_now - _lastWeb < 5000) return;
      _mobWebCooldowns.set(id, _now);
    }
    let attackingMob = null;
    if (id) {
      attackingMob = enemies.find(en => en._netId === id);
      if (attackingMob) {
        attackingMob.state = 'attack';
        attackingMob.attackTimer = 0;
        if (typeof angle === 'number') attackingMob.angle = angle;
      } else if (typeof x === 'number' && typeof y === 'number') {
        const defaultShape = shape || 'wolf';
        const newMob = {
          _netId: id, x: x, y: y, _targetX: x, _targetY: y,
          vx: 0, vy: 0, hp: 100, maxHp: 100, radius: defaultShape === 'bear' ? 65 : (defaultShape === 'scorpion' ? 52 : 48),
          color: defaultShape === 'spider' ? '#2a1a38' : (defaultShape === 'bear' ? '#4a2f1b' : '#6b4932'),
          outline: '#111', shape: defaultShape, eyes: '#ff1100', hitFlash: 0,
          typeName: typeName || (defaultShape === 'spider' ? '🕷️ Örümcek' : '🐺 Kurt'),
          dmg: dmg || 25, speed: 0, xpReward: 80, goldReward: 35,
          provoked: true, lastHit: 0, lastBuildHit: 0, lastSpikeHit: 0, lastResHit: 0, lastHitSwingId: -1,
          angle: angle || 0, _lastSeen: Date.now(), isBoss: false
        };
        enemies.push(newMob);
        attackingMob = newMob;
      }
    }
    const mobShape = shape || (attackingMob ? attackingMob.shape : 'wolf');
    const ax = typeof x === 'number' ? x : (attackingMob ? attackingMob.x : player.x);
    const ay = typeof y === 'number' ? y : (attackingMob ? attackingMob.y : player.y);
    const tx = typeof targetX === 'number' ? targetX : player.x;
    const ty = typeof targetY === 'number' ? targetY : player.y;
    spawnMobAttackEffect(isWeb ? 'spider_web' : mobShape, ax, ay, angle, tx, ty);

    if (targetId && _mySocketId && targetId !== _mySocketId) {
      const tgt = _otherPlayers.get(targetId);
      if (tgt) {
        tgt.hp = Math.max(0, typeof hp === 'number' ? hp : tgt.hp - dmg);
        spawnBlood(tgt.x, tgt.y, 6);
        floatingTexts.push({ x: tgt.x, y: tgt.y - 40, text: `-${dmg} HP`, alpha: 1, life: 35, color: '#ff3333' });
      }
      return;
    }
    if (_isDying || _spawnProtected) return;
    if (isWeb) {
      // Spider web projectile is in flight — damage & 1.5s root are applied on projectile contact!
      return;
    }
    // Prevent phantom damage: verify attacking mob coordinates are within range of player
    const mobDist = Math.hypot(player.x - ax, player.y - ay);
    if (mobDist > 220) return; // ignore stale/desynced phantom attack
    const _prevHp = player.hp;
    const directDmg = Math.max(1, Math.round(dmg * (1 - (player.armorBonus || 0))));
    player.hp = Math.max(0, typeof hp === 'number' ? hp : player.hp - directDmg);
    shake(12);
    spawnBlood(player.x, player.y, 8);
    triggerDmgFlash();
    const _actualDmg = Math.round(_prevHp - player.hp);
    const _showDmg = _actualDmg > 0 ? _actualDmg : directDmg;
    const _sourceName = typeName || (mobShape === 'bear' ? '🐻 Ayı' : (mobShape === 'scorpion' ? '🦂 Akrep' : (mobShape === 'spider' ? '🕷️ Örümcek' : '🐺 Kurt')));
    floatingTexts.push({ x: player.x, y: player.y - 50, text: `-${_showDmg} HP (${_sourceName})`, alpha: 1, life: 45, color: '#ff3333', big: true });
    if (typeName) _lastDamager = { typeName: _sourceName };
    playSound(95 + Math.floor(Math.random()*40), 0.16, 'sawtooth', 0.35);
    updateHpBar();
    if (player.hp <= 0 && !_isDying) die();
  });

  // ── Another player respawned — add back to render map ───────────────
  // ── Server's authoritative respawn position for OWN player ─────────────────
  // This is the single source of truth — avoids 3-way race between:
  // client randomForestPoint / _handlePvpKill server pos / respawn handler server pos
  _socket.on('own_respawn', ({ x, y }) => {
    player.x = x;
    player.y = y;
    // PERF: Immediately snap camera to respawn position so _buildGdLayer does NOT
    // rebuild every frame while camera slowly catches up (was causing FPS to halve).
    // Without this, camera lerps from death pos → spawn pos over many frames,
    // triggering a ground layer rebuild (2700+ canvas ops) each frame.
    if (canvas.width > 0) {
      camX = x - canvas.width / 2;
      camY = y - canvas.height / 2;
      // Sync the ground cache coords so no rebuild is triggered on first post-grace frame
      _gdCachedCamX = camX;
      _gdCachedCamY = camY;
    }
    floatingTexts.push({ x: player.x, y: player.y - 80, text: '🛡️ 3 Saniyelik Koruma!', alpha: 1, life: 100, color: '#44ddff', big: true });
  });

  _socket.on('player_respawn', ({ id, state }) => {
    if (id === _mySocketId) return; // own position handled by own_respawn
    const _prS = state;
    _otherPlayers.set(id, {
      name: _prS.n || _prS.name || '?', skin: _prS.sk || _prS.skin || 'default',
      x: _prS.x ?? 0, y: _prS.y ?? 0, angle: _prS.a ?? _prS.angle ?? 0,
      vx: _prS.vx || 0, vy: _prS.vy || 0,
      hp: _prS.hp ?? 100, maxHp: _prS.mhp ?? _prS.maxHp ?? 100,
      weapon: _prS.w ?? _prS.weapon ?? 1, isAttacking: _prS.atk ?? false,
      kills: _prS.k ?? 0, xp: _prS.xp ?? 0, gold: _prS.g ?? 0, score: _prS.sc ?? 0,
      axeTier: _prS.at ?? 0, swordTier: _prS.st ?? 0,
      rankId: _prS.rk ?? 0, color: _prS.color || '#8B5E3A', team: _prS.team || '',
      acc: _prS.acc || {},
      buildX: (typeof _prS.bx === 'number') ? _prS.bx : null,
      buildY: (typeof _prS.by === 'number') ? _prS.by : null,
      _sx: _prS.x ?? 0, _sy: _prS.y ?? 0, _targetAngle: _prS.a ?? _prS.angle ?? 0,
      _snapshots: [{ t: Date.now(), x: _prS.x ?? 0, y: _prS.y ?? 0, a: _prS.a ?? 0, vx: _prS.vx || 0, vy: _prS.vy || 0 }],
    });
  });

}

let _gameClan = null;
let _gameClanOwner = false;
function _toggleInGameClan() {
  const panel = document.getElementById('clan-game-panel');
  if (!panel) return;
  panel.classList.toggle('show');
  if (panel.classList.contains('show') && _socket?.connected) _socket.emit('clan_get');
}
const _clanButton = document.getElementById('clan-game-btn');
if (_clanButton) _clanButton.addEventListener('click', _toggleInGameClan);
function _setupInGameClan() {
  const panel = document.getElementById('clan-game-panel');
  const button = document.getElementById('clan-game-btn');
  if (!panel || !button || panel.dataset.ready) return;
  panel.dataset.ready = '1';
  const status = (message) => { const el = document.getElementById('clan-game-status'); if (el) el.textContent = message || ''; };
  const render = (clan) => {
    _gameClan = clan; _gameClanOwner = clan.ownerId === _mySocketId || clan.ownerName === player.name;
    button.innerHTML = `🛡️ [${clan.tag || 'KLAN'}] ${clan.name}`;
    document.getElementById('clan-game-empty').style.display = 'none';
    document.getElementById('clan-game-owned').style.display = 'block';
    document.getElementById('clan-game-title').textContent = `${clan.name} [${clan.tag}]`;
    const code = document.getElementById('clan-game-code-show'); code.textContent = 'Kod: ' + clan.id.toUpperCase();
    code.onclick = () => navigator.clipboard?.writeText(clan.id).then(() => status('Klan kodu kopyalandı'));
    document.getElementById('clan-game-members').innerHTML = (clan.members || []).map(member => `<div class="clan-game-member">🛡️ <span>${member.name}${member.name === clan.ownerName ? ' 👑' : ''}</span>${_gameClanOwner && member.id !== _mySocketId ? `<button data-kick="${member.id}">At</button>` : ''}</div>`).join('');
    panel.querySelectorAll('[data-kick]').forEach(el => el.onclick = () => _socket.emit('clan_kick', { memberId: el.dataset.kick }));
  };
  const showEmpty = () => {
    _gameClan = null;
    button.innerHTML = '🛡️ Klan (Oluştur / Katıl)';
    document.getElementById('clan-game-empty').style.display = 'block';
    document.getElementById('clan-game-owned').style.display = 'none';
  };
  document.getElementById('clan-game-close').onclick = () => panel.classList.remove('show');
  document.getElementById('clan-game-create').onclick = () => _socket?.emit('clan_create', { name: document.getElementById('clan-game-name').value, tag: document.getElementById('clan-game-tag').value });
  document.getElementById('clan-game-join').onclick = () => _socket?.emit('clan_join', { id: document.getElementById('clan-game-code').value.trim().toLowerCase() });
  document.getElementById('clan-game-leave').onclick = () => _socket?.emit('clan_leave');
  _socket.on('clan_joined', render); _socket.on('clan_update', render);
  _socket.on('clan_left', showEmpty); _socket.on('clan_kicked', showEmpty);
  _socket.on('clan_error', data => status(data?.msg || 'Klan işlemi başarısız.'));
}

// ─── Chat input (Enter key) ──────────────────────────────────────────────────
document.addEventListener('keydown', (e) => {
  if (!_connected) return;
  if (e.key === 'Enter') {
    if (_chatInput && document.body.contains(_chatInput)) {
      // Submit
      const msg = _chatInput.value.trim().slice(0, 60);
      if (msg) {
        _socket.emit('chat', { msg });
        // Show local bubble
        player._chatMsg = msg; player._chatExpiry = Date.now() + 4500;
        pushKillFeed(`💬 ${player.name}: ${msg}`);
      }
      document.body.removeChild(_chatInput);
      _chatInput = null;
    } else if (!_chatInput) {
      // Open chat
      _chatInput = document.createElement('input');
      _chatInput.type = 'text'; _chatInput.maxLength = 60;
      _chatInput.placeholder = 'Mesaj yaz... (Enter gönder, Esc iptal)';
      Object.assign(_chatInput.style, {
        position:'fixed', bottom:'90px', left:'50%', transform:'translateX(-50%)',
        width:'320px', padding:'10px 16px', borderRadius:'22px',
        border:'2.5px solid rgba(255,255,255,0.5)', background:'rgba(0,0,0,0.72)',
        color:'#fff', fontSize:'15px', fontFamily:'Arial', outline:'none', zIndex:'9999'
      });
      document.body.appendChild(_chatInput);
      setTimeout(() => _chatInput && _chatInput.focus(), 10);
      _chatInput.addEventListener('keydown', ev => {
        if (ev.key === 'Escape') { document.body.removeChild(_chatInput); _chatInput = null; ev.stopPropagation(); }
        if (ev.key === 'Enter') ev.stopPropagation(); // handled by document listener above
      });
    }
  }
});

// ⑤ CSP Reconciliation: seq counter — each state emit gets a unique seq number.
// Server echoes seq back in self_state. Client uses this to verify its position was accepted.
let _mpSeq = 0;
let _mpLastAckedSeq = 0; // last seq acknowledged by server
let _mpPredictedX = null, _mpPredictedY = null; // last predicted position sent to server

// Dead-zone: skip state emit if change is negligible (saves bandwidth on idle)
function _mpUpdate() {
  if (!_connected || !_socket) return;
  if (_isDying) return; // dead — don't send stale positions

  // Fixed network tick rate (~30Hz moving / ~12Hz idle) decoupled from screen refresh rate
  const now = performance.now();
  const _moving = Math.abs(player.vx||0) > 0.3 || Math.abs(player.vy||0) > 0.3 || player.isAttacking || player.weapon >= 3;
  const minInterval = _moving ? 33 : 85;
  if (now - _lastMpSendTime < minInterval) return;

  const dx = Math.abs(player.x - _lastEmitX);
  const dy = Math.abs(player.y - _lastEmitY);
  const da = Math.abs(player.angle - _lastEmitAngle);
  const dhp = Math.abs(player.hp - _lastEmitHp);
  const dsc = Math.abs((player.score || 0) - _lastEmitScore);
  const dgold = Math.abs((player.gold || 0) - _lastEmitGold);
  const dkills = Math.abs((player.kills || 0) - _lastEmitKills);
  const dxp = Math.abs((player.xp || 0) - _lastEmitXp);
  const dvx = Math.abs((player.vx||0) - (_lastEmitVx||0));
  const dvy = Math.abs((player.vy||0) - (_lastEmitVy||0));
  if (dx > 0.3 || dy > 0.3 || da > 0.005 || dhp > 0.5 || dsc >= 10 || dgold >= 1 || dkills >= 1 || dxp >= 1 || dvx > 0.3 || dvy > 0.3 || player.isAttacking || player.isAttacking !== _lastEmitAttacking || player.weapon >= 3) {
    _lastMpSendTime = now;
    _lastEmitX = player.x; _lastEmitY = player.y;
    _lastEmitAngle = player.angle; _lastEmitHp = player.hp; _lastEmitScore = player.score || 0;
    _lastEmitGold = player.gold || 0; _lastEmitKills = player.kills || 0; _lastEmitXp = player.xp || 0;
    _lastEmitAttacking = player.isAttacking;
    _lastEmitVx = player.vx || 0; _lastEmitVy = player.vy || 0;
    // ⑤ CSP: record predicted position + increment seq
    const _curSeq = ++_mpSeq;
    _mpPredictedX = player.x; _mpPredictedY = player.y;
    // Include vx/vy so server can forward velocity for dead-reckoning
    // Include build preview position so other players can see our ghost
    let _emitBX = null, _emitBY = null;
    if (player.weapon >= 3) {
      const _freshGhost = _computeGhostPos();
      _emitBX = _freshGhost.x; _emitBY = _freshGhost.y;
    }
    const _effAxeTier = (playerAcc && playerAcc.baltalar && playerAcc.baltalar.startsWith('ba_tier_')) ? Math.max(_wepTier(_axeXP), parseInt(playerAcc.baltalar.replace('ba_tier_', '')) || 0) : _wepTier(_axeXP);
    const _effSwordTier = (playerAcc && playerAcc.kiliclar && playerAcc.kiliclar.startsWith('ki_tier_')) ? Math.max(_wepTier(_swordXP), parseInt(playerAcc.kiliclar.replace('ki_tier_', '')) || 0) : _wepTier(_swordXP);
    const _statePayload = {
      x: player.x, y: player.y, angle: player.angle,
      vx: player.vx || 0, vy: player.vy || 0,
      hp: player.hp, maxHp: player.maxHp,
      weapon: player.weapon, isAttacking: player.isAttacking, attackTimer: player.attackTimer, attackDuration: player.attackDuration,
      kills: player.kills, xp: player.xp, gold: player.gold || 0,
      wood: player.wood || 0, stone: player.stone || 0, apples: player.apples || 0,
      sc: player.score || 0,
      axeTier: _effAxeTier,
      swordTier: _effSwordTier,
      skin: _playerSkin,
      buildX: _emitBX, buildY: _emitBY,
      rankId: Math.min(typeof _myRankId !== 'undefined' ? _myRankId : 0, 11),
      acc: { a: playerAcc.aksesuarlar, y: playerAcc.yuz, s: playerAcc.sapkalar, k: playerAcc.kanatlar },
      seq: _curSeq,
      ping: (typeof _ping === 'number' && _ping > 0 ? _ping : 50)
    };
    if (player.weapon >= 3) _socket.emit('state', _statePayload);
    else _socket.volatile.emit('state', _statePayload);
  }
}

let _bgTabHeartbeat = null;
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    // When tab is hidden, browsers freeze requestAnimationFrame.
    // Run update() and _mpUpdate() via a 33ms interval (30Hz) so player continues to simulate, move, attack, and sync in background!
    if (!_bgTabHeartbeat) {
      _bgTabHeartbeat = setInterval(() => {
        try {
          if (!_isDying && player && !player.dead) {
            update();
            _mpUpdate();
          }
        } catch (_) {}
      }, 33);
    }
  } else {
    if (_bgTabHeartbeat) {
      clearInterval(_bgTabHeartbeat);
      _bgTabHeartbeat = null;
    }
    _lastTime = performance.now();
    // Tab became active: if player died while tabbed out, immediately ensure death screen is visible!
    if (player && (player.dead || player.hp <= 0 || _isDying)) {
      die();
      const deathOverlay = document.getElementById('death-overlay');
      if (deathOverlay) deathOverlay.classList.add('show');
    } else if (_connected && _socket && player && !player.dead) {
      _mpUpdate();
    }
  }
});

function _mpSwing() {
  if (!_connected || !_socket) return;
  const _msTier = player.weapon === 2 ? _wepTier(_swordXP) : _wepTier(_axeXP);
  const _msTM   = [1.0, 1.5, 2.2, 3.5, 5.0, 8.0];
  const _msBDmg = player.weapon === 2 ? 30 : 22;
  const _msDmg  = Math.min(120, Math.round(_msBDmg * (_msTM[_msTier] || 1) * (player.dmgBonus || 1)));
  
  _socket.emit('swing', {
    angle: player.angle, weapon: player.weapon,
    axeTier: _wepTier(_axeXP), swordTier: _wepTier(_swordXP),
    x: player.x, y: player.y,
    dmg: _msDmg,
    range: _swingHitRange(),
    swingId: _swingId,
    timestamp: Date.now(),
    ping: (typeof _ping === 'number' && _ping > 0 ? _ping : 50)
  });
}

function _mpBuildPlaced(b, radius) {
  if (!_connected || !_socket || !b._netId) return;
  _socket.emit('place_building', { id: b._netId, type: b.type, x: b.x, y: b.y,
    angle: b.angle, hp: b.hp, maxHp: b.maxHp, radius: radius || 34, tier: b.tier || 0 });
}

function _mpBuildDestroyed(b) {
  if (!_connected || !_socket || !b._netId) return;
  _socket.emit('build_destroy', { id: b._netId });
}

function drawOtherPlayers() {
  try {
    const _vHalfW = (canvas.width  / 2) / (ZOOM || 0.55) + 120;
    const _vHalfH = (canvas.height / 2) / (ZOOM || 0.55) + 120;
    _otherPlayers.forEach((p, _opSockId) => {
      if (!p || typeof p.x !== 'number' || typeof p.y !== 'number' || isNaN(p.x) || isNaN(p.y)) return;
      try {
        if (p._trappedBy) {
          const _trb = _buildingsMap.get(p._trappedBy) || buildings.find(b => (b._netId === p._trappedBy || b.id === p._trappedBy || b._bLid === p._trappedBy));
          if (_trb && _trb.hp > 0) {
            p.x = _trb.x;
            p.y = _trb.y;
          } else {
            p._trappedBy = null;
          }
        }
    const dx = p.x - (camX + canvas.width / 2);
    const dy = p.y - (camY + canvas.height / 2);
    if (Math.abs(dx) > _vHalfW || Math.abs(dy) > _vHalfH) return;
    // (q0 aggressive cull removed — was hiding on-screen players)

    const pAcc = p.acc || {};
    const fl = (p.hp || 100) <= 0;

    // ── Block 1: rotated body + accessories ─────────────────────────────────
    ctx.save();
    try {
      ctx.translate(p.x, p.y);

      // Ground shadow — PERF: use cached gradient (fixed params, no need to recreate each frame)
      if (!drawOtherPlayers._shadowGrd) {
        const _g = ctx.createRadialGradient(5, 17, 0, 3, 14, 30);
        _g.addColorStop(0, 'rgba(0,0,0,0.28)'); _g.addColorStop(1, 'rgba(0,0,0,0)');
        drawOtherPlayers._shadowGrd = _g;
      }
      ctx.fillStyle = drawOtherPlayers._shadowGrd;
      ctx.beginPath(); ctx.ellipse(4, 17, 31, 10, 0, 0, Math.PI*2); ctx.fill();

      ctx.rotate(p.angle);

      // ── Accessories drawn BEFORE body (behind body) ──────────────────────
      if (pAcc.a === 'a_halo')     drawPlayerHalo(ctx, globalTime, 35);
      if (pAcc.a === 'a_cape')     drawPlayerCape(ctx, globalTime, 35);
      if (pAcc.a === 'a_tail')     drawPlayerTail(ctx, globalTime, 35);
      if (pAcc.k && pAcc.k !== 'w_none') {
        drawPlayerWings(ctx, pAcc.k, globalTime);
      }
      if (pAcc.a === 'a_backpack') drawPlayerBackpack(ctx, 35);

      // ── Weapon + arms — identical style to local player ──────────────────
      {
        let swAng = 0;
        let prog = 0;
        if (p.isAttacking && p.attackTimer > 0) {
          const dur = p.attackDuration || ATTACK_DUR[p.weapon] || 20;
          prog = Math.max(0, Math.min(1, p.attackTimer / dur));
          if (p.weapon >= 3) {
            swAng = Math.sin(prog * Math.PI) * 0.2;
          } else {
            const peakT = p.weapon === 2 ? 0.30 : 0.20;
            const remap = prog < peakT ? prog / peakT : 1 - (prog - peakT) / (1 - peakT);
            swAng = Math.sin(remap * Math.PI * 0.5) * (p.weapon === 2 ? (Math.PI / 1.2) : (Math.PI / 1.5));
          }
        }
        // Draw clean .io-style weapon swing arc (kavis cizgisi - no blue lines)
        if (p.isAttacking && p.weapon < 3 && p.attackTimer > 0) {
          _drawWeaponSlashArc(ctx, prog, p.weapon);
        }
        ctx.save(); ctx.rotate(swAng);

        // Weapon (only for axe/sword, not building items)
        if (p.weapon === 1 || p.weapon === 2) {
          const _otherWeaponKind = p.weapon === 1 ? 'axe' : 'sword';
          const _otherWeaponTier = p.weapon === 1 ? (p.axeTier ?? 0) : (p.swordTier ?? 0);
          const _otherWeaponImage = _weaponSprite(_otherWeaponKind, _otherWeaponTier);
          if (_otherWeaponImage) _drawWeaponSprite(ctx, _otherWeaponImage, _otherWeaponKind);
          else if (p.weapon === 1) drawAxeByTier(ctx, _otherWeaponTier, globalTime);
          else drawSwordByTier(ctx, _otherWeaponTier, globalTime);
        }

        // Arms — same two-ellipse style for ALL weapon modes (weapon + building)
        const armCol = SKIN_ARM_COLORS[p.skin] || '#c4966a';
        const armDark = armCol.startsWith('#') ? _hexDimColor(armCol, 0.7) : armCol;
        for (let _pai = 0; _pai < 2; _pai++) {
          const ay = _pai === 0 ? -13 : 20, sign = _pai === 0 ? -1 : 1;
          const armX = p.weapon === 2 ? 38 : 30;
          const armY = ay - (p.weapon === 2 ? 2 : 0);
          ctx.save(); ctx.translate(armX, armY);
          drawSkinHand(ctx, p.skin, armCol, armDark, sign);
          ctx.restore();
        }
        ctx.restore(); // undo swAng
      }

      // ── Body — PERF: shared OC cache per (skin+flash). All players w/ same skin share one OC.
      {
        const _otherPlayerImage = !fl ? _playerSprite(p.skin || 'default') : null;
        if (_otherPlayerImage) {
          _drawCenteredSprite(ctx, _otherPlayerImage, 35 * 3.6);
        } else {
          const _obsk = (p.skin || 'default') + (fl ? '_fl' : '_nfl');
          let _obEnt = _BODY_OC_CACHE.get(_obsk);
          const _obTTL = _qualityLevel >= 2 ? 6 : _qualityLevel === 1 ? 10 : 16;
          if (!_obEnt || globalTime - _obEnt.age >= _obTTL) {
            const _obcw = 126; // 35 * 3.6 = 126
            if (!_obEnt) { _obEnt = { oc: createRenderCanvas(_obcw, _obcw), age: -99 }; _BODY_OC_CACHE.set(_obsk, _obEnt); }
            const _obcc = _obEnt.oc.getContext('2d');
            _obcc.imageSmoothingEnabled = true; _obcc.imageSmoothingQuality = 'high';
            _obcc.clearRect(0, 0, _obcw, _obcw);
            _obcc.save(); _obcc.translate(63, 63);
            drawSkinBody(_obcc, 35, p.skin || 'default', globalTime, fl);
            _obcc.restore();
            _obEnt.age = globalTime;
          }
          ctx.drawImage(_obEnt.oc, -63, -63);
        }
      }
      // ── Eyes overlay (on top of body)
      {
        const _eyeSk = p.skin || 'default';
        let _eyeOC = _EYE_OC_CACHE.get(_eyeSk);
        if (!_eyeOC) {
          _eyeOC = createRenderCanvas(126, 126);
          const _ec = _eyeOC.getContext('2d');
          _ec.imageSmoothingEnabled = true; _ec.imageSmoothingQuality = 'high';
          _ec.save(); _ec.translate(63, 63);
          drawSkinEyesOverlay(_ec, 35, _eyeSk, false);
          _ec.restore();
          _EYE_OC_CACHE.set(_eyeSk, _eyeOC);
        }
        ctx.drawImage(_eyeOC, -63, -63);
      }
      // ── Face accessory ────────────────────────────────────────────────────
      if (pAcc.y && pAcc.y !== 'f_none') drawPlayerFace(ctx, pAcc.y);
      // ── Hat (centered above head, not rotating with player) ───────────────
      if (pAcc.s && pAcc.s !== 'h_none') {
        ctx.save(); ctx.rotate(-p.angle);
        drawPlayerHat(ctx, pAcc.s, globalTime, 35);
        ctx.restore();
      }
    } finally {
      ctx.restore(); // end translate + rotate
    }

    // ── Block 2: world-coord overlays (name, HP, chat, arc, kills) ────────
    ctx.save();
    try {
      const _hpRatio = Math.max(0, (p.hp || 0) / (p.maxHp || 100));
      // Defer name tag to screen-space pass — always on top, pixel-crisp
      if (_ntPoolIdx < _NT_OBJ_POOL.length) {
        const _nto = _NT_OBJ_POOL[_ntPoolIdx++];
        _nto.wx = p.x; _nto.wy = p.y - 44; _nto.name = p.name || '?';
        _nto.rankId = p.rankId ?? 0; _nto.hpRatio = _hpRatio; _nto.isOwn = false;
        _pendingNameTags.push(_nto);
      }

      // Bounty crown above bounty target
      const _currentBountyId = (typeof _bountyId !== 'undefined') ? _bountyId : null;
      if (_currentBountyId && _opSockId === _currentBountyId) {
        const _bc_y = p.y - 90;
        const _bc_pulse = 0.7 + 0.3 * Math.sin(_nowMs * 0.006);
        ctx.save();
        ctx.font = `${Math.round(28 * _bc_pulse)}px serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = `rgba(255,215,0,${_bc_pulse})`;
        ctx.strokeStyle = 'rgba(0,0,0,0.7)';
        ctx.lineWidth = 3;
        ctx.strokeText('👑', p.x, _bc_y);
        ctx.fillText('👑', p.x, _bc_y);
        ctx.restore();
      }

      // HP bar
      const hpPct = _hpRatio;
      const bw = 54, bh = 7, bxBar = p.x - bw / 2, byBar = p.y + 45;
      ctx.fillStyle = 'rgba(0,0,0,0.55)';
      ctx.beginPath(); ctx.roundRect(bxBar, byBar, bw, bh, 4); ctx.fill();
      ctx.fillStyle = hpPct > 0.5 ? '#44df22' : hpPct > 0.25 ? '#f5c842' : '#e03333';
      ctx.beginPath(); ctx.roundRect(bxBar, byBar, bw * hpPct, bh, 4); ctx.fill();

      // Chat bubble
      if (p._chatMsg && p._chatExpiry && _nowMs < p._chatExpiry) {
        const fade = Math.min(1, (p._chatExpiry - _nowMs) / 700);
        const cmx = p.x, cmy = p.y - 86;
        ctx.font = '11px Arial'; ctx.textAlign = 'center';
        const cw = Math.max(60, ctx.measureText(p._chatMsg).width + 20);
        ctx.globalAlpha = fade * 0.92;
        ctx.fillStyle = '#fff'; ctx.strokeStyle = '#aaa'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.roundRect(cmx - cw/2, cmy - 18, cw, 24, 6); ctx.fill(); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cmx-5, cmy+6); ctx.lineTo(cmx+5, cmy+6); ctx.lineTo(cmx, cmy+14); ctx.closePath(); ctx.fill();
        ctx.globalAlpha = fade;
        ctx.fillStyle = '#222';
        ctx.fillText(p._chatMsg.length > 28 ? p._chatMsg.slice(0,27)+'…' : p._chatMsg, cmx, cmy - 2);
        ctx.globalAlpha = 1;
      }

      // Kill badge
      if ((p.kills || 0) > 0) {
        ctx.font = 'bold 10px Arial'; ctx.fillStyle = '#ffdd00';
        ctx.fillText(`⚔ ${p.kills}`, p.x, p.y - 82);
      }
    } finally {
      ctx.restore();
    }

    // ── Build preview ghost — matches local player ghost style ────────────
    if (p.weapon >= 3 && p.buildX != null && p.buildY != null) {
      const gbx = p.buildX, gby = p.buildY;
      ctx.save();
      try {
        ctx.globalAlpha = 0.45;
        drawBuilding({ x: gbx, y: gby, type: p.weapon, angle: p.angle, life: 0, hp: 100, maxHp: 100, shake: 0, hitTimer: 0 }, true);
        ctx.globalAlpha = 0.92;
        const _typeLabel3 = {3:'🗡️ Kazık (Spikes)',4:'💨 Değirmen (Windmill)',5:'⚡ Hız Pedi (Boost)',6:'🪤 Ayı Tuzağı (Bear Trap)',7:'🔫 Taret (Turret)',8:'🚪 Kapı/Duvar (Door)',9:'💚 Şifa Pedi (Heal Pad)',10:'🔥 Kamp Ateşi'}[p.weapon] || '🏗️ Yapı';
        ctx.font = 'bold 13px Arial'; ctx.textAlign = 'center';
        ctx.strokeStyle = 'rgba(0,0,0,0.75)'; ctx.lineWidth = 3;
        ctx.strokeText(_typeLabel3, gbx, gby - 52); ctx.fillStyle = '#aaffaa'; ctx.fillText(_typeLabel3, gbx, gby - 52);
        ctx.font = '11px Arial'; ctx.fillStyle = 'rgba(255,255,255,0.85)';
        ctx.strokeText(p.name || '?', gbx, gby - 37); ctx.fillText(p.name || '?', gbx, gby - 37);
      } finally {
        ctx.restore();
      }
    }
  } catch (_eSingle) {
    console.warn('drawOtherPlayers single player error:', _eSingle);
  }
});
} catch (_eAll) {
  console.error('drawOtherPlayers fatal error:', _eAll);
}
}

// ─── Chat bubble for LOCAL player ────────────────────────────────────────────
function _drawLocalChatBubble() {
  if (!player._chatMsg || !player._chatExpiry || _nowMs >= player._chatExpiry) return;
  const fade = Math.min(1, (player._chatExpiry - _nowMs) / 700);
  const cmx = player.x, cmy = player.y - player.radius - 50;
  ctx.save();
  // BUG FIX: set font BEFORE measureText so bubble width matches rendered text
  ctx.font = '11px Arial'; ctx.textAlign = 'center';
  const cw = Math.max(60, ctx.measureText(player._chatMsg).width + 20);
  ctx.globalAlpha = fade * 0.92;
  ctx.fillStyle = '#fff'; ctx.strokeStyle = '#aaa'; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.roundRect(cmx - cw/2, cmy - 18, cw, 24, 6); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(cmx-5, cmy+6); ctx.lineTo(cmx+5, cmy+6); ctx.lineTo(cmx, cmy+14); ctx.closePath(); ctx.fill();
  ctx.globalAlpha = fade;
  ctx.fillStyle = '#222'; ctx.font = '11px Arial'; ctx.textAlign = 'center';
  ctx.fillText(player._chatMsg.length > 28 ? player._chatMsg.slice(0,27)+'…' : player._chatMsg, cmx, cmy - 2);
  ctx.globalAlpha = 1;
  ctx.restore();
}

// Leaderboard: ONLY real online players + local player (Ranked by Gold)
const _origUpdateLB = updateLeaderboard;
updateLeaderboard = function() {
  const playerGold = player.gold || 0;
  const all = [{ name: player.name || 'Sen', score: playerGold, gold: playerGold, kills: player.kills, isMe: true }];
  _otherPlayers.forEach((p) => {
    if (!p || !p.name) return;
    const pGold = typeof p.gold === 'number' ? p.gold : (Number(p.score) || 0);
    all.push({ name: p.name, score: pGold, gold: pGold, kills: p.kills||0, isMe: false });
  });
  all.sort((a, b) => (b.gold - a.gold) || (b.score - a.score));
  if (typeof _renderStarveLeaderboard === 'function') {
    _renderStarveLeaderboard(all);
  }
};

// Update minimap to show other players
// PERF: replaced per-call toMM({x,y}) with inline scalar computation — zero object allocation
const _origDrawMinimap = drawMinimap;
drawMinimap = function() {
  _origDrawMinimap();
  const _off = WORLD;
  // Draw other players as colored dots on minimap
  mmCtx.fillStyle = '#ff4444';
  mmCtx.strokeStyle = '#fff';
  mmCtx.lineWidth = 1;
  _otherPlayers.forEach(function(p) {
    if (!p || typeof p.x !== 'number') return;
    const mx = (p.x + _off) * MM_SCALE, my = (p.y + _off) * MM_SCALE;
    if (mx < 0 || mx > MM_SIZE || my < 0 || my > MM_SIZE) return;
    mmCtx.beginPath(); mmCtx.arc(mx, my, 3.5, 0, Math.PI * 2);
    mmCtx.fill(); mmCtx.stroke();
  });

  // Tren simgesi minimapte
  if (typeof _trainSt !== 'undefined') {
    const _tx = (_trainSt.x + _off) * MM_SCALE, _ty = (_trainSt.y + _off) * MM_SCALE;
    if (_tx >= 0 && _tx <= MM_SIZE && _ty >= 0 && _ty <= MM_SIZE) {
      mmCtx.save();
      mmCtx.translate(_tx, _ty);
      mmCtx.rotate(_trainSt.ang || 0);
      // Lokomotif gövdesi
      mmCtx.fillStyle = '#ee3322';
      mmCtx.strokeStyle = '#fff';
      mmCtx.lineWidth = 1.2;
      mmCtx.beginPath(); mmCtx.roundRect(-6,-2.5,12,5,1.5); mmCtx.fill(); mmCtx.stroke();
      // Ön far
      mmCtx.fillStyle = '#ffee88';
      mmCtx.beginPath(); mmCtx.arc(7,0,2,0,Math.PI*2); mmCtx.fill();
      // Durak halkası
      if (_trainSt.stopped) {
        mmCtx.strokeStyle = 'rgba(255,220,60,0.9)';
        mmCtx.lineWidth = 1.5;
        mmCtx.beginPath(); mmCtx.arc(0,0,9,0,Math.PI*2); mmCtx.stroke();
      }
      mmCtx.restore();
      // İstasyon durakları minimapte
      for (const wp of _TRAIN_WPS) {
        if (!wp.isStop) continue;
        const sx = (wp.x + _off) * MM_SCALE, sy = (wp.y + _off) * MM_SCALE;
        if (sx < 2 || sx > MM_SIZE-2 || sy < 2 || sy > MM_SIZE-2) continue;
        mmCtx.fillStyle = 'rgba(255,220,80,0.7)';
        mmCtx.strokeStyle = 'rgba(0,0,0,0.5)';
        mmCtx.lineWidth = 0.8;
        mmCtx.beginPath(); mmCtx.arc(sx, sy, 2.5, 0, Math.PI*2);
        mmCtx.fill(); mmCtx.stroke();
      }
    }
  }

  // ── Airdrop Sandıkları Minimapte ──
  if (typeof airdropsList !== 'undefined' && airdropsList.length > 0) {
    const pulse = Math.sin(Date.now() * 0.006);
    for (let _ai = 0; _ai < airdropsList.length; _ai++) {
      const ad = airdropsList[_ai];
      if (!ad || typeof ad.x !== 'number') continue;
      const ax = (ad.x + _off) * MM_SCALE, ay = ((ad.y + (ad.dropY || 0)) + _off) * MM_SCALE;
      if (ax < 0 || ax > MM_SIZE || ay < 0 || ay > MM_SIZE) continue;
      mmCtx.save();
      mmCtx.translate(ax, ay);
      // Pulsing ring
      mmCtx.strokeStyle = ad.tier === 2 ? 'rgba(0, 229, 255, 0.85)' : 'rgba(255, 215, 0, 0.85)';
      mmCtx.lineWidth = 1.5;
      mmCtx.beginPath(); mmCtx.arc(0, 0, 5.5 + pulse * 2, 0, Math.PI * 2); mmCtx.stroke();
      // Chest box
      mmCtx.fillStyle = ad.tier === 2 ? '#00e5ff' : '#ffd700';
      mmCtx.strokeStyle = '#000'; mmCtx.lineWidth = 1;
      mmCtx.beginPath(); mmCtx.roundRect(-3.5, -3, 7, 6, 1.2); mmCtx.fill(); mmCtx.stroke();
      mmCtx.restore();
    }
  }

  // ── Altın Kralı 👑 Taç İkonu Minimapte ──
  if (typeof _bountyId !== 'undefined' && _bountyId) {
    let kingX = null, kingY = null;
    if (_bountyId === _mySocketId) {
      kingX = player.x; kingY = player.y;
    } else {
      const kp = _otherPlayers.get(_bountyId);
      if (kp && typeof kp.x === 'number') { kingX = kp.x; kingY = kp.y; }
    }
    if (kingX !== null) {
      const kx = (kingX + _off) * MM_SCALE, ky = (kingY + _off) * MM_SCALE;
      if (kx >= 0 && kx <= MM_SIZE && ky >= 0 && ky <= MM_SIZE) {
        const pulse = 1 + Math.sin(Date.now() * 0.008) * 0.2;
        mmCtx.save();
        mmCtx.font = `${Math.round(12 * pulse)}px serif`;
        mmCtx.textAlign = 'center';
        mmCtx.textBaseline = 'middle';
        mmCtx.shadowColor = '#ffd700';
        mmCtx.shadowBlur = 5;
        mmCtx.fillText('👑', kx, ky);
        mmCtx.restore();
      }
    }
  }
}

// ============================================================
// BUILDING DAMAGE — local enemies vs buildings (client-side)
// Spike/windmill damage to AI enemies; emit HP sync to server
// ============================================================
// Periodically purge stale cooldown entries to prevent unbounded Map growth
setInterval(() => {
  const cutoff = Date.now() - 5000;
  if (typeof _spikeEnemyCooldowns !== 'undefined') {
    for (const [k, t] of _spikeEnemyCooldowns) { if (t < cutoff) _spikeEnemyCooldowns.delete(k); }
  }
}, 10000);

function checkBuildingDamage() {
  _buildDmgTimer++;
  // Her 8 frame'de bir çalış (~133ms) — cooldown (500ms) gerçek hızı belirler
  if (_buildDmgTimer < 8) return;
  _buildDmgTimer = 0;

  const now = Date.now();

  // ── SPIKE / WİNDMİLL → DÜŞMAN HASARI ──
  // Düşman dışta (kısa liste), spatial grid ile yakın binalar içte → O(1) başına
  if (typeof enemies !== 'undefined') {
    for (var _mei = enemies.length - 1; _mei >= 0; _mei--) {
      var e = enemies[_mei];
      if (e.hp <= 0) continue;
      var _cbdNear = _sgQuery(e.x, e.y, 110);
      var _eDead = false;
      for (var _cbi = 0; _cbi < _cbdNear.length; _cbi++) {
        var b = _cbdNear[_cbi];
        if (b.hp <= 0 || (b.type !== 3 && b.type !== 4)) continue;
        var effectR = b.type === 4 ? 72 : 60;
        var _totR = effectR + (e.radius || 28);
        var _cbx = e.x - b.x, _cby = e.y - b.y;
        if (Math.abs(_cbx) > _totR || Math.abs(_cby) > _totR) continue;
        if (_cbx * _cbx + _cby * _cby > _totR * _totR) continue;
        var _bTierDmg = _getTier(b);
        var dmgPerTick = Math.round((b.type === 4 ? 22 : 45) * (TIER_DMG_MULS[_bTierDmg] || 1));
        var _bId = b._netId || (b._bLid = b._bLid || ++_eLidCounter);
        var _eLid = e._netId !== undefined ? e._netId : (e._lid = e._lid || ++_eLidCounter);
        var cdKey = 'e' + _eLid + '_b' + _bId;
        if (now - (_spikeEnemyCooldowns.get(cdKey) || 0) < 500) continue;
        _spikeEnemyCooldowns.set(cdKey, now);
        e.hitFlash = 8;
        spawnBlood(e.x, e.y, 5);
        floatingTexts.push({ x: e.x, y: e.y - 32, text: '-' + dmgPerTick + ' \uD83D\uDDE1', alpha: 1, life: 26, color: '#ffcc44' });
        if (e._netId !== undefined) {
          if (_connected && _socket) _socket.emit('mob_hit_req', { mobId: e._netId, dmg: dmgPerTick, bId: b._netId });
        } else {
          e.hp = Math.max(0, e.hp - dmgPerTick);
          if (e.hp <= 0) {
            spawnBlood(e.x, e.y, 10); spawnGoldBurst(e.x, e.y);
            var _xp = e.xpReward || e.xp || 22, _gd = e.goldReward || e.gold || 4;
            player.xp += _xp; player.kills++; player.score = (player.score||0) + Math.round(_xp*1.5+_gd*6);
            player.gold += _gd; updateUI(); updateXP(); recordKill(); spawnLoot(e.x, e.y, _gd);
            enemies.splice(_mei, 1);
            _eDead = true; break;
          }
        }
      }
      if (_eDead) continue;
    }
  }

  // ── SPİKE PVP + TUZAK PVP — diğer oyuncular (kısa liste) × spatial grid ──
  if (_connected && _mySocketId) {
    _otherPlayers.forEach(function(op, opId) {
      if (!op || (op.hp !== undefined && op.hp <= 0)) return;
      var _pvpNear = _sgQuery(op.x, op.y, 110);
      for (var _pvbi = 0; _pvbi < _pvpNear.length; _pvbi++) {
        var bp = _pvpNear[_pvbi];
        if (bp.hp <= 0 || bp._ownerId !== _mySocketId) continue;
        var _opdx = op.x - bp.x, _opdy = op.y - bp.y;
        var _opd2 = _opdx * _opdx + _opdy * _opdy;
        // Spike PvP
        if (bp.type === 3) {
          if (Math.abs(_opdx) > 76 || Math.abs(_opdy) > 76 || _opd2 > 5776) continue;
          var _bSpikeId = bp._netId || (bp._bLid = bp._bLid || ++_eLidCounter);
          var spCdKey = 'pvp_spike_' + opId + '_' + _bSpikeId;
          if (now - (_spikeEnemyCooldowns.get(spCdKey) || 0) < 350) continue;
          _spikeEnemyCooldowns.set(spCdKey, now);
          var spikePvpDmg = Math.round(60 * (TIER_DMG_MULS[_getTier(bp)] || 1));
          _socket.emit('spike_hit', { targetId: opId, buildingId: bp._netId, bId: bp._netId, dmg: spikePvpDmg });
          spawnBlood(op.x, op.y, 5);
          floatingTexts.push({ x: op.x, y: op.y - 32, text: '-' + spikePvpDmg + ' \uD83D\uDDE1\uFE0F', alpha: 1, life: 30, color: '#ffaa44' });
        }
        // Trap PvP (Zero Damage — Moomoo.io style: only root, no blood, no damage)
        if (bp.type === 6) {
          var trapR = 28;
          if (Math.abs(_opdx) > trapR || Math.abs(_opdy) > trapR || _opd2 > trapR * trapR) continue;
          var trCdKey = 'trap_pvp_' + opId + '_' + bp._netId;
          if (now - (_spikeEnemyCooldowns.get(trCdKey) || 0) < 1000) continue;
          _spikeEnemyCooldowns.set(trCdKey, now);
          _socket.emit('trap_touch', { victimId: opId, buildingId: bp._netId });
          _myTrapVictims.set(opId, bp._netId);
          playSound(140, 0.14, 'sawtooth', 0.25);
        }
      }
    });
  }

  // ── HP EMİT — sadece kendi binalarımız için, O(N) ama basit kontrol ──
  for (var _hei = 0; _hei < buildings.length; _hei++) {
    var bh = buildings[_hei];
    if (bh.hp <= 0 || bh._ownerId !== _mySocketId || !bh._netId) continue;
    if (!bh._lastEmittedHp) { bh._lastEmittedHp = bh.hp; }
    else if (bh._lastEmittedHp !== bh.hp) {
      bh._lastEmittedHp = bh.hp;
      if (_connected && _socket) _socket.emit('build_hp_update', { id: bh._netId, hp: bh.hp });
    }
  }

  // Eski spike cooldown'larını temizle
  if (_spikeEnemyCooldowns.size > 200) {
    _spikeEnemyCooldowns.forEach(function(t, k) { if (now - t > 5000) _spikeEnemyCooldowns.delete(k); });
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// TREN SİSTEMİ — İstemci Tarafı
// ══════════════════════════════════════════════════════════════════════════════
// Tren rotası — tüm koordinatlar 1.25x büyütüldü, duraklar arası mesafe uzatıldı
// Ek ara nokta segmentleri ile yolculuk süresi ve mesafesi artırıldı
const _TRAIN_WPS = [
  { x:  -750, y: -2000, isStop:true,  stopName:'🌿 Orman Kuzeyi' },
  { x:   200, y: -2900, isStop:false },
  { x:   800, y: -3800, isStop:false },
  { x:  1250, y: -4750, isStop:true,  stopName:'❄️ Kar Köyü' },
  { x:  -100, y: -5500, isStop:false },
  { x:  -800, y: -5900, isStop:false },
  { x: -1250, y: -6250, isStop:true,  stopName:'❄️ Buz Sarayı' },
  { x: -2000, y: -5200, isStop:false },
  { x: -2750, y: -4750, isStop:false },
  { x: -2250, y: -1500, isStop:true,  stopName:'🌿 Orman Batısı' },
  { x: -3400, y: -2600, isStop:false },
  { x: -4600, y: -2800, isStop:false },
  { x: -5250, y: -1750, isStop:true,  stopName:'🌑 Karanlık Çukur' },
  { x: -6000, y:  -400, isStop:false },
  { x: -6250, y:   500, isStop:true,  stopName:'🌑 Gölge Vadisi' },
  { x: -5200, y:  2000, isStop:false },
  { x: -4000, y:  3200, isStop:false },
  { x: -3000, y:  3750, isStop:false },
  { x: -1500, y:  5250, isStop:true,  stopName:'🌿 Bataklık Limanı' },
  { x:   300, y:  6000, isStop:false },
  { x:   750, y:  6500, isStop:true,  stopName:'🌿 Zehirli Göl' },
  { x:  2200, y:  5400, isStop:false },
  { x:  3400, y:  4600, isStop:false },
  { x:  4200, y:  3400, isStop:false },
  { x:  5750, y:  1500, isStop:true,  stopName:'🏜️ Sıcak Oazis' },
  { x:  6250, y: -1250, isStop:true,  stopName:'🏜️ Kum Fırtınası' },
  { x:  5200, y: -2800, isStop:false },
  { x:  3800, y: -3200, isStop:false },
  { x:  2400, y: -3000, isStop:false },
  { x:  1500, y: -2750, isStop:false },
];
const _TRAIN_N = _TRAIN_WPS.length;
const _TRAIN_SEG_LENS = [];
for (let _tsi = 0; _tsi < _TRAIN_N; _tsi++) {
  const _ta = _TRAIN_WPS[_tsi], _tb = _TRAIN_WPS[(_tsi+1)%_TRAIN_N];
  _TRAIN_SEG_LENS.push(Math.hypot(_tb.x-_ta.x, _tb.y-_ta.y));
}

// Canlı tren durumu (online: sunucudan; offline: simüle)
let _trainSt = {
  x: _TRAIN_WPS[0].x, y: _TRAIN_WPS[0].y, ang: 0,
  stopped: true, stopName: _TRAIN_WPS[0].stopName || '',
  cars: [
    { x:_TRAIN_WPS[0].x-130, y:_TRAIN_WPS[0].y, angle:0 },
    { x:_TRAIN_WPS[0].x-260, y:_TRAIN_WPS[0].y, angle:0 },
    { x:_TRAIN_WPS[0].x-390, y:_TRAIN_WPS[0].y, angle:0 },
    { x:_TRAIN_WPS[0].x-520, y:_TRAIN_WPS[0].y, angle:0 },
    { x:_TRAIN_WPS[0].x-650, y:_TRAIN_WPS[0].y, angle:0 },
  ],
  pax: [],
};
let _onTrain = false;

// _TRAIN_SPD: px advanced per frame (scaled by _dt in _stepTrainSim for fps-independence)
// _TRAIN_STOP_DUR: ms tren durakta bekler — 35s çünkü 12s çok kısa, oyuncular binemeden ayrılıyordu
const _TRAIN_SPD = 16, _TRAIN_STOP_DUR = 35000, _TRAIN_CAR_GAP = 130;

// Offline simülasyon — _TRAIN_STOP_DUR yukarıda tanımlı olmalı (önce sabitler)
const _tSim = { segIdx:0, t:0, stopped:true, stopUntil: Date.now()+_TRAIN_STOP_DUR };

function _tSimPos(si, t) {
  const a=_TRAIN_WPS[si], b=_TRAIN_WPS[(si+1)%_TRAIN_N];
  return { x:a.x+(b.x-a.x)*t, y:a.y+(b.y-a.y)*t, angle:Math.atan2(b.y-a.y,b.x-a.x) };
}
function _tSimBack(si, t, dist) {
  let rem=dist, s=si, tt=t;
  while(rem>0){
    const cov=tt*_TRAIN_SEG_LENS[s];
    if(cov>=rem){ tt=(cov-rem)/_TRAIN_SEG_LENS[s]; rem=0; }
    else{ rem-=cov; s=(s-1+_TRAIN_N)%_TRAIN_N; tt=1; }
  }
  return _tSimPos(s,tt);
}

function _stepTrainSim() {
  // Train system disabled to keep the map clean and minimal.
}

// ── RAYLAR ──────────────────────────────────────────────────────────────────
function drawTrainRails() {
  // Disabled: the map is intentionally kept clean and low-contrast to match the Sploop.io style.
}

// ── TREN OC CACHE ────────────────────────────────────────────────────────────
// Lokomotif ve vagon gövdeleri shadowBlur'u her frame yerine bir kez OC'ye pişirir.
let _locoBodyOC=null;
function _buildLocoBodyOC(){
  const S=2.4,W=450,H=260,CX=225,CY=130;
  _locoBodyOC=createRenderCanvas(W,H);
  const c=_locoBodyOC.getContext('2d');
  c.translate(CX,CY); c.scale(S,S);
  c.shadowColor='rgba(0,0,0,0.7)'; c.shadowBlur=28; c.shadowOffsetY=14;
  const g=c.createLinearGradient(-60,-26,60,26);
  g.addColorStop(0,'#ff4422'); g.addColorStop(0.3,'#cc1800'); g.addColorStop(0.7,'#991100'); g.addColorStop(1,'#550800');
  c.fillStyle=g; c.strokeStyle='#1a0000'; c.lineWidth=3;
  c.beginPath(); c.roundRect(-60,-26,120,52,11); c.fill(); c.stroke();
  const shine=c.createLinearGradient(-60,-26,-60,-14);
  shine.addColorStop(0,'rgba(255,120,80,0.55)'); shine.addColorStop(1,'rgba(255,60,30,0)');
  c.fillStyle=shine; c.beginPath(); c.roundRect(-59,-25,118,14,[11,11,0,0]); c.fill();
  _locoBodyOC._cx=CX; _locoBodyOC._cy=CY;
}
let _carBodyOCs=[null,null,null];
const _carBodyColors=[['#4466bb','#223388','#112266'],['#226633','#144422','#0a2a12'],['#884400','#552200','#2a1000']];
function _buildCarBodyOC(vi){
  const S=2.4,W=340,H=200,CX=170,CY=100;
  const oc=createRenderCanvas(W,H);
  const c=oc.getContext('2d');
  c.translate(CX,CY); c.scale(S,S);
  const [bc0,bc1,bc2]=_carBodyColors[vi];
  const bg=c.createLinearGradient(-50,-22,50,22);
  bg.addColorStop(0,bc0); bg.addColorStop(0.5,bc1); bg.addColorStop(1,bc2);
  c.shadowColor='rgba(0,0,0,0.5)'; c.shadowBlur=18; c.shadowOffsetY=9;
  c.fillStyle=bg; c.strokeStyle='#000'; c.lineWidth=2.5;
  c.beginPath(); c.roundRect(-50,-22,100,44,9); c.fill(); c.stroke();
  oc._cx=CX; oc._cy=CY;
  _carBodyOCs[vi]=oc;
}

// ── LOKOMOTİF ───────────────────────────────────────────────────────────────
function _drawLoco(c,x,y,ang){
  c.save(); c.translate(x,y); c.rotate(ang);
  c.scale(2.4,2.4);
  // Zemin gölgesi — OC'den (shadowBlur her frame değil, bir kez pişirildi)
  if(!_locoBodyOC) _buildLocoBodyOC();
  c.save(); c.scale(1/2.4,1/2.4); c.drawImage(_locoBodyOC,-_locoBodyOC._cx,-_locoBodyOC._cy); c.restore();
  // Ana gövde — koyu kırmızı-siyah gradient (shadow OC'de, burada gölgesiz)
  const g=c.createLinearGradient(-60,-26,60,26);
  g.addColorStop(0,'#ff4422'); g.addColorStop(0.3,'#cc1800'); g.addColorStop(0.7,'#991100'); g.addColorStop(1,'#550800');
  c.fillStyle=g; c.strokeStyle='#1a0000'; c.lineWidth=3;
  c.beginPath(); c.roundRect(-60,-26,120,52,11); c.fill(); c.stroke();
  // Üst parlak şerit
  const shine=c.createLinearGradient(-60,-26,-60,-14);
  shine.addColorStop(0,'rgba(255,120,80,0.55)'); shine.addColorStop(1,'rgba(255,60,30,0)');
  c.fillStyle=shine; c.beginPath(); c.roundRect(-59,-25,118,14,[11,11,0,0]); c.fill();

  // Sarı şerit bant — gövde kenarı
  c.strokeStyle='#ffcc00'; c.lineWidth=3;
  c.beginPath(); c.roundRect(-60,-26,120,52,11); c.stroke();

  // Kazan silindiri
  const bg=c.createLinearGradient(18,-22,18,22);
  bg.addColorStop(0,'#666'); bg.addColorStop(0.4,'#3a3a3a'); bg.addColorStop(1,'#111');
  c.fillStyle=bg; c.strokeStyle='#000'; c.lineWidth=2.5;
  c.beginPath(); c.roundRect(10,-21,52,42,6); c.fill(); c.stroke();
  // Kazan bandları
  c.strokeStyle='rgba(255,200,0,0.35)'; c.lineWidth=2;
  for(const rx of[18,30,48]){ c.beginPath(); c.moveTo(rx,-21); c.lineTo(rx,21); c.stroke(); }
  // Kazan parıltı
  const kaz=c.createLinearGradient(10,-21,10,-8);
  kaz.addColorStop(0,'rgba(255,255,255,0.18)'); kaz.addColorStop(1,'rgba(255,255,255,0)');
  c.fillStyle=kaz; c.beginPath(); c.roundRect(11,-20,50,12,[6,6,0,0]); c.fill();

  // Kabin çerçevesi (arka)
  const cab=c.createLinearGradient(-62,-32,-62,32);
  cab.addColorStop(0,'#cc2200'); cab.addColorStop(1,'#770e00');
  c.fillStyle=cab; c.strokeStyle='#1a0000'; c.lineWidth=2.5;
  c.beginPath(); c.roundRect(-64,-34,36,68,7); c.fill(); c.stroke();
  // Çatı
  c.fillStyle='#880c00'; c.strokeStyle='#1a0000'; c.lineWidth=2;
  c.beginPath(); c.roundRect(-65,-38,38,10,[6,6,0,0]); c.fill(); c.stroke();
  // Kabin pencereleri — mavi parlak
  for(const py of[-20,7]){
    const wg=c.createLinearGradient(-57,py,-45,py+14);
    wg.addColorStop(0,'#cceeff'); wg.addColorStop(1,'#77aadd');
    c.fillStyle=wg; c.strokeStyle='#335577'; c.lineWidth=2;
    c.beginPath(); c.roundRect(-57,py,22,14,4); c.fill(); c.stroke();
    // parıltı
    c.fillStyle='rgba(255,255,255,0.45)'; c.fillRect(-55,py+2,7,4);
  }

  // Baca
  c.fillStyle='#222'; c.strokeStyle='#000'; c.lineWidth=2.5;
  c.beginPath(); c.roundRect(46,-32,18,26,5); c.fill(); c.stroke();
  // Baca başlığı (şapka)
  c.fillStyle='#1a1a1a'; c.strokeStyle='#ffcc00'; c.lineWidth=2;
  c.beginPath(); c.ellipse(55,-33,16,7,0,0,Math.PI*2); c.fill(); c.stroke();
  // Duman izi (statik)
  c.fillStyle='rgba(180,180,180,0.2)';
  c.beginPath(); c.ellipse(55,-46,9,6,0,0,Math.PI*2); c.fill();

  // Ön takoz (cowcatcher) — sarı kenarlı
  const ccg=c.createLinearGradient(58,-20,78,20);
  ccg.addColorStop(0,'#dd2200'); ccg.addColorStop(1,'#770000');
  c.fillStyle=ccg; c.strokeStyle='#ffcc00'; c.lineWidth=2.5;
  c.beginPath(); c.moveTo(58,-20); c.lineTo(78,-10); c.lineTo(78,10); c.lineTo(58,20); c.closePath(); c.fill(); c.stroke();
  // Takoz çizgileri
  c.strokeStyle='rgba(255,180,0,0.5)'; c.lineWidth=2;
  for(const gy of[-12,-4,4,12]){ c.beginPath(); c.moveTo(60,gy); c.lineTo(77,gy); c.stroke(); }

  // Ön far — parlak
  c.save(); c.shadowColor='#ffee44'; c.shadowBlur=20;
  c.fillStyle='#ffee88'; c.strokeStyle='#cc9900'; c.lineWidth=2.5;
  c.beginPath(); c.arc(74,0,9,0,Math.PI*2); c.fill(); c.stroke();
  c.fillStyle='rgba(255,255,200,0.8)'; c.beginPath(); c.arc(72,-2,4,0,Math.PI*2); c.fill();
  c.restore();

  // Tekerlekler — çift çemberli (hız trene göre)
  const spA=(globalTime*(_tSim.stopped?0.03:0.52))%(Math.PI*2);
  for(const [wx,wr,big] of[[-44,11,false],[-20,11,false],[8,14,true],[38,11,false]]){
    // Dış çember
    c.fillStyle='#1c1c1c'; c.strokeStyle='#555'; c.lineWidth=3;
    c.beginPath(); c.arc(wx,-27,wr,Math.PI,0,false); c.fill(); c.stroke();
    c.beginPath(); c.arc(wx, 27,wr,0,Math.PI,false); c.fill(); c.stroke();
    // İç çember
    c.strokeStyle='#888'; c.lineWidth=1.5;
    c.beginPath(); c.arc(wx,-27,wr*0.55,Math.PI,0,false); c.stroke();
    c.beginPath(); c.arc(wx, 27,wr*0.55,0,Math.PI,false); c.stroke();
    // Parmaklar
    c.strokeStyle=big?'rgba(120,80,0,0.9)':'rgba(90,90,90,0.9)'; c.lineWidth=big?2.5:2;
    for(let si=0;si<(big?6:4);si++){
      const sa=spA+si*(Math.PI*2/(big?6:4));
      for(const sy of[-27,27]){
        c.beginPath(); c.moveTo(wx,sy); c.lineTo(wx+Math.cos(sa)*(wr-3),sy+Math.sin(sa)*(wr-3)); c.stroke();
      }
    }
    // Merkez vida
    c.fillStyle='#ffcc00'; c.beginPath(); c.arc(wx,-27,3,0,Math.PI*2); c.fill();
    c.beginPath(); c.arc(wx, 27,3,0,Math.PI*2); c.fill();
  }
  // Bağlantı çubuğu (side rod)
  const srodG=c.createLinearGradient(-52,-27,24,-27);
  srodG.addColorStop(0,'#888'); srodG.addColorStop(0.5,'#ccc'); srodG.addColorStop(1,'#888');
  c.strokeStyle=srodG; c.lineWidth=5; c.lineCap='round';
  c.beginPath(); c.moveTo(-52,-27); c.lineTo(24,-27); c.stroke();
  c.beginPath(); c.moveTo(-52, 27); c.lineTo(24, 27); c.stroke();

  // İsim plakası — altın
  const plq=c.createLinearGradient(-38,-9,38,9);
  plq.addColorStop(0,'#886600'); plq.addColorStop(0.5,'#ffcc00'); plq.addColorStop(1,'#886600');
  c.fillStyle=plq; c.strokeStyle='#1a0000'; c.lineWidth=1.5;
  c.beginPath(); c.roundRect(-38,-9,76,18,5); c.fill(); c.stroke();
  c.fillStyle='#1a0800'; c.font='bold 8px Arial'; c.textAlign='center'; c.textBaseline='middle';
  c.fillText('FOREST EXPRESS',0,0);
  c.textBaseline='alphabetic';

  c.restore();
}

// ── VAGON ───────────────────────────────────────────────────────────────────
function _drawCar(c,x,y,ang,idx){
  c.save(); c.translate(x,y); c.rotate(ang);
  c.scale(2.4,2.4);
  // Gövde gölgesi — OC'den (shadowBlur=18 her frame değil, bir kez pişirildi)
  const vi=idx%3;
  if(!_carBodyOCs[vi]) _buildCarBodyOC(vi);
  c.save(); c.scale(1/2.4,1/2.4); c.drawImage(_carBodyOCs[vi],-_carBodyOCs[vi]._cx,-_carBodyOCs[vi]._cy); c.restore();
  // Vagon gövdesi (shadow OC'de, burada gölgesiz)
  const [bc0,bc1,bc2]=_carBodyColors[vi];
  const carpBg=c.createLinearGradient(-50,-22,50,22);
  carpBg.addColorStop(0,bc0); carpBg.addColorStop(0.5,bc1); carpBg.addColorStop(1,bc2);
  c.fillStyle=carpBg; c.strokeStyle='#000'; c.lineWidth=2.5;
  c.beginPath(); c.roundRect(-50,-22,100,44,9); c.fill(); c.stroke();
  // Sarı şerit
  c.strokeStyle='#ffcc00'; c.lineWidth=2;
  c.beginPath(); c.roundRect(-50,-22,100,44,9); c.stroke();
  // Üst parıltı
  const topS=c.createLinearGradient(-50,-22,-50,-10);
  topS.addColorStop(0,'rgba(255,255,255,0.22)'); topS.addColorStop(1,'rgba(255,255,255,0)');
  c.fillStyle=topS; c.beginPath(); c.roundRect(-49,-21,98,12,[9,9,0,0]); c.fill();
  // Çatı şeridi
  c.fillStyle='rgba(0,0,0,0.5)'; c.beginPath(); c.roundRect(-49,-22,98,7,[9,9,0,0]); c.fill();
  c.fillStyle='rgba(0,0,0,0.4)'; c.beginPath(); c.roundRect(-49,15,98,7,[0,0,9,9]); c.fill();

  // Pencereler — mavi parlak
  for(let w=0;w<4;w++){
    const wx=-38+w*24;
    for(const py of[-14,4]){
      const wg=c.createLinearGradient(wx,py,wx+16,py+11);
      wg.addColorStop(0,'#cceeff'); wg.addColorStop(1,'#7799cc');
      c.fillStyle=wg; c.strokeStyle='#224466'; c.lineWidth=1.5;
      c.beginPath(); c.roundRect(wx,py,16,11,3); c.fill(); c.stroke();
      c.fillStyle='rgba(255,255,255,0.45)'; c.fillRect(wx+2,py+2,5,3);
    }
  }
  // Kapı bölücü
  c.strokeStyle='rgba(255,200,0,0.3)'; c.lineWidth=2;
  c.beginPath(); c.moveTo(2,-21); c.lineTo(2,21); c.stroke();

  // Tekerlekler (hız trene göre)
  const spA=(globalTime*(_tSim.stopped?0.03:0.52))%(Math.PI*2);
  for(const wx of[-32,-2,28]){
    c.fillStyle='#1c1c1c'; c.strokeStyle='#555'; c.lineWidth=2.5;
    c.beginPath(); c.arc(wx,-23,10,Math.PI,0,false); c.fill(); c.stroke();
    c.beginPath(); c.arc(wx, 23,10,0,Math.PI,false); c.fill(); c.stroke();
    c.strokeStyle='#888'; c.lineWidth=1.5;
    for(let si=0;si<4;si++){
      const sa=spA+si*Math.PI/2;
      for(const sy of[-23,23]){
        c.beginPath(); c.moveTo(wx,sy); c.lineTo(wx+Math.cos(sa)*7,sy+Math.sin(sa)*7); c.stroke();
      }
    }
    c.fillStyle='#ffcc00'; c.beginPath(); c.arc(wx,-23,2.5,0,Math.PI*2); c.fill();
    c.beginPath(); c.arc(wx, 23,2.5,0,Math.PI*2); c.fill();
  }
  // Bağlantı
  c.fillStyle='#666'; c.strokeStyle='#333'; c.lineWidth=2;
  c.beginPath(); c.arc(-51,0,5,0,Math.PI*2); c.fill(); c.stroke();
  c.beginPath(); c.arc( 51,0,5,0,Math.PI*2); c.fill(); c.stroke();
  c.strokeStyle='#555'; c.lineWidth=3.5;
  c.beginPath(); c.moveTo(-45,0); c.lineTo(-56,0); c.stroke();
  c.beginPath(); c.moveTo( 45,0); c.lineTo( 56,0); c.stroke();
  c.restore();
}

// ── TREN ÇIZIM ANA FONKSİYON ────────────────────────────────────────────────
function drawTrain(){
  // Disabled: the train and station system is intentionally removed for the cleaner map.
}

// ── BOARDING BUTONU ──────────────────────────────────────────────────────────
// Train button: lazy-init because the <div id="train-btn"> is defined AFTER this
// script block in the HTML. getElementById would return null here at parse time.
let _trainBtnEl = null;
let _trainBtnSetup = false;
const _trainBtnAction = () => {
  if(_onTrain){
    // Exiting: set immediately for local responsiveness
    _onTrain=false;
    if(_GAME_MODE==='online'&&typeof _socket!=='undefined'&&_socket) _socket.emit('train_exit');
  } else {
    if(_GAME_MODE==='online'&&typeof _socket!=='undefined'&&_socket){
      // Online: emit board request — wait for server train_boarded confirmation before moving
      // (avoids teleporting if server denies the request)
      _socket.emit('train_board');
    } else {
      // Offline: snap locally
      _onTrain=true;
      let _snapX=_trainSt.x, _snapY=_trainSt.y, _snapMin=Math.hypot(player.x-_trainSt.x,player.y-_trainSt.y);
      for(let _ci=0;_ci<_trainSt.cars.length;_ci++){
        const _cc=_trainSt.cars[_ci]; if(!_cc) continue;
        const _cd=Math.hypot(player.x-_cc.x,player.y-_cc.y);
        if(_cd<_snapMin){_snapMin=_cd;_snapX=_cc.x;_snapY=_cc.y;}
      }
      player.x=_snapX; player.y=_snapY; player.vx=0; player.vy=0; player.momX=0; player.momY=0;
    }
  }
};
function _updateTrainBtn(){
  // Disabled: train UI and boarding are removed from the active game view.
  const _trainBtnHide = document.getElementById('train-btn');
  if (_trainBtnHide) _trainBtnHide.style.display = 'none';
}

// ── TREN HİT EFEKTİ ─────────────────────────────────────────────────────────
function _onTrainHit(data){
  if(!data) return;
  player.hp=Math.max(0,data.hp);
  player.momX=(data.kx||0)*9; player.momY=(data.ky||0)*9;
  floatingTexts.push({ x:player.x, y:player.y-55, text:`🚂 -${data.dmg}`, alpha:1, life:60, color:'#ff4400', big:true });
  for(let i=0;i<5;i++) _spawnParticle(player.x+(Math.random()-0.5)*30,player.y+(Math.random()-0.5)*30,(Math.random()-0.5)*9,-3-Math.random()*5,3+Math.random()*4,22+Math.random()*14,'#ff8844');
  if(typeof playSound==='function') playSound(180+Math.random()*40, 0.22, 'sawtooth', 0.28);
}

// ── SOCKET KURULUMU (bağlandıktan sonra bir kez) ─────────────────────────────
const _trainSockInterval = setInterval(() => {
  if(_GAME_MODE!=='online'){ clearInterval(_trainSockInterval); return; }
  if(typeof _socket==='undefined'||!_socket||!_connected){ return; }
  clearInterval(_trainSockInterval);
  // train_tick: server-authoritative train state broadcast every ~2s
  // Snap local simulation state so all clients are synchronized.
  _socket.on('train_tick', (data) => {
    if(!data) return;
    // Sync local sim to server ground-truth
    _tSim.segIdx   = data.segIdx ?? _tSim.segIdx;
    _tSim.t        = data.t      ?? _tSim.t;
    _tSim.stopped  = !!data.stopped;
    _tSim.stopUntil = data.stopUntil ?? _tSim.stopUntil;
    // Immediately update rendered state
    _trainSt.x = data.x; _trainSt.y = data.y; _trainSt.ang = data.ang ?? 0;
    _trainSt.stopped  = _tSim.stopped;
    _trainSt.stopName = data.stopName || '';
    if(data.cars && Array.isArray(data.cars)) _trainSt.cars = data.cars;
  });
  // Legacy event kept for backwards-compat (server may also send train_state)
  _socket.on('train_state', (data) => {
    if(!data) return;
    _trainSt.x=data.x; _trainSt.y=data.y; _trainSt.ang=data.ang||0;
    _trainSt.stopped=!!data.stopped; _trainSt.stopName=data.stopName||'';
    if(data.cars&&Array.isArray(data.cars)) _trainSt.cars=data.cars;
  });
  _socket.on('train_hit', _onTrainHit);
  // train_boarded: server confirmed board — snap position and sync sim state
  _socket.on('train_boarded', (data) => {
    _onTrain=true;
    if(data && typeof data.x==='number'){
      // Snap player and local sim to server-confirmed position
      player.x=data.x; player.y=data.y;
      player.vx=0; player.vy=0; player.momX=0; player.momY=0;
      if(typeof data.segIdx==='number') _tSim.segIdx=data.segIdx;
      if(typeof data.t==='number')      _tSim.t=data.t;
      if(typeof data.stopped==='boolean') _tSim.stopped=data.stopped;
      if(typeof data.stopUntil==='number') _tSim.stopUntil=data.stopUntil;
      _trainSt.x=data.x; _trainSt.y=data.y; _trainSt.ang=data.ang||0;
      _trainSt.stopped=_tSim.stopped; _trainSt.stopName=data.stopName||'';
      if(data.cars&&Array.isArray(data.cars)) _trainSt.cars=data.cars;
    }
    floatingTexts.push({ x:player.x, y:player.y-70, text:'🚂 Trene Binildi!', alpha:1, life:60, color:'#44ff88', big:true });
  });
  // train_board_denied: server rejected board request
  _socket.on('train_board_denied', (data) => {
    _onTrain=false;
    const msg=(data&&data.reason)||'Trene binilemiyor!';
    floatingTexts.push({ x:player.x, y:player.y-60, text:'⛔ '+msg, alpha:1, life:60, color:'#ff6644' });
  });
  _socket.on('train_exited', () => { _onTrain=false; floatingTexts.push({ x:player.x, y:player.y-70, text:'🚂 Tren\'den İnildi', alpha:1, life:50, color:'#ffaa44' }); });
}, 450);

// Start — socket.io sadece online modda yüklenir (async, sayfa yüklenmesini bloklamaz)
updateUI();
if (_GAME_MODE === 'online') {
  const _sioScript = document.createElement('script');
  _sioScript.src = 'socket.io.js';
  _sioScript.async = true;
  _sioScript.onload = () => initMultiplayer();
  _sioScript.onerror = () => {
    // Keep the game playable when a VDS/proxy blocks the socket asset.
    initMultiplayerOfflineFallback();
    const badge = document.getElementById('ping-display');
    if (badge) { badge.textContent = '🌐 Sunucuya bağlanılamadı'; badge.style.color = '#ff8888'; badge.style.display = ''; }
  };
  document.head.appendChild(_sioScript);
} else {
  initMultiplayer(); // offline modda sadece rozeti gösterir
}
updateWeaponUI(); // tier barlarını başlangıçta sıfırdan ayarla
resize();
_respawnGrace = 60; // skip heavy first-frame rendering on initial join
// Pre-build background cache before first game frame to prevent first-frame stutter
if (typeof requestIdleCallback === 'function') {
  requestIdleCallback(function(){ if (!_bgReady) _buildBgCache(); }, { timeout: 400 });
} else {
  setTimeout(function(){ if (!_bgReady) _buildBgCache(); }, 0);
}
requestAnimationFrame(update);
// Show FPS counter immediately when game loop starts (no need to wait for socket connect)
if (_fpsEl) { _fpsEl.style.display = ''; _fpsEl.textContent = '⚡ -- FPS'; }
// Dismiss loading screen when game is ready
function _safeDismissLoading() {
  var ls = document.getElementById('loading-screen');
  var lf = document.getElementById('loading-bar-fill');
  if (lf) lf.style.width = '100%';
  if (ls) {
    ls.classList.add('fade-out', 'gone');
    ls.style.setProperty('display', 'none', 'important');
    ls.style.setProperty('visibility', 'hidden', 'important');
    ls.style.setProperty('pointer-events', 'none', 'important');
    ls.style.setProperty('opacity', '0', 'important');
  }
}
window._loadingDone = _safeDismissLoading;
setTimeout(_safeDismissLoading, 500);
setTimeout(_safeDismissLoading, 1200); // Safety fallback

// ── iOS Safari tam ekran: kapsamlı scroll/overflow engeli ────────
(function(){
  var W = window.innerWidth, H = window.innerHeight;

  function _isScrollable(el) {
    while (el && el !== document.body) {
      var cls = el.className || '';
      if (typeof cls === 'string' && (cls.indexOf('inventory') >= 0 || cls.indexOf('inv-slot') >= 0 || el.id === 'snap-settings-panel' || el.id === 'ach-panel' || el.id === 'bp-panel')) return true;
      el = el.parentElement;
    }
    return false;
  }
  var opts = { passive:false, capture:true };
  document.addEventListener('touchmove', function(e){
    if (_isScrollable(e.target)) return;
    e.preventDefault();
  }, opts);
  document.addEventListener('touchstart', function(e){ if(e.touches.length>1) e.preventDefault(); }, opts);
  window.addEventListener('scroll', function(){ window.scrollTo(0,0); }, opts);

  if(window.scrollX||window.scrollY) window.scrollTo(0,0);
  window.scrollTo(0,0);

  function fixCanvas(){ window.scrollTo(0,0); }
  window.addEventListener('resize', fixCanvas);
  if(window.visualViewport){
    window.visualViewport.addEventListener('resize', fixCanvas);
    window.visualViewport.addEventListener('scroll', function(){ window.scrollTo(0,0); });
  }
  window.addEventListener('orientationchange', function(){
    setTimeout(fixCanvas,100); setTimeout(fixCanvas,400); setTimeout(fixCanvas,900);
  });
  fixCanvas();
})();

// =====================================================================
// VIRAL ENGAGEMENT FEATURES — ForestBrawl.io
// Loading Screen · Tutorial · Daily Quests · Achievements · Spectator
// Friend Invite · Enhanced Death Screen · Events
// =====================================================================
(function(){
'use strict';

// ── LOADING SCREEN ────────────────────────────────────────────────────
// Elements are defined AFTER this script block, so look them up lazily
var _lbIv = null;
var _TIPS = [
  '🌲 Ağaçları vurarak odun topla ve bina inşa et!',
  '⚔️ Kill serisi yaparak bonus hasar kazan!',
  '🏹 Fok silahı en hızlı saldırır, kılıç en güçlüdür.',
  '🛡️ Duvar inşa ederek düşman oklarından korun!',
  '💰 Sandıkları aç — büyük altın ödülleri var!',
  '🔥 Killstreak × 2 ile çok daha fazla hasar verirsin.',
  '🗺️ Haritanın ortasına yavaş yavaş ölüm bölgesi gelir!',
  '👁️ Minimapi takip et — kirmizi noktalar dusmandır!',
];
function _initLoadingScreen() {
  var _lsEl  = document.getElementById('loading-screen');
  var _lbFil = document.getElementById('loading-bar-fill');
  var _ltEl  = document.getElementById('loading-tip');
  if (_ltEl) _ltEl.textContent = _TIPS[Math.floor(Math.random() * _TIPS.length)];
  if (_lbFil) {
    var _lbProg = 0;
    _lbIv = setInterval(function(){
      _lbProg = Math.min(_lbProg + Math.random()*18 + 4, 88);
      _lbFil.style.width = _lbProg + '%';
      if (_lbProg >= 88) clearInterval(_lbIv);
    }, 220);
  }
  window._loadingDone = function(){
    if (_lbIv) clearInterval(_lbIv);
    _safeDismissLoading();
  };
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', _initLoadingScreen);
} else {
  _initLoadingScreen();
}

// ── TUTORIAL ──────────────────────────────────────────────────────────
var _tutSteps = [
  { icon:'🗺️', title:'Harekete Geç!', desc:'<b>WASD</b> veya ok tuşlarıyla hareket et. <b>Mouse</b> ile nişan al, <b>Sol Tık</b> veya <b>Space</b> ile saldır.' },
  { icon:'🪓', title:'Kaynak Topla!', desc:'Ağaç, taş ve altın madenine yaklaş ve vur. Topladığın kaynakla <b>bina inşa et</b> — bir duvar bile seni kurtarabilir!' },
  { icon:'⚔️', title:'Hayatta Kal!', desc:'Düşmanları öldürerek <b>XP ve altın</b> kazan. Kill serisi yap, yeni silah seviyelerine ulaş. <b>Sen en güçlü ol!</b>' },
];
var _tutStep = 0;

function _tutShow(){
  var _tutOv = document.getElementById('tutorial-overlay');
  if (!_tutOv) return;
  _tutStep = 0;
  _tutRender();
  _tutOv.classList.add('show');
}
function _tutRender(){
  var s = _tutSteps[_tutStep];
  var _tutNum  = document.getElementById('tutorial-step-num');
  var _tutIcon = document.getElementById('tutorial-step-icon');
  var _tutTtl  = document.getElementById('tutorial-step-title');
  var _tutDesc = document.getElementById('tutorial-step-desc');
  var _tutDots = document.getElementById('tutorial-dots');
  var _tutNext = document.getElementById('tut-next');
  if (_tutNum)  _tutNum.textContent  = 'ADIM ' + (_tutStep+1) + '/' + _tutSteps.length;
  if (_tutIcon) _tutIcon.textContent = s.icon;
  if (_tutTtl)  _tutTtl.textContent  = s.title;
  if (_tutDesc) _tutDesc.innerHTML   = s.desc;
  if (_tutDots) {
    var dots = _tutDots.querySelectorAll('.tut-dot');
    dots.forEach(function(d,i){ d.classList.toggle('active', i===_tutStep); });
  }
  if (_tutNext) _tutNext.textContent = _tutStep === _tutSteps.length-1 ? '✅ Başla!' : 'Sonraki →';
}
window._tutNext = function(){
  if (_tutStep < _tutSteps.length-1) { _tutStep++; _tutRender(); }
  else { window._tutClose(); }
};
window._tutClose = function(){
  localStorage.setItem('fb_tutorial_done', '1');
  var _tutOv = document.getElementById('tutorial-overlay');
  if (_tutOv) _tutOv.classList.remove('show');
};

// Every game entry requires an explicit, non-persistent control consent.
function _initEntryConsent(){
  var _consent = document.getElementById('entry-consent');
  var _accept = document.getElementById('entry-consent-accept');
  var _reject = document.getElementById('entry-consent-reject');
  if (!_consent || !_accept || !_reject) return;
  _accept.addEventListener('click', function(){
    _entryConsentAccepted = true;
    _consent.classList.add('hidden');
    _consent.style.display = 'none';
    if (document.documentElement.requestFullscreen) document.documentElement.requestFullscreen().catch(function(){});
    if (navigator.vibrate) navigator.vibrate(20);
  });
  _reject.addEventListener('click', function(){
    _entryConsentAccepted = false;
    if (typeof _goToMenu === 'function') _goToMenu();
    else window.location.href = 'index.html';
  });
  document.addEventListener('keydown', function(e){
    if (!_controlsAllowed() && !e.target.closest('#entry-consent')) {
      e.preventDefault();
      e.stopPropagation();
    }
  }, true);
  document.addEventListener('pointerdown', function(e){
    if (!_controlsAllowed() && !e.target.closest('#entry-consent')) {
      e.preventDefault();
      e.stopPropagation();
    }
  }, true);

  if ('ontouchstart' in window || navigator.maxTouchPoints > 0) {
    window.addEventListener('touchstart', function(e){
      if (!_controlsAllowed() && !e.target.closest('#entry-consent')) {
        e.preventDefault();
      }
    }, { passive: false });
  }
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', _initEntryConsent);
else _initEntryConsent();

// ── DAILY QUESTS ──────────────────────────────────────────────────────
var _QUEST_POOL = [
  {id:'kills5',   name:'Düşman Avı',      goal:5,  unit:'kill',   key:'kills',  emoji:'⚔️',  reward:'+100🪙'},
  {id:'kills10',  name:'Savaşçı',         goal:10, unit:'kill',   key:'kills',  emoji:'💀',  reward:'+250🪙'},
  {id:'wood50',   name:'Oduncu',          goal:50, unit:'odun',   key:'wood',   emoji:'🌲',  reward:'+80🪙'},
  {id:'stone30',  name:'Taş Ustası',      goal:30, unit:'taş',    key:'stone',  emoji:'🪨',  reward:'+80🪙'},
  {id:'gold100',  name:'Hazine Avcısı',   goal:100,unit:'altın',  key:'gold',   emoji:'💰',  reward:'+150🪙'},
  {id:'survive3', name:'Hayatta Kal',     goal:3,  unit:'dakika', key:'time',   emoji:'⏱️',  reward:'+120🪙'},
  {id:'chests2',  name:'Sandık Avcısı',   goal:2,  unit:'sandık', key:'chests', emoji:'📦',  reward:'+200🪙'},
  {id:'kills20',  name:'Katil Makinesi',  goal:20, unit:'kill',   key:'kills',  emoji:'🔥',  reward:'+400🪙'},
  {id:'builds5',  name:'Mühendis',        goal:5,  unit:'bina',   key:'builds', emoji:'🏗️',  reward:'+100🪙'},
  {id:'wood100',  name:'Ormancı',         goal:100,unit:'odun',   key:'wood',   emoji:'🌳',  reward:'+200🪙'},
];

var _today    = new Date().toDateString();
var _stored   = null;
try { _stored = JSON.parse(localStorage.getItem('fb_quests_v2') || 'null'); } catch(e){}
var _quests;

if (_stored && _stored.date === _today) {
  _quests = _stored.quests;
} else {
  // Seeded pick so everyone gets same daily quests
  var _seed = 0;
  var _td   = _today;
  for (var _qi=0;_qi<_td.length;_qi++) _seed = (_seed + _td.charCodeAt(_qi)) & 0x7fffffff;
  var _rngState = _seed;
  function _seededRng(n){ _rngState = (_rngState * 1664525 + 1013904223) & 0x7fffffff; return _rngState % n; }
  var _chosen = [];
  var _usedIdx = {};
  while (false) {
    var _pi = _seededRng(_QUEST_POOL.length);
    if (!_usedIdx[_pi]) { _usedIdx[_pi]=1; _chosen.push(Object.assign({}, _QUEST_POOL[_pi], {progress:0, done:false})); }
  }
  _quests = _chosen;
  try { localStorage.setItem('fb_quests_v2', JSON.stringify({date:_today, quests:_quests})); } catch(e){}
}
window._dailyQuests = null;

// Debounced quest render — max one DOM rewrite per second (prevents layout thrash on every kill)
var _questDirty = false;
var _questRenderTimer = null;
function _scheduleQuestRender(){
  if (_questRenderTimer) return;
  _questRenderTimer = setTimeout(function(){
    _questRenderTimer = null;
    if (_questDirty) { _questDirty = false; _renderQuests(); }
  }, 1000);
}

// Debounced quest save — max one localStorage write per 6 seconds
var _questSavePending = false;
function _scheduleQuestSave(){
  if (_questSavePending) return;
  _questSavePending = true;
  setTimeout(function(){
    _questSavePending = false;
    try { localStorage.setItem('fb_quests_v2', JSON.stringify({date:_today, quests:_quests})); } catch(e){}
  }, 6000);
}

window._updateQuestProgress = _trackQuestProgress;

var _questPanel  = null;
var _questBody   = null;
var _questDoneCt = null;
var _questBadge  = null;
function _ensureQuestEls(){ if(!_questPanel){_questPanel=document.getElementById('quest-panel');_questBody=document.getElementById('quest-body');_questDoneCt=document.getElementById('quest-done-count');_questBadge=document.getElementById('quest-badge');} }

function _renderQuests(){
  _ensureQuestEls();
  if (!_questBody || !_quests) return;
  var _doneCount = 0;
  _questBody.innerHTML = '';
  for (var _qi3=0; _qi3<_quests.length; _qi3++){
    var _q3 = _quests[_qi3];
    var _pct = Math.min(100, Math.round((_q3.progress||0) / _q3.goal * 100));
    if (_q3.done) _doneCount++;
    var _div = document.createElement('div');
    _div.className = 'quest-item' + (_q3.done ? ' done' : '');
    _div.innerHTML =
      '<div class="quest-row1"><div class="quest-name">' + _q3.emoji + ' ' + _q3.name + '</div><div class="quest-reward">' + _q3.reward + '</div></div>' +
      '<div class="quest-bar-wrap"><div class="quest-bar-fill' + (_q3.done ? ' done-fill' : '') + '" style="width:' + _pct + '%"></div></div>' +
      (_q3.done
        ? '<div class="quest-done-text">✅ Tamamlandı!</div>'
        : '<div class="quest-progress-text">' + (_q3.progress||0) + ' / ' + _q3.goal + ' ' + _q3.unit + '</div>');
    _questBody.appendChild(_div);
  }
  if (_questDoneCt) _questDoneCt.textContent = _doneCount + '/3';
  if (_questBadge) _questBadge.textContent = _doneCount + '/3';
}
window._toggleQuests = function(){ _ensureQuestEls(); if (_questPanel) _questPanel.classList.toggle('open'); };
setTimeout(_renderQuests, 600);

// ── ACHIEVEMENT POPUP (in-game) ───────────────────────────────────────
var _achTimer   = null;
var _achQueue   = [];
var _achShowing = false;

function _showAchPopup(icon, name, desc){
  _achQueue.push({icon:icon, name:name, desc:desc});
  if (!_achShowing) _nextAch();
}
function _nextAch(){
  var _achPopEl = document.getElementById('ach-popup');
  if (!_achQueue.length || !_achPopEl) { _achShowing=false; return; }
  _achShowing = true;
  var _a = _achQueue.shift();
  var _achIconEl = document.getElementById('ach-icon-wrap');
  var _achNameEl = document.getElementById('ach-name');
  var _achDescEl = document.getElementById('ach-desc');
  if (_achIconEl) _achIconEl.textContent = _a.icon;
  if (_achNameEl) _achNameEl.textContent = _a.name;
  if (_achDescEl) _achDescEl.textContent = _a.desc;
  _achPopEl.classList.add('show');
  clearTimeout(_achTimer);
  _achTimer = setTimeout(function(){
    _achPopEl.classList.remove('show');
    setTimeout(_nextAch, 500);
  }, 3200);
}
window._showAchPopup = _showAchPopup;

// ── KILL STREAK ACHIEVEMENT POPUPS ────────────────────────────────────
// Patch into recordKill to show in-game popups for milestones
var _achKillMilestones = {5:'🏹',10:'⚔️',15:'💀',20:'🔥',25:'👑',30:'💫'};
var _achKillDone = {};
// We patch quest tracking post-hoc via _updateQuestProgress, achievement
// streaks are shown from the per-session streak counter in the main game loop.
// Hook into window to expose ach popup for streak milestones
window._checkStreakAch = function(streak){
  if (_achKillMilestones[streak] && !_achKillDone[streak]){
    _achKillDone[streak] = true;
    var _icon = _achKillMilestones[streak];
    var _msgs = {5:'İlk Kan Serisi',10:'Katil',15:'Yıkıcı',20:'Ölüm Meleği',25:'Efsanevi',30:'UNSTOPPABLE'};
    _showAchPopup(_icon, _msgs[streak] + '!', streak + '× Kill Serisi — Harika!');
  }
};

// ── SPECTATOR MODE ────────────────────────────────────────────────────
var _specMode = false;
var _specCamX = 0, _specCamY = 0;
var _specDragSX=0, _specDragSY=0, _specDragging=false;

window._enterSpectator = function(){
  _specMode = true;
  if (typeof player !== 'undefined') { _specCamX = player.x||0; _specCamY = player.y||0; }
  var _doEl = document.getElementById('death-overlay');
  if (_doEl) _doEl.classList.remove('show');
  var _specHud = document.getElementById('spectator-hud');
  if (_specHud) _specHud.classList.add('show');
};
window._exitSpectator = function(){
  _specMode = false;
  var _specHud = document.getElementById('spectator-hud');
  if (_specHud) _specHud.classList.remove('show');
  if (typeof respawn === 'function') respawn();
};
// Expose for game loop to check
window._isSpectatorMode = function(){ return _specMode; };
window._getSpecCam = function(){ return {x:_specCamX, y:_specCamY}; };

// Touch/mouse drag for spectator cam
document.addEventListener('mousemove', function(e){
  if (!_specMode || !_specDragging) return;
  var _scale = (typeof _camScale !== 'undefined' ? _camScale : 1) || 1;
  _specCamX -= (e.clientX - _specDragSX) / _scale;
  _specCamY -= (e.clientY - _specDragSY) / _scale;
  _specDragSX = e.clientX; _specDragSY = e.clientY;
});
document.addEventListener('mousedown', function(e){
  if (!_specMode) return;
  _specDragging = true; _specDragSX = e.clientX; _specDragSY = e.clientY;
});
document.addEventListener('mouseup', function(){ _specDragging = false; });
document.addEventListener('touchmove', function(e){
  if (!_specMode || !e.touches.length) return;
  var _t = e.touches[0];
  var _scale = (typeof _camScale !== 'undefined' ? _camScale : 1) || 1;
  _specCamX -= (_t.clientX - _specDragSX) / _scale;
  _specCamY -= (_t.clientY - _specDragSY) / _scale;
  _specDragSX = _t.clientX; _specDragSY = _t.clientY;
}, {passive:true});
document.addEventListener('touchstart', function(e){
  if (!_specMode || !e.touches.length) return;
  var _t = e.touches[0];
  _specDragging = true; _specDragSX = _t.clientX; _specDragSY = _t.clientY;
}, {passive:true});
document.addEventListener('touchend', function(){ _specDragging = false; }, {passive:true});

// ── FRIEND INVITE BUTTON ─────────────────────────────────────────────
var _myPartyCode = null;
window._getPartyCode = function(){
  if (!_myPartyCode){
    var _pname = (typeof player !== 'undefined' && player.name) ? player.name.replace(/[^a-z0-9]/gi,'').slice(0,7)||'fb' : 'fb';
    _myPartyCode = _pname.toUpperCase() + Math.random().toString(36).slice(2,5).toUpperCase();
  }
  return _myPartyCode;
};
window._inviteFriend = function(){
  var _base = window.location.origin + (typeof _BASE !== 'undefined' ? _BASE : '/');
  var _code = window._getPartyCode();
  var _url  = _base + '?partyCode=' + _code;
  var _btn  = document.getElementById('invite-hud-btn');
  function _copied(){ if (_btn){ var _old=_btn.innerHTML; _btn.innerHTML='✅ Kopyalandı!'; setTimeout(function(){_btn.innerHTML=_old;},2000); } }
  if (navigator.share) {
    navigator.share({title:'🌲 ForestBrawl.io', text:'ForestBrawl.io\'da benimle oyna! 🌲', url:_url}).catch(function(){});
  } else if (navigator.clipboard) {
    navigator.clipboard.writeText(_url).then(_copied).catch(function(){ prompt('Arkadaşına gönder:', _url); });
  } else {
    prompt('Arkadaşına gönder:', _url);
  }
  if (navigator.vibrate) navigator.vibrate(40);
};
window._shareScoreWithParty = function(){
  var _base = window.location.origin + (typeof _BASE !== 'undefined' ? _BASE : '/');
  var _code = window._getPartyCode();
  var _url  = _base + '?partyCode=' + _code;
  var _kills = (typeof player !== 'undefined' && player.kills) || 0;
  var _age   = (typeof getAge === 'function' && typeof player !== 'undefined') ? getAge(player.xp) : '?';
  var _time  = (typeof _fmtTime === 'function' && typeof globalTime !== 'undefined') ? _fmtTime(globalTime) : '';
  var _text  = '⚔️ ForestBrawl.io\'da ' + _kills + ' kill yaptım! Age ' + _age + ', ' + _time + ' hayatta kaldım!\n🌲 Benimle oyna: ' + _url;
  var _btn   = document.getElementById('death-invite-btn');
  function _copied2(){ if (_btn){ var _old2=_btn.innerHTML; _btn.innerHTML='✅ Kopyalandı!'; setTimeout(function(){_btn.innerHTML=_old2;},2200); } }
  if (navigator.share) {
    navigator.share({title:'🌲 ForestBrawl.io', text:_text.split('\n').join(' — '), url:_url}).catch(function(){});
  } else if (navigator.clipboard) {
    navigator.clipboard.writeText(_text).then(_copied2).catch(function(){ prompt('Kopyala:', _text); });
  } else {
    prompt('Kopyala:', _text);
  }
  if (navigator.vibrate) navigator.vibrate([40,20,40]);
};

// ── RANDOM EVENTS (Disabled) ──────────────────────────────────────────
var _meteorTimer   = 99999999;
var _meteorActive  = false;
var _meteors       = [];
function _getMeteorBan(){ return null; }

window._spawnMeteor = function(){};
window._updateMeteors = function(){};
window._drawMeteors = function(ctx2, camX, camY, camScale2){};

var _goldRushTimer  = 99999999;
var _goldRushActive = false;
var _goldRushEnd    = 0;
window._goldRushMult = 1;
window._updateGoldRush = function(){};

// ── STREAK ACHIEVEMENT HOOK (called from game loop after recordKill) ──
// The game's kill streak counter is `killStreak`.
// We poll it once per second to detect milestones.
setInterval(function(){
  if (typeof killStreak !== 'undefined' && window._checkStreakAch) {
    window._checkStreakAch(killStreak);
  }
}, 1000);

})();
